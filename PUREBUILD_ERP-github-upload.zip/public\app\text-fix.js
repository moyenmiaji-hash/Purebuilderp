/* Display-only text fixes: Sales filter boxes show full text; Site Progress tables never break words mid-letter. */
(function(){
  var css=`body.sales-mode #view .sov-filters .sales-filterbar select,body.sales-mode #view .sov-filters .sales-filterbar input{height:36px!important;min-height:36px!important;padding:0 28px 0 10px!important;line-height:34px!important;font-size:13px!important;text-overflow:ellipsis;box-sizing:border-box!important}
body.sales-mode #view .sov-filters .sales-filterbar input[type=date]{padding-right:8px!important}
body.progress-mode #view .v2-p table{width:100%}
body.progress-mode #view .v2-p table td,body.progress-mode #view .v2-p table th{word-break:normal!important;overflow-wrap:normal!important;hyphens:none!important}
body.progress-mode #view .v2-p table td:nth-child(1),body.progress-mode #view .v2-p table td:nth-child(n+4):nth-child(-n+10),body.progress-mode #view .v2-p table td:nth-child(n+12),body.progress-mode #view .v2-p table th{white-space:nowrap!important}
body.progress-mode #view .v2-p table td:nth-child(2){min-width:140px}
body.progress-mode #view .v2-p:has(table){overflow-x:auto}`;
  var s=document.createElement('style');s.id='pbTextFix';s.textContent=css;document.head.appendChild(s);
})();

(function(){var st=document.createElement('style');st.textContent='#boqProjectSelect{height:36px!important;min-height:36px!important;line-height:1.3!important;padding:6px 30px 6px 10px!important;font-size:13px!important;min-width:220px!important;box-sizing:border-box!important;color:#0f2a5c}body.dark #boqProjectSelect,[data-theme=dark] #boqProjectSelect{color:#e6eefc}';document.head.appendChild(st)})();
