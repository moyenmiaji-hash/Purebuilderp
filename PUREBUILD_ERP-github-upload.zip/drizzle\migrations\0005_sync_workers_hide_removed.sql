CREATE OR REPLACE FUNCTION public.sync_attendance_workers(p_workers jsonb)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  INSERT INTO public.erp_attendance_workers(legacy_id,project_legacy_id,name,worker_code,status,role,employment_category,updated_at)
  SELECT w->>'legacy_id', w->>'project_legacy_id', w->>'name', w->>'worker_code', coalesce(w->>'status','Active'), w->>'role', w->>'employment_category', now()
  FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','') <> ''
  ON CONFLICT (legacy_id) DO UPDATE SET project_legacy_id=EXCLUDED.project_legacy_id, name=EXCLUDED.name,
    worker_code=EXCLUDED.worker_code, status=EXCLUDED.status, role=EXCLUDED.role, employment_category=EXCLUDED.employment_category, updated_at=now();
  GET DIAGNOSTICS n = ROW_COUNT;
  -- Workers no longer in the office list are marked Inactive (row kept, only hidden from staff).
  UPDATE public.erp_attendance_workers SET status='Inactive', updated_at=now()
  WHERE status <> 'Inactive'
    AND legacy_id NOT IN (SELECT w->>'legacy_id' FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','')<>'');
  RETURN n;
END $$;