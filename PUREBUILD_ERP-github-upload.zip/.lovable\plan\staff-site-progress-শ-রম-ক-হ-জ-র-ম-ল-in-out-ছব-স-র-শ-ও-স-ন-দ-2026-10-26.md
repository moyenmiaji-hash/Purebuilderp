# Staff Site Progress: শ্রমিক হাজিরা, মাল In/Out, ছবি, সারাংশ ও সুন্দর ডিজাইন

পুরনো তথ্য মোছা বা বদলানো হবে না। নতুন মেনু যোগ হবে না। শুধু Approve করার পরেই মূল অ্যাপে তথ্য ঢুকবে।

## ১. শ্রমিকের তালিকা স্টাফ অ্যাপে

- মূল অ্যাপের Labour & HR-এ যে শ্রমিক যে প্রজেক্ট/Site-এ যোগ করা আছে, তাদের নাম, কোড, কাজের ধরন স্টাফ অ্যাপে ওই প্রজেক্টে দেখাবে।
- Admin সেভ করলেই কিছুক্ষণ পরে নিজে থেকে Cloud-এ চলে যাবে (আলাদা বোতাম লাগবে না)।

## ২. হাজিরা দেওয়া (Step 3)

- প্রতিটি শ্রমিকের পাশে: Present / Absent / Leave / Half Day, কাজের ঘণ্টা, Overtime ঘণ্টা।
- উপরে "সবার জন্য একসাথে" অংশ: এক চাপে সবাইকে Present / Absent / Leave, সবার ঘণ্টা ও Overtime একই বসানো। পরে চাইলে আলাদা করে বদলানো যাবে।
- মোট উপস্থিত/অনুপস্থিত/ছুটি/Overtime উপরে ছোট বাক্সে দেখাবে।
- অফিস Approve করলে এই হাজিরা মূল অ্যাপের Labour & HR-এ ওই প্রজেক্ট ও তারিখে নিজে থেকে বসবে। একই দিনের হাজিরা দুইবার ঢুকবে না।

## ৩. মাল In / Out

- "Material In" (সাইটে এলো) আর "Material Out / Used" (ব্যবহার হলো) — মালের নাম মূল অ্যাপের Warehouse/Stock তালিকা থেকে বাছাই, পরিমাণ, একক।
- Approve করলে Warehouse/Stock-এ ওই প্রজেক্ট/Site-এ In/Out এন্ট্রি নিজে থেকে যোগ হবে। হাতে যত আছে তার বেশি Out হলে সতর্কবার্তা। Ar Summary typer thakbe stock e prevoice ki chilo ba jmne valo hoy tmi bujhe kore dao

## ৪. ছবি

- ক্যামেরা বা গ্যালারি থেকে ছবি, ছোট প্রিভিউ, বাদ দেওয়ার বোতাম।

## ৫. সারাংশ ও "Yes, Submit"

- Step 5-এ সুন্দর সারাংশ কার্ড: Site, তারিখ, Location, কাজ, হাজিরার হিসাব, মাল In/Out, ছবির ছোট ছবি।
- Submit চাপলে নিশ্চিত করার বাক্স: "সব ঠিক আছে? — Yes, Submit / Back"। Yes চাপলে তবেই পাঠানো হবে।

## ৬. স্টাফ অ্যাপের ডিজাইন

- রঙিন আইকন, প্রতিটি ধাপের আলাদা রঙ, বড় পরিষ্কার বোতাম, Home-এ সুন্দর কার্ড। বর্তমান কাজ ও বোতামগুলো একই থাকবে।

## ৭. Access পাতা এক স্ক্রিনে

- Access পাতা ডেস্কটপে স্ক্রল ছাড়া এক স্ক্রিনে দেখাবে।

## ৮. যাচাই

- আলাদা টেস্ট ব্রাউজারে মোবাইল সাইজে পুরো ধাপ দেখা হবে। আসল Cloud-এ পরীক্ষার রিপোর্ট পাঠালে পরে মুছে ফেলা হবে, আপনার তথ্যে হাত দেওয়া হবে না।

## Technical details

- Workers: extend existing auto-sync in team-erp.js to call `sync_attendance_workers` with employees per project; staff reads via `get_assigned_attendance_workers`.
- Attendance entries + material in/out lines stored in `report_payload` (new keys `attendance[]`, `material_moves[]`), so no table reshaping.
- On Approve in Site Progress (main app), merge into `db` attendance and stock transactions with optional `cloudReportId` side field to prevent duplicates; then `save()`.
- foreman-wizard.js: confirmation overlay before triggering existing submit; styling in staff-mobile.html only.
- Access: fix/extend existing `apFit`. Bump `PB_SAFETY_VERSION`.