<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## PURE_BUILD app (public/app)
- Subdirectories have their own AGENTS.md; read public/app/AGENTS.md before changing files there.
- Never reshape or delete saved user records; new optional data goes in side fields/maps so old data loads unchanged.
- The office ERP page lives at public/app/erp.html; public/app/index.html and the /app route only forward to it, because the preview server cannot serve a directory index.html.
