/* PURE_BUILD Warehouse → Site Receiving approval (foreman receiving reports, Cloud kind 'receiving').
   Approve = review_site_receiving RPC (records approved lines + audit event), then posts db.stock rows ONCE tagged
   cloudStockSubId using PBWhCalc.receivingPost: supplier → accepted In; central / site purchase → only damage & shortage Out
   (those were already added by the issue voucher / purchase). Damaged never becomes usable stock. */
(function () {
  if (typeof window.stock !== "function" || !window.WHX) return;
  const X = () => window.WHX, W = () => window.PBWhCalc, C = () => window.PB_CLOUD_CLIENT;
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const canApprove = () => !window.PB_CLOUD_ROLE || ["admin", "manager"].includes(window.PB_CLOUD_ROLE);
  const who = () => window.PB_CLOUD_NAME || "Office";
  const SRC = { central: "🏬 Central Warehouse", supplier: "🚚 Direct supplier", site_purchase: "🛒 Site purchase" };
  const rno = (s) => "RCV-" + String(s.id).slice(0, 8).toUpperCase();
  const list = () => (X().cloud().rcv || []);
  const posted = (sid) => (db.stock || []).some((x) => x.cloudStockSubId === sid);
  const sum = (s, k) => (s.lines || []).reduce((a, l) => a + n(l[k]), 0);
  const F = (window.RCV_F = window.RCV_F || { st: "pending" });

  function post(s) {
    if (posted(s.id)) return false;
    const pid = X().cproj(s.project_id).local_project_id; if (!pid) return false;
    const ap = s.approved_lines || s.lines || [];
    (s.lines || []).forEach((l, i) => {
      const acc = n((ap[i] || l).accepted), already = s.source === "supplier" && s.ref_id && window.PB_PURCHASE_AUTO && window.PB_PURCHASE_AUTO.isAuto(s.ref_id), r = W().receivingPost(already ? "central" : s.source, l.expected, acc, l.damaged), m = X().matOf(l);
      const b = { date: s.work_date, projectId: pid, ...(m ? { materialId: m.id, item: m.name, unit: m.unit } : { item: String(l.item).trim(), unit: String(l.unit || "").trim() }), cloudStockSubId: s.id, whLine: i, ref: rno(s), foreman: s.submitted_name || "Foreman", enteredBy: s.submitted_name || "Foreman", approvedBy: who(), postedAt: new Date().toISOString(), note: "Site receiving " + rno(s) + (s.invoice_no ? " · " + s.invoice_no : "") };
      if (r.inQty > 0) db.stock.push({ ...b, id: id(), direction: "In", qty: r.inQty, source: s.source === "supplier" ? "Supplier Delivery" : "Receiving Excess", supplier: s.supplier || "", ...(s.source === "supplier" && s.ref_id ? { sourcePurchaseId: s.ref_id } : {}) });
      if (r.damageOut > 0) db.stock.push({ ...b, id: id(), direction: "Out", qty: r.damageOut, source: "Receiving Damage", movement: "Wastage" });
      if (r.shortOut > 0) db.stock.push({ ...b, id: id(), direction: "Out", qty: r.shortOut, source: "Receiving Shortage", movement: "Shortage" });
    });
    return true;
  }
  async function photo(path) { const { data, error } = await C().storage.from("site-progress-photos").createSignedUrl(path, 600); if (error) { toast(error.message); return; } window.open(data.signedUrl, "_blank"); }
  async function events(sid) {
    const box = document.getElementById("rcvEv"); if (!box) return;
    const { data } = await C().from("site_stock_events").select("event_type,note,created_at,actor").eq("submission_id", sid).order("created_at");
    box.innerHTML = (data || []).map((e) => `<div>• <b>${esc(e.event_type)}</b> — ${esc(String(e.created_at).replace("T", " ").slice(0, 16))}${e.note ? " — " + esc(e.note) : ""}</div>`).join("") || "—";
  }
  function view(sid) {
    const s = list().find((x) => x.id === sid); if (!s) return;
    const pend = s.review_status === "pending" && canApprove(), ap = s.approved_lines || [];
    openModal(rno(s) + " · " + (SRC[s.source] || "Receiving"), `<p class="muted">${esc(X().cproj(s.project_id).name || "Site")} · ${esc(s.work_date)} · by ${esc(s.submitted_name || "Foreman")} · ${esc(s.ref_label || "")}<br>Supplier: ${esc(s.supplier || "—")} · Invoice/challan: ${esc(s.invoice_no || "—")}${s.source === "supplier" && !s.ref_id ? ' · <span class="pill amber">No purchase order — check before approving</span>' : ""}</p>
      <div class="tablewrap"><table class="table"><thead><tr><th>Material</th><th class="n">${s.source === "central" ? "Dispatched" : "Ordered"}</th><th class="n">Received</th><th class="n">Accepted (foreman)</th><th class="n">Damaged</th><th class="n">Shortage</th><th class="n">Approved accepted</th></tr></thead><tbody>${(s.lines || []).map((l, i) => `<tr><td><b>${esc(l.item)}</b> <small class="muted">${esc(l.unit)}</small></td><td class="n">${l.expected == null ? "—" : fmt(l.expected)}</td><td class="n">${fmt(l.received)}</td><td class="n">${fmt(l.accepted)}</td><td class="n">${fmt(l.damaged)}</td><td class="n">${fmt(l.shortage)}</td><td class="n">${pend ? `<input type="number" class="rcvA" min="0" max="${n(l.received)}" step="any" value="${n(l.accepted)}" style="width:80px">` : ap[i] ? fmt(ap[i].accepted) : "—"}</td></tr>`).join("")}</tbody></table></div>
      <p><b>Photos:</b> ${(s.photos || []).map((p, i) => `<button type="button" class="btn small" onclick="RCV.photo('${esc(p.path)}')">${esc(p.category || "photo")} ${i + 1}</button>`).join(" ") || "none"}</p>
      ${s.remarks ? `<p><b>Foreman remarks:</b> ${esc(s.remarks)}</p>` : ""}${s.review_note ? `<p><b>Office note:</b> ${esc(s.review_note)}</p>` : ""}
      ${pend ? `<div class="field"><label>Approval remarks (required to reject)</label><textarea id="rcvNote" rows="2"></textarea></div><div style="display:flex;gap:8px;justify-content:flex-end"><button class="btn danger" onclick="RCV.decide('${s.id}','rejected')">Reject</button><button class="btn primary" onclick="RCV.decide('${s.id}','approved')">Approve &amp; update site stock</button></div>` : ""}
      ${s.review_status === "approved" && !posted(s.id) && canApprove() ? `<button class="btn primary" onclick="RCV.post('${s.id}')">Post to site stock</button>` : ""}
      <h4 style="margin:12px 0 4px">History</h4><div id="rcvEv" class="muted">Loading…</div>`, () => true);
    document.getElementById("modalSave").style.display = "none"; events(sid);
  }
  async function decide(sid, dec) {
    const s = list().find((x) => x.id === sid); if (!s) return;
    const note = (document.getElementById("rcvNote") || {}).value || "";
    const pid = X().cproj(s.project_id).local_project_id;
    if (dec === "approved" && (!pid || !(db.projects || []).some((p) => p.id === pid))) { toast("This site is not linked to a project in the office ERP yet."); return; }
    const lines = [...document.querySelectorAll(".rcvA")].map((x, i) => ({ item: s.lines[i].item, accepted: n(x.value) }));
    if (dec === "approved" && lines.some((l, i) => l.accepted < 0 || l.accepted > n(s.lines[i].received) + 1e-9)) { toast("Approved quantity must be between 0 and received"); return; }
    if (dec === "rejected" && !note.trim()) { toast("Please write the reason for rejection"); return; }
    if (!confirm(dec === "approved" ? "Approve this receiving? Site stock will change now." : "Reject this receiving?")) return;
    const { error } = await C().rpc("review_site_receiving", { p_id: sid, p_decision: dec, p_note: note, p_lines: dec === "approved" ? lines : null });
    if (error) { toast(error.message); return; }
    Object.assign(s, { review_status: dec, review_note: note, approved_lines: dec === "approved" ? lines : null });
    if (dec === "approved" && post(s)) save();
    if (typeof closeModal === "function") closeModal(); render(); toast(dec === "approved" ? rno(s) + " approved — site stock updated" : "Rejected");
  }
  function postNow(sid) { const s = list().find((x) => x.id === sid); if (s && s.review_status === "approved" && post(s)) { save(); toast("Posted to site stock"); } if (typeof closeModal === "function") closeModal(); render(); }

  function tab() {
    const all = list(), cs = X().cloud();
    const groups = { pending: all.filter((s) => s.review_status === "pending"), approved: all.filter((s) => s.review_status === "approved"), rejected: all.filter((s) => s.review_status === "rejected"),
      shortage: all.filter((s) => sum(s, "shortage") > 0), damaged: all.filter((s) => sum(s, "damaged") > 0) };
    const lab = { pending: "⏳ Pending", approved: "✅ Approved", rejected: "❌ Rejected", shortage: "📉 Shortage cases", damaged: "⚠️ Damaged" };
    const rows = groups[F.st] || [];
    return `<section class="panel"><div class="toolbar"><div><h3 style="margin:0">📥 Site Receiving Approval</h3><small class="muted">Foreman receiving reports. Only approved accepted quantity enters site stock.</small></div><div><button class="btn small" onclick="RCV.csv()">⬇ Excel (CSV)</button> <button class="btn small" onclick="RCV.print()">🖨 Print</button> <button class="btn small" onclick="WHX.reload()">↻ Refresh</button></div></div>
      <div class="wh-seg" style="flex-wrap:wrap;margin:6px 0 10px">${Object.keys(lab).map((k) => `<button type="button" class="${F.st === k ? "on" : ""}" onclick="RCV_F.st='${k}';render()">${lab[k]}<em>${groups[k].length}</em></button>`).join("")}</div>
      ${cs.err ? `<div class="empty">Could not load: ${esc(cs.err)}</div>` : ""}
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Receiving ID</th><th>Source</th><th>Site</th><th>Foreman</th><th>Materials (received / accepted / damaged / short)</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map((s) => `<tr><td>${esc(s.work_date)}</td><td><b>${rno(s)}</b><br><small class="muted">${esc(s.invoice_no || "")}</small></td><td>${esc(SRC[s.source] || "")}${s.source === "supplier" && !s.ref_id ? '<br><span class="pill amber">Unlinked</span>' : ""}</td><td>${esc(X().cproj(s.project_id).name || "Site")}</td><td>${esc(s.submitted_name || "—")}</td><td>${(s.lines || []).map((l) => `${esc(l.item)}: ${fmt(l.received)} / ${fmt(l.accepted)} / ${fmt(l.damaged)} / ${fmt(l.shortage)} ${esc(l.unit)}`).join("<br>")}</td><td><span class="pill ${s.review_status === "approved" ? "green" : s.review_status === "rejected" ? "red" : "amber"}">${esc(s.review_status)}</span>${s.review_status === "approved" && !posted(s.id) ? '<br><span class="pill red">Not posted</span>' : ""}</td><td><button class="btn small ${s.review_status === "pending" ? "primary" : ""}" onclick="RCV.view('${s.id}')">${s.review_status === "pending" && canApprove() ? "Review" : "View"}</button></td></tr>`).join("") || `<tr><td colspan="8" class="empty">${cs.loaded ? "Nothing here." : "Loading…"}</td></tr>`}</tbody></table></div></section>`;
  }
  function reportRows() {
    const all = list(), st = F.st, f = { pending: (s) => s.review_status === "pending", approved: (s) => s.review_status === "approved", rejected: (s) => s.review_status === "rejected", shortage: (s) => sum(s, "shortage") > 0, damaged: (s) => sum(s, "damaged") > 0 }[st] || (() => true);
    const out = []; all.filter(f).forEach((s) => (s.lines || []).forEach((l, i) => out.push([s.work_date, rno(s), (SRC[s.source] || "").replace(/^\S+ /, ""), X().cproj(s.project_id).name || "Site", s.submitted_name || "", l.item, l.unit, l.expected == null ? "" : n(l.expected), n(l.received), n(l.accepted), (s.approved_lines || [])[i] ? n(s.approved_lines[i].accepted) : "", n(l.damaged), n(l.shortage), s.review_status])));
    return { head: ["Date", "Receiving ID", "Source", "Site", "Foreman", "Material", "Unit", "Expected", "Received", "Accepted", "Approved", "Damaged", "Shortage", "Status"], out };
  }
  function csv() { const { head, out } = reportRows(); const q = (v) => '"' + String(v).replace(/"/g, '""') + '"'; const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([[head, ...out].map((r) => r.map(q).join(",")).join("\n")], { type: "text/csv" })); a.download = "site-receiving-" + F.st + ".csv"; a.click(); }
  function print() { const { head, out } = reportRows(), co = (db.settings || {}).companyName || "PURE_BUILD", w = window.open("", "_blank"); if (!w) return; w.document.write(`<!doctype html><title>Site Receiving</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Arial;font-size:11px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:4px}th{background:#f1f0f8}</style><h2>${esc(co)} — Site Receiving Report (${esc(F.st)})</h2><table><tr>${head.map((h) => `<th>${h}</th>`).join("")}</tr>${out.map((r) => `<tr>${r.map((v) => `<td>${esc(v)}</td>`).join("")}</tr>`).join("") || '<tr><td colspan="14">No rows</td></tr>'}</table>`); w.document.close(); w.print(); }
  window.RCV = { view, decide, photo, post: postNow, csv, print };

  const orig = window.stock;
  window.stock = function () {
    orig.apply(this, arguments);
    const view = document.getElementById("view"), nav = view && view.querySelector(".stock-tabs"); if (!nav) return;
    const p = list().filter((s) => s.review_status === "pending").length, T = window.stockTab;
    const b = `<button type="button" class="wh-tab ${T === "wreceive" ? "active" : ""}" onclick="stockGo('wreceive')"><span>📥 Site Receiving</span>${p ? ` <em>${p}</em>` : ""}</button>`;
    const last = [...nav.querySelectorAll(".wh-tab")].pop(); if (last) last.insertAdjacentHTML("afterend", b); else nav.insertAdjacentHTML("beforeend", b);
    if (T !== "wreceive") return;
    nav.querySelectorAll(":scope > button.active").forEach((x) => { if (!x.matches("[onclick*=wreceive]")) x.classList.remove("active"); });
    const tools = nav.querySelector(".stock-tab-tools"); if (tools) tools.style.display = "none";
    const body = view.querySelector(".stock-tab-body"); if (!body) return;
    body.className = "stock-tab-body stock-tab-wreceive";
    try { body.innerHTML = tab(); } catch (e) { console.error("site-receiving", e); body.innerHTML = '<div class="panel"><div class="empty">This section could not be shown. Your data is safe.</div></div>'; }
    const cs = X().cloud(); if (!cs.loaded && !cs.loading) X().load();
  };
})();
