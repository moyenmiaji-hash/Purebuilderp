/* AP extras: multi-bill payment + payment voucher, retention register, AP settings (VAT / TDS %).
   Payments are normal 'Supplier Payment' transactions (same shape as the single payment) so Ledger, Cash/Bank and balances stay consistent.
   Retention + settings live only in side data db.apRetention / db.apSettings. Old records are never changed. */
(function () {
  if (typeof payables !== "function") return;
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const N = (v) => Number(v) || 0;
  const M = (n) => new Intl.NumberFormat("en-AE", { style: "currency", currency: "AED", minimumFractionDigits: 2 }).format(N(n));
  const today = () => new Date().toISOString().slice(0, 10);
  const isAdmin = () => !window.PB_CLOUD_ROLE || window.PB_CLOUD_ROLE === "admin";
  const ret = () => (db.apRetention = db.apRetention && typeof db.apRetention === "object" ? db.apRetention : {});
  const cfg = () => (db.apSettings = db.apSettings && typeof db.apSettings === "object" ? db.apSettings : { vatPct: 5, tdsPct: 0, retentionPct: 0 });
  const same = (a, b) => String(a || "").trim().toLowerCase() === String(b || "").trim().toLowerCase();

  /* retention held on a bill (not yet released) */
  window.apRetentionHeld = function (p) { const r = ret()[p?.id]; if (!r || r.released) return 0; return Math.min(N(r.amount), apOutstandingAmount(p)); };
  window.apPayableNow = function (p) { return Math.max(0, apOutstandingAmount(p) - apRetentionHeld(p)); };

  /* ---------- AP Settings ---------- */
  window.apOpenSettings = function () {
    if (!isAdmin()) { toast("Only Admin can change AP settings"); return; }
    const c = cfg();
    openModal("Accounts Payable Settings", `<div class="formgrid"><div class="field"><label>VAT %</label><input id="aps_vat" type="number" step="0.01" min="0" value="${E(c.vatPct)}"></div><div class="field"><label>Tax deducted at source (TDS) %</label><input id="aps_tds" type="number" step="0.01" min="0" value="${E(c.tdsPct)}"></div><div class="field"><label>Default retention %</label><input id="aps_ret" type="number" step="0.01" min="0" value="${E(c.retentionPct)}"></div></div><p style="font-size:11px;color:#64748b">Rates are used for checks and suggestions only. Saved bills are never recalculated.</p><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="apSaveSettings()">Save</button></div>`);
  };
  window.apSaveSettings = function () {
    const g = (k) => Math.max(0, N(document.getElementById(k)?.value));
    Object.assign(cfg(), { vatPct: g("aps_vat"), tdsPct: g("aps_tds"), retentionPct: g("aps_ret"), updatedAt: new Date().toISOString() });
    save(); closeModal(); render(); toast("AP settings saved");
  };

  /* ---------- Retention ---------- */
  window.apOpenRetention = function () {
    const list = (db.payables || []).filter((p) => apIsPosted(p) && (ret()[p.id] || apOutstandingAmount(p) > 0));
    const rows = list.map((p) => { const r = ret()[p.id] || {}; const held = apRetentionHeld(p);
      return `<tr><td>${E(p.invoiceNo || "—")}</td><td>${E(p.supplier)}</td><td style="text-align:right">${M(p.amount)}</td><td style="text-align:right">${r.pct != null ? E(r.pct) + "%" : "—"}</td><td style="text-align:right">${r.amount ? M(r.amount) : "—"}</td><td style="text-align:right">${M(held)}</td><td>${E(r.releaseDate || "—")}</td><td>${r.released ? `<span style="color:#047857">Released ${E(r.releasedAt || "")}</span>` : r.amount ? "Held" : "—"}</td><td style="white-space:nowrap"><button class="btn small" onclick="apEditRetention('${E(p.id)}')">${r.amount ? "Edit" : "Set"}</button>${r.amount && !r.released ? ` <button class="btn small" onclick="apReleaseRetention('${E(p.id)}')">Release</button>` : ""}</td></tr>`; });
    const totalHeld = list.reduce((s, p) => s + apRetentionHeld(p), 0);
    openModal("Retention Money", `<p style="font-size:12px;margin:0 0 8px">Retention held is kept back from payment until it is released. Total held: <b>${M(totalHeld)}</b></p><div style="max-height:60vh;overflow:auto"><table class="appx-table"><thead><tr><th>Bill</th><th>Vendor</th><th class="n">Gross</th><th class="n">%</th><th class="n">Retention</th><th class="n">Held now</th><th>Release date</th><th>Status</th><th></th></tr></thead><tbody>${rows.join("") || '<tr><td colspan="9" style="text-align:center;padding:16px">No approved bills</td></tr>'}</tbody></table></div>`);
  };
  window.apEditRetention = function (pid) {
    const p = db.payables.find((x) => x.id === pid); if (!p) return; const r = ret()[pid] || {}; const pct = r.pct != null ? r.pct : cfg().retentionPct;
    openModal(`Retention — ${E(p.invoiceNo || "")}`, `<p style="font-size:12px">${E(p.supplier)} · Gross ${M(p.amount)} · Outstanding ${M(apOutstandingAmount(p))}</p><div class="formgrid"><div class="field"><label>Retention %</label><input id="rt_pct" type="number" step="0.01" min="0" max="100" value="${E(pct)}" oninput="document.getElementById('rt_amt').value=(${N(p.amount)}*Number(this.value||0)/100).toFixed(2)"></div><div class="field"><label>Retention amount</label><input id="rt_amt" type="number" step="0.01" min="0" value="${(r.amount != null ? N(r.amount) : (N(p.amount) * N(pct)) / 100).toFixed(2)}"></div><div class="field"><label>Release date</label><input id="rt_date" type="date" value="${E(r.releaseDate || "")}"></div><div class="field full"><label>Contract terms / note</label><input id="rt_note" value="${E(r.note || "")}"></div></div><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="apOpenRetention()">Back</button><button class="btn primary" onclick="apSaveRetention('${E(pid)}')">Save</button></div>`);
  };
  window.apSaveRetention = function (pid) {
    const p = db.payables.find((x) => x.id === pid); const amt = N(document.getElementById("rt_amt").value);
    if (amt < 0 || amt > N(p.amount)) { toast("Retention must be between 0 and the bill amount"); return; }
    ret()[pid] = { ...(ret()[pid] || {}), pct: N(document.getElementById("rt_pct").value), amount: amt, releaseDate: document.getElementById("rt_date").value, note: document.getElementById("rt_note").value.trim(), released: false, setAt: new Date().toISOString() };
    try { apLog(p, "Retention set", String(amt)); } catch (e) {}
    save(); apOpenRetention(); toast("Retention saved");
  };
  window.apReleaseRetention = function (pid) {
    if (!isAdmin()) { toast("Only Admin can release retention"); return; }
    const p = db.payables.find((x) => x.id === pid); const r = ret()[pid]; if (!p || !r || r.released) return;
    if (!confirm(`Release retention ${M(r.amount)} for ${p.invoiceNo || ""}? It becomes payable.`)) return;
    r.released = true; r.releasedAt = today(); try { apLog(p, "Retention released", String(r.amount)); } catch (e) {}
    save(); apOpenRetention(); render(); toast("Retention released — now payable");
  };

  /* ---------- Multi-bill payment ---------- */
  const vendorsWithDue = () => [...new Set((db.payables || []).filter((p) => apCanPay(p) && apPayableNow(p) > 0 && (!selectedProject || p.projectId === selectedProject)).map((p) => String(p.supplier || "").trim()).filter(Boolean))].sort();
  window.apOpenMultiPay = function (vendor) {
    const vs = vendorsWithDue(); if (!vs.length) { toast("No approved bill is waiting for payment"); return; }
    vendor = vendor || vs[0];
    const bills = (db.payables || []).filter((p) => apCanPay(p) && apPayableNow(p) > 0 && same(p.supplier, vendor) && (!selectedProject || p.projectId === selectedProject)).sort((a, b) => String(a.dueDate || a.date).localeCompare(String(b.dueDate || b.date)));
    const methods = (db.settings?.paymentMethods || ["Cash", "Bank Transfer", "Cheque", "Online Transfer"]);
    const rows = bills.map((p) => `<tr><td><input type="checkbox" class="mp_chk" data-id="${E(p.id)}" checked onchange="apMultiSum()"></td><td>${E(p.invoiceNo)}</td><td>${E(p.dueDate || p.date || "")}</td><td>${E(typeof projectName === "function" ? projectName(p.projectId) : "")}</td><td style="text-align:right">${M(apOutstandingAmount(p))}</td><td style="text-align:right">${M(apRetentionHeld(p))}</td><td><input type="number" class="mp_amt" data-id="${E(p.id)}" data-max="${apPayableNow(p).toFixed(2)}" step="0.01" min="0" value="${apPayableNow(p).toFixed(2)}" style="width:110px;text-align:right" oninput="apMultiSum()"></td></tr>`).join("");
    openModal("Pay several bills", `<div class="formgrid"><div class="field"><label>Vendor</label><select id="mp_vendor" onchange="apOpenMultiPay(this.value)">${vs.map((v) => `<option ${same(v, vendor) ? "selected" : ""}>${E(v)}</option>`).join("")}</select></div><div class="field"><label>Payment date</label><input id="mp_date" type="date" value="${today()}"></div><div class="field"><label>Method</label><select id="mp_method">${methods.map((m) => `<option>${E(m)}</option>`).join("")}</select></div><div class="field"><label>Reference / cheque no</label><input id="mp_ref"></div><div class="field full"><label>Remarks</label><input id="mp_rem"></div></div><div style="max-height:40vh;overflow:auto;margin-top:8px"><table class="appx-table"><thead><tr><th></th><th>Bill</th><th>Due</th><th>Project</th><th class="n">Outstanding</th><th class="n">Retention held</th><th>Pay now</th></tr></thead><tbody>${rows}</tbody></table></div><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:10px"><b id="mp_total"></b><div style="display:flex;gap:8px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" id="mp_go" onclick="apDoMultiPay()">Pay selected</button></div></div>`);
    apMultiSum();
  };
  window.apMultiSum = function () {
    let t = 0, n = 0; document.querySelectorAll(".mp_amt").forEach((i) => { const c = document.querySelector(`.mp_chk[data-id="${i.dataset.id}"]`); if (c?.checked) { t += N(i.value); n++; } });
    const el = document.getElementById("mp_total"); if (el) el.textContent = `${n} bill(s) · Total ${M(t)}`;
  };
  window.apDoMultiPay = function () {
    if (window.__apPayBusy) { toast("Payment is already being saved"); return; }
    const picks = [...document.querySelectorAll(".mp_amt")].filter((i) => document.querySelector(`.mp_chk[data-id="${i.dataset.id}"]`)?.checked && N(i.value) > 0).map((i) => ({ p: db.payables.find((x) => x.id === i.dataset.id), amount: Math.round(N(i.value) * 100) / 100 }));
    if (!picks.length) { toast("Select at least one bill"); return; }
    try { apPostingTotalsCache = null; } catch (e) {}
    for (const k of picks) { if (!k.p || !apCanPay(k.p)) { toast("A selected bill can no longer be paid"); return; } if (k.amount > apPayableNow(k.p) + 0.005) { toast(`${k.p.invoiceNo}: more than payable now (outstanding minus retention)`); return; } }
    const date = document.getElementById("mp_date").value || today(), method = document.getElementById("mp_method").value, ref = document.getElementById("mp_ref").value.trim(), rem = document.getElementById("mp_rem").value.trim();
    const total = picks.reduce((s, k) => s + k.amount, 0);
    if (!confirm(`Pay ${M(total)} to ${picks[0].p.supplier} for ${picks.length} bill(s)?`)) return;
    window.__apPayBusy = true; setTimeout(() => { window.__apPayBusy = false; }, 1500); document.getElementById("mp_go").disabled = true;
    const voucherNo = "PV-" + date.replace(/-/g, "") + "-" + String(((db.transactions || []).filter((x) => x.voucherNo && String(x.voucherNo).startsWith("PV-" + date.replace(/-/g, ""))).map((x) => x.voucherNo).filter((v, i, a) => a.indexOf(v) === i).length + 1)).padStart(3, "0");
    const ids = [];
    const ok = apCommit("Record multi-bill payment", () => {
      picks.forEach((k) => {
        const p = k.p, paymentId = id(), paidBefore = apPaidAmount(p);
        db.transactions.push({ id: paymentId, date, projectId: p.projectId, ...(typeof apBld === "function" && apBld(p) ? { building: apBld(p) } : {}), type: "Supplier Payment", amount: k.amount, paymentMethod: method, description: rem || `Supplier payment · ${p.invoiceNo} · ${voucherNo}`, category: "Supplier Payment", supplier: p.supplier, status: "Paid", dueDate: "", reference: ref || voucherNo, invoiceNo: p.invoiceNo || "", documentName: "", documentType: "", documentData: "", payableId: p.id, sourcePayableId: p.id, postingKey: `ap-payment:${paymentId}`, voucherNo });
        try { apPostingTotalsCache = null; } catch (e) {}
        p.paid = paidBefore + k.amount; const nb = apOutstandingAmount(p); p.apStatus = nb <= 0 ? "Paid" : "Partially Paid"; p.paidAt = new Date().toISOString();
        apLog(p, "Payment recorded", `${k.amount} · ${method} · ${voucherNo}`); ids.push(paymentId);
      });
    });
    if (!ok) return;
    closeModal(); render(); toast(`Payment ${voucherNo} saved for ${picks.length} bill(s)`);
    setTimeout(() => apPrintVoucher(voucherNo), 300);
  };

  /* ---------- Payment voucher print ---------- */
  window.apPrintVoucher = function (voucherNo) {
    const tx = (db.transactions || []).filter((x) => x.type === "Supplier Payment" && (x.voucherNo === voucherNo || x.id === voucherNo));
    if (!tx.length) { toast("Payment not found"); return; }
    const co = db.company?.name || db.settings?.companyName || "PURE_BUILD"; const t0 = tx[0]; const total = tx.reduce((s, x) => s + N(x.amount), 0);
    const w = window.open("", "_blank"); if (!w) { toast("Allow pop-ups to print"); return; }
    w.document.write(`<html><head><title>${E(voucherNo)}</title><style>body{font-family:Arial,sans-serif;font-size:12px;margin:24px}h1{font-size:18px;margin:0}h2{font-size:14px;margin:4px 0 14px}table{width:100%;border-collapse:collapse;margin:10px 0}th,td{border:1px solid #cbd5e1;padding:6px;text-align:left}th{background:#f1f5f9}.n{text-align:right}.sig{display:flex;justify-content:space-between;margin-top:60px}.sig div{border-top:1px solid #333;width:28%;text-align:center;padding-top:4px}</style></head><body><h1>${E(co)}</h1><h2>PAYMENT VOUCHER · ${E(t0.voucherNo || String(t0.id).slice(-8).toUpperCase())}</h2><table><tr><th>Date</th><td>${E(t0.date)}</td><th>Vendor</th><td>${E(t0.supplier)}</td></tr><tr><th>Method</th><td>${E(t0.paymentMethod || "")}</td><th>Reference</th><td>${E(t0.reference || "")}</td></tr></table><table><thead><tr><th>Bill</th><th>Project</th><th class="n">Amount</th></tr></thead><tbody>${tx.map((x) => `<tr><td>${E(x.invoiceNo)}</td><td>${E(typeof projectName === "function" ? projectName(x.projectId) : "")}</td><td class="n">${M(x.amount)}</td></tr>`).join("")}<tr><th colspan="2">Total</th><th class="n">${M(total)}</th></tr></tbody></table><div class="sig"><div>Prepared by</div><div>Approved by</div><div>Received by</div></div></body></html>`);
    w.document.close(); setTimeout(() => w.print(), 300);
  };

  /* ---------- Hook buttons into the AP page ---------- */
  const base = payables;
  window.payables = payables = function () {
    const r = base.apply(this, arguments); const tab = window.apTab || "overview";
    const ws = document.querySelector("#view .ap-workspace"); if (!ws) return r;
    const held = (db.payables || []).filter((p) => apIsPosted(p) && (!selectedProject || p.projectId === selectedProject)).reduce((s, p) => s + apRetentionHeld(p), 0);
    const c = cfg();
    if (["payments", "overview", "bills"].includes(tab) && !ws.querySelector(".apx2-bar")) {
      ws.insertAdjacentHTML("afterbegin", `<div class="apx2-bar" style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0 0 10px"><button class="btn primary" onclick="apOpenMultiPay()">Pay several bills</button><button class="btn" onclick="apOpenRetention()">Retention (held ${M(held)})</button><button class="btn" onclick="apOpenSettings()">AP Settings · VAT ${E(c.vatPct)}% · TDS ${E(c.tdsPct)}%</button></div>`);
    }
    if (tab === "payments") {
      ws.querySelectorAll("table tbody tr").forEach((tr) => { if (tr.querySelector(".apx2-pv")) return; const txt = tr.innerText; const t = (db.transactions || []).find((x) => x.type === "Supplier Payment" && x.voucherNo && txt.includes(x.invoiceNo || "§§") && (txt.includes(x.reference || "§§") || txt.includes(x.voucherNo))); if (t) { const td = tr.lastElementChild; td && td.insertAdjacentHTML("beforeend", ` <button class="btn small apx2-pv" onclick="apPrintVoucher('${E(t.voucherNo)}')">Voucher</button>`); } });
    }
    return r;
  };


  /* single bill payment form: retention cannot be paid until released */
  document.addEventListener("click", function (ev) {
    const btn = ev.target.closest && ev.target.closest("button"); if (!btn) return;
    const pay = document.getElementById("fPayable"), amt = document.getElementById("fAmount"); if (!pay || !amt) return;
    if (!btn.closest(".modal,#modal,.modal-card,[role=dialog]") || !/save|pay|record|confirm/i.test(btn.textContent || "")) return;
    const p = (db.payables || []).find((x) => String(x.id) === String(pay.value)); if (!p) return;
    const held = apRetentionHeld(p); if (held <= 0) return;
    if (N(amt.value) > apPayableNow(p) + 0.005) { ev.preventDefault(); ev.stopImmediatePropagation(); toast(`Retention ${M(held)} is held on this bill. Max payable now: ${M(apPayableNow(p))}`); amt.value = apPayableNow(p).toFixed(2); }
  }, true);
  if (typeof recordGroupPayment === "function") {
    const origRGP = recordGroupPayment;
    window.recordGroupPayment = recordGroupPayment = function () {
      const r = origRGP.apply(this, arguments);
      const fix = () => { const pay = document.getElementById("fPayable"), amt = document.getElementById("fAmount"); if (!pay || !amt) return; const p = (db.payables || []).find((x) => String(x.id) === String(pay.value)); if (!p) return; const held = apRetentionHeld(p); let n = document.getElementById("apx2-retnote"); if (held > 0) { amt.max = apPayableNow(p).toFixed(2); if (N(amt.value) > apPayableNow(p)) amt.value = apPayableNow(p).toFixed(2); if (!n) { amt.insertAdjacentHTML("afterend", '<small id="apx2-retnote" style="color:#b45309;display:block"></small>'); n = document.getElementById("apx2-retnote"); } n.textContent = `Retention held ${M(held)} — max payable now ${M(apPayableNow(p))}`; } else if (n) n.textContent = ""; };
      setTimeout(() => { fix(); document.getElementById("fPayable")?.addEventListener("change", () => setTimeout(fix, 0)); }, 0);
      return r;
    };
  }

  /* ---------- Vendor advance accounting: Dr 1450 Vendor Advances / Cr Cash-Bank; refund reverses; adjustment Dr AP / Cr 1450 ---------- */
  const ADV = "Supplier Payment Advance", REF = "Vendor Advance Refund", ACC = "1450 · Vendor Advances";
  if (typeof costAccountFor === "function") { const o = costAccountFor; window.costAccountFor = costAccountFor = function (c) { return c === "Vendor Advance" ? ACC : o.apply(this, arguments); }; }
  if (typeof isLedgerEntry === "function") { const o = isLedgerEntry; window.isLedgerEntry = isLedgerEntry = function (x) { if (x && (x.type === ADV || x.type === REF)) return x.status === "Posted"; return o.apply(this, arguments); }; }
  if (typeof ledgerDrCr === "function") { const o = ledgerDrCr; window.ledgerDrCr = ledgerDrCr = function (x) { if (x && x.type === ADV) return { dr: 0, cr: N(x.amount) }; if (x && x.type === REF) return { dr: N(x.amount), cr: 0 }; return o.apply(this, arguments); }; }
  if (typeof ledgerAccountMeta === "function") { const o = ledgerAccountMeta; window.ledgerAccountMeta = ledgerAccountMeta = function (x) {
    if (x && (x.type === ADV || x.type === REF)) { const m = String(x.paymentMethod || "").toLowerCase(); const cb = m.includes("bank") ? "1200 · Bank" : m.includes("cash") ? "1100 · Cash" : m.includes("mobile") ? "1250 · Mobile Wallet" : m.includes("cheque") ? "1210 · Cheques in Hand" : "1100 · Cash / Bank";
      return x.type === ADV ? { debit: ACC + (x.supplier ? " — " + x.supplier : ""), credit: cb, costCode: "AP-ADV", source: "Accounts Payable · Vendor Advance", reference: x.reference || "", journalNo: x.journalNo || "" } : { debit: cb, credit: ACC + (x.supplier ? " — " + x.supplier : ""), costCode: "AP-ADV-REF", source: "Accounts Payable · Advance Refund", reference: x.reference || "", journalNo: x.journalNo || "" }; }
    return o.apply(this, arguments); }; }
  /* post cash/bank entries for advances created or refunded from now on (once, keyed by advance id) */
  window.apPostAdvanceCash = function () {
    let changed = false; const T = (db.transactions = db.transactions || []);
    (db.apAdvances || []).forEach((a) => {
      if (!a.cashPosted && !T.some((x) => x.postingKey === "ap-adv-pay:" + a.id)) { T.push({ id: id(), date: a.date, projectId: a.projectId || "", type: ADV, amount: N(a.amount), paymentMethod: a.method || "", description: `${a.type || "Vendor Advance"} · ${a.no}`, category: "Vendor Advance", supplier: a.supplier, status: "Posted", reference: a.reference || a.no, advanceId: a.id, postingKey: "ap-adv-pay:" + a.id }); a.cashPosted = true; changed = true; }
      (a.refunds || []).forEach((r, i) => { const key = `ap-adv-ref:${a.id}:${i}`; if (!r.posted && !T.some((x) => x.postingKey === key)) { T.push({ id: id(), date: r.date, projectId: a.projectId || "", type: REF, amount: N(r.amount), paymentMethod: a.method || "", description: `Advance refund · ${a.no}`, category: "Vendor Advance", supplier: a.supplier, status: "Posted", reference: a.no, advanceId: a.id, postingKey: key }); r.posted = true; changed = true; } });
    });
    return changed;
  };
  ["apSaveAdvance", "apRefundAdvance"].forEach((fn) => { const o = window[fn]; if (typeof o !== "function") return; window[fn] = function () { const before = JSON.stringify(db.apAdvances || []); const r = o.apply(this, arguments); if (JSON.stringify(db.apAdvances || []) !== before && apPostAdvanceCash()) { save(); render(); } return r; }; });
  /* single-payment guard: warn when paying into held retention */
  if (typeof apCanPay === "function") {
    const origCan = apCanPay;
    window.apCanPay = apCanPay = function (p) { return origCan(p) && (apRetentionHeld(p) <= 0 || apPayableNow(p) > 0); };
  }
})();
