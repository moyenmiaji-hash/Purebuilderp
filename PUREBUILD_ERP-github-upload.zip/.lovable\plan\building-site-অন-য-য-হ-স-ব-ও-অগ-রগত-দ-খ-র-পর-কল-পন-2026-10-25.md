# Building / Site অনুযায়ী হিসাব ও অগ্রগতি দেখার পরিকল্পনা

এই ভুল বার্তাটা আসল কোনো কোড-ভুল না, এটা আপনার নোট ফাইলের লেখা। নোটে যা বলা আছে নিচে সেটার পরিকল্পনা দেওয়া হলো। পুরনো কোনো তথ্য মোছা বা বদলানো হবে না, আর নতুন কোনো মেনু যোগ হবে না।

```text
Dubai Mohol (Project)
  ├─ Building A  → খরচ, BOQ, অগ্রগতি, মাল, রিপোর্ট
  ├─ Building B  → ...
  └─ Building C  → ...
```

## ১. Ledger: Building অনুযায়ী খরচ
- প্রজেক্ট বাছার ঘরের পাশে একটা "All Buildings / Sites" বাছাই থাকবে (প্রজেক্টে Building থাকলেই দেখাবে)।
- একটা Building বাছলে তালিকায় আর মোট DR / CR / Balance-এ শুধু ওই Building-এর এন্ট্রি দেখাবে।
- টেবিলে প্রজেক্টের নিচে ছোট করে Building নাম দেখাবে। Print আর Export CSV-ও ফিল্টার মেনে চলবে।
- পুরনো এন্ট্রিগুলোতে Building নেই, তাই সেগুলো "General" হিসেবে দেখাবে।

## ২. Projects / Sites: প্রতিটা Building আলাদা করে দেখা
- প্রজেক্টের পাতার (যেমন Dubai Mohol) Overview-এর উপরে Building-এর বোতাম থাকবে: "All · Building A · Building B · ..."
- একটা Building বাছলে Overview-এর বাক্সগুলো শুধু ওই Building-এর হিসাব দেখাবে: কাজ কতটা হয়েছে, আসল খরচ, BOQ মূল্য, মালের ঢোকানো/বের করা, দৈনিক রিপোর্ট।
- Overview-এ নতুন "Building History" অংশ থাকবে, যেখানে ওই Building-এর লেনদেন, মাল আর অগ্রগতির তারিখ অনুযায়ী তালিকা দেখাবে।
- বাকি ট্যাবগুলোও (BOQ & Work Progress, Daily Reports, Materials, Expenses) একই Building বাছাই মেনে চলবে।

## ৩. Foreman-দের আপডেট: Site বাছাই
- Site Progress-এর Foreman Daily Update ফর্মে প্রজেক্টের পাশে "Building / Site" বাছাই থাকবে। না বাছলেও সেভ হবে।
- Staff মোবাইল অ্যাপের আপডেট ফর্মেও একই বাছাই থাকবে।

## ৪. Site Progress: Building অনুযায়ী অগ্রগতি
- প্রজেক্ট বাছার পাশে Building বাছাই থাকবে; বাছলে Trade-wise Progress, Work Detail Progress আর Foreman Updates শুধু ওই Building-এর দেখাবে।

## যা করা হবে না
- নতুন মেনু বা পাতা যোগ হবে না, পুরনো তথ্য বদলানো বা মোছা হবে না, হিসাবের নিয়ম বদলাবে না।

## Technical details
- Reuse `projectBuildings(pid)` and the existing optional `transaction.building` / `stockTxn.building`; add optional `dailyReport.building`. BOQ items are matched by their `building` field.
- One shared helper `matchBuilding(rec, b)` handles the filters: `""` = all, `"__general"` = records without a building.
- Project detail keeps the selected building in UI state only. Pages change through `setPage()`. Staff app (`team-staff.js`) gets an optional select. Tested only in a throwaway browser.
