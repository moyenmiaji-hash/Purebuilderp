/* p234 look only: calm popup background, tidy Dashboard "Site Progress" and
   "Alerts & Notifications" boxes. Colours/borders/spacing only, no data change. */
(function () {
  var P = 'html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3) #view#view#view#view ';
  var css = [
    /* popup background: soft dim instead of bright white fog */
    'html body #modal.open,html body .modal.open{background:rgba(32,30,52,.38)!important;backdrop-filter:none!important}',
    'html body #modal .modalbox{box-shadow:0 24px 60px -18px rgba(32,30,52,.45)!important;border:1px solid #e7e4f0!important}',
    /* Alerts */
    P + '.dashboard-alert-content{display:flex!important;flex-direction:column!important;min-width:0!important;min-height:0!important;gap:5px!important;padding:2px 3px 4px!important;background:transparent!important;overscroll-behavior:contain}',
    P + '.dbn-title{order:-1;display:flex!important;align-items:center;gap:7px;margin:0 0 2px!important;padding:0 2px 4px!important;border-bottom:1px solid #ebe8f4;font-size:10px!important;font-weight:800;color:#35445d!important}',
    P + '.dbn-title small{color:#858398!important;font-weight:600}',
    P + '.dbn-sec{order:3;flex:0 0 auto!important;min-width:0!important;margin:0!important;padding:0!important;border:1px solid #e8eaf2!important;border-radius:10px!important;background:#fff!important;box-shadow:0 2px 5px rgba(41,40,58,.04)!important;overflow:hidden}',
    P + '.dbn-sec:has(.dbn-row.red){order:0}',
    P + '.dbn-sec:has(.dbn-row.amber):not(:has(.dbn-row.red)){order:1}',
    P + '.dbn-sec:has(.dbn-row.blue):not(:has(.dbn-row.red)):not(:has(.dbn-row.amber)){order:2}',
    P + '.dbn-sec-head{display:flex!important;align-items:center;gap:6px;min-width:0;margin:0!important;padding:4px 7px!important;font-size:9px!important;line-height:1.15!important;font-weight:800!important;color:#4b4a63!important;background:#f7f7fb!important;border:0!important;border-bottom:1px solid #ebe8f4!important}',
    P + '.dbn-sec-title{flex:1;min-width:0}',
    P + '.dbn-sec-count{min-width:18px;height:17px;display:inline-grid!important;place-items:center;border-radius:99px;background:#e8e4fb!important;color:#6654bc!important;font-size:9px!important;padding:0 5px}',
    P + '.dbn-sec-body{display:grid!important;gap:3px!important;min-width:0;padding:4px 5px!important}',
    P + '.dbn-row{display:grid!important;grid-template-columns:22px minmax(0,1fr)!important;align-items:center;gap:6px!important;min-width:0!important;min-height:32px!important;margin:0!important;padding:4px 6px!important;border:1px solid #eef0f5!important;border-left:3px solid #b8bfd0!important;border-radius:8px!important;background:#fff!important;box-shadow:0 1px 2px rgba(41,40,58,.04)!important;font-size:9px!important;line-height:1.25!important;color:#29283A!important}',
    P + '.dbn-row.red{border-color:#f5d9de!important;border-left-color:#dc5267!important;background:#fff8f8!important}' + P + '.dbn-row.amber,' + P + '.dbn-row.orange{border-color:#f2e5c7!important;border-left-color:#d99418!important;background:#fffaf0!important}' + P + '.dbn-row.green{border-color:#d6eee0!important;border-left-color:#229b65!important;background:#f6fcf8!important}' + P + '.dbn-row.blue{border-color:#dce5f6!important;border-left-color:#6374d6!important;background:#f8f9ff!important}',
    P + '.dbn-row .dbn-icon{flex:none;width:22px!important;height:22px!important;display:grid!important;place-items:center;border-radius:7px!important;background:#f1eefb!important;color:#7765ca!important}',
    P + '.dbn-row.red .dbn-icon{background:#fde8eb!important;color:#c83e55!important}' + P + '.dbn-row.amber .dbn-icon,' + P + '.dbn-row.orange .dbn-icon{background:#fff0d3!important;color:#ad6d00!important}' + P + '.dbn-row.green .dbn-icon{background:#e2f5e9!important;color:#16804d!important}' + P + '.dbn-row.blue .dbn-icon{background:#e8edff!important;color:#5868c4!important}',
    P + '.dbn-sec-icon,' + P + '.dbn-title-icon{flex:none;width:19px!important;height:19px!important;display:grid!important;place-items:center;border-radius:6px!important;background:#eeebfb!important;color:#7765ca!important}',
    P + '.dbn-row .dashboard-icon svg,' + P + '.dbn-sec-icon svg,' + P + '.dbn-title-icon svg{width:12px!important;height:12px!important}',
    P + '.dbn-copy{display:block!important;min-width:0!important;overflow:hidden!important;line-height:1.25!important;color:#30364a!important}',
    P + '.dbn-copy b{display:block!important;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px!important;font-weight:800!important}',
    P + '.dbn-copy small{display:-webkit-box!important;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;margin-top:1px!important;color:#71778a!important;font-size:8px!important;line-height:1.2!important}',
    /* Site Progress */
    P + '.dashboard-progress-panel .progress-mini{flex:1 1 0!important;min-width:0!important;min-height:0!important;overflow:auto!important;overscroll-behavior:contain}',
    P + '.dbp-list{display:grid!important;min-width:0!important;gap:5px!important;padding:2px!important}',
    P + '.dbp-row{min-width:0!important;margin:0!important;padding:6px 8px!important;border:1px solid #e8eaf2!important;border-left:3px solid #6374d6!important;border-radius:10px!important;background:linear-gradient(110deg,#fff,#fbfbff)!important;box-shadow:0 2px 5px rgba(41,40,58,.05)!important}',
    P + '.dbp-top{display:flex!important;align-items:center;gap:6px!important;min-width:0!important}',
    P + '.dbp-top b{flex:1 1 auto!important;min-width:0!important;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px!important;line-height:1.2!important;color:#29283A!important}',
    P + '.dbp-status{flex:none;padding:2px 6px!important;border:1px solid #dfe5f5;border-radius:999px!important;background:#f2f4fb!important;color:#5d6682!important;font-size:8px!important;line-height:1.2!important;font-weight:800!important;white-space:nowrap}',
    P + '.dbp-status[data-state="active"]{border-color:#cfe9dc!important;background:#edfaf2!important;color:#16804d!important}',
    P + '.dbp-status[data-state="complete"]{border-color:#bfe4d0!important;background:#e1f6e9!important;color:#137442!important}',
    P + '.dbp-pct{flex:none;min-width:43px;padding:2px 6px!important;border:1px solid #dcdff5;border-radius:7px!important;background:#f0efff!important;color:#574bb2!important;font-size:9px!important;font-variant-numeric:tabular-nums;text-align:center;font-weight:900!important}',
    P + '.dbp-meta{display:flex!important;align-items:center;gap:8px!important;min-width:0!important;margin:3px 0 4px!important;font-size:8px!important;line-height:1.2!important;color:#858398!important}',
    P + '.dbp-meta span{min-width:0!important;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    P + '.dbp-meta span:first-child{color:#59647c!important;font-weight:700!important}',
    P + '.dbp-bar{height:4px!important;border-radius:99px!important;background:#ecebf4!important;overflow:hidden}',
    P + '.dbp-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#7664d1,#28a875)!important;transition:width .25s ease}'
  ].join('\n');
  var s = document.createElement('style'); s.id = 'pb-dash-tidy'; s.textContent = css;
  (document.body || document.head).appendChild(s);
})();
