import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type TurnstileWindow = Window & {
  PB_TURNSTILE?: {
    getToken: (container: HTMLElement | null) => Promise<string | undefined>;
  };
};

export const Route = createFileRoute("/admin-setup")({
  head: () => ({
    meta: [
      { title: "PURE_BUILD — Admin Setup" },
      {
        name: "description",
        content: "Sign in and enroll multi-factor authentication for a PURE_BUILD Admin account.",
      },
      { property: "og:title", content: "PURE_BUILD — Admin Security Setup" },
      {
        property: "og:description",
        content: "Sign in and enroll multi-factor authentication for a PURE_BUILD Admin account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminSetup,
});

function AdminSetup() {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [factor, setFactor] = useState<{
    id: string;
    challengeId: string;
    qrCode?: string;
    secret?: string;
  } | null>(null);
  const [code, setCode] = useState("");
  const captchaContainer = useRef<HTMLDivElement>(null);

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const turnstile = (window as TurnstileWindow).PB_TURNSTILE;
      const captchaToken = turnstile
        ? await turnstile.getToken(captchaContainer.current)
        : undefined;
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: pw,
        options: captchaToken ? { captchaToken } : undefined,
      });
      if (error || !data.user) throw new Error("ইমেইল বা পাসওয়ার্ড সঠিক নয়।");

      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("role, status")
        .eq("id", data.user.id)
        .maybeSingle();
      if (profileError) throw new Error("অ্যাকাউন্ট যাচাই করা যায়নি।");
      if (profile?.status !== "active" || profile.role !== "admin") {
        await supabase.auth.signOut();
        throw new Error("এই অ্যাকাউন্টের Admin অনুমতি নেই।");
      }

      const { data: assurance, error: assuranceError } =
        await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (assuranceError) throw new Error("MFA অবস্থা যাচাই করা যায়নি।");
      if (assurance.currentLevel === "aal2") {
        setMsg("আপনি MFA-সহ Admin হিসেবে সাইন ইন করেছেন।");
        setPw("");
        return;
      }

      const { data: factors, error: factorsError } = await supabase.auth.mfa.listFactors();
      if (factorsError) throw new Error("Authenticator যাচাই করা যায়নি।");
      const verified = factors.totp.find((item) => item.status === "verified");
      let factorId = verified?.id;
      let qrCode: string | undefined;
      let secret: string | undefined;
      if (!factorId) {
        const { data: enrolled, error: enrollError } = await supabase.auth.mfa.enroll({
          factorType: "totp",
          issuer: "PURE_BUILD",
        });
        if (enrollError || !enrolled?.totp) {
          throw new Error("Admin authenticator তৈরি করা যায়নি।");
        }
        factorId = enrolled.id;
        qrCode = enrolled.totp.qr_code;
        secret = enrolled.totp.secret;
      }
      const { data: challenge, error: challengeError } = await supabase.auth.mfa.challenge({
        factorId,
      });
      if (challengeError || !challenge) {
        throw new Error("MFA যাচাই শুরু করা যায়নি।");
      }
      setFactor({ id: factorId, challengeId: challenge.id, qrCode, secret });
      setPw("");
      setMsg(
        qrCode
          ? "Authenticator app দিয়ে QR scan করুন, তারপর তৈরি হওয়া code দিন।"
          : "Authenticator app-এর code দিন।",
      );
    } catch (error) {
      setMsg(error instanceof Error ? error.message : "সাইন ইন করা যায়নি।");
    } finally {
      setBusy(false);
    }
  }

  async function verifyMfa(e: React.FormEvent) {
    e.preventDefault();
    if (!factor) return;
    setBusy(true);
    try {
      const { error } = await supabase.auth.mfa.verify({
        factorId: factor.id,
        challengeId: factor.challengeId,
        code: code.trim(),
      });
      if (error) throw new Error("Authenticator code সঠিক নয় বা মেয়াদ শেষ হয়েছে।");
      const { data: assurance, error: assuranceError } =
        await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (assuranceError || assurance.currentLevel !== "aal2") {
        throw new Error("MFA verification সম্পন্ন হয়নি। আবার চেষ্টা করুন।");
      }
      const { data: isAdmin, error: roleError } = await supabase.rpc("has_role", {
        _user_id: (await supabase.auth.getUser()).data.user?.id || "",
        _role: "admin",
      });
      if (roleError || !isAdmin) throw new Error("Admin অনুমতি যাচাই করা যায়নি।");
      setFactor(null);
      setCode("");
      setMsg("MFA-সহ Admin sign-in সফল হয়েছে।");
    } catch (error) {
      setMsg(error instanceof Error ? error.message : "MFA যাচাই করা যায়নি।");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-sm p-6 font-sans">
      <h1 className="mb-1 text-xl font-bold">PURE_BUILD Admin Setup</h1>
      <p className="mb-4 text-sm text-muted-foreground">
        Admin account Supabase Dashboard থেকে তৈরি করে bootstrap SQL চালান। এখানে নতুন account তৈরি
        করা যায় না।
      </p>
      <form onSubmit={signIn} className="space-y-3">
        <input
          className="w-full rounded border p-2"
          type="email"
          placeholder="Admin ইমেইল"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          className="w-full rounded border p-2"
          type="password"
          placeholder="Admin পাসওয়ার্ড"
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          required
        />
        <div ref={captchaContainer} />
        <button disabled={busy} className="w-full rounded bg-primary p-2 text-primary-foreground">
          Admin হিসেবে সাইন ইন
        </button>
      </form>
      {factor && (
        <form onSubmit={verifyMfa} className="mt-4 space-y-3">
          {factor.qrCode && (
            <div className="space-y-2">
              <img
                className="mx-auto max-h-56 rounded bg-white p-3"
                src={factor.qrCode}
                alt="Admin authenticator QR code"
              />
              <p className="break-all text-xs text-muted-foreground">
                Recovery secret: {factor.secret}
              </p>
            </div>
          )}
          <label className="block text-sm font-medium">
            Authenticator code
            <input
              className="mt-1 w-full rounded border p-2"
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              value={code}
              onChange={(event) => setCode(event.target.value)}
              required
              minLength={6}
              maxLength={8}
            />
          </label>
          <button disabled={busy} className="w-full rounded bg-primary p-2 text-primary-foreground">
            Verify and enable Admin MFA
          </button>
        </form>
      )}
      {msg && <p className="mt-4 text-sm">{msg}</p>}
    </main>
  );
}
