// Permanent cloud storage for ERP data. Admin only. Code updates never touch this data.
const LEGACY_KEY = "PURE_BUILD_REAL_V1";
const LEGACY_CHOICE_PREFIX = "PURE_BUILD_LEGACY_CHOICE_";
let KEY = LEGACY_KEY;
let REV_KEY = "PURE_BUILD_CLOUD_REV";
let HASH_KEY = "PURE_BUILD_CLOUD_HASH";
let tenantId = "";
const PUSH_DELAY = 1500;

let client = null;
let ready = false;
let busy = false;
let rev = 0;
let timer = null;
let state = "starting";
let card = null;

async function sha256(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function readLocal() {
  const text = localStorage.getItem(KEY) || "";
  let parsed = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  const empty = !parsed || (!(parsed.projects || []).length && !(parsed.transactions || []).length);
  return { text, parsed, empty };
}

function setTenantScope(organizationId) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(organizationId || "")) {
    throw new Error("The signed-in profile has no valid company assignment.");
  }
  tenantId = organizationId.toLowerCase();
  KEY = `${LEGACY_KEY}_${tenantId}`;
  REV_KEY = `PURE_BUILD_CLOUD_REV_${tenantId}`;
  HASH_KEY = `PURE_BUILD_CLOUD_HASH_${tenantId}`;
  if (typeof window.PB_APP_API?.setStorageKey !== "function") {
    throw new Error("The ERP app cannot select company-specific data storage. Refresh the app to load the latest version.");
  }
  window.PB_APP_API.setStorageKey(KEY);
}

function badge() {
  let el = document.getElementById("pb-sync-badge");
  if (!el) {
    el = document.createElement("div");
    el.id = "pb-sync-badge";
    el.style.cssText = "position:fixed;left:12px;bottom:12px;z-index:60;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:700;color:#fff;background:#334155;box-shadow:0 4px 14px #0004;max-width:80vw";
    document.body.append(el);
  }
  return el;
}

function setState(next, text, color) {
  state = next;
  const el = badge();
  el.textContent = text;
  el.style.background = color;
}

function showCard(html, actions) {
  hideCard();
  card = document.createElement("div");
  card.style.cssText = "position:fixed;left:12px;bottom:52px;z-index:61;width:min(380px,calc(100vw - 24px));padding:14px;border-radius:14px;background:#10233e;color:#fff;border:1px solid #4a76ad;box-shadow:0 12px 40px #0008;font-size:13px;line-height:1.5";
  card.innerHTML = `<div>${html}</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"></div>`;
  const row = card.lastElementChild;
  actions.forEach(([label, handler, primary]) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.style.cssText = `border:0;border-radius:9px;padding:9px 12px;font-weight:800;cursor:pointer;color:#fff;background:${primary ? "#2563eb" : "#334b6e"}`;
    button.addEventListener("click", handler);
    row.append(button);
  });
  document.body.append(card);
}

function hideCard() {
  card?.remove();
  card = null;
}

function downloadText(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

async function markSynced(text, revision) {
  rev = revision;
  localStorage.setItem(REV_KEY, String(revision));
  localStorage.setItem(HASH_KEY, await sha256(text));
}

async function pull(row) {
  const old = localStorage.getItem(KEY);
  // Keep a local copy only when this browser has changes the cloud does not have yet.
  const alreadySynced = old && (await sha256(old)) === localStorage.getItem(HASH_KEY);
  if (old && !readLocal().empty && !alreadySynced) localStorage.setItem(`${KEY}_BEFORE_CLOUD_${Date.now()}`, old);
  const text = JSON.stringify(row.data);
  localStorage.setItem(KEY, text);
  await markSynced(text, row.revision);
  // Show the cloud data right away, without reloading the whole page.
  if (typeof window.PB_RELOAD_DATA === "function") {
    try {
      window.PB_RELOAD_DATA();
      ready = true;
      setState("synced", "☁ Cloud saved", "#15803d");
      return;
    } catch (error) { console.error("Live refresh failed", error); }
  }
  location.reload();
}

async function push() {
  if (!ready || busy) return;
  const local = readLocal();
  if (local.empty && rev > 0) return;
  const hash = await sha256(local.text);
  if (hash === localStorage.getItem(HASH_KEY) && rev > 0) { setState("synced", "☁ Cloud saved", "#15803d"); return; }
  busy = true;
  const slow = setTimeout(() => setState("saving", "☁ Saving…", "#b45309"), 2500);
  try {
    const { data, error } = await client.rpc("erp_state_save", { p_expected: rev, p_data: local.parsed });
    if (error) throw error;
    clearTimeout(slow);
    await markSynced(local.text, data);
    const latest = await sha256(readLocal().text);
    if (latest !== hash) schedule();
    else setState("synced", "☁ Cloud saved", "#15803d");
  } catch (error) {
    clearTimeout(slow);
    console.error("Cloud save failed", error);
    if (String(error.message || "").includes("REVISION_CONFLICT")) {
      ready = false;
      await check();
    } else if (String(error.message || "").includes("EMPTY_OVERWRITE_BLOCKED")) {
      setState("error", "☁ Blocked: empty data not saved", "#b91c1c");
    } else {
      setState("error", "☁ Not saved – retrying", "#b91c1c");
      setTimeout(schedule, 30000);
    }
  } finally {
    busy = false;
  }
}

function schedule() {
  clearTimeout(timer);
  timer = setTimeout(() => void push(), PUSH_DELAY);
}

async function fetchCloud() {
  const { data, error } = await client.from("erp_cloud_state").select("data, revision, updated_at").maybeSingle();
  if (error) throw error;
  return data;
}

async function check() {
  setState("checking", "☁ Checking cloud…", "#334155");
  const cloud = await fetchCloud();
  const local = readLocal();
  const localRev = Number(localStorage.getItem(REV_KEY) || 0);
  const localHash = local.text ? await sha256(local.text) : "";
  const unchanged = localHash === localStorage.getItem(HASH_KEY);

  if (!cloud) {
    rev = 0;
    if (local.empty) { ready = true; setState("synced", "☁ Cloud ready", "#15803d"); return; }
    setState("action", "☁ Upload needed", "#b45309");
    showCard("No data in Cloud yet. Upload this browser's data to the cloud to keep it permanently safe.", [
      ["Upload to cloud", async () => { hideCard(); ready = true; await push(); }, true],
    ]);
    return;
  }

  rev = cloud.revision;
  const cloudEmpty = !(cloud.data?.projects || []).length && !(cloud.data?.transactions || []).length;
  if (local.empty && cloudEmpty) { ready = true; setState("synced", "☁ Cloud ready", "#15803d"); return; }
  if (local.empty) { await pull(cloud); return; }
  if (localRev === cloud.revision) {
    ready = true;
    if (unchanged) setState("synced", "☁ Cloud saved", "#15803d");
    else await push();
    return;
  }
  if (unchanged) { await pull(cloud); return; }

  // Cloud is the source of truth: keep a safety copy of this browser's data, then load cloud data (no question).
  try { window.pbSafetySnapshot?.("before-cloud-load"); } catch {}
  try {
    localStorage.setItem(
      `PURE_BUILD_LOCAL_COPY_${tenantId}_${Date.now()}`,
      local.text,
    );
    trimLocalCopies();
  } catch {}
  // Keep this browser's new/edited records (e.g. a BOQ item just saved) on top of the cloud data,
  // so a save made at the same moment as another device is never lost.
  const merged = mergeState(cloud.data || {}, local.parsed || {});
  await pull({ data: merged, revision: cloud.revision });
  if (JSON.stringify(merged) !== JSON.stringify(cloud.data)) { ready = true; schedule(); }
}

// Union of records by id: cloud records stay, local-only records are added, local edits win for the same id.
function mergeState(cloudData, localData) {
  const out = { ...cloudData };
  for (const [key, lv] of Object.entries(localData)) {
    const cv = cloudData[key];
    if (Array.isArray(lv) && Array.isArray(cv) && lv.every((r) => r && typeof r === "object" && r.id != null)) {
      const map = new Map(cv.map((r) => [r && r.id, r]));
      const extra = [];
      lv.forEach((r) => { if (map.has(r.id)) map.set(r.id, r); else extra.push(r); });
      out[key] = [...cv.map((r) => (r && map.has(r.id) ? map.get(r.id) : r)), ...extra];
    } else if (!(key in cloudData)) {
      out[key] = lv;
    }
  }
  return out;
}

function trimLocalCopies() {
  const prefix = `PURE_BUILD_LOCAL_COPY_${tenantId}_`;
  const keys = Object.keys(localStorage).filter((k) => k.startsWith(prefix)).sort();
  while (keys.length > 3) localStorage.removeItem(keys.shift());
}

function hookSave() {
  const original = window.save;
  if (typeof original !== "function") return;
  window.save = function (...args) {
    const result = original.apply(this, args);
    if (ready) schedule();
    return result;
  };
  if (window.PB_APP_API) window.PB_APP_API.save = window.save;
  setInterval(() => { if (ready && !busy) void push(); }, 20000);
}

const PAGE_MODULE = {
  dashboard: "Dashboard", transactions: "Transactions", billing: "Sales & Invoice", ledger: "Ledger",
  payables: "Accounts Payable", stock: "Stock", labour: "Labour & HR", projects: "Projects",
  progress: "Site Progress", quotation: "Quotation", boq: "BOQ", reports: "Reports", profitLoss: "Profit & Loss",
};
const ROLE_MODULES = {
  manager: Object.values(PAGE_MODULE),
  accountant: ["Dashboard", "Transactions", "Sales & Invoice", "Ledger", "Accounts Payable", "Reports", "Profit & Loss"],
};

// Admin keeps everything. Other office roles only see the modules their profile allows.
function applyRoleLimits(profile) {
  if (profile.role === "admin") return;
  const configured = profile.permissions?.modules;
  const allowed = new Set(configured && Object.keys(configured).length ? Object.keys(configured) : ROLE_MODULES[profile.role] || []);
  const canOpen = (pageName) => !PAGE_MODULE[pageName] || allowed.has(PAGE_MODULE[pageName]);
  const apply = () => {
    document.querySelectorAll(".nav button[data-page]").forEach((button) => {
      const name = button.dataset.page;
      const hide = name === "access" ? false : name === "settings" ? true : !canOpen(name);
      button.style.display = hide ? "none" : "";
    });
    const current = window.PB_APP_API?.getPage?.();
    if (current && !["access"].includes(current) && !canOpen(current) && typeof window.setPage === "function" && !apply.busy) {
      apply.busy = true;
      window.setPage("dashboard");
      window.render?.();
      apply.busy = false;
    }
  };
  window.addEventListener("pb:rendered", apply);
  apply();
}

async function start() {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  for (let i = 0; i < 200 && !window.PB_CLOUD_CLIENT; i += 1) await wait(50);
  client = window.PB_CLOUD_CLIENT;
  if (!client) return;
  hookSave();
  const begin = async () => {
    const { data } = await client.auth.getSession();
    if (!data.session?.user) { ready = false; setState("signedout", "☁ Cloud: sign in (Access page)", "#475569"); return; }
    const { data: profile } = await client.from("profiles").select("organization_id, role, status, permissions").eq("id", data.session.user.id).maybeSingle();
    if (!profile || profile.status !== "active" || !["admin", "manager", "accountant"].includes(profile.role)) { badge().remove(); return; }
    try { setTenantScope(profile.organization_id); } catch (error) {
      console.error("Cloud sync could not select company storage", error);
      setState("error", "☁ Company data unavailable", "#b91c1c");
      showCard(error.message || "Could not load this company's ERP data. Refresh and try again.", [
        ["Retry", () => { hideCard(); void begin(); }, true],
      ]);
      return;
    }
    applyRoleLimits(profile);
    const runCheck = async () => {
      try { await check(); } catch (error) {
        console.error("Cloud check failed", error);
        setState("error", "☁ Cloud offline", "#b91c1c");
        setTimeout(begin, 15000);
      }
    };
    const legacy = localStorage.getItem(LEGACY_KEY);
    const choiceKey = `${LEGACY_CHOICE_PREFIX}${tenantId}`;
    if (!localStorage.getItem(KEY) && legacy && !localStorage.getItem(choiceKey)) {
      ready = false;
      setState("action", "☁ Choose company data", "#b45309");
      showCard("This browser has older ERP data that is not linked to a company. Choose whether to keep it separate or explicitly import it into this signed-in company.", [
        ["Use company cloud data", async () => { localStorage.setItem(choiceKey, "cloud"); hideCard(); await runCheck(); }, false],
        ["Import old browser data", async () => { localStorage.setItem(KEY, legacy); localStorage.setItem(choiceKey, "imported"); hideCard(); await runCheck(); }, true],
      ]);
      return;
    }
    await runCheck();
  };
  await begin();
  client.auth.onAuthStateChange((event) => {
    if (event === "SIGNED_IN" && !ready && state !== "checking" && state !== "action") setTimeout(begin, 300);
    if (event === "SIGNED_OUT") {
      ready = false;
      clearTimeout(timer);
      location.reload();
    }
  });
  setInterval(async () => {
    if (!ready || busy) return;
    try {
      const cloud = await fetchCloud();
      if (cloud && cloud.revision !== rev) { ready = false; await check(); }
    } catch (error) { console.error("Cloud poll failed", error); }
  }, 60000);
}

start();
