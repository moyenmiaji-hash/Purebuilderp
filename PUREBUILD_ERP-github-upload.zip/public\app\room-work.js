/* Room-wise BOQ / work panel. Reuses db.boq items; only adds optional side fields
   (spec, startDate, endDate, notes, attachments[], progressLog[]). Old items load unchanged. */
(function(){
  const CATS=['Civil','Brickwork','Plaster','Tiles','Painting','Electrical','Plumbing','Finishing'];
  const num=v=>Number(v)||0;
  const sameLoc=(i,pid,l)=>String(i.projectId)===String(pid)&&String(i.building||'')===l[0]&&String(i.floor||'')===l[1]&&String(i.area||'')===l[2];
  const canEdit=()=>typeof boqCanApprove==='function'?boqCanApprove():true;
  let cur=null;
  function items(){return cur?(db.boq||[]).filter(i=>sameLoc(i,cur.pid,cur.loc)):[]}
  function catList(){const s=new Set(CATS);(db.boq||[]).forEach(b=>b.category&&s.add(b.category));return [...s]}
  function addCatList(){const el=document.getElementById('fBoqCat');if(!el)return;let dl=document.getElementById('pbCatList');if(!dl){dl=document.createElement('datalist');dl.id='pbCatList';document.body.appendChild(dl)}dl.innerHTML=catList().map(c=>`<option value="${esc(c)}">`).join('');el.setAttribute('list','pbCatList')}
  function body(){
    const list=items(),q=list.reduce((n,i)=>n+num(i.qty),0),d=list.reduce((n,i)=>n+Math.min(num(i.executedQty),num(i.qty)||Infinity),0),amt=list.reduce((n,i)=>n+num(i.amount),0);
    const appr=list.filter(i=>['Approved','Revised'].includes(boqStatus(i))).reduce((n,i)=>n+num(i.qty),0),pct=q?Math.min(100,d/q*100):0;
    const [b,f,a]=cur.loc;const k=(t,v)=>`<div class="rw-k"><small>${t}</small><b>${v}</b></div>`;
    const rows=list.map(i=>{const iq=num(i.qty),id=num(i.executedQty),ip=iq?Math.min(100,id/iq*100):0;return `<tr><td><b>${esc(i.boqId||'')}</b><br><span class="pill">${esc(i.category||'—')}</span></td><td>${esc(i.description||'')}${i.spec?`<br><small class="muted">${esc(i.spec)}</small>`:''}</td><td>${fmt(iq)} ${esc(i.unit||'')}</td><td>${money(i.rate)}</td><td>${money(i.amount)}</td><td>${fmt(id)} / ${fmt(Math.max(0,iq-id))}</td><td><div class="rw-bar"><i style="width:${ip}%"></i></div><small>${ip.toFixed(1)}%</small></td><td>${boqStatusPill(i)}</td><td class="rw-act"><button type="button" class="btn small" onclick="pbRoomDetail('${esc(i.id)}')">View Details</button>${canEdit()?`<button type="button" class="btn small" onclick="pbRoomEdit('${esc(i.id)}')">Edit</button>`:''}<button type="button" class="btn small primary" onclick="pbRoomProgress('${esc(i.id)}')">Add Progress</button></td></tr>`}).join('');
    return `<div class="rw"><div class="rw-head"><div><div class="muted">${esc(projectName(cur.pid))}</div><h3>${esc(a||f||b)}</h3><div class="muted">🏢 ${esc(b||'—')} · ${esc(f||'—')} · ${esc(a||'—')}</div></div>${canEdit()?`<button type="button" class="btn primary" onclick="pbRoomAdd()">+ Add Work Item</button>`:''}</div>
    <div class="rw-kpi">${k('Total items',list.length)}${k('Approved qty',fmt(appr))}${k('BOQ amount',money(amt))}${k('Progress',pct.toFixed(1)+'%')}</div><div class="rw-bar big"><i style="width:${pct}%"></i></div>
    <div class="tablewrap"><table class="table"><thead><tr><th>ID / Category</th><th>Work</th><th>Qty</th><th>Rate</th><th>Amount</th><th>Done / Left</th><th>Progress</th><th>Status</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="9" class="empty">No work items in this room yet. Use “+ Add Work Item”.</td></tr>'}</tbody></table></div></div>`;
  }
  function show(){openModal(`Room · ${(cur.loc.filter(Boolean).join(' / '))||'Location'}`,body(),()=>true);const ms=document.getElementById('modalSave');if(ms)ms.style.display='none';document.querySelector('#modal .modalbox,#modal .modal')?.classList.add('rw-wide')}
  window.pbRoomOpen=function(pid,loc){cur={pid,loc:loc.map(v=>String(v||''))};show()};
  const back=()=>{if(cur)setTimeout(show,60)};
  window.pbRoomAdd=function(){if(!cur)return;closeModal();projectAddBoqAtLocation(cur.pid,{building:cur.loc[0],floor:cur.loc[1],area:cur.loc[2]});addCatList()};
  window.pbRoomEdit=function(id){closeModal();editBOQ(id);addCatList()};
  window.pbRoomDetail=function(id){
    const x=(db.boq||[]).find(b=>b.id===id);if(!x)return;boqDetail(id);
    const host=document.querySelector('#modalBody .boq-dt');if(!host)return;
    const log=(x.progressLog||[]).slice().sort((p,q)=>String(q.date).localeCompare(String(p.date)));
    const lq={building:x.building,floor:x.floor,area:x.area};
    const tx=(db.transactions||[]).filter(t=>String(t.projectId)===String(x.projectId)&&(t.boqId===x.id||(typeof matchLocation==='function'&&(x.floor||x.area)&&matchLocation(t,lq))));
    const st=(db.stock||[]).filter(s=>String(s.projectId)===String(x.projectId)&&(x.floor||x.area)&&typeof matchLocation==='function'&&matchLocation({...s,building:typeof stockBld==='function'?stockBld(s):s.building},lq));
    const extra=document.createElement('div');extra.className='rw-extra';
    extra.innerHTML=`<div class="boq-dt-grid"><div class="boq-dt-cell"><small>Specification</small><b>${esc(x.spec||'—')}</b></div><div class="boq-dt-cell"><small>Start</small><b>${esc(x.startDate||'—')}</b></div><div class="boq-dt-cell"><small>Finish</small><b>${esc(x.endDate||'—')}</b></div></div>${x.notes?`<p class="muted">📝 ${esc(x.notes)}</p>`:''}
    <b>Progress history</b><table class="table"><thead><tr><th>Date</th><th>Qty</th><th>By</th><th>Note</th></tr></thead><tbody>${log.map(p=>`<tr><td>${esc(p.date)}</td><td>+${fmt(p.qty)} ${esc(x.unit||'')}</td><td>${esc(p.by||'')}${p.source==='foreman'?' <span class="pill">Foreman</span>':''}</td><td>${esc(p.note||'')}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">No dated progress entries yet.</td></tr>'}</tbody></table>
    <b>Materials / labour / cost at this room</b><div class="muted" style="margin:4px 0 8px">Material out: ${fmt(st.filter(s=>s.direction==='Out').reduce((n,s)=>n+num(s.qty),0))} · Cost entries: ${tx.length} · ${money(tx.reduce((n,t)=>n+num(t.amount),0))}</div>
    <b>Attachments</b><div class="rw-att">${(x.attachments||[]).map((f,ix)=>`<a href="${esc(f.data)}" download="${esc(f.name)}" target="_blank">📎 ${esc(f.name)}</a>`).join('')||'<span class="muted">None</span>'}</div>
    ${canEdit()?`<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px"><button type="button" class="btn" onclick="pbRoomInfo('${esc(x.id)}')">Edit specs, dates, notes &amp; files</button></div>`:''}`;
    host.insertBefore(extra,host.querySelector('.boq-dt-status'));
  };
  window.pbRoomInfo=function(id){
    const x=(db.boq||[]).find(b=>b.id===id);if(!x||!canEdit())return;
    openModal(`${x.boqId||'Item'} · Specs & notes`,`<div class="formgrid"><div class="field full"><label>Specification</label><input id="rwSpec" maxlength="300" value="${esc(x.spec||'')}"></div><div class="field"><label>Start date</label><input id="rwStart" type="date" value="${esc(x.startDate||'')}"></div><div class="field"><label>Finish date</label><input id="rwEnd" type="date" value="${esc(x.endDate||'')}"></div><div class="field full"><label>Notes / remarks</label><textarea id="rwNotes" maxlength="1000">${esc(x.notes||'')}</textarea></div><div class="field full"><label>Add attachment (max 400 KB each)</label><input id="rwFile" type="file" multiple accept="image/*,.pdf"></div></div>`,async()=>{
      const s=document.getElementById('rwStart').value,e=document.getElementById('rwEnd').value;
      if(s&&e&&e<s){toast('Finish date cannot be before start date');return false}
      const files=[...(document.getElementById('rwFile').files||[])];
      for(const f of files)if(f.size>400*1024){toast(`${f.name} is larger than 400 KB`);return false}
      const read=f=>new Promise(r=>{const fr=new FileReader();fr.onload=()=>r({name:f.name,data:fr.result,at:new Date().toISOString()});fr.readAsDataURL(f)});
      const added=await Promise.all(files.map(read));
      x.spec=document.getElementById('rwSpec').value.trim();x.startDate=s;x.endDate=e;x.notes=document.getElementById('rwNotes').value.trim();
      if(added.length)x.attachments=[...(x.attachments||[]),...added];
      save();toast('Saved');render();back();return true});
  };
  window.pbRoomProgress=function(id){
    const x=(db.boq||[]).find(b=>b.id===id);if(!x)return;
    const q=num(x.qty),d=num(x.executedQty),left=Math.max(0,q-d);
    if(!['Approved','Revised'].includes(boqStatus(x))){toast('Approve this BOQ item before adding progress');return}
    openModal(`${x.boqId||'Item'} · Add Progress`,`<p class="muted">${esc(x.description||'')} — done ${fmt(d)} of ${fmt(q)} ${esc(x.unit||'')}, remaining <b>${fmt(left)}</b></p><div class="formgrid"><div class="field"><label>Date *</label><input id="rwPDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div><div class="field"><label>Quantity done today (${esc(x.unit||'')}) *</label><input id="rwPQty" type="number" min="0" step="0.001" max="${left}"></div><div class="field full"><label>Note</label><input id="rwPNote" maxlength="300"></div></div>`,()=>{
      const date=document.getElementById('rwPDate').value,qty=Number(document.getElementById('rwPQty').value);
      if(!date){toast('Select a date');return false}
      if(!(qty>0)){toast('Enter a quantity above 0');return false}
      if(qty>left+1e-9){toast(`Only ${fmt(left)} ${x.unit||''} remaining`);return false}
      x.progressLog=[...(x.progressLog||[]),{id:'pg_'+Date.now().toString(36),date,qty,by:typeof boqWho==='function'?boqWho():'Office',note:document.getElementById('rwPNote').value.trim(),source:'office',at:new Date().toISOString()}];
      x.executedQty=d+qty;save();toast('Progress saved');render();back();return true});
  };
  const css=document.createElement('style');css.textContent=`.rw-wide{max-width:min(1180px,96vw)!important;width:96vw}.rw-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}.rw-head h3{margin:2px 0;font-size:22px}.rw-kpi{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:12px 0 8px}.rw-k{border:1px solid #e3e8ef;border-radius:10px;padding:10px;background:#f8fafc}.rw-k small{display:block;color:#64748b}.rw-k b{font-size:18px}.rw-bar{height:6px;background:#e5e7eb;border-radius:9px;overflow:hidden;min-width:70px}.rw-bar.big{height:9px;margin-bottom:12px}.rw-bar i{display:block;height:100%;background:#16a34a}.rw-act{display:flex;gap:4px;flex-wrap:wrap}.rw-extra{margin:10px 0}.rw-att{display:flex;gap:10px;flex-wrap:wrap;margin:4px 0}@media(max-width:700px){.rw-kpi{grid-template-columns:repeat(2,1fr)}}`;document.head.appendChild(css);
})();
