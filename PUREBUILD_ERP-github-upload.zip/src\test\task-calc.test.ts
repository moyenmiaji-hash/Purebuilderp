import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

// The office app is plain JS in public/app; load the formula file the same way the browser does.
const src = readFileSync(path.resolve(__dirname, "../../public/app/task-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const calc = box["PB_TASK_CALC"];

const task = (over: Record<string, unknown> = {}) => ({
  id: "t1", assigned_to: "f1", status: "in_progress", start_date: "2026-10-20", due_date: "2026-10-24",
  target_qty: 100, unit: "m³", period: "daily", period_target: 20, category: "Concrete", ...over,
});
const up = (over: Record<string, unknown>) => ({ task_id: "t1", review_status: "approved", reported_qty: 0, approved_qty: 0, ...over });

describe("foreman task formulas", () => {
  it("note example: 100 m³ target, 20 m³ daily, 15 approved today → 75% daily, 85 remaining", () => {
    const s = calc.taskStats(task(), [up({ report_date: "2026-10-22", reported_qty: 15, approved_qty: 15 })], "2026-10-22");
    expect(s.dailyPct).toBe(75);
    expect(s.remaining).toBe(85);
    expect(s.overallPct).toBe(15);
  });

  it("reported quantity stays separate from approved quantity", () => {
    const s = calc.taskStats(task(), [up({ report_date: "2026-10-21", review_status: "submitted", reported_qty: 30 })], "2026-10-22");
    expect(s.reported).toBe(30);
    expect(s.approved).toBe(0);
  });

  it("remaining never goes negative and over-target is flagged", () => {
    const s = calc.taskStats(task(), [up({ report_date: "2026-10-21", reported_qty: 120, approved_qty: 120 })], "2026-10-22");
    expect(s.remaining).toBe(0);
    expect(s.over).toBe(true);
  });

  it("overdue = due date passed and not completed", () => {
    expect(calc.taskStats(task(), [], "2026-10-25").overdue).toBe(true);
    expect(calc.taskStats(task({ status: "completed" }), [], "2026-10-25").overdue).toBe(false);
  });

  it("missing reports are counted separately, not as missed targets", () => {
    const s = calc.taskStats(task(), [up({ report_date: "2026-10-20", reported_qty: 10, approved_qty: 10 })], "2026-10-23");
    expect(s.missingReports).toBe(2);
    expect(s.missedTargets).toBe(1);
  });

  it("No Data instead of 0% when there is nothing to divide by", () => {
    expect(calc.pct(0, 0)).toBeNull();
    expect(calc.dashboardKpis([], [], "2026-10-22").avgAchievement).toBeNull();
  });

  it("cancelled tasks are left out of dashboard totals", () => {
    const k = calc.dashboardKpis([task(), task({ id: "t2", status: "cancelled" })], [], "2026-10-22");
    expect(k.total).toBe(1);
  });

  it("different units are never added together in a foreman's period", () => {
    const tasks = [task(), task({ id: "t2", unit: "kg", category: "Steel" })];
    const r = calc.foremanPeriod(tasks, [], "f1", "2026-10-20", "2026-10-21", "2026-10-22");
    expect(r.groups).toHaveLength(2);
  });

  it("target achievement = approved ÷ planned × 100", () => {
    const r = calc.foremanPeriod([task()], [up({ report_date: "2026-10-20", reported_qty: 20, approved_qty: 20 }), up({ report_date: "2026-10-21", reported_qty: 10, approved_qty: 10 })], "f1", "2026-10-20", "2026-10-21", "2026-10-22");
    expect(r.groups[0].achievement).toBe(75);
  });
});

describe("BOQ balance on the task form", () => {
  const C2 = box["PB_TASK_CALC"];
  it("outstanding = BOQ qty − done − other tasks − this target", () => {
    const b = C2.boqTaskBalance(100, 20, 30, 25);
    expect(b.available).toBe(50);
    expect(b.outstanding).toBe(25);
    expect(b.over).toBe(0);
  });
  it("flags a target bigger than what is left", () => {
    const b = C2.boqTaskBalance(100, 20, 30, 60);
    expect(b.outstanding).toBe(0);
    expect(b.over).toBe(10);
  });
});

describe("task performance reports", () => {
  const ups = [
    up({ id: "u1", report_date: "2026-10-21", reported_qty: 18, approved_qty: 15, workers: 5, work_hours: 8 }),
    up({ id: "u2", report_date: "2026-10-22", reported_qty: 20, approved_qty: null, review_status: "submitted", workers: 4, work_hours: 8 }),
    up({ id: "u3", report_date: "2026-10-23", reported_qty: 30, approved_qty: null, review_status: "rejected", workers: 6, work_hours: 8 }),
  ];
  it("daily target vs actual: 15 approved of 20 daily target = 75%; waiting qty is not actual; returned report ignored", () => {
    const rows = calc.dailyRows([task()], ups, "2026-10-20", "2026-10-24");
    expect(rows.length).toBe(2);
    const d21 = rows.find((r: any) => r.date === "2026-10-21");
    expect(d21.approved).toBe(15);
    expect(d21.achievement).toBe(75);
    const d22 = rows.find((r: any) => r.date === "2026-10-22");
    expect(d22.approved).toBe(0);
    expect(d22.pending).toBe(20);
  });
  it("worker productivity uses approved reports only: 15 m³ ÷ 5 workers = 3 per worker-day, 15 ÷ 40 man-hours", () => {
    const [p] = calc.productivity([task()], ups, "2026-10-20", "2026-10-24");
    expect(p.workerDays).toBe(5);
    expect(p.perWorker).toBe(3);
    expect(p.perHour).toBeCloseTo(0.375);
  });
  it("project completion = approved ÷ target, capped at 100%", () => {
    const [p] = calc.projectRows([task({ project_id: "P1" })], [up({ report_date: "2026-10-21", approved_qty: 150 })], "2026-10-22");
    expect(p.completion).toBe(100);
    const [q] = calc.projectRows([task({ project_id: "P1" })], ups, "2026-10-22");
    expect(q.completion).toBe(15);
  });
});
