// Foreman phone: "My Tasks" tab. Shows only tasks assigned to the signed-in foreman (Cloud rules enforce this).
// Sends daily quantity, notes, delay reason, problems and photos. The office approves; the foreman can never approve.
(function () {
  const $ = (id) => document.getElementById(id);
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const Q = (n) => (n == null ? "—" : Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 }));
  const C = () => window.PB_TASK_CALC;
  const DELAYS = [["", "No delay"], ["material", "Material shortage"], ["labour", "Not enough workers"], ["equipment", "Equipment failure"], ["weather", "Weather"], ["design", "Design change"], ["client", "Client instruction"], ["other", "Other reason"]];
  const PROBLEMS = ["Labour shortage", "Material shortage", "Equipment problem", "Other blocker"];
  const ST = { assigned: ["New", "amber"], in_progress: ["In Progress", "green"], submitted: ["Waiting approval", "amber"], rejected: ["Returned — fix & resend", "red"], completed: ["Completed", "green"], cancelled: ["Cancelled", ""] };
  const s = { tasks: [], updates: [], tab: "open", open: "", loading: false, msg: "" };
  const cl = () => window.PB_STAFF_CLIENT;
  const today = () => C().dubaiToday();

  const sec = document.createElement("section");
  sec.className = "card"; sec.dataset.tab = "tasks";
  sec.innerHTML = `<div class="body"><div class="section-title"><span>✅</span><h2>My Tasks</h2></div><div id="mt-body"><p class="hint">Loading…</p></div></div>`;
  (document.querySelector('[data-tab="home"]') || $("report-form"))?.before(sec);
  const css = document.createElement("style");
  css.textContent = `.mt-chips{display:flex;gap:6px;overflow-x:auto;margin:0 0 10px}.mt-chips button{flex:0 0 auto;border:1px solid #35527a;background:#1b3150;color:#c2d2e3;border-radius:999px;padding:6px 12px;font-size:12px;font-weight:800}.mt-chips button.on{background:#2f7fd8;color:#fff;border-color:#2f7fd8}
  .mt-card{display:block;width:100%;text-align:left;border:1px solid #2a4163;background:#0f1c2e;color:#e3edf8;border-radius:14px;padding:12px;margin:0 0 9px;font:inherit}.mt-card b{font-size:15px}.mt-card small{display:block;color:#9fb3c8;font-size:12px;margin-top:2px}
  .mt-row{display:flex;justify-content:space-between;gap:8px;align-items:center}.mt-bar{height:7px;border-radius:9px;background:#2a4163;overflow:hidden;margin:8px 0 4px}.mt-bar i{display:block;height:100%;background:#22c55e}
  .mt-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin:10px 0}.mt-grid div{border:1px solid #2a4163;border-radius:10px;padding:7px;text-align:center}.mt-grid small{display:block;font-size:10px;color:#9fb3c8}.mt-grid b{font-size:15px}
  .mt-box{border:1px solid #2a4163;border-radius:12px;padding:10px;margin:8px 0;font-size:13px;color:#d6e2ef}.mt-box h4{margin:0 0 4px;font-size:13px}
  .mt-probs{display:flex;flex-wrap:wrap;gap:6px}.mt-probs label{border:1px solid #35527a;border-radius:999px;padding:5px 10px;font-size:12px;display:flex;gap:5px;align-items:center}
  .mt-thumbs{display:flex;gap:6px;flex-wrap:wrap}.mt-thumbs img{width:56px;height:56px;object-fit:cover;border-radius:8px}
  .mt-msg{min-height:1em;font-size:13px;margin:6px 0}.mt-msg.bad{color:#fca5a5}.mt-msg.good{color:#86efac}
  .mt-hist{border-left:3px solid #2f7fd8;padding:4px 10px;margin:6px 0;font-size:12.5px}
  #mt-body input[type=checkbox]{width:18px!important;height:18px!important;min-height:0!important;min-width:0!important;flex:0 0 18px;margin:0;padding:0;accent-color:#2f7fd8}.mt-check{display:flex!important;gap:8px;align-items:center;font-weight:600;font-size:13px;margin:6px 0}`;
  document.head.append(css);

  async function load() {
    const c = cl(); const prof = window.PB_STAFF_PROFILE;
    if (!c || !prof) { s.msg = "Sign in first."; return; }
    s.loading = true;
    const [t, u] = await Promise.all([
      c.from("foreman_tasks").select("*, team_projects(name)").eq("assigned_to", prof.id).order("due_date"),
      c.from("foreman_task_updates").select("*").order("report_date", { ascending: false }),
    ]);
    s.loading = false;
    if (t.error || u.error) { s.msg = (t.error || u.error).message; return; }
    s.tasks = t.data || []; s.updates = u.data || []; s.msg = "";
  }
  const stat = (t) => C().taskStats(t, s.updates, today());

  function list() {
    const td = today();
    const by = { open: (t) => !["completed", "cancelled"].includes(t.status), today: (t) => t.start_date <= td && t.due_date >= td && !["completed", "cancelled"].includes(t.status), overdue: (t) => stat(t).overdue, done: (t) => ["completed", "cancelled"].includes(t.status), all: () => true };
    const count = (k) => s.tasks.filter(by[k]).length;
    const rows = s.tasks.filter(by[s.tab]);
    $("mt-body").innerHTML = `${s.msg ? `<p class="mt-msg bad">${E(s.msg)}</p>` : ""}
      <div class="mt-chips">${[["open", "Open"], ["today", "Today"], ["overdue", "Overdue"], ["done", "Done"], ["all", "All"]].map(([k, l]) => `<button type="button" class="${s.tab === k ? "on" : ""}" data-mt-tab="${k}">${l} (${count(k)})</button>`).join("")}</div>
      ${rows.map((t) => { const x = stat(t), [l, c] = ST[t.status] || [t.status, ""], w = Math.min(100, x.overallPct || 0); return `<button type="button" class="mt-card" data-mt-open="${t.id}"><div class="mt-row"><b>${E(t.title)}</b><span class="pill ${c}">${l}</span></div><small>${E(t.team_projects?.name || "Site")}${t.building ? " · " + E(t.building) : ""}${t.floor ? " · " + E(t.floor) : ""}</small><div class="mt-bar"><i style="width:${w}%"></i></div><div class="mt-row"><small>${Q(x.approved)} / ${Q(t.target_qty)} ${E(t.unit)} approved · ${Q(x.remaining)} left</small><small>${x.overdue ? '<span class="pill red">Overdue</span>' : `Due ${E(t.due_date)}`}</small></div><small>Priority: ${E(t.priority)} · Today target: ${Q(C().dailyTarget(t))} ${E(t.unit)}</small></button>`; }).join("") || `<p class="hint">${s.tasks.length ? "No task in this list." : "No task assigned to you yet. The office will assign tasks here."}</p>`}
      <button type="button" class="btn" style="width:100%" data-mt-reload>⟳ Refresh</button>`;
  }

  async function detail(id) {
    const t = s.tasks.find((x) => x.id === id); if (!t) return list();
    const x = stat(t), ups = s.updates.filter((u) => u.task_id === id), td = today();
    const closed = ["completed", "cancelled"].includes(t.status);
    const sentToday = ups.some((u) => u.report_date === td && u.review_status !== "rejected");
    const key = `mt-${id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    let urls = {};
    const paths = [...(t.attachments || []), ...ups.flatMap((u) => u.photos || [])].map((p) => p.path).filter(Boolean);
    if (paths.length) { const { data } = await cl().storage.from("site-progress-photos").createSignedUrls(paths, 600); (data || []).forEach((d) => { if (d.signedUrl) urls[d.path] = d.signedUrl; }); }
    const [l, c] = ST[t.status] || [t.status, ""];
    $("mt-body").innerHTML = `<button type="button" class="btn" data-mt-back>‹ My Tasks</button>
      <h3 style="margin:10px 0 2px">${E(t.title)}</h3><small style="color:#9fb3c8">${E(t.team_projects?.name || "Site")} ${t.building ? "· " + E(t.building) : ""} ${t.floor ? "· " + E(t.floor) : ""} ${t.location ? "· " + E(t.location) : ""}</small>
      <div style="margin:6px 0"><span class="pill ${c}">${l}</span> ${x.overdue ? '<span class="pill red">Overdue</span>' : ""} <span class="pill">${E(t.priority)}</span></div>
      <div class="mt-grid"><div><small>Target</small><b>${Q(t.target_qty)}</b><small>${E(t.unit)}</small></div><div><small>Approved</small><b>${Q(x.approved)}</b><small>${x.pending ? "+ waiting" : "&nbsp;"}</small></div><div><small>Left</small><b>${Q(x.remaining)}</b><small>${E(t.unit)}</small></div>
        <div><small>Daily target</small><b>${Q(C().dailyTarget(t))}</b></div><div><small>Start</small><b style="font-size:12px">${E(t.start_date)}</b></div><div><small>Due</small><b style="font-size:12px">${E(t.due_date)}</b></div></div>
      ${t.description ? `<div class="mt-box"><h4>Instructions</h4>${E(t.description)}</div>` : ""}
      ${t.acceptance_criteria ? `<div class="mt-box"><h4>Work is accepted when</h4>${E(t.acceptance_criteria)}</div>` : ""}
      ${t.required_labour || t.required_materials ? `<div class="mt-box"><h4>Needed</h4>${t.required_labour ? `Workers: ${E(t.required_labour)}<br>` : ""}${E(t.required_materials || "")}</div>` : ""}
      ${(t.attachments || []).length ? `<div class="mt-box"><h4>Drawings / files</h4><div class="mt-thumbs">${t.attachments.map((a) => urls[a.path] ? (/^image\//.test(a.content_type || "") ? `<a href="${urls[a.path]}" target="_blank" rel="noopener"><img src="${urls[a.path]}" alt="${E(a.name)}"></a>` : `<a href="${urls[a.path]}" target="_blank" rel="noopener" style="color:#93c5fd">📄 ${E(a.name)}</a>`) : "").join("")}</div></div>` : ""}
      ${t.status === "assigned" ? `<button type="button" class="submit" data-mt-start="${id}">▶ Start Work</button>` : ""}
      ${!closed && t.status !== "assigned" ? (sentToday ? `<div class="mt-box">Today's update is already sent. You can send the next one tomorrow${ups.find((u) => u.report_date === td)?.review_status === "submitted" ? " — the office is checking it" : ""}.</div>` : `
      <form id="mt-form" class="mt-box"><h4>Send today's progress</h4>
        <div class="field"><label>Date</label><input class="input" type="date" name="report_date" value="${td}" max="${td}" min="${E(t.start_date)}" required></div>
        <div class="field"><label>Work done (${E(t.unit)})</label><input class="input" type="number" name="reported_qty" min="0" step="any" inputmode="decimal" required placeholder="e.g. ${Q(C().dailyTarget(t))}">
          <div class="mt-chips">${[["Today target", C().dailyTarget(t)], ["Half", Math.round((C().dailyTarget(t) / 2) * 100) / 100], ["All left", x.remaining]].filter((c) => c[1] > 0).map(([l, v]) => `<button type="button" class="mt-chip" data-mt-q="${v}">${l} · ${Q(v)}</button>`).join("")}</div>
          <div class="mt-live" id="mt-live"><div class="mt-bar"><i id="mt-live-bar" style="width:${Math.min(100, x.overallPct || 0)}%"></i></div><small id="mt-live-t">Type the quantity to see progress.</small></div></div>
        <div class="mt-two" style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><div class="field"><label>Workers today</label><input class="input" type="number" name="workers" min="0" step="1" inputmode="numeric" placeholder="e.g. 6"></div><div class="field"><label>Working hours</label><input class="input" type="number" name="work_hours" min="0" max="24" step="0.5" inputmode="decimal" placeholder="e.g. 8"></div></div>
        <div class="field"><label>Note</label><textarea class="input" name="note" rows="2" placeholder="What was done today?"></textarea></div>
        <div class="field"><label>Delay reason (if behind)</label><select class="input" name="delay_reason">${DELAYS.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select><label class="mt-check"><input type="checkbox" name="delay_external"> This delay was outside my control</label></div>
        <div class="field"><label>Problems on site</label><div class="mt-probs">${PROBLEMS.map((p) => `<label><input type="checkbox" name="blockers" value="${p}"> ${p}</label>`).join("")}</div></div>
        <div class="field"><label>Site photos (max 5)</label><input class="input" type="file" name="photos" accept="image/*" multiple capture="environment"><div class="mt-thumbs" id="mt-prev"></div></div>
        <label class="mt-check" style="margin:4px 0 10px"><input type="checkbox" name="ask_complete"> The whole task is finished</label>
        <p class="mt-msg" id="mt-msg"></p>
        <button class="submit" type="submit">Submit for approval</button>
        <p class="hint">The office checks and approves it. Only approved quantity counts.</p>
      </form>`) : ""}
      <div class="mt-box"><h4>My submissions</h4>${ups.map((u) => `<div class="mt-hist"><b>${E(u.report_date)}</b> · ${Q(u.reported_qty)} ${E(t.unit)} · <span class="pill ${u.review_status === "approved" ? "green" : u.review_status === "rejected" ? "red" : "amber"}">${u.review_status === "approved" ? `Approved ${Q(u.approved_qty)}` : u.review_status === "rejected" ? "Returned — please correct and send again" : "Waiting"}</span>${u.workers != null || u.work_hours != null ? ` · 👷 ${u.workers ?? "—"} × ${u.work_hours ?? "—"} hrs` : ""}${u.review_note ? `<div>Office: ${E(u.review_note)}</div>` : ""}${(u.photos || []).length ? `<div class="mt-thumbs">${u.photos.map((p) => urls[p.path] ? `<img src="${urls[p.path]}" alt="photo">` : "").join("")}</div>` : ""}</div>`).join("") || '<p class="hint">Nothing sent yet.</p>'}</div>`;
    const f = $("mt-form"); if (!f) return;
    const live = () => { const q = Number(f.reported_qty.value) || 0, tg = Number(t.target_qty) || 0, done = Number(x.approved) || 0, p = tg ? Math.min(100, ((done + q) / tg) * 100) : 0;
      $("mt-live-bar").style.width = p + "%"; $("mt-live-t").innerHTML = q > 0 ? `After approval: <b>${Q(done + q)} / ${Q(tg)} ${E(t.unit)}</b> · ${Math.round(p)}% done${q > x.remaining ? ' · <span style="color:#f87171">more than left</span>' : ""}` : "Type the quantity to see progress."; };
    f.reported_qty.oninput = live;
    f.querySelectorAll("[data-mt-q]").forEach((b) => (b.onclick = () => { f.reported_qty.value = b.dataset.mtQ; live(); }));
    if (!document.getElementById("mt-chip-css")) { const s = document.createElement("style"); s.id = "mt-chip-css"; s.textContent = `.mt-chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.mt-chip{border:0;border-radius:20px;padding:7px 12px;font-weight:700;font-size:12px;background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;box-shadow:0 3px 8px rgba(99,102,241,.3)}.mt-chip:active{transform:scale(.96)}.mt-live{margin-top:10px;padding:10px;border-radius:12px;background:rgba(99,102,241,.1)}.mt-live small{display:block;margin-top:6px}`; document.head.appendChild(s); }
    f.photos.onchange = () => { $("mt-prev").innerHTML = [...f.photos.files].slice(0, 5).map((file) => `<img src="${URL.createObjectURL(file)}" alt="preview">`).join(""); };
    f.onsubmit = async (e) => {
      e.preventDefault();
      const msg = $("mt-msg"), btn = f.querySelector('[type="submit"]');
      const qty = Number(f.reported_qty.value);
      if (!(qty >= 0) || f.reported_qty.value === "") { msg.className = "mt-msg bad"; msg.textContent = "Enter the work done (0 or more)."; return; }
      if (f.report_date.value > td) { msg.className = "mt-msg bad"; msg.textContent = "Date cannot be in the future."; return; }
      if (qty < C().dailyTarget(t) && !f.delay_reason.value && !f.note.value.trim()) { msg.className = "mt-msg bad"; msg.textContent = "You are below today's target. Please choose a delay reason or write a note."; return; }
      btn.disabled = true; btn.textContent = "Sending…"; msg.textContent = "";
      try {
        const photos = [];
        for (const [i, file] of [...f.photos.files].slice(0, 5).entries()) {
          const small = await shrink(file);
          const path = `${window.PB_STAFF_PROFILE.organization_id}/${t.project_id}/task-${t.id}/${key}-${i}.jpg`;
          const { error } = await cl().storage.from("site-progress-photos").upload(path, small, { contentType: "image/jpeg", upsert: false });
          if (error) throw new Error("Photo could not upload: " + error.message);
          photos.push({ path, name: file.name, content_type: "image/jpeg", size: small.size });
        }
        const p = { report_date: f.report_date.value, reported_qty: qty, note: f.note.value, delay_reason: f.delay_reason.value, delay_external: f.delay_external.checked,
          blockers: [...f.querySelectorAll('[name="blockers"]:checked')].map((x) => x.value), photos, ask_complete: f.ask_complete.checked, unit: t.unit, idempotency_key: key };
        const { data: sent, error } = await cl().rpc("submit_foreman_task_update", { p_task: t.id, p });
        if (error) throw error;
        const wk = f.workers.value, hr = f.work_hours.value;
        if (sent?.updateId && !sent.duplicate && (wk !== "" || hr !== "")) {
          const r = await cl().rpc("set_task_update_labour", { p_update: sent.updateId, p_workers: wk === "" ? null : Math.round(Number(wk)), p_hours: hr === "" ? null : Number(hr) });
          if (r.error) console.warn("Workers/hours not saved", r.error);
        }
        await load(); detail(id);
        setTimeout(() => { const m = $("mt-body"); m?.insertAdjacentHTML("afterbegin", '<p class="mt-msg good">✓ Sent. The office will check it.</p>'); }, 0);
      } catch (err) { msg.className = "mt-msg bad"; msg.textContent = String(err.message || err).replace(/^.*?ERROR:\s*/, ""); btn.disabled = false; btn.textContent = "Submit for approval"; }
    };
  }
  async function shrink(file) {
    try {
      const img = await createImageBitmap(file); const max = 1600, r = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas"); cv.width = Math.round(img.width * r); cv.height = Math.round(img.height * r);
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      const blob = await new Promise((res) => cv.toBlob(res, "image/jpeg", 0.75));
      return blob || file;
    } catch { return file; }
  }

  document.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-mt-tab],[data-mt-open],[data-mt-back],[data-mt-reload],[data-mt-start],[data-go='tasks']");
    if (!b) return;
    if (b.dataset.go === "tasks") { s.open = ""; $("mt-body").innerHTML = '<p class="hint">Loading…</p>'; await load(); list(); return; }
    if (b.dataset.mtTab) { s.tab = b.dataset.mtTab; list(); }
    else if (b.dataset.mtOpen) { s.open = b.dataset.mtOpen; detail(s.open); }
    else if (b.hasAttribute("data-mt-back")) { s.open = ""; list(); }
    else if (b.hasAttribute("data-mt-reload")) { await load(); list(); }
    else if (b.dataset.mtStart) {
      b.disabled = true;
      const { error } = await cl().rpc("start_foreman_task", { p_task: b.dataset.mtStart });
      if (error) { alert(error.message); b.disabled = false; return; }
      await load(); detail(b.dataset.mtStart);
    }
  });

  // ---- Task notifications: new tasks pop up; "OK" puts the BOQ work item into the New Entry box. ----
  // Seen/dismissed state is phone-local only; nothing in Cloud changes until the foreman submits the entry.
  const SEEN = "PB_TASK_NOTI_SEEN";
  const seen = () => { try { return JSON.parse(localStorage.getItem(SEEN) || "[]"); } catch { return []; } };
  const markSeen = (id) => { const a = seen(); if (!a.includes(id)) { a.push(id); localStorage.setItem(SEEN, JSON.stringify(a.slice(-500))); } };
  const active = () => s.tasks.filter((t) => !["completed", "cancelled"].includes(t.status));
  const fresh = () => active().filter((t) => !seen().includes(t.id));
  const nc = document.createElement("style");
  nc.textContent = `#mt-noti{position:fixed;left:10px;right:10px;top:10px;z-index:9999;display:flex;flex-direction:column;gap:8px;max-height:70vh;overflow:auto}
  .mt-n{background:#10233d;border:1px solid #2f7fd8;border-radius:14px;padding:12px;color:#e3edf8;box-shadow:0 10px 30px rgba(0,0,0,.45);font-size:13px}
  .mt-n b{display:block;font-size:14px;margin-bottom:2px}.mt-n small{color:#9fb3c8}.mt-n .mt-row{margin-top:8px;justify-content:flex-end}
  .mt-n button{border:0;border-radius:10px;padding:8px 12px;font-weight:800;font-size:12.5px}.mt-n .ok{background:#22c55e;color:#06210f}.mt-n .later{background:#2a4163;color:#dbe7f5}
  .mt-bell{position:relative;border:1px solid #35527a;background:#1b3150;color:#e3edf8;border-radius:999px;padding:6px 12px;font-weight:800;font-size:12px;margin:0 0 10px}
  .mt-bell em{font-style:normal;background:#ef4444;color:#fff;border-radius:999px;padding:0 6px;margin-left:4px}`;
  document.head.append(nc);
  const box = document.createElement("div"); box.id = "mt-noti"; document.body.append(box);
  const card = (t) => `<div class="mt-n"><b>🔔 New task: ${E(t.title)}</b><small>${E(t.team_projects?.name || "Site")}${t.building ? " · " + E(t.building) : ""}${t.floor ? " · " + E(t.floor) : ""} · ${Q(t.target_qty)} ${E(t.unit)} · Due ${E(t.due_date)}</small>
    <div class="mt-row"><button type="button" class="later" data-mtn-later="${t.id}">Later</button><button type="button" class="ok" data-mtn-ok="${t.id}">OK — add to entry</button></div></div>`;
  function popup(list) { box.innerHTML = list.map(card).join(""); }
  function bell() {
    const body = $("mt-body"); if (!body || s.open || !active().length || body.querySelector(".mt-bell")) return;
    const n = fresh().length;
    body.insertAdjacentHTML("afterbegin", `<button type="button" class="mt-bell" data-mtn-all>🔔 Task notifications${n ? `<em>${n}</em>` : ""} — add a task to today's entry</button>`);
  }
  new MutationObserver(bell).observe($("mt-body"), { childList: true });

  async function addToEntry(id) {
    const t = s.tasks.find((x) => x.id === id); if (!t) return;
    markSeen(id); box.innerHTML = "";
    document.querySelector('[data-go="report"]')?.click();
    const proj = $("project");
    if (proj && proj.value !== t.project_id && [...proj.options].some((o) => o.value === t.project_id)) {
      proj.value = t.project_id; proj.dispatchEvent(new Event("change", { bubbles: true }));
    }
    if (!t.boq_item_id) { note(`Task "${t.title}" has no BOQ item. Add the work manually.`, "error"); return; }
    for (let i = 0; i < 40; i++) {
      const sels = [...document.querySelectorAll("#boq-progress-lines [data-boq-item]")];
      if (sels.some((x) => x.value === t.boq_item_id)) { note("This task is already in today's entry."); return; }
      if (sels.length && sels[0].querySelector(`option[value="${t.boq_item_id}"]`)) {
        let sel = sels.find((x) => !x.value);
        if (!sel) { $("add-boq-progress")?.click(); sel = [...document.querySelectorAll("#boq-progress-lines [data-boq-item]")].pop(); }
        sel.value = t.boq_item_id; sel.dispatchEvent(new Event("change", { bubbles: true }));
        const q = sel.closest(".report-item")?.querySelector("[data-today]");
        if (q) { q.placeholder = `Today target ${Q(C().dailyTarget(t))}`; q.focus(); }
        note(`✓ "${t.title}" added. Enter today's quantity, add anything else, then submit.`, "success"); return;
      }
      await new Promise((r) => setTimeout(r, 200));
    }
    note("This task's BOQ item is not open at this site/location. Pick the location or add the work manually.", "error");
  }
  function note(msg, type = "success") { const n = $("notice"); if (n) { n.textContent = msg; n.className = `notice show ${type}`; } }

  async function check() {
    if (!cl() || !window.PB_STAFF_PROFILE) return;
    await load();
    const f = fresh();
    if (f.length) {
      popup(f);
      try { if ("Notification" in window && Notification.permission === "granted" && document.hidden) new Notification("PURE_BUILD — new task", { body: f.map((t) => t.title).join(", ") }); } catch {}
    }
    if (document.querySelector('[data-tab="tasks"]:not([hidden])') && !s.open) list();
  }
  document.addEventListener("click", (e) => {
    const b = e.target.closest("[data-mtn-ok],[data-mtn-later],[data-mtn-all]"); if (!b) return;
    if (b.dataset.mtnOk) addToEntry(b.dataset.mtnOk);
    else if (b.dataset.mtnLater) { markSeen(b.dataset.mtnLater); b.closest(".mt-n")?.remove(); bell(); }
    else { try { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); } catch {} popup(active()); }
  });
  let tries = 0;
  const boot = setInterval(() => { if (cl() && window.PB_STAFF_PROFILE) { clearInterval(boot); check(); setInterval(check, 60000); } else if (++tries > 60) clearInterval(boot); }, 1000);
})();
