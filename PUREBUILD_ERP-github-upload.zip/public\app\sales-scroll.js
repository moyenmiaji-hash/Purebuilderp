/* Sales & Invoiced scroll layout: page scrolls normally, side menu stays fixed, main tables full width (no clipped columns). Display only. */
(function(){
  var B='html body.sales-mode';var P='html body.progress-mode';
  var css=`
html:has(body.sales-mode){overflow-x:hidden!important;overflow-y:auto!important;height:auto!important}
${B}{height:auto!important;min-height:100vh!important;overflow:visible!important}
${B} .app,${B} .main,${B} .content,${B} #view{height:auto!important;max-height:none!important;overflow:visible!important;zoom:1!important}
${B} .app{grid-template-rows:auto!important;min-height:100vh!important}
${B} .sidebar{position:sticky!important;top:0!important;height:100vh!important;max-height:100vh!important;align-self:start!important;overflow-y:auto!important}
${B} #view>*{flex:0 0 auto!important}
${B} #view .sov-main{grid-template-columns:minmax(0,1fr)!important}
${B} #view .sov-table{overflow:visible!important}
${B} #view .sov-wrap{max-height:none!important;overflow-x:auto!important;overflow-y:visible!important}
${B} #view .sov-wrap table{width:100%!important;min-width:0!important;table-layout:auto!important}
${B} #view .sov-wrap td{max-width:none!important;overflow:visible!important;text-overflow:clip!important}
${B} #view .sov-wrap td.sov-act{overflow:visible!important}
${B} #view .sov-wrap td{white-space:normal!important;word-break:normal!important;overflow-wrap:normal!important;hyphens:none!important}
${B} #view .sov-wrap td.r,${B} #view .sov-wrap td:first-child,${B} #view .sov-wrap td:nth-child(2){white-space:nowrap!important}
${B} #view .sov-wrap td .sales-status{display:inline-block!important;font-size:11px!important;line-height:1.3!important;padding:3px 9px!important;border-radius:999px!important;white-space:nowrap!important;font-weight:800!important;transform:none!important;zoom:1!important}
${B} #view .sov-side{max-height:none!important;overflow:visible!important;display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;align-items:stretch!important;gap:12px!important}
${B} #view .sov-side>*{margin:0!important;height:auto!important;min-height:100%!important;box-sizing:border-box!important}
${B} #view .sov-side .sov-det>.sov-pj{display:block}
${B} #view .sov-side .sov-det:not([open])>.sov-pj{display:block!important}
${B} #view .sov-side .sov-det{max-height:240px!important;overflow:auto!important}
${B} #view .sov-side .sov-det:not([open]){align-self:start}
${B} #view .sov-wrap thead th{top:0!important}
@media (max-width:1100px){${B} #view .sov-side{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
@media (max-width:760px){${B} #view .sov-side{grid-template-columns:1fr!important}}
body.dark-theme .sov-det summary,body.dark-theme .sov-qa h4{color:#e2ecf8!important}
html:has(body.progress-mode){overflow-x:hidden!important;overflow-y:auto!important;height:auto!important}
${P}{height:auto!important;min-height:100vh!important;overflow:visible!important}
${P} .app,${P} .main,${P} .content,${P} #view{height:auto!important;max-height:none!important;overflow:visible!important;zoom:1!important}
${P} .app{grid-template-rows:auto!important;min-height:100vh!important}
${P} .sidebar{position:sticky!important;top:0!important;height:100vh!important;max-height:100vh!important;align-self:start!important;overflow-y:auto!important}
${P} #view>*,${P} .main>*,${P} .content>*{flex:0 0 auto!important}
${P} .main,${P} .content,${P} #view{min-height:0!important;display:block!important}
${P} #view .progress-main-grid,${P} #view .progress-bottom-grid{height:auto!important;max-height:none!important;overflow:visible!important}
@media print{${B} .sidebar{position:static!important;height:auto!important}}
`;
  var s=document.createElement('style');s.id='pbSalesScroll';s.textContent=css;document.head.appendChild(s);
  function sync(){
    var t=document.getElementById('topTitle');
    var on=!!(t&&t.textContent==='Sales & Invoiced')||!!document.querySelector('#view .sov');
    document.body.classList.toggle('sales-mode',on);
  }
  function start(){
    sync();
    var v=document.getElementById('view');if(v)new MutationObserver(sync).observe(v,{childList:true});
    var t=document.getElementById('topTitle');if(t)new MutationObserver(sync).observe(t,{childList:true,characterData:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
/* keep Project Billing Summary open in the scroll layout (display only) */
(function(){function o(){document.querySelectorAll('body.sales-mode #view .sov-side details.sov-det:not([open])').forEach(function(d){if(!d.dataset.pbo){d.dataset.pbo=1;d.open=true}})}new MutationObserver(o).observe(document.documentElement,{childList:true,subtree:true});o()})();
