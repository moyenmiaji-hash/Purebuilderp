// Foreman task target/performance formulas. Pure functions only (no DOM, no Cloud) so they can be unit-tested.
(function (root) {
  const DAY = 86400000;
  const CLOSED = ["completed", "cancelled"];
  const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
  const dubaiToday = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Dubai" });
  const toDay = (s) => Date.parse(String(s).slice(0, 10) + "T00:00:00Z");
  const addDays = (s, n) => new Date(toDay(s) + n * DAY).toISOString().slice(0, 10);
  const daysBetween = (a, b) => Math.round((toDay(b) - toDay(a)) / DAY) + 1; // inclusive
  const pct = (part, whole) => (whole > 0 ? (part / whole) * 100 : null); // null = "No Data"

  // Planned quantity for one calendar day (0 outside start..due; cancelled tasks plan nothing).
  function dailyTarget(task) {
    const span = Math.max(1, daysBetween(task.start_date, task.due_date));
    const pt = task.period_target == null || task.period_target === "" ? null : num(task.period_target);
    if (task.period === "daily" && pt != null) return pt;
    if (task.period === "weekly" && pt != null) return pt / 7;
    return num(task.target_qty) / span;
  }
  function plannedOn(task, day) {
    if (task.status === "cancelled") return 0;
    if (day < task.start_date || day > task.due_date) return 0;
    return dailyTarget(task);
  }

  function taskUpdates(task, updates) { return (updates || []).filter((u) => u.task_id === task.id); }

  // Per-task numbers. Reported and approved quantities stay separate.
  function taskStats(task, updates, today = dubaiToday()) {
    const ups = taskUpdates(task, updates);
    const approved = ups.filter((u) => u.review_status === "approved").reduce((s, u) => s + num(u.approved_qty), 0);
    const reported = ups.filter((u) => u.review_status !== "rejected").reduce((s, u) => s + num(u.reported_qty), 0);
    const pending = ups.filter((u) => u.review_status === "submitted").length;
    const target = num(task.target_qty);
    const todayApproved = ups.filter((u) => u.review_status === "approved" && u.report_date === today).reduce((s, u) => s + num(u.approved_qty), 0);
    const todayPlanned = plannedOn(task, today);
    const lastDay = [today, task.due_date].sort()[0] < today ? task.due_date : addDays(today, -1);
    let workingDays = 0, missedTargets = 0, missingReports = 0;
    if (task.status !== "cancelled") {
      for (let d = task.start_date; d <= lastDay; d = addDays(d, 1)) {
        const dayUps = ups.filter((u) => u.report_date === d && u.review_status !== "rejected");
        if (!dayUps.length) { missingReports++; continue; } // missing report ≠ zero work
        workingDays++;
        const ok = dayUps.filter((u) => u.review_status === "approved").reduce((s, u) => s + num(u.approved_qty), 0);
        if (dayUps.every((u) => u.review_status === "approved") && ok < dailyTarget(task) - 1e-9) missedTargets++;
      }
    }
    return {
      target, approved, reported, pending,
      remaining: Math.max(0, target - approved),
      over: approved > target + 1e-9,
      overallPct: pct(approved, target),
      todayApproved, todayPlanned,
      dailyPct: todayPlanned > 0 && ups.some((u) => u.report_date === today && u.review_status === "approved") ? pct(todayApproved, todayPlanned) : null,
      overdue: !CLOSED.includes(task.status) && task.due_date < today,
      workingDays, missedTargets, missingReports,
      lastUpdate: ups.map((u) => u.created_at || u.report_date).sort().pop() || null,
      delayReason: ups.filter((u) => u.delay_reason).sort((a, b) => String(a.report_date).localeCompare(String(b.report_date))).pop()?.delay_reason || "",
    };
  }

  // Dashboard KPI boxes.
  function dashboardKpis(tasks, updates, today = dubaiToday()) {
    const live = tasks.filter((t) => t.status !== "cancelled");
    const stats = live.map((t) => taskStats(t, updates, today));
    const started = live.map((t, i) => [t, stats[i]]).filter(([t]) => t.start_date <= today);
    const pcts = started.map(([, s]) => s.overallPct).filter((x) => x != null).map((x) => Math.min(100, x));
    return {
      total: live.length,
      assigned: live.filter((t) => t.status === "assigned").length,
      inProgress: live.filter((t) => t.status === "in_progress" || t.status === "rejected").length,
      submitted: live.filter((t) => t.status === "submitted").length,
      completed: live.filter((t) => t.status === "completed").length,
      overdue: stats.filter((s) => s.overdue).length,
      avgAchievement: pcts.length ? pcts.reduce((a, b) => a + b, 0) / pcts.length : null,
      activeForemen: new Set(live.filter((t) => !CLOSED.includes(t.status)).map((t) => t.assigned_to)).size,
    };
  }

  // Groups of comparable work (same unit + category) so different units are never added together.
  function groupKey(task) { return `${String(task.unit || "").trim().toLowerCase()}|${String(task.category || "").trim().toLowerCase()}`; }

  // Performance for one foreman between from..to (inclusive), per unit/category group.
  function foremanPeriod(tasks, updates, foremanId, from, to, today = dubaiToday()) {
    const mine = tasks.filter((t) => t.assigned_to === foremanId && t.status !== "cancelled");
    const groups = {};
    const days = [];
    for (let d = from; d <= to; d = addDays(d, 1)) days.push(d);
    mine.forEach((t) => {
      const g = groups[groupKey(t)] ||= { unit: t.unit, category: t.category || "", planned: 0, approved: 0 };
      days.forEach((d) => { g.planned += plannedOn(t, d); });
      taskUpdates(t, updates).filter((u) => u.review_status === "approved" && u.report_date >= from && u.report_date <= to)
        .forEach((u) => { g.approved += num(u.approved_qty); });
    });
    Object.values(groups).forEach((g) => { g.achievement = pct(g.approved, g.planned); });
    const dueInPeriod = mine.filter((t) => t.due_date >= from && t.due_date <= to);
    const doneInPeriod = mine.filter((t) => t.status === "completed" && t.completed_at && t.completed_at.slice(0, 10) >= from && t.completed_at.slice(0, 10) <= to);
    const onTime = doneInPeriod.filter((t) => t.completed_at.slice(0, 10) <= t.due_date);
    const dueDone = dueInPeriod.filter((t) => t.status === "completed");
    let missingReports = 0, missedTargets = 0;
    const lastDay = to < today ? to : addDays(today, -1);
    mine.forEach((t) => {
      const ups = taskUpdates(t, updates);
      for (let d = from > t.start_date ? from : t.start_date; d <= lastDay && d <= t.due_date; d = addDays(d, 1)) {
        const dayUps = ups.filter((u) => u.report_date === d && u.review_status !== "rejected");
        if (!dayUps.length) { missingReports++; continue; }
        const ok = dayUps.filter((u) => u.review_status === "approved").reduce((s, u) => s + num(u.approved_qty), 0);
        if (dayUps.every((u) => u.review_status === "approved") && ok < dailyTarget(t) - 1e-9) missedTargets++;
      }
    });
    return {
      tasks: mine.length,
      completed: mine.filter((t) => t.status === "completed").length,
      inProgress: mine.filter((t) => !CLOSED.includes(t.status) && t.status !== "assigned").length,
      overdue: mine.filter((t) => !CLOSED.includes(t.status) && t.due_date < today).length,
      groups: Object.values(groups),
      completionRate: pct(dueDone.length, dueInPeriod.length),
      onTimeRate: pct(onTime.length, doneInPeriod.length),
      missingReports, missedTargets,
    };
  }

  // BOQ balance for a task: what the BOQ has, what is already done / given to other tasks, and what stays outstanding after this target.
  function boqTaskBalance(boqQty, doneQty, otherTargets, thisTarget) {
    const boq = Math.max(0, num(boqQty)), done = Math.max(0, num(doneQty)), other = Math.max(0, num(otherTargets)), mine = Math.max(0, num(thisTarget));
    const available = Math.max(0, boq - done - other);
    const outstanding = boq - done - other - mine;
    return { boq, done, other, available, target: mine, outstanding: Math.max(0, outstanding), over: outstanding < -1e-9 ? -outstanding : 0 };
  }

  // Daily target vs actual for every task-day that has a report in the period. Only approved qty counts as actual.
  function dailyRows(tasks, updates, from, to) {
    const rows = [];
    (tasks || []).forEach((t) => {
      const byDay = {};
      taskUpdates(t, updates).filter((u) => u.report_date >= from && u.report_date <= to && u.review_status !== "rejected").forEach((u) => {
        const r = byDay[u.report_date] ||= { task: t, date: u.report_date, target: dailyTarget(t), reported: 0, approved: 0, pending: 0, workers: 0, hours: 0 };
        r.reported += num(u.reported_qty);
        if (u.review_status === "approved") r.approved += num(u.approved_qty); else r.pending += num(u.reported_qty);
        r.workers += num(u.workers); r.hours += num(u.workers) * num(u.work_hours);
      });
      Object.values(byDay).forEach((r) => { r.achievement = pct(r.approved, r.target); rows.push(r); });
    });
    return rows.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
  }
  // Worker productivity per foreman+unit: approved qty ÷ worker-days and ÷ man-hours (only approved reports that give workers).
  function productivity(tasks, updates, from, to) {
    const g = {};
    (tasks || []).forEach((t) => taskUpdates(t, updates).filter((u) => u.review_status === "approved" && u.report_date >= from && u.report_date <= to && num(u.workers) > 0).forEach((u) => {
      const k = `${t.assigned_to}|${String(t.unit || "").toLowerCase()}`;
      const r = g[k] ||= { foreman: t.assigned_to, unit: t.unit, qty: 0, workerDays: 0, manHours: 0, reports: 0 };
      r.qty += num(u.approved_qty); r.workerDays += num(u.workers); r.manHours += num(u.workers) * num(u.work_hours); r.reports++;
    }));
    return Object.values(g).map((r) => ({ ...r, perWorker: r.workerDays ? r.qty / r.workerDays : null, perHour: r.manHours ? r.qty / r.manHours : null }));
  }
  // Project-wise completion: approved ÷ target over all open/closed (non-cancelled) tasks of the project, per unit.
  function projectRows(tasks, updates, today = dubaiToday()) {
    const g = {};
    (tasks || []).filter((t) => t.status !== "cancelled").forEach((t) => {
      const k = `${t.project_id}|${String(t.unit || "").toLowerCase()}`, s = taskStats(t, updates, today);
      const r = g[k] ||= { project: t.project_id, unit: t.unit, tasks: 0, completed: 0, overdue: 0, target: 0, approved: 0 };
      r.tasks++; if (t.status === "completed") r.completed++; if (s.overdue) r.overdue++;
      r.target += num(t.target_qty); r.approved += num(s.approved);
    });
    return Object.values(g).map((r) => ({ ...r, completion: pct(Math.min(r.approved, r.target), r.target) }));
  }

  const api = { dubaiToday, addDays, daysBetween, pct, dailyTarget, plannedOn, taskStats, dashboardKpis, foremanPeriod, groupKey, boqTaskBalance, dailyRows, productivity, projectRows };
  root.PB_TASK_CALC = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
