// Mobile-first layer for the foreman app: Home screen, 5-step report wizard, local draft, compact bottom nav.
// Only re-arranges existing elements (ids unchanged), so team-staff.js logic, Cloud saving and permissions stay the same.
(function () {
  const $ = (id) => document.getElementById(id);
  const form = $("report-form");
  if (!form) return;
  const DRAFT_KEY = "PB_FOREMAN_DRAFT";
  const today = () => new Date().toISOString().slice(0, 10);
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ---------- Build the 5 steps from the existing form sections ----------
  const bodies = [...form.querySelectorAll(":scope > .body")];
  const [s1, s2, s3] = bodies; // site+work, labour, materials, photos
  const s4 = bodies[3];
  const mk = (n, title) => { const d = document.createElement("div"); d.className = "body fw-step"; d.dataset.step = n; d.innerHTML = `<div class="section-title"><span>${n}</span><h2>${title}</h2></div>`; return d; };
  const st = [mk(1, "Project &amp; Location"), mk(2, "Work Progress"), mk(3, "Labour &amp; Materials"), mk(4, "Photos &amp; Remarks"), mk(5, "Review &amp; Submit")];
  const fieldOf = (id) => $(id)?.closest(".field") || $(id);
  // Step 1
  st[0].append(fieldOf("project"), s1.querySelector(".grid"), fieldOf("location-picker"), fieldOf("location"));
  // Step 2
  st[1].append($("boq-progress-lines"), $("add-boq-progress"), fieldOf("description"));
  // Step 3
  [...s2.children].forEach((c, i) => i && st[2].append(c));
  const mt = document.createElement("div"); mt.className = "sub"; mt.textContent = "📦 Materials In / Out"; st[2].append(mt, $("report-material-lines"), $("add-report-material"));
  // Step 4
  [...s4.children].forEach((c, i) => { if (i && c.id !== "submit-report" && c.id !== "notice") st[3].append(c); });
  // Step 5
  const review = document.createElement("div"); review.id = "fw-review"; review.className = "fw-review";
  const submitEl = $("submit-report"); st[4].append(review);
  const noticeEl = $("notice");
  bodies.forEach((b) => b.remove());
  const head = document.createElement("div"); head.className = "fw-head";
  head.innerHTML = `<div class="fw-dots">${[1, 2, 3, 4, 5].map((n) => `<i data-dot="${n}"></i>`).join("")}</div><b id="fw-label">Step 1 of 5</b>`;
  const foot = document.createElement("div"); foot.className = "fw-foot";
  foot.innerHTML = `<button type="button" class="btn" id="fw-back">‹ Back</button><button type="button" class="btn" id="fw-draft">Save Draft</button><button type="button" class="btn fw-next" id="fw-next">Next ›</button>`;
  form.append(head, ...st, noticeEl, foot); foot.append(submitEl); submitEl.classList.add("fw-submit"); submitEl.textContent = "Submit";

  let step = 1;
  function show(n) {
    step = Math.max(1, Math.min(5, n));
    st.forEach((s) => s.hidden = Number(s.dataset.step) !== step);
    form.querySelectorAll("[data-dot]").forEach((d) => d.classList.toggle("on", Number(d.dataset.dot) <= step));
    $("fw-label").textContent = `Step ${step} of 5`;
    $("fw-back").style.visibility = step === 1 ? "hidden" : "visible";
    $("fw-next").hidden = step === 5; submitEl.hidden = step !== 5;
    if (step === 5) buildReview();
    window.scrollTo(0, 0);
  }
  function stepOk() {
    if (step === 1 && (!$("project").value || !$("date").value)) { flash("Choose your site and report date first."); return false; }
    return true;
  }
  function flash(msg, type = "error") { const n = $("notice"); n.textContent = msg; n.className = `notice show ${type}`; }
  $("fw-next").onclick = () => { if (stepOk()) { $("notice").className = "notice"; show(step + 1); } };
  $("fw-back").onclick = () => show(step - 1);

  function buildReview() {
    const txt = (id) => { const e = $(id); if (!e) return ""; return e.tagName === "SELECT" ? (e.selectedOptions[0]?.textContent || "") : e.value; };
    const boq = [...form.querySelectorAll("#boq-progress-lines .report-item")].map((r) => {
      const sel = r.querySelector("select"), qty = [...r.querySelectorAll("input[type=number]")][0];
      return `${esc(sel?.selectedOptions[0]?.textContent || "—")} · <b>${esc(qty?.value || 0)}</b>`;
    });
    const mats = [...form.querySelectorAll("#report-material-lines .report-item")].map((r) => {
      const v = (k) => r.querySelector(`[data-material="${k}"]`)?.value || "";
      const dir = v("direction") === "In" ? '<span class="fw-tag g">IN</span>' : '<span class="fw-tag r">OUT</span>';
      const info = r.querySelector(".mat-stock")?.textContent || "";
      return `${dir} ${esc(v("item") || "—")} · <b>${esc(v("qty") || 0)} ${esc(v("unit"))}</b>${info ? `<br><small>${esc(info)}</small>` : ""}`;
    });
    const att = typeof window.PB_REPORT_ATTENDANCE === "function" ? window.PB_REPORT_ATTENDANCE() : [];
    const c = (s) => att.filter((x) => x.status === s).length;
    const files = [...($("photos")?.files || [])];
    const row = (a, b) => `<div class="fw-row"><span>${a}</span><b>${b === "" || b == null ? "—" : b}</b></div>`;
    review.innerHTML = `<div class="fw-sumhead">📋 Report summary</div>`
      + row("🏗 Site", esc(txt("project"))) + row("📅 Date", esc(txt("date"))) + row("📍 Location", esc(txt("location")))
      + `<div class="fw-row col"><span>🔨 Work items</span><div>${boq.length ? boq.join("<br>") : "None added"}</div></div>`
      + row("👷 Workers present", esc($("labour-total")?.textContent || "0"))
      + `<div class="fw-row col"><span>🗓 Attendance</span><div class="fw-chips"><i class="g">Present ${c("Present")}</i><i class="b">Half ${c("Half Day")}</i><i class="r">Absent ${c("Absent")}</i><i class="a">Leave ${c("Leave")}</i><i>OT ${att.reduce((a, x) => a + x.overtime, 0)}h</i></div></div>`
      + `<div class="fw-row col"><span>📦 Materials In / Out</span><div>${mats.length ? mats.join("<br>") : "None"}</div></div>`
      + `<div class="fw-row col"><span>📷 Photos (${files.length})</span><div class="fw-thumbs" id="fw-rev-thumbs"></div></div>`
      + row("📝 Remarks", esc(txt("remarks")).slice(0, 80))
      + `<p class="hint">Check everything, then tap Submit. You can still go Back to change it.</p>`;
    const th = $("fw-rev-thumbs"); files.forEach((f) => { const im = document.createElement("img"); im.src = URL.createObjectURL(f); th.append(im); });
  }

  // ---------- Photo preview with remove ----------
  const photoInput = $("photos");
  if (photoInput) {
    photoInput.setAttribute("accept", "image/jpeg,image/png,image/webp");
    const prev = document.createElement("div"); prev.className = "fw-thumbs fw-photo-prev"; photoInput.closest(".field")?.append(prev);
    const drawPhotos = () => {
      prev.innerHTML = "";
      [...photoInput.files].forEach((f, i) => {
        const d = document.createElement("div"); d.className = "fw-thumb";
        d.innerHTML = `<img src="${URL.createObjectURL(f)}" alt=""><button type="button" aria-label="Remove photo">×</button>`;
        d.querySelector("button").onclick = () => { const dt = new DataTransfer(); [...photoInput.files].forEach((x, j) => j !== i && dt.items.add(x)); photoInput.files = dt.files; drawPhotos(); };
        prev.append(d);
      });
    };
    photoInput.addEventListener("change", drawPhotos);
  }

  // ---------- Confirm before submit ----------
  let confirmed = false;
  submitEl.addEventListener("click", (e) => {
    if (confirmed) { confirmed = false; return; }
    e.preventDefault(); e.stopImmediatePropagation();
    buildReview();
    const ov = document.createElement("div"); ov.className = "fw-confirm";
    ov.innerHTML = `<div class="fw-confirm-box"><div class="fw-confirm-ico">✅</div><h3>Everything correct?</h3><p>Once submitted, the office will review this report. You cannot edit it after sending.</p><div class="fw-confirm-sum">${review.innerHTML.replace(/<p class="hint">[\s\S]*?<\/p>/, "")}</div><div class="fw-confirm-btns"><button type="button" class="btn" data-no>‹ Back</button><button type="button" class="btn fw-next" data-yes>Yes, Submit</button></div></div>`;
    document.body.append(ov);
    ov.querySelector("[data-no]").onclick = () => ov.remove();
    ov.querySelector("[data-yes]").onclick = () => {
      ov.remove();
      // Hidden steps can't show the browser's warning, so find the problem and open its step.
      const bad = [...form.querySelectorAll("input,select,textarea")].find((x) => !x.closest("[data-manual-labour]") && !x.checkValidity());
      form.querySelectorAll("[data-manual-labour] [required]").forEach((x) => x.removeAttribute("required"));
      if (bad) { const s = bad.closest(".fw-step"); if (s) show(Number(s.dataset.step)); flash("Please fill this field first: " + (bad.closest(".field,label")?.querySelector("label,span")?.textContent || bad.name || "required field")); bad.focus(); return; }
      if (form.requestSubmit) form.requestSubmit(submitEl); else { confirmed = true; submitEl.click(); }
    };
  }, true);

  // ---------- Draft (this phone only; never claims it reached the cloud) ----------
  const simpleIds = ["project", "date", "location-picker", "location", "description", "labour-mason", "labour-helper", "labour-other", "labour-hours", "labour-overtime", "inspection-remarks", "remarks"];
  function saveDraft() {
    const d = { savedAt: new Date().toISOString(), step };
    simpleIds.forEach((id) => { if ($(id)) d[id] = $(id).value; });
    ["inspection-quality", "inspection-safety"].forEach((id) => { if ($(id)) d[id] = $(id).checked; });
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify(d)); flash("Draft saved on this phone. It is not sent until you tap Submit.", "success"); }
    catch { flash("Draft could not be saved on this phone."); }
    renderHome();
  }
  function loadDraft() {
    let d; try { d = JSON.parse(localStorage.getItem(DRAFT_KEY) || "null"); } catch { d = null; }
    if (!d) return false;
    simpleIds.forEach((id) => { if ($(id) && d[id] != null) { $(id).value = d[id]; $(id).dispatchEvent(new Event("change", { bubbles: true })); $(id).dispatchEvent(new Event("input", { bubbles: true })); } });
    ["inspection-quality", "inspection-safety"].forEach((id) => { if ($(id)) $(id).checked = !!d[id]; });
    return true;
  }
  $("fw-draft").onclick = saveDraft;
  // Clear draft only after the real success message appears.
  new MutationObserver(() => {
    const n = $("notice");
    if (n.classList.contains("success") && /submitted/i.test(n.textContent)) { localStorage.removeItem(DRAFT_KEY); show(1); renderHome(); }
  }).observe($("notice"), { attributes: true, childList: true, characterData: true, subtree: true });
  // Warn before leaving with unsent work.
  let dirty = false;
  form.addEventListener("input", () => dirty = true);
  form.addEventListener("submit", () => dirty = false);
  window.addEventListener("beforeunload", (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } });

  // ---------- Home screen ----------
  const home = document.createElement("section");
  home.className = "card"; home.dataset.tab = "home";
  home.innerHTML = `<div class="body fw-home">
    <div class="fw-hello"><div><small id="fw-date"></small><b id="fw-site">Your site</b></div></div>
    <button type="button" class="submit" id="fw-new">＋ New Site Entry</button>
    <button type="button" class="btn" id="fw-resume" hidden style="width:100%;margin-top:8px">Continue saved draft</button>
    <div class="fw-stats"><div><b id="fw-c-draft">0</b><span>Draft</span></div><div><b id="fw-c-sub">0</b><span>Waiting</span></div><div><b id="fw-c-app">0</b><span>Approved</span></div></div>
    <div class="fw-quick"><button type="button" data-goto="attendance">👥<span>Attendance</span></button><button type="button" data-goto="material">📦<span>Material</span></button><button type="button" data-goto="equipment">🚜<span>Equipment</span></button><button type="button" data-goto="diary">📓<span>Diary</span></button></div>
  </div>`;
  form.before(home);
  const profile = document.createElement("section");
  profile.className = "card"; profile.dataset.tab = "profile";
  profile.innerHTML = `<div class="body"><div class="section-title"><span>👤</span><h2>Profile</h2></div><div class="fw-row"><span>Signed in as</span><b id="fw-user">—</b></div><div class="fw-quick" style="margin-top:12px"><button type="button" data-goto="attendance">👥<span>Attendance</span></button><button type="button" data-goto="material">📦<span>Material</span></button><button type="button" data-goto="equipment">🚜<span>Equipment</span></button><button type="button" data-goto="diary">📓<span>Diary</span></button></div><button type="button" class="btn" style="width:100%;margin-top:12px" id="fw-signout">Sign out</button></div>`;
  form.after(profile);
  const hist = $("progress-history"); if (hist) hist.dataset.tab = "history";

  function renderHome() {
    $("fw-date").textContent = new Date().toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
    const p = $("project"); $("fw-site").textContent = (p?.value && p.selectedOptions[0]?.textContent) || (p && p.options.length > 1 ? p.options[1].textContent : "Your site");
    const hasDraft = !!localStorage.getItem(DRAFT_KEY);
    $("fw-c-draft").textContent = hasDraft ? 1 : 0; $("fw-resume").hidden = !hasDraft;
    const pills = [...document.querySelectorAll("#progress-report-history .pill")].map((x) => x.textContent.trim().toLowerCase());
    $("fw-c-sub").textContent = pills.filter((x) => x === "submitted" || x === "waiting").length;
    $("fw-c-app").textContent = pills.filter((x) => x === "approved").length;
    $("fw-user").textContent = $("user-name")?.textContent || "—";
  }
  new MutationObserver(renderHome).observe($("progress-report-history"), { childList: true, subtree: true });
  $("project")?.addEventListener("change", renderHome);

  // ---------- Navigation ----------
  const bar = $("tabbar"), ub = $("userbar");
  function go(n) {
    document.querySelectorAll("[data-tab]").forEach((e) => e.classList.toggle("tab-on", e.dataset.tab === n));
    const navKey = ["attendance", "material", "equipment", "diary"].includes(n) ? "profile" : n;
    bar.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.go === navKey));
    document.querySelector(".hero").hidden = true;
    if (n === "home") renderHome();
    window.scrollTo(0, 0);
  }
  window.PB_FOREMAN_GO = go;
  bar.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; if (b.dataset.go === "report") { if (!$("date").value) $("date").value = today(); show(1); } go(b.dataset.go); });
  document.addEventListener("click", (e) => { const b = e.target.closest("[data-goto]"); if (b) go(b.dataset.goto); });
  $("fw-new").onclick = () => { if (!$("date").value) $("date").value = today(); show(1); go("report"); };
  $("fw-resume").onclick = () => { loadDraft(); show(1); go("report"); };
  $("fw-signout").onclick = () => $("sign-out")?.click();
  function sync() { bar.hidden = ub.hidden; if (!ub.hidden) go((bar.querySelector(".on") || { dataset: { go: "home" } }).dataset.go); else document.querySelector(".hero").hidden = false; }
  new MutationObserver(sync).observe(ub, { attributes: true, attributeFilter: ["hidden"] });
  show(1); sync();
})();
