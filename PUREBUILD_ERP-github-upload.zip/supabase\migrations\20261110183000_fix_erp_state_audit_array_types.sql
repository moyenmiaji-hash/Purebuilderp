CREATE OR REPLACE FUNCTION public.audit_erp_state()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  k text;
  modules text[] := ARRAY[
    'projects', 'transactions', 'boq', 'invoices', 'quotations', 'payables',
    'stock', 'employees', 'progress', 'dailyReports', 'runningBills', 'projectLocations'
  ];
  o jsonb;
  n jsonb;
  rid text;
  role_now text;
BEGIN
  SELECT role INTO role_now FROM public.profiles WHERE id = auth.uid();
  FOREACH k IN ARRAY modules LOOP
    IF jsonb_typeof(coalesce(NEW.data->k, '[]')) <> 'array'
      OR jsonb_typeof(coalesce(OLD.data->k, '[]')) <> 'array'
    THEN
      IF OLD.data->k IS DISTINCT FROM NEW.data->k THEN
        INSERT INTO public.audit_log(actor_id, actor_role, module, action, old_values, new_values)
        VALUES (auth.uid(), role_now, k, 'update', NULL, jsonb_build_object('changed', true));
      END IF;
      CONTINUE;
    END IF;

    FOR n IN SELECT * FROM jsonb_array_elements(coalesce(NEW.data->k, '[]')) LOOP
      rid := n->>'id';
      IF rid IS NULL THEN CONTINUE; END IF;
      SELECT e INTO o
      FROM jsonb_array_elements(coalesce(OLD.data->k, '[]')) e
      WHERE e->>'id' = rid
      LIMIT 1;
      IF o IS NULL THEN
        INSERT INTO public.audit_log(actor_id, actor_role, project_id, module, record_id, action, new_values)
        VALUES (
          auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'),
          k, rid, 'create', public.audit_clean(n)
        );
      ELSIF o IS DISTINCT FROM n THEN
        INSERT INTO public.audit_log(
          actor_id, actor_role, project_id, module, record_id, action, old_values, new_values, reason
        )
        VALUES (
          auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'), k, rid,
          CASE
            WHEN lower(coalesce(n->>'status', '')) IN ('void', 'approved', 'rejected')
              AND (o->>'status') IS DISTINCT FROM (n->>'status')
            THEN lower(CASE
              WHEN lower(n->>'status') = 'approved' THEN 'approve'
              WHEN lower(n->>'status') = 'rejected' THEN 'reject'
              ELSE 'void'
            END)
            ELSE 'update'
          END,
          public.audit_clean(o), public.audit_clean(n), n->>'reason'
        );
      END IF;
      o := NULL;
    END LOOP;

    FOR o IN SELECT * FROM jsonb_array_elements(coalesce(OLD.data->k, '[]')) LOOP
      rid := o->>'id';
      IF rid IS NULL THEN CONTINUE; END IF;
      IF NOT EXISTS (
        SELECT 1
        FROM jsonb_array_elements(coalesce(NEW.data->k, '[]')) e
        WHERE e->>'id' = rid
      ) THEN
        INSERT INTO public.audit_log(actor_id, actor_role, project_id, module, record_id, action, old_values)
        VALUES (
          auth.uid(), role_now, coalesce(o->>'projectId', o->>'project', o->>'pid'),
          k, rid, 'delete', public.audit_clean(o)
        );
      END IF;
    END LOOP;
  END LOOP;
  RETURN NEW;
END
$$;
