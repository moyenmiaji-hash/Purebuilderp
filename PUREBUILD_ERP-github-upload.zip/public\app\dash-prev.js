/* Dashboard: KPI card click -> previous month figures (read-only). Also keeps Monthly Revenue title fully visible. */
(function(){
  if(window.__dashPrev)return;window.__dashPrev=1;
  var css=document.createElement('style');css.textContent=
  '.dpm-ov{position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:99999;display:flex;align-items:center;justify-content:center}'+
  '.dpm{background:#fff;border-radius:16px;width:min(560px,94vw);max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.3);font-family:inherit}'+
  '.dpm-h{display:flex;align-items:center;gap:8px;padding:14px 18px;background:linear-gradient(135deg,#0f2a4a,#1e4f86);color:#fff}'+
  '.dpm-h b{flex:1;font-size:15px}.dpm-h button{background:rgba(255,255,255,.15);color:#fff;border:0;border-radius:8px;padding:6px 10px;cursor:pointer;font-weight:700}'+
  '.dpm-b{padding:16px 18px;display:grid;grid-template-columns:1fr 1fr;gap:10px}'+
  '.dpm-i{border:1px solid #e3e8f0;border-radius:12px;padding:10px 12px}.dpm-i small{display:block;color:#64748b;font-size:11px;font-weight:700;text-transform:uppercase}'+
  '.dpm-i strong{font-size:17px;color:#0f172a}.dpm-i.on{border-color:#2f7be5;background:#eef5ff;box-shadow:0 0 0 2px #2f7be533}.dpm-i .neg{color:#dc2626}'+
  '.dpm-f{padding:0 18px 14px;color:#64748b;font-size:12px}'+
  'body.dashboard-mode .card.kpi{cursor:pointer}'+
  'body.dashboard-mode .dashboard-panel h3.dpm-full{white-space:normal!important;overflow:visible!important;text-overflow:clip!important;font-size:12.5px!important;line-height:1.2}';
  document.head.appendChild(css);
  function key(d){return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
  function M(v){try{return (window.dashboardMoney||window.money)(v)}catch(e){return 'AED '+Math.round(v).toLocaleString()}}
  function sum(a,f){return a.reduce(function(s,x){return s+(Number(f(x))||0)},0)}
  function calc(off){
    var now=new Date(),s=new Date(now.getFullYear(),now.getMonth()-off,1),e=new Date(now.getFullYear(),now.getMonth()-off+1,0);
    var from=key(s),to=key(e),inR=function(x){var d=String(x.date||x.billDate||'').slice(0,10);return d>=from&&d<=to};
    var sp=window.selectedProject||'',pf=function(a){return (a||[]).filter(function(x){return !sp||x.projectId===sp})};
    var lf=ledgerFin(from,to,sp),c={totalRevenue:lf.inc,net:lf.net},exp=lf.exp;
    var tx=pf(db.transactions).filter(function(x){return inR(x)&&x.status!=='Due'});
    var sign=function(x){return x.type==='Income'?1:(isExpenseEntry(x)||/supplier payment|salary|payroll/i.test(String(x.type||'')))?-1:0};
    var meth=function(re){return sum(tx.filter(function(x){return re.test(String(x.paymentMethod||''))}),function(x){return sign(x)*(Number(x.amount)||0)})};
    var invs=pf(db.invoices).filter(function(x){return inR(x)&&(typeof invoiceIsConfirmed!=='function'||invoiceIsConfirmed(x))});
    var bills=pf(db.payables).filter(function(x){return inR(x)&&(typeof apIsPosted!=='function'||apIsPosted(x))});
    var vat=sum(tx.filter(function(x){return /vat/i.test(String(x.category||'')+' '+String(x.type||''))}),function(x){return sign(x)*(Number(x.amount)||0)});
    return {label:s.toLocaleString('en-US',{month:'long',year:'numeric'}),items:[
      ['rev','Total Revenue',c.totalRevenue],['exp','Total Expenses',exp],['profit',c.net<0?'Net Loss':'Net Profit',c.net],
      ['ar','Invoiced (Receivable)',sum(invs,function(x){return x.amount})],['ap','Supplier Bills (Payable)',sum(bills,function(x){return x.amount||x.total})],
      ['bank','Bank movement',meth(/bank|mobile/i)],['cash','Cash movement',meth(/^cash/i)],['vat','VAT entries',vat]]};
  }
  function which(card){var t=(card.querySelector('.kpi-title')||card).textContent.toLowerCase();
    if(/revenue/.test(t))return 'rev';if(/expense/.test(t))return 'exp';if(/profit|loss/.test(t))return 'profit';if(/receivable/.test(t))return 'ar';
    if(/payable/.test(t))return 'ap';if(/bank/.test(t))return 'bank';if(/cash/.test(t))return 'cash';if(/vat/.test(t))return 'vat';return 'profit'}
  function open(sel){var off=1,ov=document.createElement('div');ov.className='dpm-ov';document.body.appendChild(ov);
    function draw(){var r=calc(off);ov.innerHTML='<div class="dpm"><div class="dpm-h"><button data-a="p">‹</button><b>'+r.label+'</b><button data-a="n"'+(off<=1?' disabled style="opacity:.4"':'')+'>›</button><button data-a="x">✕</button></div><div class="dpm-b">'+
      r.items.map(function(i){return '<div class="dpm-i'+(i[0]===sel?' on':'')+'"><small>'+i[1]+'</small><strong class="'+(i[2]<0?'neg':'')+'">'+M(i[2])+'</strong></div>'}).join('')+
      '</div><div class="dpm-f">Previous month figures. Use ‹ › to see other months. Dashboard cards show all-time totals.</div></div>'}
    draw();ov.addEventListener('click',function(e){var a=e.target.getAttribute&&e.target.getAttribute('data-a');
      if(e.target===ov||a==='x')ov.remove();else if(a==='p'){off++;draw()}else if(a==='n'&&off>1){off--;draw()}});}
  document.addEventListener('click',function(e){if(!document.body.classList.contains('dashboard-mode'))return;
    var card=e.target.closest&&e.target.closest('.card.kpi');if(!card||e.target.closest('a,button'))return;
    try{open(which(card))}catch(err){console.warn('dash-prev',err)}},true);
  function fix(){document.querySelectorAll('.dashboard-panel h3').forEach(function(h){if(/Monthly Revenue/.test(h.textContent)&&!h.classList.contains('dpm-full')){h.classList.add('dpm-full');h.title=h.textContent}})}
  new MutationObserver(fix).observe(document.documentElement,{childList:true,subtree:true});fix();
})();
