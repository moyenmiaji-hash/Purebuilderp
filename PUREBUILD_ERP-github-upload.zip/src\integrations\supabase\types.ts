export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18";
  };
  public: {
    Tables: {
      erp_attendance_submissions: {
        Row: {
          attendance_date: string;
          created_at: string;
          id: string;
          idempotency_key: string | null;
          organization_id: string;
          project_id: string;
          project_legacy_id: string | null;
          submitted_by: string;
        };
        Insert: {
          attendance_date: string;
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          organization_id?: string;
          project_id: string;
          project_legacy_id?: string | null;
          submitted_by: string;
        };
        Update: {
          attendance_date?: string;
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          organization_id?: string;
          project_id?: string;
          project_legacy_id?: string | null;
          submitted_by?: string;
        };
        Relationships: [
          {
            foreignKeyName: "erp_attendance_submissions_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      erp_attendance_workers: {
        Row: {
          employment_category: string | null;
          legacy_id: string;
          name: string;
          project_legacy_id: string;
          role: string | null;
          status: string;
          updated_at: string;
          worker_code: string | null;
        };
        Insert: {
          employment_category?: string | null;
          legacy_id: string;
          name: string;
          project_legacy_id: string;
          role?: string | null;
          status?: string;
          updated_at?: string;
          worker_code?: string | null;
        };
        Update: {
          employment_category?: string | null;
          legacy_id?: string;
          name?: string;
          project_legacy_id?: string;
          role?: string | null;
          status?: string;
          updated_at?: string;
          worker_code?: string | null;
        };
        Relationships: [];
      };
      erp_cloud_state: {
        Row: {
          data: Json;
          id: number;
          revision: number;
          updated_at: string;
          updated_by: string | null;
        };
        Insert: {
          data: Json;
          id?: number;
          revision?: number;
          updated_at?: string;
          updated_by?: string | null;
        };
        Update: {
          data?: Json;
          id?: number;
          revision?: number;
          updated_at?: string;
          updated_by?: string | null;
        };
        Relationships: [];
      };
      erp_site_attendance: {
        Row: {
          attendance_date: string;
          created_at: string;
          hours: number;
          id: string;
          overtime: number;
          project_id: string;
          project_legacy_id: string | null;
          remarks: string | null;
          status: string;
          submission_id: string | null;
          submitted_by: string | null;
          updated_at: string;
          updated_by: string | null;
          worker_code: string | null;
          worker_legacy_id: string;
          worker_name: string | null;
          worker_role: string | null;
        };
        Insert: {
          attendance_date: string;
          created_at?: string;
          hours?: number;
          id?: string;
          overtime?: number;
          project_id: string;
          project_legacy_id?: string | null;
          remarks?: string | null;
          status: string;
          submission_id?: string | null;
          submitted_by?: string | null;
          updated_at?: string;
          updated_by?: string | null;
          worker_code?: string | null;
          worker_legacy_id: string;
          worker_name?: string | null;
          worker_role?: string | null;
        };
        Update: {
          attendance_date?: string;
          created_at?: string;
          hours?: number;
          id?: string;
          overtime?: number;
          project_id?: string;
          project_legacy_id?: string | null;
          remarks?: string | null;
          status?: string;
          submission_id?: string | null;
          submitted_by?: string | null;
          updated_at?: string;
          updated_by?: string | null;
          worker_code?: string | null;
          worker_legacy_id?: string;
          worker_name?: string | null;
          worker_role?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "erp_site_attendance_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "erp_site_attendance_submission_id_fkey";
            columns: ["submission_id"];
            isOneToOne: false;
            referencedRelation: "erp_attendance_submissions";
            referencedColumns: ["id"];
          },
        ];
      };
      erp_site_attendance_history: {
        Row: {
          attendance_id: string;
          changed_at: string;
          changed_by: string | null;
          id: number;
          new_values: Json | null;
          old_values: Json | null;
        };
        Insert: {
          attendance_id: string;
          changed_at?: string;
          changed_by?: string | null;
          id?: never;
          new_values?: Json | null;
          old_values?: Json | null;
        };
        Update: {
          attendance_id?: string;
          changed_at?: string;
          changed_by?: string | null;
          id?: never;
          new_values?: Json | null;
          old_values?: Json | null;
        };
        Relationships: [];
      };
      erp_state_history: {
        Row: {
          data: Json;
          id: number;
          revision: number;
          saved_at: string;
          saved_by: string | null;
        };
        Insert: {
          data: Json;
          id?: never;
          revision: number;
          saved_at?: string;
          saved_by?: string | null;
        };
        Update: {
          data?: Json;
          id?: never;
          revision?: number;
          saved_at?: string;
          saved_by?: string | null;
        };
        Relationships: [];
      };
      foreman_task_events: {
        Row: {
          actor: string | null;
          created_at: string;
          event_type: string;
          id: number;
          new_values: Json | null;
          old_values: Json | null;
          reason: string | null;
          task_id: string;
        };
        Insert: {
          actor?: string | null;
          created_at?: string;
          event_type: string;
          id?: never;
          new_values?: Json | null;
          old_values?: Json | null;
          reason?: string | null;
          task_id: string;
        };
        Update: {
          actor?: string | null;
          created_at?: string;
          event_type?: string;
          id?: never;
          new_values?: Json | null;
          old_values?: Json | null;
          reason?: string | null;
          task_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "foreman_task_events_task_id_fkey";
            columns: ["task_id"];
            isOneToOne: false;
            referencedRelation: "foreman_tasks";
            referencedColumns: ["id"];
          },
        ];
      };
      foreman_task_updates: {
        Row: {
          approved_qty: number | null;
          ask_complete: boolean;
          blockers: Json;
          boq_applied_qty: number | null;
          created_at: string;
          delay_external: boolean;
          delay_reason: string | null;
          id: string;
          idempotency_key: string | null;
          note: string | null;
          photos: Json;
          report_date: string;
          reported_qty: number;
          review_note: string | null;
          review_status: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          submitted_by: string;
          task_id: string;
          work_hours: number | null;
          workers: number | null;
        };
        Insert: {
          approved_qty?: number | null;
          ask_complete?: boolean;
          blockers?: Json;
          boq_applied_qty?: number | null;
          created_at?: string;
          delay_external?: boolean;
          delay_reason?: string | null;
          id?: string;
          idempotency_key?: string | null;
          note?: string | null;
          photos?: Json;
          report_date: string;
          reported_qty: number;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          submitted_by: string;
          task_id: string;
          work_hours?: number | null;
          workers?: number | null;
        };
        Update: {
          approved_qty?: number | null;
          ask_complete?: boolean;
          blockers?: Json;
          boq_applied_qty?: number | null;
          created_at?: string;
          delay_external?: boolean;
          delay_reason?: string | null;
          id?: string;
          idempotency_key?: string | null;
          note?: string | null;
          photos?: Json;
          report_date?: string;
          reported_qty?: number;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          submitted_by?: string;
          task_id?: string;
          work_hours?: number | null;
          workers?: number | null;
        };
        Relationships: [
          {
            foreignKeyName: "foreman_task_updates_task_id_fkey";
            columns: ["task_id"];
            isOneToOne: false;
            referencedRelation: "foreman_tasks";
            referencedColumns: ["id"];
          },
        ];
      };
      foreman_tasks: {
        Row: {
          acceptance_criteria: string | null;
          assigned_by: string | null;
          assigned_team: string | null;
          assigned_to: string;
          attachments: Json;
          boq_item_id: string | null;
          building: string | null;
          category: string | null;
          completed_at: string | null;
          created_at: string;
          description: string | null;
          due_date: string;
          floor: string | null;
          id: string;
          local_project_id: string | null;
          location: string | null;
          notes: string | null;
          organization_id: string;
          original_due_date: string | null;
          original_target_qty: number | null;
          period: string;
          period_target: number | null;
          priority: string;
          project_id: string;
          required_labour: number | null;
          required_materials: string | null;
          start_date: string;
          status: string;
          target_qty: number;
          task_no: number;
          title: string;
          unit: string;
          updated_at: string;
          working_days: number | null;
        };
        Insert: {
          acceptance_criteria?: string | null;
          assigned_by?: string | null;
          assigned_team?: string | null;
          assigned_to: string;
          attachments?: Json;
          boq_item_id?: string | null;
          building?: string | null;
          category?: string | null;
          completed_at?: string | null;
          created_at?: string;
          description?: string | null;
          due_date: string;
          floor?: string | null;
          id?: string;
          local_project_id?: string | null;
          location?: string | null;
          notes?: string | null;
          organization_id?: string;
          original_due_date?: string | null;
          original_target_qty?: number | null;
          period?: string;
          period_target?: number | null;
          priority?: string;
          project_id: string;
          required_labour?: number | null;
          required_materials?: string | null;
          start_date: string;
          status?: string;
          target_qty: number;
          task_no?: never;
          title: string;
          unit: string;
          updated_at?: string;
          working_days?: number | null;
        };
        Update: {
          acceptance_criteria?: string | null;
          assigned_by?: string | null;
          assigned_team?: string | null;
          assigned_to?: string;
          attachments?: Json;
          boq_item_id?: string | null;
          building?: string | null;
          category?: string | null;
          completed_at?: string | null;
          created_at?: string;
          description?: string | null;
          due_date?: string;
          floor?: string | null;
          id?: string;
          local_project_id?: string | null;
          location?: string | null;
          notes?: string | null;
          organization_id?: string;
          original_due_date?: string | null;
          original_target_qty?: number | null;
          period?: string;
          period_target?: number | null;
          priority?: string;
          project_id?: string;
          required_labour?: number | null;
          required_materials?: string | null;
          start_date?: string;
          status?: string;
          target_qty?: number;
          task_no?: never;
          title?: string;
          unit?: string;
          updated_at?: string;
          working_days?: number | null;
        };
        Relationships: [
          {
            foreignKeyName: "foreman_tasks_boq_item_id_fkey";
            columns: ["boq_item_id"];
            isOneToOne: false;
            referencedRelation: "team_boq_items";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "foreman_tasks_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          created_at: string;
          display_name: string | null;
          id: string;
          organization_id: string;
          permissions: Json;
          role: string;
          status: string;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          display_name?: string | null;
          id: string;
          organization_id?: string;
          permissions?: Json;
          role?: string;
          status?: string;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          display_name?: string | null;
          id?: string;
          organization_id?: string;
          permissions?: Json;
          role?: string;
          status?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      project_documents: {
        Row: {
          created_at: string;
          doc_type: string;
          file_name: string | null;
          file_path: string;
          id: string;
          is_active: boolean;
          project_id: string;
          title: string;
          uploaded_by: string | null;
        };
        Insert: {
          created_at?: string;
          doc_type?: string;
          file_name?: string | null;
          file_path: string;
          id?: string;
          is_active?: boolean;
          project_id: string;
          title: string;
          uploaded_by?: string | null;
        };
        Update: {
          created_at?: string;
          doc_type?: string;
          file_name?: string | null;
          file_path?: string;
          id?: string;
          is_active?: boolean;
          project_id?: string;
          title?: string;
          uploaded_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "project_documents_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_boq_assignments: {
        Row: {
          assigned_by: string | null;
          assigned_to: string;
          boq_item_id: string;
          created_at: string;
          id: string;
          organization_id: string;
          project_id: string;
        };
        Insert: {
          assigned_by?: string | null;
          assigned_to: string;
          boq_item_id: string;
          created_at?: string;
          id?: string;
          organization_id?: string;
          project_id: string;
        };
        Update: {
          assigned_by?: string | null;
          assigned_to?: string;
          boq_item_id?: string;
          created_at?: string;
          id?: string;
          organization_id?: string;
          project_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "site_boq_assignments_boq_item_id_fkey";
            columns: ["boq_item_id"];
            isOneToOne: false;
            referencedRelation: "team_boq_items";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "site_boq_assignments_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_diary_entries: {
        Row: {
          created_at: string;
          delays: string | null;
          entry_date: string;
          id: string;
          idempotency_key: string | null;
          local_project_id: string | null;
          manpower_count: number | null;
          organization_id: string;
          project_id: string;
          remarks: string | null;
          safety_notes: string | null;
          submitted_by: string;
          visitors: string | null;
          weather: string | null;
          work_summary: string | null;
        };
        Insert: {
          created_at?: string;
          delays?: string | null;
          entry_date: string;
          id?: string;
          idempotency_key?: string | null;
          local_project_id?: string | null;
          manpower_count?: number | null;
          organization_id?: string;
          project_id: string;
          remarks?: string | null;
          safety_notes?: string | null;
          submitted_by: string;
          visitors?: string | null;
          weather?: string | null;
          work_summary?: string | null;
        };
        Update: {
          created_at?: string;
          delays?: string | null;
          entry_date?: string;
          id?: string;
          idempotency_key?: string | null;
          local_project_id?: string | null;
          manpower_count?: number | null;
          organization_id?: string;
          project_id?: string;
          remarks?: string | null;
          safety_notes?: string | null;
          submitted_by?: string;
          visitors?: string | null;
          weather?: string | null;
          work_summary?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "site_diary_entries_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_equipment_logs: {
        Row: {
          condition: string | null;
          created_at: string;
          entry_date: string;
          equipment_code: string | null;
          equipment_name: string;
          id: string;
          idempotency_key: string | null;
          local_project_id: string | null;
          location: string | null;
          operating_hours: number | null;
          organization_id: string;
          project_id: string;
          remarks: string | null;
          submitted_by: string;
        };
        Insert: {
          condition?: string | null;
          created_at?: string;
          entry_date: string;
          equipment_code?: string | null;
          equipment_name: string;
          id?: string;
          idempotency_key?: string | null;
          local_project_id?: string | null;
          location?: string | null;
          operating_hours?: number | null;
          organization_id?: string;
          project_id: string;
          remarks?: string | null;
          submitted_by: string;
        };
        Update: {
          condition?: string | null;
          created_at?: string;
          entry_date?: string;
          equipment_code?: string | null;
          equipment_name?: string;
          id?: string;
          idempotency_key?: string | null;
          local_project_id?: string | null;
          location?: string | null;
          operating_hours?: number | null;
          organization_id?: string;
          project_id?: string;
          remarks?: string | null;
          submitted_by?: string;
        };
        Relationships: [
          {
            foreignKeyName: "site_equipment_logs_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_expense_requests: {
        Row: {
          amount: number;
          category: string;
          created_at: string;
          description: string | null;
          id: string;
          idempotency_key: string | null;
          payee: string | null;
          project_id: string;
          request_date: string;
          requested_by: string;
          review_note: string | null;
          review_status: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
        };
        Insert: {
          amount: number;
          category: string;
          created_at?: string;
          description?: string | null;
          id?: string;
          idempotency_key?: string | null;
          payee?: string | null;
          project_id: string;
          request_date: string;
          requested_by: string;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
        };
        Update: {
          amount?: number;
          category?: string;
          created_at?: string;
          description?: string | null;
          id?: string;
          idempotency_key?: string | null;
          payee?: string | null;
          project_id?: string;
          request_date?: string;
          requested_by?: string;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "site_expense_requests_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_material_request_lines: {
        Row: {
          id: string;
          item_code: string | null;
          item_name: string;
          note: string | null;
          request_id: string;
          requested_qty: number;
          unit: string | null;
        };
        Insert: {
          id?: string;
          item_code?: string | null;
          item_name: string;
          note?: string | null;
          request_id: string;
          requested_qty: number;
          unit?: string | null;
        };
        Update: {
          id?: string;
          item_code?: string | null;
          item_name?: string;
          note?: string | null;
          request_id?: string;
          requested_qty?: number;
          unit?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "site_material_request_lines_request_id_fkey";
            columns: ["request_id"];
            isOneToOne: false;
            referencedRelation: "site_material_requests";
            referencedColumns: ["id"];
          },
        ];
      };
      site_material_requests: {
        Row: {
          created_at: string;
          id: string;
          idempotency_key: string | null;
          organization_id: string;
          project_id: string;
          remarks: string | null;
          request_date: string;
          requested_by: string;
          review_note: string | null;
          review_status: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
        };
        Insert: {
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          organization_id?: string;
          project_id: string;
          remarks?: string | null;
          request_date: string;
          requested_by: string;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
        };
        Update: {
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          organization_id?: string;
          project_id?: string;
          remarks?: string | null;
          request_date?: string;
          requested_by?: string;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "site_material_requests_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_progress_report_boq_lines: {
        Row: {
          boq_item_id: string;
          id: string;
          local_boq_id: string | null;
          percent: number;
          previous_qty: number;
          remaining_qty: number;
          report_id: string;
          today_qty: number;
          total_qty: number;
        };
        Insert: {
          boq_item_id: string;
          id?: string;
          local_boq_id?: string | null;
          percent?: number;
          previous_qty?: number;
          remaining_qty?: number;
          report_id: string;
          today_qty: number;
          total_qty?: number;
        };
        Update: {
          boq_item_id?: string;
          id?: string;
          local_boq_id?: string | null;
          percent?: number;
          previous_qty?: number;
          remaining_qty?: number;
          report_id?: string;
          today_qty?: number;
          total_qty?: number;
        };
        Relationships: [
          {
            foreignKeyName: "site_progress_report_boq_lines_report_id_fkey";
            columns: ["report_id"];
            isOneToOne: false;
            referencedRelation: "site_progress_reports";
            referencedColumns: ["id"];
          },
        ];
      };
      site_progress_reports: {
        Row: {
          created_at: string;
          created_by: string;
          id: string;
          local_id: string | null;
          local_project_id: string | null;
          organization_id: string;
          project_id: string;
          report_date: string;
          report_payload: Json;
          review_note: string | null;
          review_status: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          updated_by: string | null;
        };
        Insert: {
          created_at?: string;
          created_by: string;
          id?: string;
          local_id?: string | null;
          local_project_id?: string | null;
          organization_id?: string;
          project_id: string;
          report_date?: string;
          report_payload?: Json;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          updated_by?: string | null;
        };
        Update: {
          created_at?: string;
          created_by?: string;
          id?: string;
          local_id?: string | null;
          local_project_id?: string | null;
          organization_id?: string;
          project_id?: string;
          report_date?: string;
          report_payload?: Json;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          updated_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "site_progress_reports_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      site_stock_events: {
        Row: {
          actor: string | null;
          created_at: string;
          detail: Json | null;
          event_type: string;
          id: number;
          note: string | null;
          submission_id: string;
        };
        Insert: {
          actor?: string | null;
          created_at?: string;
          detail?: Json | null;
          event_type: string;
          id?: number;
          note?: string | null;
          submission_id: string;
        };
        Update: {
          actor?: string | null;
          created_at?: string;
          detail?: Json | null;
          event_type?: string;
          id?: number;
          note?: string | null;
          submission_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "site_stock_events_submission_id_fkey";
            columns: ["submission_id"];
            isOneToOne: false;
            referencedRelation: "site_stock_submissions";
            referencedColumns: ["id"];
          },
        ];
      };
      site_stock_submissions: {
        Row: {
          approved_lines: Json | null;
          created_at: string;
          id: string;
          idempotency_key: string | null;
          invoice_no: string | null;
          kind: string;
          lines: Json;
          photos: Json;
          posted_to_stock: boolean;
          project_id: string;
          ref_id: string | null;
          ref_label: string | null;
          remarks: string | null;
          review_note: string | null;
          review_status: string;
          reviewed_at: string | null;
          reviewed_by: string | null;
          source: string | null;
          submitted_by: string;
          submitted_name: string | null;
          supplier: string | null;
          work_date: string;
        };
        Insert: {
          approved_lines?: Json | null;
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          invoice_no?: string | null;
          kind?: string;
          lines?: Json;
          photos?: Json;
          posted_to_stock?: boolean;
          project_id: string;
          ref_id?: string | null;
          ref_label?: string | null;
          remarks?: string | null;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          source?: string | null;
          submitted_by: string;
          submitted_name?: string | null;
          supplier?: string | null;
          work_date: string;
        };
        Update: {
          approved_lines?: Json | null;
          created_at?: string;
          id?: string;
          idempotency_key?: string | null;
          invoice_no?: string | null;
          kind?: string;
          lines?: Json;
          photos?: Json;
          posted_to_stock?: boolean;
          project_id?: string;
          ref_id?: string | null;
          ref_label?: string | null;
          remarks?: string | null;
          review_note?: string | null;
          review_status?: string;
          reviewed_at?: string | null;
          reviewed_by?: string | null;
          source?: string | null;
          submitted_by?: string;
          submitted_name?: string | null;
          supplier?: string | null;
          work_date?: string;
        };
        Relationships: [
          {
            foreignKeyName: "site_stock_submissions_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      team_boq_items: {
        Row: {
          approved_completed_qty: number;
          completed_qty: number;
          description: string;
          id: string;
          is_active: boolean;
          item_code: string | null;
          local_boq_id: string;
          metadata: Json;
          organization_id: string;
          project_id: string;
          quantity: number;
          remaining_qty: number | null;
          sort_order: number;
          unit: string | null;
        };
        Insert: {
          approved_completed_qty?: number;
          completed_qty?: number;
          description: string;
          id?: string;
          is_active?: boolean;
          item_code?: string | null;
          local_boq_id: string;
          metadata?: Json;
          organization_id?: string;
          project_id: string;
          quantity?: number;
          remaining_qty?: number | null;
          sort_order?: number;
          unit?: string | null;
        };
        Update: {
          approved_completed_qty?: number;
          completed_qty?: number;
          description?: string;
          id?: string;
          is_active?: boolean;
          item_code?: string | null;
          local_boq_id?: string;
          metadata?: Json;
          organization_id?: string;
          project_id?: string;
          quantity?: number;
          remaining_qty?: number | null;
          sort_order?: number;
          unit?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "team_boq_items_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      team_project_members: {
        Row: {
          created_at: string;
          id: string;
          organization_id: string;
          permissions: Json;
          project_id: string;
          status: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          organization_id?: string;
          permissions?: Json;
          project_id: string;
          status?: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          organization_id?: string;
          permissions?: Json;
          project_id?: string;
          status?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "team_project_members_project_id_fkey";
            columns: ["project_id"];
            isOneToOne: false;
            referencedRelation: "team_projects";
            referencedColumns: ["id"];
          },
        ];
      };
      team_projects: {
        Row: {
          created_at: string;
          id: string;
          local_project_id: string;
          metadata: Json;
          name: string;
          organization_id: string;
          project_code: string | null;
          status: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          local_project_id: string;
          metadata?: Json;
          name: string;
          organization_id?: string;
          project_code?: string | null;
          status?: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          local_project_id?: string;
          metadata?: Json;
          name?: string;
          organization_id?: string;
          project_code?: string | null;
          status?: string;
        };
        Relationships: [];
      };
      user_roles: {
        Row: {
          id: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Insert: {
          id?: string;
          role: Database["public"]["Enums"]["app_role"];
          user_id: string;
        };
        Update: {
          id?: string;
          role?: Database["public"]["Enums"]["app_role"];
          user_id?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      add_foreman_task_attachments: {
        Args: { p_files: Json; p_task: string };
        Returns: Json;
      };
      create_foreman_task: { Args: { p: Json }; Returns: string };
      erp_state_save: {
        Args: { p_data: Json; p_expected: number };
        Returns: number;
      };
      get_assigned_attendance_workers: {
        Args: { p_project_id: string };
        Returns: {
          name: string;
          role: string;
          worker_code: string;
          worker_legacy_id: string;
        }[];
      };
      get_project_boq_assignable_staff: {
        Args: { p_project_id: string };
        Returns: {
          display_name: string;
          user_id: string;
        }[];
      };
      get_site_incoming: { Args: { p_project_id: string }; Returns: Json };
      get_site_stock_balance: {
        Args: { p_project_id: string };
        Returns: {
          balance: number;
          item: string;
          unit: string;
        }[];
      };
      get_task_foremen: {
        Args: never;
        Returns: {
          display_name: string;
          project_id: string;
          user_id: string;
        }[];
      };
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"];
          _user_id: string;
        };
        Returns: boolean;
      };
      is_office_user: { Args: { _user_id: string }; Returns: boolean };
      mark_site_stock_posted: { Args: { p_id: string }; Returns: Json };
      pb_log_security_event: {
        Args: {
          p_action: string;
          p_actor: string;
          p_module: string;
          p_organization: string;
          p_record_id: string;
        };
        Returns: undefined;
      };
      pb_apply_task_update_to_boq: {
        Args: { p_update: string };
        Returns: number;
      };
      pb_can_manage_tasks: { Args: { _user: string }; Returns: boolean };
      pb_is_member: {
        Args: { _project: string; _user: string };
        Returns: boolean;
      };
      review_foreman_task_update: {
        Args: {
          p_approved_qty: number;
          p_complete: boolean;
          p_decision: string;
          p_note: string;
          p_update: string;
        };
        Returns: Json;
      };
      review_site_expense_request: {
        Args: { p_decision: string; p_id: string; p_note: string };
        Returns: Json;
      };
      review_site_material_request: {
        Args: {
          p_decision: string;
          p_request_id: string;
          p_review_note: string;
        };
        Returns: Json;
      };
      review_site_receiving: {
        Args: {
          p_decision: string;
          p_id: string;
          p_lines: Json;
          p_note: string;
        };
        Returns: Json;
      };
      review_site_stock_update: {
        Args: { p_decision: string; p_id: string; p_note: string };
        Returns: Json;
      };
      set_foreman_task_status: {
        Args: { p_reason: string; p_status: string; p_task: string };
        Returns: Json;
      };
      set_foreman_task_team: {
        Args: { p_task: string; p_team: string };
        Returns: Json;
      };
      set_task_update_labour: {
        Args: { p_hours: number; p_update: string; p_workers: number };
        Returns: Json;
      };
      start_foreman_task: { Args: { p_task: string }; Returns: Json };
      submit_foreman_task_update: {
        Args: { p: Json; p_task: string };
        Returns: Json;
      };
      submit_site_attendance: {
        Args: {
          p_attendance_date: string;
          p_entries: Json;
          p_idempotency_key: string;
          p_project_id: string;
        };
        Returns: Json;
      };
      submit_site_expense_request: {
        Args: { p: Json; p_project_id: string };
        Returns: Json;
      };
      submit_site_material_request: {
        Args: {
          p_idempotency_key: string;
          p_items: Json;
          p_project_id: string;
          p_remarks: string;
          p_request_date: string;
        };
        Returns: Json;
      };
      submit_site_stock_update: {
        Args: { p: Json; p_project_id: string };
        Returns: Json;
      };
      sync_attendance_workers: { Args: { p_workers: Json }; Returns: number };
      update_foreman_task: {
        Args: { p: Json; p_reason: string; p_task: string };
        Returns: Json;
      };
    };
    Enums: {
      app_role: "admin" | "manager" | "accountant" | "auditor" | "staff";
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "accountant", "auditor", "staff"],
    },
  },
} as const;
