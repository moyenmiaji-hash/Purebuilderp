CREATE TABLE public.site_stock_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  submitted_by uuid NOT NULL,
  submitted_name text,
  work_date date NOT NULL,
  kind text NOT NULL DEFAULT 'daily',
  lines jsonb NOT NULL DEFAULT '[]'::jsonb,
  supplier text,
  invoice_no text,
  remarks text,
  photos jsonb NOT NULL DEFAULT '[]'::jsonb,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  posted_to_stock boolean NOT NULL DEFAULT false,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_stock_submissions TO authenticated;
GRANT ALL ON public.site_stock_submissions TO service_role;
ALTER TABLE public.site_stock_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or office read stock submissions" ON public.site_stock_submissions FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE INDEX site_stock_submissions_project_idx ON public.site_stock_submissions(project_id, work_date);

CREATE OR REPLACE FUNCTION public.get_site_stock_balance(p_project_id uuid)
RETURNS TABLE(item text, unit text, balance numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE legacy text;
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  RETURN QUERY
    SELECT trim(s->>'item'), coalesce(s->>'unit',''),
      sum(CASE WHEN s->>'direction' = 'In' THEN 1 ELSE -1 END * coalesce(nullif(s->>'qty','')::numeric,0))
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'stock','[]'::jsonb)) s
    WHERE c.id = 1 AND s->>'projectId' = legacy AND coalesce(trim(s->>'item'),'') <> ''
    GROUP BY 1,2 ORDER BY 1;
END $$;

CREATE OR REPLACE FUNCTION public.submit_site_stock_update(p_project_id uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); d date := coalesce(nullif(p->>'work_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  kd text := coalesce(nullif(p->>'kind',''),'daily'); ln jsonb; nm text;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_stock_submissions WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'id',rid,'duplicate',true); END IF; END IF;
  IF kd NOT IN ('daily','site_purchase') THEN RAISE EXCEPTION 'Invalid update type'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF jsonb_typeof(p->'lines') <> 'array' OR jsonb_array_length(p->'lines') = 0 THEN RAISE EXCEPTION 'Add at least one material'; END IF;
  FOR ln IN SELECT * FROM jsonb_array_elements(p->'lines') LOOP
    IF coalesce(trim(ln->>'item'),'') = '' THEN RAISE EXCEPTION 'Material name is required'; END IF;
    IF coalesce((ln->>'received')::numeric,0) < 0 OR coalesce((ln->>'used')::numeric,0) < 0 OR coalesce((ln->>'damaged')::numeric,0) < 0
       OR coalesce((ln->>'returned')::numeric,0) < 0 OR coalesce((ln->>'qty')::numeric,0) < 0 THEN RAISE EXCEPTION 'Quantities cannot be negative'; END IF;
  END LOOP;
  SELECT display_name INTO nm FROM public.profiles WHERE id = auth.uid();
  INSERT INTO public.site_stock_submissions(project_id, submitted_by, submitted_name, work_date, kind, lines, supplier, invoice_no, remarks, photos, idempotency_key)
  VALUES (p_project_id, auth.uid(), nm, d, kd, p->'lines', nullif(p->>'supplier',''), nullif(p->>'invoice_no',''), nullif(p->>'remarks',''), coalesce(p->'photos','[]'::jsonb), k)
  RETURNING id INTO rid;
  RETURN jsonb_build_object('saved',true,'id',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_stock_update(p_id uuid, p_decision text, p_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE r public.site_stock_submissions;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed or not found'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own update'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_id;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE OR REPLACE FUNCTION public.mark_site_stock_posted(p_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  UPDATE public.site_stock_submissions SET posted_to_stock = true WHERE id = p_id AND review_status = 'approved';
  RETURN jsonb_build_object('saved', FOUND);
END $$;

REVOKE EXECUTE ON FUNCTION public.get_site_stock_balance(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.submit_site_stock_update(uuid, jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.review_site_stock_update(uuid, text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.mark_site_stock_posted(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_site_stock_balance(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.submit_site_stock_update(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.review_site_stock_update(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mark_site_stock_posted(uuid) TO authenticated;