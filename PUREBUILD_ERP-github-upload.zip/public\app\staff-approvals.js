/* Staff Approvals: one window listing everything site staff sent from the phone app and is
   still waiting for the office (site reports, task updates, material requests, expense requests).
   Display + existing review actions only — it calls the same approve/reject RPCs used on the
   original pages, and site reports open the existing Site Progress review. Never edits ERP records. */
(function () {
  const C = () => window.PB_CLOUD_CLIENT;
  const E = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : "AED " + Number(v || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const Q = (v) => Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 3 });
  const T = { report: ["Site Report", "#2563eb", "📝"], task: ["Task Update", "#16a34a", "✅"], material: ["Material", "#d97706", "📦"], expense: ["Expense", "#0f766e", "💵"] };
  const ST = { tab: "all", site: "", range: "all", q: "", items: [], loading: false, err: "" };
  const signedIn = () => !!(C() && window.PB_CLOUD_ROLE);
  const isOffice = () => signedIn() && String(window.PB_CLOUD_ROLE).toLowerCase() !== "staff";
  const dubaiToday = () => new Date(Date.now() + 4 * 3600e3).toISOString().slice(0, 10);

  async function safe(p) { try { const r = await p; return r.error ? [] : r.data || []; } catch { return []; } }

  async function load() {
    if (!signedIn()) { ST.items = []; return; }
    ST.loading = true;
    const c = C();
    const [reports, ups, mats, exps, projects] = await Promise.all([
      safe(c.from("site_progress_reports").select("id,project_id,local_project_id,report_date,created_by,report_payload,created_at").eq("review_status", "submitted").order("created_at", { ascending: false }).limit(200)),
      safe(c.from("foreman_task_updates").select("id,task_id,submitted_by,report_date,reported_qty,note,delay_reason,photos,ask_complete,workers,work_hours,created_at").eq("review_status", "submitted").order("created_at", { ascending: false }).limit(200)),
      safe(c.from("site_material_requests").select("id,project_id,requested_by,request_date,remarks,created_at").eq("review_status", "submitted").order("created_at", { ascending: false }).limit(200)),
      safe(c.from("site_expense_requests").select("id,project_id,requested_by,request_date,category,amount,payee,description,created_at").eq("review_status", "pending").order("created_at", { ascending: false }).limit(200)),
      safe(c.from("team_projects").select("id,name,local_project_id")),
    ]);
    const taskIds = [...new Set(ups.map((u) => u.task_id))];
    const tasks = taskIds.length ? await safe(c.from("foreman_tasks").select("id,task_no,title,unit,project_id,building,floor").in("id", taskIds)) : [];
    const lines = mats.length ? await safe(c.from("site_material_request_lines").select("request_id,item_name,unit,requested_qty").in("request_id", mats.map((m) => m.id))) : [];
    const people = [...new Set([...reports.map((r) => r.created_by), ...ups.map((u) => u.submitted_by), ...mats.map((m) => m.requested_by), ...exps.map((x) => x.requested_by)].filter(Boolean))];
    const profs = people.length ? await safe(c.from("profiles").select("id,display_name").in("id", people)) : [];
    const who = (id) => (profs.find((p) => p.id === id) || {}).display_name || "Site staff";
    const proj = (id) => projects.find((p) => p.id === id) || {};
    const items = [];
    reports.forEach((r) => {
      const pl = r.report_payload || {}, n = Array.isArray(pl.boq_progress) ? pl.boq_progress.length : 0;
      items.push({ kind: "report", id: r.id, date: r.report_date, at: r.created_at, site: proj(r.project_id).name || "Site", pid: r.project_id, local: r.local_project_id || proj(r.project_id).local_project_id, who: who(r.created_by),
        text: (pl.description || "Daily site progress") + (n ? ` · ${n} BOQ item${n > 1 ? "s" : ""}` : ""), value: Array.isArray(pl.photos) && pl.photos.length ? `${pl.photos.length} photo(s)` : "" });
    });
    ups.forEach((u) => {
      const t = tasks.find((x) => x.id === u.task_id) || {};
      items.push({ kind: "task", id: u.id, date: u.report_date, at: u.created_at, site: proj(t.project_id).name || "Site", pid: t.project_id, who: who(u.submitted_by), qty: Number(u.reported_qty) || 0, complete: !!u.ask_complete,
        text: `${t.task_no ? "T-" + t.task_no + " · " : ""}${t.title || "Task"}${[t.building, t.floor].filter(Boolean).length ? " · " + [t.building, t.floor].filter(Boolean).join(" / ") : ""}${u.note ? " — " + u.note : ""}${u.delay_reason ? " · Delay: " + u.delay_reason : ""}`,
        value: `${Q(u.reported_qty)} ${t.unit || ""}${u.ask_complete ? " · says finished" : ""}${Array.isArray(u.photos) && u.photos.length ? ` · ${u.photos.length} photo(s)` : ""}` });
    });
    mats.forEach((m) => {
      const ls = lines.filter((l) => l.request_id === m.id);
      items.push({ kind: "material", id: m.id, date: m.request_date, at: m.created_at, site: proj(m.project_id).name || "Site", pid: m.project_id, who: who(m.requested_by),
        text: (ls.map((l) => `${l.item_name} ${Q(l.requested_qty)} ${l.unit || ""}`.trim()).join(", ") || "Material request") + (m.remarks ? " — " + m.remarks : ""), value: `${ls.length} item(s)` });
    });
    exps.forEach((x) => {
      items.push({ kind: "expense", id: x.id, date: x.request_date, at: x.created_at, site: proj(x.project_id).name || "Site", pid: x.project_id, who: who(x.requested_by),
        text: `${x.category || "Expense"}${x.payee ? " · Pay to " + x.payee : ""}${x.description ? " — " + x.description : ""}`, value: M(x.amount) });
    });
    items.sort((a, b) => String(b.at).localeCompare(String(a.at)));
    ST.items = items; ST.loading = false;
    badge();
  }

  /* History: who sent what on which date, and what the office decided (read-only) */
  async function loadHist() {
    if (!signedIn()) { ST.hist = []; return; }
    const c = C(); ST.histLoading = true;
    const [reports, ups, mats, exps, projects] = await Promise.all([
      safe(c.from("site_progress_reports").select("id,project_id,report_date,created_by,report_payload,review_status,review_note,reviewed_by,reviewed_at,created_at").neq("review_status", "submitted").order("created_at", { ascending: false }).limit(300)),
      safe(c.from("foreman_task_updates").select("id,task_id,submitted_by,report_date,reported_qty,approved_qty,note,review_status,review_note,reviewed_by,reviewed_at,created_at").neq("review_status", "submitted").order("created_at", { ascending: false }).limit(300)),
      safe(c.from("site_material_requests").select("id,project_id,requested_by,request_date,remarks,review_status,review_note,reviewed_by,reviewed_at,created_at").neq("review_status", "submitted").order("created_at", { ascending: false }).limit(300)),
      safe(c.from("site_expense_requests").select("id,project_id,requested_by,request_date,category,amount,description,review_status,review_note,reviewed_by,reviewed_at,created_at").neq("review_status", "pending").order("created_at", { ascending: false }).limit(300)),
      safe(c.from("team_projects").select("id,name")),
    ]);
    const taskIds = [...new Set(ups.map((u) => u.task_id))];
    const tasks = taskIds.length ? await safe(c.from("foreman_tasks").select("id,task_no,title,unit,project_id").in("id", taskIds)) : [];
    const people = [...new Set([...reports.flatMap((r) => [r.created_by, r.reviewed_by]), ...ups.flatMap((u) => [u.submitted_by, u.reviewed_by]), ...mats.flatMap((m) => [m.requested_by, m.reviewed_by]), ...exps.flatMap((x) => [x.requested_by, x.reviewed_by])].filter(Boolean))];
    const profs = people.length ? await safe(c.from("profiles").select("id,display_name").in("id", people)) : [];
    const who = (id) => (profs.find((p) => p.id === id) || {}).display_name || (id ? "Staff" : "—");
    const pn = (id) => (projects.find((p) => p.id === id) || {}).name || "Site";
    const h = [];
    reports.forEach((r) => { const pl = r.report_payload || {}, b = (pl.boq_progress || []).map((x) => `${x.boq_id || x.item || ""} ${x.today_qty != null ? "+" + Q(x.today_qty) : ""}`.trim()).filter(Boolean).join(", ");
      h.push({ kind: "report", date: r.report_date, at: r.created_at, pid: r.project_id, site: pn(r.project_id), who: who(r.created_by), text: (pl.description || "Daily site progress") + (b ? " · " + b : ""), value: "", st: r.review_status, by: who(r.reviewed_by), on: r.reviewed_at, note: r.review_note }); });
    ups.forEach((u) => { const t = tasks.find((x) => x.id === u.task_id) || {};
      h.push({ kind: "task", date: u.report_date, at: u.created_at, pid: t.project_id, site: pn(t.project_id), who: who(u.submitted_by), text: `${t.task_no ? "T-" + t.task_no + " · " : ""}${t.title || "Task"}${u.note ? " — " + u.note : ""}`, value: `Sent ${Q(u.reported_qty)}${u.review_status === "approved" ? " · Approved " + Q(u.approved_qty) : ""} ${t.unit || ""}`, st: u.review_status, by: who(u.reviewed_by), on: u.reviewed_at, note: u.review_note }); });
    mats.forEach((m) => h.push({ kind: "material", date: m.request_date, at: m.created_at, pid: m.project_id, site: pn(m.project_id), who: who(m.requested_by), text: m.remarks || "Material request", value: "", st: m.review_status, by: who(m.reviewed_by), on: m.reviewed_at, note: m.review_note }));
    exps.forEach((x) => h.push({ kind: "expense", date: x.request_date, at: x.created_at, pid: x.project_id, site: pn(x.project_id), who: who(x.requested_by), text: `${x.category || "Expense"}${x.description ? " — " + x.description : ""}`, value: M(x.amount), st: x.review_status, by: who(x.reviewed_by), on: x.reviewed_at, note: x.review_note }));
    h.sort((a, b) => String(b.date + b.at).localeCompare(String(a.date + a.at)));
    ST.hist = h; ST.histLoading = false;
  }
  function histView() {
    const q = (ST.q || "").toLowerCase(), now = new Date(), td = now.toISOString().slice(0, 10), wk = new Date(now - 6 * 864e5).toISOString().slice(0, 10);
    const rows = (ST.hist || []).filter((i) => (!ST.site || i.pid === ST.site) && (ST.range === "all" || (ST.range === "today" ? i.date === td : i.date >= wk)) && (!q || [i.site, i.who, i.text, i.by, i.note].join(" ").toLowerCase().includes(q)));
    if (ST.histLoading && !ST.hist) return '<p class="muted">Loading history…</p>';
    if (!rows.length) return '<div class="pb-sa-empty">📭 No history for this filter.</div>';
    let last = "";
    return rows.map((i) => { const [label, color, ico] = T[i.kind]; const ok = i.st === "approved", dh = i.date !== last ? `<div class="sa-h-day">📅 ${E(i.date)}</div>` : ""; last = i.date;
      return dh + `<div class="pb-sa-row" style="--c:${color}"><div class="pb-sa-ico">${ico}</div><div class="pb-sa-main"><div class="pb-sa-top"><span class="pb-sa-tag">${label}</span><b>${E(i.site)}</b><small>👷 ${E(i.who)}</small></div><div class="pb-sa-text">${E(i.text)}${i.note ? `<br><small style="color:${ok ? "#166534" : "#b91c1c"}">💬 ${E(i.note)}</small>` : ""}</div></div><div class="pb-sa-val">${E(i.value)}</div><div class="pb-sa-act" style="text-align:right"><span class="sa-st ${ok ? "ok" : "no"}">${ok ? "✅ Approved" : "↩ " + E(i.st === "rejected" ? "Rejected" : i.st)}</span><br><small class="muted">${E(i.by)}${i.on ? " · " + E(new Date(i.on).toLocaleString()) : ""}</small></div></div>`; }).join("");
  }

  function filtered() {
    const t = dubaiToday(), wk = new Date(Date.now() + 4 * 3600e3 - 6 * 864e5).toISOString().slice(0, 10), q = ST.q.trim().toLowerCase();
    return ST.items.filter((i) => (ST.tab === "all" || i.kind === ST.tab) && (!ST.site || i.pid === ST.site)
      && (ST.range === "all" || (ST.range === "today" ? i.date === t : i.date >= wk))
      && (!q || `${i.site} ${i.who} ${i.text} ${i.value}`.toLowerCase().includes(q)));
  }

  function badge() {
    const n = ST.items.length;
    const b = document.getElementById("pb-sa-nav-n"); if (b) { b.textContent = n; b.hidden = !n; }
    const d = document.getElementById("pb-sa-dash"); if (d) { d.hidden = !n; const s = d.querySelector("b"); if (s) s.textContent = n; }
  }

  function draw() {
    const box = document.getElementById("pb-sa-body"); if (!box) return;
    const rows = filtered(), cnt = (k) => ST.items.filter((i) => k === "all" || i.kind === k).length;
    const sites = [...new Map(ST.items.map((i) => [i.pid, i.site])).entries()];
    box.innerHTML = `
      <div class="pb-sa-tabs">${["all", "report", "task", "material", "expense"].map((k) => `<button class="${ST.tab === k ? "on" : ""}" data-sa-tab="${k}" style="--c:${k === "all" ? "#334155" : T[k][1]}">${k === "all" ? "All" : T[k][2] + " " + T[k][0]}<em>${cnt(k)}</em></button>`).join("")}<button class="${ST.tab === "history" ? "on" : ""}" data-sa-tab="history" style="--c:#0f766e">🕘 History</button></div>
      <div class="pb-sa-filters">
        <select data-sa-site><option value="">All sites</option>${sites.map(([id, n]) => `<option value="${E(id)}" ${ST.site === id ? "selected" : ""}>${E(n)}</option>`).join("")}</select>
        <div class="pb-sa-range">${[["today", "Today"], ["week", "This week"], ["all", "All"]].map(([k, l]) => `<button class="${ST.range === k ? "on" : ""}" data-sa-range="${k}">${l}</button>`).join("")}</div>
        <input data-sa-q placeholder="Search staff, site, work…" value="${E(ST.q)}">
        <button class="btn small" data-sa-reload>⟳ Refresh</button>
      </div>
      ${okMsg ? `<div class="pb-sa-okmsg">${E(okMsg)}</div>` : ""}
      ${ST.err ? `<div class="pb-sa-err">${E(ST.err)}</div>` : ""}
      <div class="pb-sa-list">${ST.tab === "history" ? histView() : ST.loading && !ST.items.length ? '<p class="muted">Loading…</p>' : rows.length ? rows.map(row).join("") : '<div class="pb-sa-empty">🎉 Nothing waiting for approval here.</div>'}</div>`;
  }

  function row(i) {
    const [label, color, ico] = T[i.kind];
    const act = i.kind === "report"
      ? `<button class="btn small primary" data-sa-open="${E(i.id)}">Open &amp; review</button>`
      : `<button class="btn small pb-sa-ok" data-sa-act="approved" data-sa-id="${E(i.id)}" data-sa-kind="${i.kind}">✓ Approve</button><button class="btn small pb-sa-no" data-sa-act="rejected" data-sa-id="${E(i.id)}" data-sa-kind="${i.kind}">${i.kind === "task" ? "↩ Return" : "✕ Reject"}</button>`;
    return `<div class="pb-sa-row" style="--c:${color}"><div class="pb-sa-ico">${ico}</div>
      <div class="pb-sa-main"><div class="pb-sa-top"><span class="pb-sa-tag">${label}</span><b>${E(i.site)}</b><small>${E(i.date)} · ${E(i.who)}</small></div>
      <div class="pb-sa-text">${E(i.text)}</div></div>
      <div class="pb-sa-val">${E(i.value)}</div><div class="pb-sa-act">${act}</div></div>`;
  }

  function qtyDialog(it) {
    return new Promise((res) => {
      const ov = document.createElement("div"); ov.className = "pb-qd-ov";
      ov.innerHTML = `<div class="pb-qd"><div class="pb-qd-h"><span>✓</span><div><b>Approve task update</b><small>${E(it.site)} · ${E(it.who)} · ${E(it.date)}</small></div></div>
        <div class="pb-qd-work">${E(it.text)}</div>
        <div class="pb-qd-rep">Foreman reported <b>${Q(it.qty)}</b> ${E(it.value).replace(/^[\d.,\s]+/, "").split("·")[0]}</div>
        <label>Approved quantity</label>
        <div class="pb-qd-step"><button type="button" data-d="-1">−</button><input type="number" min="0" max="${it.qty}" step="any" value="${it.qty}"><button type="button" data-d="1">+</button></div>
        <div class="pb-qd-chips"><button type="button" data-p="1">100%</button><button type="button" data-p=".75">75%</button><button type="button" data-p=".5">50%</button><button type="button" data-p="0">0</button></div>
        <div class="pb-qd-bar"><i></i></div><small class="pb-qd-t"></small>
        ${it.complete ? `<label class="pb-qd-done"><input type="checkbox" checked> Foreman says the task is finished — mark as completed</label>` : ""}
        <p class="pb-qd-err"></p>
        <div class="pb-qd-f"><button type="button" class="btn" data-x>Cancel</button><button type="button" class="btn primary" data-ok>✓ Approve</button></div></div>`;
      document.body.appendChild(ov);
      const inp = ov.querySelector("input[type=number]"), bar = ov.querySelector(".pb-qd-bar i"), t = ov.querySelector(".pb-qd-t"), err = ov.querySelector(".pb-qd-err");
      const upd = () => { const v = Number(inp.value) || 0, p = it.qty ? Math.min(100, (v / it.qty) * 100) : 0; bar.style.width = p + "%"; t.textContent = `${Math.round(p)}% of reported quantity will be added to BOQ`; };
      ov.querySelectorAll("[data-d]").forEach((b) => (b.onclick = () => { inp.value = Math.max(0, Math.min(it.qty, (Number(inp.value) || 0) + Number(b.dataset.d))); upd(); }));
      ov.querySelectorAll("[data-p]").forEach((b) => (b.onclick = () => { inp.value = Math.round(it.qty * Number(b.dataset.p) * 100) / 100; upd(); }));
      inp.oninput = upd; upd(); setTimeout(() => inp.select(), 30);
      const close = (v) => { ov.remove(); res(v); };
      ov.querySelector("[data-x]").onclick = () => close(null);
      ov.onclick = (e) => { if (e.target === ov) close(null); };
      ov.querySelector("[data-ok]").onclick = () => { const v = inp.value.trim(), aq = Number(v);
        if (v === "" || !isFinite(aq) || aq < 0 || aq > it.qty) { err.textContent = `Enter a quantity between 0 and ${Q(it.qty)}.`; return; }
        const cb = ov.querySelector(".pb-qd-done input"); close({ qty: aq, done: cb ? cb.checked : false }); };
      inp.onkeydown = (e) => { if (e.key === "Enter") ov.querySelector("[data-ok]").click(); if (e.key === "Escape") close(null); };
    });
  }

  async function act(kind, id, decision) {
    const it = ST.items.find((x) => x.id === id && x.kind === kind); if (!it) return;
    const c = C(); let res;
    if (decision === "rejected") {
      const note = prompt(kind === "task" ? "What must the foreman correct? (required)" : "Reason for rejecting (required):", "");
      if (note === null) return; if (!note.trim()) return alert("Please write a reason.");
      if (kind === "task") res = await c.rpc("review_foreman_task_update", { p_update: id, p_decision: "rejected", p_approved_qty: null, p_note: note.trim(), p_complete: false });
      if (kind === "material") res = await c.rpc("review_site_material_request", { p_request_id: id, p_decision: "rejected", p_review_note: note.trim() });
      if (kind === "expense") res = await c.rpc("review_site_expense_request", { p_id: id, p_decision: "rejected", p_note: note.trim() });
    } else {
      if (kind === "task") {
        const r = await qtyDialog(it); if (!r) return;
        const aq = r.qty, done = r.done;
        res = await c.rpc("review_foreman_task_update", { p_update: id, p_decision: "approved", p_approved_qty: aq, p_note: "", p_complete: done });
      }
      if (kind === "material") { if (!confirm("Approve this material request? (Stock is not issued automatically.)")) return; res = await c.rpc("review_site_material_request", { p_request_id: id, p_decision: "approved", p_review_note: "" }); }
      if (kind === "expense") { if (!confirm(`Approve expense request ${it.value}?`)) return; res = await c.rpc("review_site_expense_request", { p_id: id, p_decision: "approved", p_note: "" }); }
    }
    if (res?.error) { ST.err = "Could not save: " + String(res.error.message || res.error).replace(/^.*?ERROR:\s*/, ""); draw(); return; }
    ST.err = ""; if (typeof toast === "function") toast(decision === "approved" ? "Approved" : "Sent back");
    await load(); draw();
  }

  function css() {
    if (document.getElementById("pb-sa-css")) return;
    const s = document.createElement("style"); s.id = "pb-sa-css";
    s.textContent = `.sa-h-day{margin:12px 0 6px;font-weight:800;color:#0f766e;font-size:13px;border-bottom:1px solid #ccfbf1;padding-bottom:4px}
.sa-st{display:inline-block;padding:4px 10px;border-radius:20px;font-weight:700;font-size:12px}.sa-st.ok{background:#dcfce7;color:#166534}.sa-st.no{background:#fee2e2;color:#b91c1c}
.pb-qd-ov{position:fixed;inset:0;z-index:9900;background:rgba(30,27,60,.35);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center}
.pb-qd{width:min(440px,94vw);background:#fff;border-radius:20px;padding:20px;box-shadow:0 24px 60px rgba(30,27,75,.3);font-size:14px}
.pb-qd-h{display:flex;gap:12px;align-items:center;margin-bottom:12px}.pb-qd-h>span{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg,#10b981,#059669);color:#fff;font-size:20px;font-weight:800}
.pb-qd-h b{display:block;font-size:17px;color:#0f172a}.pb-qd-h small{color:#64748b}
.pb-qd-work{padding:10px 12px;border-radius:12px;background:#f1f5f9;color:#334155;font-weight:600;margin-bottom:8px}
.pb-qd-rep{margin-bottom:12px;color:#475569}.pb-qd-rep b{color:#0f766e;font-size:16px}
.pb-qd label{font-weight:800;color:#1e293b;font-size:13px}
.pb-qd-step{display:flex;gap:8px;margin:6px 0 10px}.pb-qd-step input{flex:1;text-align:center;font-size:20px;font-weight:800;border:2px solid #c7d2fe;border-radius:12px;padding:8px}
.pb-qd-step button{width:46px;border:0;border-radius:12px;background:#eef2ff;color:#4338ca;font-size:22px;font-weight:800;cursor:pointer}
.pb-qd-chips{display:flex;gap:6px;margin-bottom:12px}.pb-qd-chips button{flex:1;border:1px solid #c7d2fe;background:#fff;border-radius:20px;padding:6px;font-weight:700;color:#4338ca;cursor:pointer}.pb-qd-chips button:hover{background:#eef2ff}
.pb-qd-bar{height:10px;border-radius:8px;background:#e2e8f0;overflow:hidden}.pb-qd-bar i{display:block;height:100%;background:linear-gradient(90deg,#10b981,#22c55e);transition:width .2s}
.pb-qd-t{display:block;color:#64748b;margin:6px 0 10px}
.pb-qd-done{display:flex;gap:8px;align-items:center;padding:10px;border-radius:12px;background:#ecfdf5;color:#166534!important;font-weight:700}
.pb-qd-err{color:#b91c1c;font-weight:700;min-height:4px;margin:6px 0}
.pb-qd-f{display:flex;justify-content:flex-end;gap:8px}.pb-qd-f .primary{background:linear-gradient(135deg,#10b981,#059669)!important;color:#fff!important;border:0}
.pb-rv-ov{z-index:9800!important}.pb-rv-done{z-index:9850!important}
.pb-sa-okmsg{margin:0 0 12px;padding:12px 16px;border-radius:12px;background:#ecfdf5;border:1px solid #86efac;color:#166534;font-weight:700;font-size:14px}
.sa-link{margin-top:12px;padding:12px 14px;border-radius:12px;background:#fff;border:1px dashed #93c5fd}
.sa-link.warn{border-color:#fca5a5;color:#b91c1c;background:#fef2f2;font-weight:600}
.sa-link-h{font-size:14px;color:#0f172a}.sa-link-h span{color:#64748b}
.sa-link-m{font-size:13px;color:#475569;margin:4px 0 10px}
.sa-bar{position:relative;height:12px;border-radius:8px;background:#e2e8f0;overflow:hidden}
.sa-bar i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#16a34a,#22c55e)}
.sa-bar em{position:absolute;top:0;bottom:0;background:repeating-linear-gradient(45deg,#3b82f6,#3b82f6 6px,#60a5fa 6px,#60a5fa 12px)}
.sa-link-n{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:8px;font-size:13px;color:#334155}
.sa-link small{display:block;margin-top:8px;color:#1d4ed8;font-size:12px}
.sa-chip{display:inline-block;margin:6px 6px 0 0;padding:4px 10px;border-radius:20px;background:#eef2ff;color:#3730a3;font-size:13px;font-weight:600}
.sa-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px;margin-top:14px}
.sa-tile{border:1px solid #e2e8f0;border-top:4px solid var(--c);border-radius:12px;padding:12px 14px;background:#fff;font-size:14px}
.sa-tile.sa-boq{grid-column:1/-1;background:linear-gradient(135deg,#eff6ff,#fff)}
.sa-tile-h{display:flex;align-items:center;gap:8px;font-weight:700;color:#0f172a;font-size:15px;margin-bottom:8px}
.sa-ic{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;font-size:18px;background:color-mix(in srgb,var(--c) 15%,#fff);box-shadow:inset 0 -2px 0 color-mix(in srgb,var(--c) 30%,transparent)}
.sa-boq-name{font-size:16px;font-weight:700;color:#1e3a8a;margin-bottom:8px}
.sa-kvs{display:flex;flex-wrap:wrap;gap:8px}
.sa-kv{padding:6px 10px;border-radius:9px;background:#f8fafc;border:1px solid #eef2f7;min-width:90px}
.sa-kv small{display:block;font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.03em}
.sa-kv b{font-size:14px;color:#0f172a}
.pb-sa-rv article[data-report-card] .pill{font-size:12px!important;padding:4px 10px!important;background:#fef3c7!important;color:#92400e!important}
.pb-sa-rv-bar{display:flex;align-items:center;gap:12px;justify-content:space-between;flex-wrap:wrap;padding:10px 12px;border:1px solid #e2e8f0;border-radius:12px;background:#f8fafc;margin-bottom:12px}
.pb-sa-rv-bar small{color:#64748b}
.pb-sa-rv>.panel{border:0!important;box-shadow:none!important;padding:0!important;background:none!important}
.pb-sa-rv>.panel>div:first-child .muted{display:none}
.pb-sa-rv>.panel>.muted{display:none}
.pb-sa-rv article[data-report-card]{border:1px solid #dbe4ef!important;border-left:5px solid #2563eb!important;border-radius:14px!important;padding:18px 20px!important;background:#fff!important;box-shadow:0 6px 20px rgba(15,23,42,.06)}
.pb-sa-rv article[data-report-card]>div:first-child b{font-size:17px}
.pb-sa-rv article[data-report-card]>.muted{display:block;margin-top:8px!important;padding:9px 12px;border-radius:10px;background:#f1f5f9;color:#334155!important;line-height:1.5}
.pb-sa-rv article[data-report-card] a.btn{border-radius:8px}
.pb-sa-rv .pb-rv-actions{position:sticky;bottom:0;background:#fff;padding-top:12px!important;margin-top:14px!important;border-top:1px dashed #cbd5e1}
.pb-sa-rv .pb-rv-actions .btn{font-size:14px!important;padding:9px 18px!important;border-radius:9px!important}
.pb-sa-rv .pb-rv-actions .btn.primary{background:#16a34a!important;border-color:#16a34a!important;color:#fff!important}

#pb-sa-ov{position:fixed;inset:0;z-index:9500;background:rgba(10,25,45,.5);display:none;align-items:center;justify-content:center;padding:18px}
#pb-sa-ov.on{display:flex}
.pb-sa-panel{width:min(1100px,97vw);height:min(88vh,860px);display:flex;flex-direction:column;background:var(--panel,#fff);color:var(--ink,#12233f);border-radius:16px;box-shadow:0 30px 60px -20px rgba(0,0,0,.5);overflow:hidden}
.pb-sa-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 18px;background:linear-gradient(110deg,#1e3a8a,#2563eb 55%,#0d9488);color:#fff}
.pb-sa-head h3{margin:0;font-size:17px}.pb-sa-head small{opacity:.85;font-weight:500}
.pb-sa-head .btn{background:rgba(255,255,255,.18);color:#fff;border-color:rgba(255,255,255,.35)}
#pb-sa-body{flex:1;overflow:auto;padding:12px 16px}
.pb-sa-tabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.pb-sa-tabs button{border:1px solid var(--line,#dfe6ef);background:var(--panel,#fff);color:var(--ink,#12233f);border-radius:999px;padding:7px 12px;font-weight:700;font-size:12.5px;cursor:pointer}
.pb-sa-tabs button em{font-style:normal;margin-left:6px;background:#e2e8f0;color:#0f172a;border-radius:999px;padding:0 7px}
.pb-sa-tabs button.on{background:var(--c);border-color:var(--c);color:#fff}.pb-sa-tabs button.on em{background:rgba(255,255,255,.25);color:#fff}
.pb-sa-filters{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
.pb-sa-filters select,.pb-sa-filters input{min-height:34px;border:1px solid var(--line,#dfe6ef);border-radius:9px;padding:6px 10px;background:var(--panel,#fff);color:var(--ink,#12233f)}
.pb-sa-filters input{flex:1;min-width:180px}
.pb-sa-range{display:flex;border:1px solid var(--line,#dfe6ef);border-radius:9px;overflow:hidden}
.pb-sa-range button{border:0;background:transparent;color:var(--ink,#12233f);padding:7px 11px;font-weight:700;font-size:12px;cursor:pointer}.pb-sa-range button.on{background:#2563eb;color:#fff}
.pb-sa-row{display:grid;grid-template-columns:42px 1fr auto auto;gap:10px;align-items:center;padding:10px 12px;border:1px solid var(--line,#dfe6ef);border-left:4px solid var(--c);border-radius:12px;margin-bottom:8px;background:var(--panel,#fff)}
.pb-sa-ico{width:38px;height:38px;border-radius:11px;display:grid;place-items:center;font-size:18px;background:color-mix(in srgb,var(--c) 14%,transparent)}
.pb-sa-top{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.pb-sa-top small{color:var(--muted,#6b7a90)}
.pb-sa-tag{font-size:10.5px;font-weight:800;color:#fff;background:var(--c);border-radius:6px;padding:2px 7px;text-transform:uppercase;letter-spacing:.03em}
.pb-sa-text{font-size:12.5px;margin-top:3px;color:var(--ink,#12233f);overflow-wrap:anywhere}
.pb-sa-val{font-weight:800;font-size:13px;text-align:right;white-space:nowrap}
.pb-sa-act{display:flex;gap:6px}.pb-sa-ok{background:#16a34a!important;color:#fff!important;border-color:#16a34a!important}.pb-sa-no{background:#fff!important;color:#b91c1c!important;border-color:#fca5a5!important}
.pb-sa-empty{padding:40px;text-align:center;color:var(--muted,#6b7a90);font-size:14px}
.pb-sa-err{background:#fef2f2;color:#991b1b;border:1px solid #fecaca;border-radius:10px;padding:8px 12px;margin-bottom:8px;font-size:13px}
#pb-sa-nav-n{margin-left:auto;background:#ef4444;color:#fff;border-radius:999px;padding:0 7px;font-size:11px;font-weight:800;line-height:18px}
#pb-sa-dash{display:flex;align-items:center;gap:8px;width:100%;margin:0 0 6px;padding:7px 10px;border:1px solid #f59e0b;border-radius:10px;background:linear-gradient(90deg,#fff7ed,#fffbeb);color:#92400e;font-weight:700;font-size:12px;cursor:pointer;text-align:left}
#pb-sa-dash[hidden]{display:none!important}#pb-sa-dash *{font-size:12px!important;line-height:18px!important}#pb-sa-dash b{background:#f59e0b;color:#fff;border-radius:999px;padding:0 7px;flex:none}#pb-sa-dash span{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700!important;color:#92400e}#pb-sa-dash i{font-style:normal;color:#b45309;font-weight:800!important;flex:none}
@media(max-width:760px){.pb-sa-row{grid-template-columns:38px 1fr}.pb-sa-val{grid-column:2;text-align:left}.pb-sa-act{grid-column:1/-1}}`;
    document.head.appendChild(s);
  }

  /* Site report review inside this window: reuses the original Cloud review card (same Approve/Reject code) */
  async function review(it) {
    rvId = it.id; okMsg = "";
    const box = document.getElementById("pb-sa-body"); if (!box) return;
    const id = String(it.id).replace(/["\\]/g, "");
    box.innerHTML = `<div class="pb-sa-rv-bar"><button class="btn small" data-sa-back>‹ Back to list</button>
      <div><span class="pb-sa-tag" style="--c:#2563eb">SITE REPORT</span> <b>${E(it.site)}</b> <small>${E(it.date)} · ${E(it.who)}</small></div>
      <small>Review and approve this report here.</small></div>
      <style>#pb-sa-review article[data-report-card]:not([data-report-card="${id}"]){display:none!important}</style>
      <div id="pb-sa-review" class="pb-sa-rv"><p class="muted">Loading report…</p></div>`;
    if (!window.PB_LOAD_PROJECT_PROGRESS_REPORTS) {
      document.getElementById("pb-sa-review").innerHTML = '<div class="pb-sa-empty">Report review is not available. Reload the page and try again.</div>';
      return;
    }
    await window.PB_LOAD_PROJECT_PROGRESS_REPORTS(it.local || it.pid, "pb-sa-review");
    const reportCard = document.querySelector(`#pb-sa-review article[data-report-card="${CSS.escape(it.id)}"]`);
    if (!reportCard) {
      const reviewBox = document.getElementById("pb-sa-review");
      if (reviewBox && reviewBox.querySelector(".empty, .muted")) {
        reviewBox.insertAdjacentHTML("beforeend", '<div class="pb-sa-empty">This report could not be loaded for review. Refresh Staff Approvals and try again.</div>');
      }
    } else if (!reportCard.querySelector('[data-review="approved"]')) {
      reportCard.querySelector(".pb-rv-actions")?.insertAdjacentHTML("beforeend", '<span class="muted">Your Cloud Team account does not have permission to review this site.</span>');
    }
  }

  /* Turn the plain review lines into clear icon tiles (display only; Approve/Reject buttons untouched) */
  const RV_KIND = [["Location:", "📍", "Location", "#0ea5e9"], ["Labour:", "👷", "Labour", "#f59e0b"], ["Attendance:", "🗓️", "Attendance", "#8b5cf6"],
    ["Materials received:", "📥", "Materials received", "#16a34a"], ["Materials used:", "📦", "Materials used", "#ea580c"], ["Inspection:", "🛡️", "Inspection", "#0d9488"]];
  /* BOQ tile: show the linked BOQ item with before → after-approval progress (read-only preview) */
  function boqLink(tile, title, parts) {
    try {
      const code = String(title).split(" · ")[0].trim();
      const d = (typeof db !== "undefined" ? db : window.db) || {}; const sp = String(window.selectedProject || (typeof selectedProject !== "undefined" ? selectedProject : ""));
      const b = (d.boq || []).find((x) => String(x.boqId || "").trim() === code && (!sp || String(x.projectId) === sp)) || (d.boq || []).find((x) => String(x.boqId || "").trim() === code) || (d.boq || []).find((x) => String(x.id) === code);
      if (!b) { tile.insertAdjacentHTML("beforeend", `<div class="sa-link warn">⚠ BOQ item ${E(code)} not found in this project — sync BOQ first.</div>`); return; }
      const total = Number(b.qty || b.quantity || 0), done = Number(b.executedQty || 0);
      const tp = parts.find((x) => /Reported today/i.test(x)); const today = tp ? Number((tp.match(/[\d.]+/) || [0])[0]) : 0;
      const after = Math.min(total, done + today), pc = (v) => total > 0 ? Math.min(100, v / total * 100) : 0;
      const proj = (d.projects || []).find((p) => String(p.id) === String(b.projectId));
      const loc = [b.building, b.floor, b.area || b.room].filter(Boolean).join(" / ");
      tile.insertAdjacentHTML("beforeend", `<div class="sa-link">
        <div class="sa-link-h">🔗 Linked BOQ: <b>${E(b.boqId || code)}</b> — ${E(b.description || "")}${b.unit ? ` <span>(${E(b.unit)})</span>` : ""}</div>
        <div class="sa-link-m">${proj ? `🏗️ ${E(proj.name)}` : ""}${loc ? ` · 📍 ${E(loc)}` : ""} · 📏 BOQ qty <b>${total.toLocaleString()}</b></div>
        <div class="sa-bar"><i style="width:${pc(done)}%"></i><em style="left:${pc(done)}%;width:${pc(after) - pc(done)}%"></em></div>
        <div class="sa-link-n"><span>✅ Done now <b>${done.toLocaleString()}</b> (${pc(done).toFixed(1)}%)</span><span>➕ This report <b>${today.toLocaleString()}</b></span><span>🎯 After approve <b>${after.toLocaleString()}</b> (${pc(after).toFixed(1)}%)</span><span>⏳ Remaining <b>${Math.max(0, total - after).toLocaleString()}</b></span></div>
        <small>On Approve, this quantity is added to this BOQ item automatically (once, never above BOQ qty).</small></div>`);
    } catch (e) {}
  }

  /* After Approve/Reject in this window: go straight back to the list (no page jumping) */
  let rvId = "", rvTimer = 0, okMsg = "";
  function afterReview(r) {
    if (!rvId || rvTimer) return;
    const card = r.querySelector(`article[data-report-card="${CSS.escape(rvId)}"]`);
    const pill = card && card.querySelector(".pill");
    const st = pill ? pill.textContent.trim().toLowerCase() : "";
    if (st !== "approved" && st !== "rejected") return;
    const it = ST.items.find((x) => x.id === rvId);
    okMsg = st === "approved" ? `✅ Approved — ${it ? it.site + " · " + it.date : "report"}. Quantity added to the linked BOQ and Site Progress.` : `↩ Rejected — ${it ? it.site + " · " + it.date : "report"}. Sent back to the foreman.`;
    ST.items = ST.items.filter((x) => x.id !== rvId); rvId = "";
    rvTimer = setTimeout(() => { rvTimer = 0; draw(); badge(); load().then(() => { draw(); badge(); }); }, 900);
  }

  function enhance(root) {
    root.querySelectorAll("article[data-report-card]:not([data-sa-done])").forEach((card) => {
      card.setAttribute("data-sa-done", "1");
      const head = card.firstElementChild;
      if (head) { const sub = head.querySelector(".muted"); if (sub) { const p = sub.textContent.split(" · "); sub.innerHTML = `<span class="sa-chip">📅 ${E(p[0] || "")}</span><span class="sa-chip">🙋 ${E(p[1] || "")}</span>`; } }
      const tiles = [];
      [...card.children].filter((el) => el.classList.contains("muted")).forEach((el) => {
        const txt = el.textContent.trim();
        const k = RV_KIND.find((x) => txt.startsWith(x[0]));
        let ico, title, color, parts;
        if (k) { [, ico, title, color] = k; parts = txt.slice(k[0].length).split(" · "); }
        else if (el.querySelector("b")) {
          ico = "🧱"; title = el.querySelector("b").textContent; color = "#2563eb";
          parts = txt.slice(title.length).split(" · ").filter((x) => x.trim());
        } else return;
        const chips = parts.map((x) => x.trim()).filter(Boolean).map((x) => {
          const m = x.match(/^([A-Za-z .]+?)\s+([\d(].*)$/);
          return m ? `<div class="sa-kv"><small>${E(m[1])}</small><b>${E(m[2])}</b></div>` : `<div class="sa-kv"><b>${E(x)}</b></div>`;
        }).join("");
        const tile = document.createElement("div"); tile.className = "sa-tile" + (k ? "" : " sa-boq"); tile.style.setProperty("--c", color);
        tile.innerHTML = `<div class="sa-tile-h"><span class="sa-ic">${ico}</span><span>${E(k ? title : "BOQ work")}</span></div>${k ? "" : `<div class="sa-boq-name">${E(title)}</div>`}<div class="sa-kvs">${chips}</div>`;
        if (!k) boqLink(tile, title, parts);
        tiles.push(tile); el.replaceWith(tile);
      });
      if (tiles.length) { const g = document.createElement("div"); g.className = "sa-grid"; tiles[0].before(g); tiles.forEach((t) => g.appendChild(t)); }
    });
  }
  new MutationObserver(() => { const r = document.getElementById("pb-sa-review"); if (!r) return; enhance(r); afterReview(r); }).observe(document.body, { childList: true, subtree: true });

  async function open() {
    css();
    let ov = document.getElementById("pb-sa-ov");
    if (!ov) {
      ov = document.createElement("div"); ov.id = "pb-sa-ov";
      ov.innerHTML = `<div class="pb-sa-panel"><div class="pb-sa-head"><h3>✔ Staff Approvals <small>— everything sent from site staff phones</small></h3><button class="btn small" data-sa-close>Close</button></div><div id="pb-sa-body"></div></div>`;
      document.body.appendChild(ov);
    }
    ov.classList.add("on");
    if (!signedIn()) { document.getElementById("pb-sa-body").innerHTML = '<div class="pb-sa-empty">Sign in to the Cloud team account to see staff approvals.</div>'; return; }
    draw(); await load(); draw();
  }
  window.pbOpenStaffApprovals = open;

  document.addEventListener("click", (e) => {
    const t = e.target;
    if (t.closest("[data-sa-close]") || t.id === "pb-sa-ov") return document.getElementById("pb-sa-ov")?.classList.remove("on");
    const tab = t.closest("[data-sa-tab]"); if (tab) { ST.tab = tab.dataset.saTab; draw(); if (ST.tab === "history") loadHist().then(draw); return; }
    const rg = t.closest("[data-sa-range]"); if (rg) { ST.range = rg.dataset.saRange; return draw(); }
    if (t.closest("[data-sa-reload]")) return (ST.tab === "history" ? loadHist() : load()).then(draw);
    const op = t.closest("[data-sa-open]");
    if (op) { const it = ST.items.find((x) => x.id === op.dataset.saOpen); if (it) review(it); return; }
    if (t.closest("[data-sa-back]")) { rvId = ""; load().then(draw); return draw(); }
    const a = t.closest("[data-sa-act]"); if (a) { a.disabled = true; act(a.dataset.saKind, a.dataset.saId, a.dataset.saAct).finally(() => { a.disabled = false; }); return; }
    if (t.closest("#pb-sa-dash") || t.closest("#pb-sa-nav")) open();
  });
  document.addEventListener("change", (e) => { if (e.target.matches("[data-sa-site]")) { ST.site = e.target.value; draw(); } });
  document.addEventListener("input", (e) => {
    if (!e.target.matches("[data-sa-q]")) return;
    ST.q = e.target.value; const pos = e.target.selectionStart; draw();
    const i = document.querySelector("[data-sa-q]"); if (i) { i.focus(); i.setSelectionRange(pos, pos); }
  });

  /* Side menu entry (no data-page, so the page router never sees it) and dashboard line */
  function decorate() {
    css();
    const prog = document.querySelector('.nav button[data-page="progress"]');
    let nav = document.getElementById("pb-sa-nav");
    if (prog && !nav) {
      prog.insertAdjacentHTML("afterend", `<button type="button" id="pb-sa-nav" title="Staff Approvals"><span class="navicon"><svg viewBox="0 0 24 24"><path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"/></svg></span>Staff Approvals<span id="pb-sa-nav-n" hidden>0</span></button>`);
      nav = document.getElementById("pb-sa-nav");
    }
    if (nav) nav.hidden = !isOffice();
    const al = document.querySelector(".dashboard-alert-content");
    if (al && !document.getElementById("pb-sa-dash")) al.insertAdjacentHTML("afterbegin", `<button type="button" id="pb-sa-dash" hidden><b>0</b><span>Staff approvals waiting</span><i>Open ›</i></button>`);
    badge();
  }
  new MutationObserver(() => { if (!document.getElementById("pb-sa-nav") || (!document.getElementById("pb-sa-dash") && document.querySelector(".dashboard-alert-content"))) decorate(); }).observe(document.body, { childList: true, subtree: true });
  decorate();
  let last = 0;
  setInterval(() => { if (isOffice() && Date.now() - last > 55e3 && !document.hidden) { last = Date.now(); load().then(() => { if (document.getElementById("pb-sa-ov")?.classList.contains("on")) draw(); }); } decorate(); }, 5000);
})();
