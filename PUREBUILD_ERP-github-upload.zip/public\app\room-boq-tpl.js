/* Room BOQ Templates: save a list of work items once, then add them to many rooms in one go.
   Templates live only in side list db.roomBoqTemplates. Applying creates normal db.boq items
   (status Draft, new BOQ IDs, building/floor/area set) — same shape as "+ Add Work Item".
   Rooms that already have the same work (description) are skipped, so nothing is duplicated. */
(function(){
  const num=v=>Number(v)||0;
  const tpls=()=>(db.roomBoqTemplates=Array.isArray(db.roomBoqTemplates)?db.roomBoqTemplates:[]);
  const nav=()=>window.PB_LOC_NAV||{};
  const blds=pid=>Array.isArray(db.projectLocations?.[pid])?db.projectLocations[pid]:[];
  const units=(cur)=>{const b=['Pcs','m²','m³','m','Nos','LS','Kg','Bag','L'],u=(db.settings?.units||[]).filter(Boolean),l=u.length?u.slice():b;if(cur&&!l.includes(cur))l.unshift(cur);return l};
  const dimsFor=u=>{u=String(u||'').toLowerCase().replace(/\s/g,'');if(/m3|m³|cum|cft|cbm/.test(u))return 3;if(/m2|m²|sqm|sqft|sft/.test(u))return 2;if(/^(m|rm|rmt|lm|mtr|meter|metre|ft|rft)$/.test(u))return 1;return 0};
  const STAT=['Draft','Under Review','Approved'];
  const rowHtml=(r={})=>{const u=r.unit||units()[0],d=dimsFor(u),dv=k=>r[k]?r[k]:'';return `<tr class="rbt-row"><td><input class="rbt-cat" value="${esc(r.category||'Civil')}" placeholder="Civil"></td><td><input class="rbt-desc" value="${esc(r.description||'')}" placeholder="e.g. Wall plaster"></td><td><select class="select rbt-unit" onchange="pbRbtUnit(this)">${units(u).map(x=>`<option ${x===u?'selected':''}>${esc(x)}</option>`).join('')}</select></td><td><div class="rbt-dims">${['length','width','height'].map((k,i)=>`<input class="rbt-${k}" type="number" min="0" step="0.001" placeholder="${'LWH'[i]}" value="${dv(k)}" style="${i<d?'':'display:none'}" oninput="pbRbtDim(this)">`).join('')}<span class="muted rbt-nod" style="${d?'display:none':''}">—</span></div></td><td><input class="rbt-qty" type="number" min="0" step="0.001" value="${r.qty??''}" title="Auto from L×W×H, or type your own"></td><td><input class="rbt-rate" type="number" min="0" step="0.01" value="${r.rate??''}"></td><td><select class="select rbt-status">${STAT.map(x=>`<option ${x===(r.status||'Draft')?'selected':''}>${x}</option>`).join('')}</select></td><td><button type="button" class="btn small danger" onclick="this.closest('tr').remove()">✕</button></td></tr>`};
  window.pbRbtUnit=function(sel){const tr=sel.closest('tr'),d=dimsFor(sel.value);['length','width','height'].forEach((k,i)=>{const e=tr.querySelector('.rbt-'+k);e.style.display=i<d?'':'none';if(i>=d)e.value=''});tr.querySelector('.rbt-nod').style.display=d?'none':'';};
  window.pbRbtDim=function(inp){const tr=inp.closest('tr'),d=dimsFor(tr.querySelector('.rbt-unit').value),v=['length','width','height'].slice(0,d).map(k=>num(tr.querySelector('.rbt-'+k).value));if(d&&v.every(x=>x>0))tr.querySelector('.rbt-qty').value=+v.reduce((a,b)=>a*b,1).toFixed(3);window.pbRbtSum&&window.pbRbtSum()};
  const readRows=()=>[...document.querySelectorAll('#modal .rbt-row')].map(t=>{const g=c=>t.querySelector(c);return {category:g('.rbt-cat').value.trim()||'Civil',description:g('.rbt-desc').value.trim(),unit:g('.rbt-unit').value,length:num(g('.rbt-length').value),width:num(g('.rbt-width').value),height:num(g('.rbt-height').value),qty:num(g('.rbt-qty').value),rate:num(g('.rbt-rate').value),status:g('.rbt-status')?.value||'Draft'}}).filter(r=>r.description);
  const css=`.rbt-tbl{width:100%;border-collapse:collapse}.rbt-tbl th{font-size:11px;text-align:left;padding:4px;color:var(--muted,#667)}.rbt-tbl td{padding:3px}.rbt-dims{display:flex;gap:3px;min-width:150px}.rbt-dims input{min-width:0}#modal #modalSave{opacity:1!important;pointer-events:auto!important}.rbt-tbl select.rbt-unit{min-width:74px}.rbt-tbl select.rbt-status{min-width:118px}#modal #modalSave{filter:none!important;background:linear-gradient(135deg,#7C5CE0,#5B3FC4)!important;color:#fff!important}.rbt-tbl input,.rbt-tbl select{width:100%;height:32px;box-sizing:border-box;padding:4px 8px}
  .rbt-rooms{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:6px;max-height:190px;overflow:auto;padding:4px}.rbt-rooms label{display:flex;gap:6px;align-items:center;border:1px solid #DCD8EE;border-radius:9px;padding:6px 8px;font-size:12.5px;cursor:pointer}.rbt-rooms label.has{opacity:.6}
  .rbt-list{display:flex;flex-direction:column;gap:6px}.rbt-item{display:flex;justify-content:space-between;align-items:center;border:1px solid #DCD8EE;border-radius:10px;padding:8px 10px}.rbt-sum{background:#F3F1FB;border-radius:10px;padding:8px 10px;margin-top:8px;font-size:12.5px}`;
  const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

  /* ---------- template editor ---------- */
  window.pbRbtEdit=function(tid,fromItems){
    const t=tid?tpls().find(x=>x.id===tid):null,rows=t?t.items:(fromItems||[{}]);
    openModal(t?'Edit BOQ Template':'New BOQ Template',`<div class="field full"><label>Template name *</label><input id="rbtName" maxlength="80" value="${esc(t?.name||'')}" placeholder="e.g. Standard Bedroom"></div>
    <p class="muted" style="margin:8px 0">Quantity here is the default for <b>one room</b>. You can change it when adding.</p>
    <table class="rbt-tbl"><thead><tr><th>Category</th><th style="width:24%">Work item *</th><th>Unit</th><th>L × W × H</th><th>Qty / room</th><th>Rate</th><th>Status</th><th></th></tr></thead><tbody id="rbtBody">${rows.map(rowHtml).join('')}</tbody></table>
    <button type="button" class="btn small" style="margin-top:6px" onclick="document.getElementById('rbtBody').insertAdjacentHTML('beforeend',window.pbRbtRow())">+ Add line</button>`,()=>{
      const name=document.getElementById('rbtName').value.trim(),items=readRows();
      if(!name){toast('Template name is required');return false}if(!items.length){toast('Add at least one work item');return false}
      if(tpls().some(x=>x.name.toLowerCase()===name.toLowerCase()&&x.id!==tid)){toast('A template with this name already exists');return false}
      if(t){t.name=name;t.items=items;t.updatedAt=new Date().toISOString()}else tpls().push({id:id(),name,items,createdAt:new Date().toISOString()});
      save();toast('Template saved');setTimeout(()=>window.pbRbtOpen(),60);return true});
    document.querySelector('#modal .modalbox,#modal .modal')?.classList.add('rw-wide');
  };
  window.pbRbtRow=()=>rowHtml();
  window.pbRbtDel=function(tid){const t=tpls().find(x=>x.id===tid);if(!t||!confirm(`Delete template "${t.name}"? BOQ items already added stay unchanged.`))return;db.roomBoqTemplates=tpls().filter(x=>x!==t);save();window.pbRbtOpen()};
  window.pbRbtFromRoom=function(pid,loc){const its=(db.boq||[]).filter(i=>String(i.projectId)===String(pid)&&String(i.building||'')===loc[0]&&String(i.floor||'')===loc[1]&&String(i.area||'')===loc[2]);
    if(!its.length){toast('This room has no work items yet');return}closeModal();setTimeout(()=>window.pbRbtEdit(null,its.map(i=>({category:i.category,description:i.description,unit:i.unit,length:i.length,width:i.width,height:i.height,qty:i.qty,rate:i.rate,status:'Draft'}))),60)};

  /* ---------- template list + apply ---------- */
  window.pbRbtOpen=function(preRoom){
    const n=nav(),pid=n.pid;if(!pid){toast('Open a project first');return}
    const B=blds(pid).find(x=>x.name===n.b),F=B?.floors?.find(x=>x.name===n.f);
    const L=tpls();
    openModal('Room BOQ Templates',`<div class="rbt-list">${L.map(t=>`<div class="rbt-item"><span><b>${esc(t.name)}</b><br><small class="muted">${t.items.length} work items · ${money(t.items.reduce((s,i)=>s+num(i.qty)*num(i.rate),0))} per room</small></span><span style="display:flex;gap:6px">${F?`<button type="button" class="btn small primary" onclick="pbRbtApply('${t.id}',${esc(JSON.stringify(preRoom||''))})">Add to rooms</button>`:''}<button type="button" class="btn small" onclick="pbRbtEdit('${t.id}')">Edit</button><button type="button" class="btn small danger" onclick="pbRbtDel('${t.id}')">Delete</button></span></div>`).join('')||'<div class="empty">No templates yet. Create one with the work you repeat in many rooms.</div>'}</div>
    <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="btn primary" onclick="pbRbtEdit()">+ New Template</button></div>
    ${F?'':'<p class="muted" style="margin-top:8px">Open a floor to add a template to its rooms.</p>'}`,()=>true);
    const ms=document.getElementById('modalSave');if(ms)ms.style.display='none';
  };
  window.pbRbtApply=function(tid,preRoom){
    const n=nav(),pid=n.pid,t=tpls().find(x=>x.id===tid),B=blds(pid).find(x=>x.name===n.b),F=B?.floors?.find(x=>x.name===n.f);if(!t||!F)return;
    const rooms=(F.rooms||[]).map(String);
    const has=(r,d)=>(db.boq||[]).some(i=>String(i.projectId)===String(pid)&&String(i.building||'')===B.name&&String(i.floor||'')===F.name&&String(i.area||'')===r&&String(i.description||'').trim().toLowerCase()===d.toLowerCase());
    const full=r=>t.items.every(i=>has(r,i.description));
    openModal(`Add "${esc(t.name)}" · ${esc(B.name)} / ${esc(F.name)}`,`<div style="display:flex;justify-content:space-between;align-items:center"><b>1. Choose rooms</b><span><button type="button" class="btn small" onclick="document.querySelectorAll('#modal .rbt-rc').forEach(c=>c.checked=!c.disabled);pbRbtSum()">Select all</button> <button type="button" class="btn small" onclick="document.querySelectorAll('#modal .rbt-rc').forEach(c=>c.checked=false);pbRbtSum()">Clear</button></span></div>
    <div class="rbt-rooms">${rooms.map(r=>{const f=full(r);return `<label class="${f?'has':''}" title="${f?'Already has all these items':''}"><input type="checkbox" class="rbt-rc" value="${esc(r)}" ${f?'disabled':(preRoom?r===preRoom:true)?'checked':''} onchange="pbRbtSum()">${esc(r)}${f?' ✓':''}</label>`}).join('')||'<div class="empty">No rooms on this floor. Use “Room Template” or “+ Add Room” first.</div>'}</div>
    <b style="display:block;margin-top:10px">2. Check quantity per room</b>
    <table class="rbt-tbl"><thead><tr><th>Category</th><th style="width:24%">Work item</th><th>Unit</th><th>L × W × H</th><th>Qty / room</th><th>Rate</th><th>Status</th><th></th></tr></thead><tbody id="rbtBody">${t.items.map(rowHtml).join('')}</tbody></table>
    <div class="rbt-sum" id="rbtSum"></div><p class="muted" style="margin-top:6px">New items are saved with the <b>Status</b> you pick on each line. Work already in a room is skipped.</p>`,()=>{
      const sel=[...document.querySelectorAll('#modal .rbt-rc:checked')].map(c=>c.value),items=readRows();
      if(!sel.length){toast('Choose at least one room');return false}if(!items.length){toast('No work items');return false}
      let added=0,skipped=0;const now=new Date().toISOString();
      sel.forEach(r=>items.forEach(it=>{if(has(r,it.description)){skipped++;return}
        db.boq.push({id:id(),boqId:nextBoqId(),projectId:pid,category:it.category,description:it.description,length:it.length||0,width:it.width||0,height:it.height||0,qty:it.qty,unit:it.unit,rate:it.rate,amount:it.qty*it.rate,building:B.name,floor:F.name,area:r,remarks:`From template: ${t.name}`,executedQty:0,createdAt:now,status:it.status||'Draft',templateId:t.id});added++}));
      if(added)projectHistoryAdd(pid,'BOQ template applied',`${t.name} → ${B.name} / ${F.name}: ${sel.length} room(s), ${added} item(s)`);
      save();closeModal();projectDetail(pid,'locations');toast(`${added} BOQ item(s) added${skipped?`, ${skipped} skipped (already there)`:''}`);return false});
    document.querySelector('#modal .modalbox,#modal .modal')?.classList.add('rw-wide');
    document.getElementById('rbtBody').addEventListener('input',window.pbRbtSum);window.pbRbtSum();
  };
  window.pbRbtSum=function(){const el=document.getElementById('rbtSum');if(!el)return;const n=document.querySelectorAll('#modal .rbt-rc:checked').length,it=readRows(),per=it.reduce((s,i)=>s+i.qty*i.rate,0);
    el.innerHTML=`<b>${n}</b> room(s) × <b>${it.length}</b> item(s) = up to <b>${n*it.length}</b> BOQ lines · ${money(per)} per room · <b>${money(per*n)}</b> total`};

  /* ---------- buttons: floor view + room panel ---------- */
  function inject(){
    document.querySelectorAll('button[onclick*="pbLocTpl"]').forEach(b=>{if(b.nextElementSibling?.classList.contains('rbt-btn'))return;
      b.insertAdjacentHTML('afterend','<button type="button" class="btn rbt-btn" onclick="pbRbtOpen()">BOQ Template</button>')});
    document.querySelectorAll('#modal button[onclick="pbRoomAdd()"]').forEach(b=>{if(b.parentElement.querySelector('.rbt-btn'))return;
      const h=document.querySelector('#modal .rw-head .muted:last-child')?.textContent||'',room=h.split('·').pop().trim();
      b.insertAdjacentHTML('beforebegin',`<button type="button" class="btn rbt-btn" style="margin-right:6px" onclick='closeModal();setTimeout(()=>pbRbtOpen(${JSON.stringify(room==='—'?'':room)}),60)'>Use BOQ Template</button>`)});
  }
  let q=0;new MutationObserver(()=>{if(q)return;q=requestAnimationFrame(()=>{q=0;inject()})}).observe(document.body,{childList:true,subtree:true});
})();
