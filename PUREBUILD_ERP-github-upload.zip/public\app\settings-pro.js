// Settings page: professional look + Sign out card. UI only; never touches saved data.
(function () {
  const css = `
  .settings-grid>.panel{border:1px solid #e3e8f0;border-radius:14px;box-shadow:0 4px 14px -8px rgba(15,40,80,.25);background:#fff}
  .settings-grid>.panel h3{display:flex;align-items:center;gap:8px;font-size:14px;color:#0f2a4a;border-bottom:1px solid #eef2f7;padding-bottom:8px;margin:0 0 10px}
  .settings-grid>.panel h3::before{content:"";width:4px;height:16px;border-radius:3px;background:linear-gradient(#c9a24a,#1d4a7a)}
  .settings-grid .input,.settings-grid input,.settings-grid textarea,.settings-grid select{border-radius:9px!important;border:1px solid #d6dee9!important}
  .settings-grid .pill,.settings-grid .chip{border-radius:999px;background:#eef4fb;color:#1d4a7a}
  .pb-acct{display:flex;align-items:center;gap:12px;margin-left:auto;padding:6px 6px 6px 8px;border:1px solid #e3e8f0;border-radius:999px;background:linear-gradient(135deg,#fff,#f3f7fc);box-shadow:0 4px 14px -8px rgba(15,40,80,.35)}
  .pb-acct .av{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#0f2a4a,#2563eb);color:#fff;font-weight:800;font-size:13px;box-shadow:0 0 0 3px #fff,0 0 0 4px #c9a24a}
  .pb-acct b{font-size:13px;color:#0f2a4a;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block}
  .pb-acct small{display:inline-block;color:#1d4a7a;background:#e8f0fb;border-radius:999px;padding:1px 8px;font-size:10.5px;font-weight:700;margin-top:2px}
  .pb-acct .pb-out{display:flex;align-items:center;gap:6px;background:linear-gradient(135deg,#dc2626,#b91c1c);border:0;color:#fff;border-radius:999px;padding:9px 16px;font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 6px 14px -6px rgba(185,28,28,.6);transition:transform .15s}
  .pb-acct .pb-out:hover{transform:translateY(-1px)}
  .pb-acct .pb-out svg{width:15px;height:15px}
  .settings-grid.pbs{display:flex!important;flex-direction:column;gap:10px!important;overflow:auto!important;grid-template-rows:none!important}
  .pb-acct .em{display:block;font-size:11px;color:#64748b;margin-top:2px;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .pbs-comp:not(.open)>:not(.pbs-sum){display:none!important}
  .pbs-sum{display:flex;align-items:center;gap:12px;cursor:pointer}
  .pbs-sum .lg{width:42px;height:42px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#0f2a4a,#2563eb);color:#fff;font-size:20px}
  .pbs-sum .in{flex:1;min-width:0}.pbs-sum b{display:block;font-size:15px;color:#0f2a4a}.pbs-sum small{color:#64748b;font-size:12px}
  .pbs-sum .mg{background:#1d4ed8;color:#fff;border:0;border-radius:8px;padding:8px 16px;font-weight:700;font-size:12.5px;cursor:pointer}
  .pbs-comp.open .pbs-sum{border-bottom:1px solid #eef2f7;padding-bottom:10px;margin-bottom:10px}
  .pbs-comp.open .pbs-sum .mg{background:#0f2a4a}
  @media(min-width:1000px){
   .pbs-cards{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:8px!important}
   .pbs-card{padding:9px 12px!important}.pbs-card .ct p{margin:2px 0 6px!important;font-size:11.5px}
   .pbs-card .ci{flex-basis:36px!important;height:36px!important;font-size:17px!important}
   .pbs-card:last-child:nth-child(3n+1){grid-column:auto!important}
   .pbs .pbs-hd{margin:0 0 8px!important}.pbs .pbs-hd .ic{width:32px;height:32px;font-size:16px}
   .settings-grid.pbs>.panel{padding:10px 14px!important}
   .pbs-dm>div{padding:9px 12px!important}.pbs-dm p{margin:2px 0 6px!important}
   .pbs .pbs-note{display:none}
  }
  .settings-grid.pbs>.panel{grid-column:auto!important;grid-row:auto!important;overflow:visible!important;padding:14px 16px!important;flex:0 0 auto}
  .pbs .pbs-hd{display:flex;align-items:center;gap:12px;margin:0 0 12px}
  .pbs .pbs-hd .ic{width:38px;height:38px;border-radius:10px;display:grid;place-items:center;background:#e8f0fe;color:#1d4ed8;font-size:18px}
  .pbs .pbs-hd b{display:block;font-size:15px;color:#0f2a4a}.pbs .pbs-hd small{color:#64748b;font-size:12px}
  .pbs .pbs-hd+h3{display:none}
  .pbs-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
  @media(max-width:1100px){.pbs-cards{grid-template-columns:1fr}}
  .pbs-card{border:1px solid #e3e8f0;border-radius:12px;padding:12px 14px;background:#fff;transition:.15s}
  .pbs-card:hover{border-color:#93b4f5;box-shadow:0 6px 16px -10px rgba(29,78,216,.5)}
  .pbs-card:last-child:nth-child(3n+1){grid-column:1/-1}
  .pbs-card>h3{display:none!important}
  .pbs-card .ch{display:flex;gap:12px;align-items:flex-start}
  .pbs-card .ci{flex:0 0 42px;height:42px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;font-size:20px}
  .pbs-card .ct{flex:1;min-width:0}.pbs-card .ct b{font-size:13.5px;color:#0f2a4a}
  .pbs-card .ct p{margin:4px 0 8px;color:#64748b;font-size:12px;line-height:1.4}
  .pbs-card .cn{background:#e8f0fe;color:#1d4ed8;border-radius:999px;padding:2px 10px;font-size:11px;font-weight:700;white-space:nowrap}
  .pbs-card .mg{background:#1d4ed8;color:#fff;border:0;border-radius:7px;padding:6px 14px;font-weight:700;font-size:12px;cursor:pointer}
  .pbs-card.open .mg{background:#0f2a4a}
  .pbs-card:not(.open)>:not(.ch):not(h3){display:none!important}
  .pbs-card.open>.toolbar{margin-top:10px}
  .pbs-dm{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
  @media(max-width:1100px){.pbs-dm{grid-template-columns:1fr}}
  .pbs-dm>div{border:1px solid;border-radius:12px;padding:12px 14px}
  .pbs-dm b{display:block;font-size:13.5px}.pbs-dm p{margin:4px 0 10px;font-size:12px;color:#64748b}
  .pbs-dm .bk{background:#eff6ff;border-color:#bfdbfe}.pbs-dm .bk b{color:#1d4ed8}
  .pbs-dm .rs{background:#f0fdf4;border-color:#bbf7d0}.pbs-dm .rs b{color:#15803d}
  .pbs-dm .dz{background:#fef2f2;border-color:#fecaca}.pbs-dm .dz b{color:#b91c1c}
  .pbs-dm .btn{margin:0 6px 6px 0}
  .pbs-dm .bk .btn:first-of-type{background:#1d4ed8;color:#fff;border-color:#1d4ed8}
  .pbs-dm .rs label.btn{background:#16a34a;color:#fff;border-color:#16a34a}
  .pbs-dm .dz .btn{background:#dc2626;color:#fff;border-color:#dc2626}
  .pbs .pbs-note{font-size:11.5px;color:#64748b;margin:10px 0 0}
  @media(min-width:1000px){
   #view:has(.stock-ov) .stock-ov .stock-ov-grid>.panel{max-height:205px!important}
   #view:has(.stock-ov) .stock-ov .stock-ov-grid2>.panel{max-height:165px!important}
   #view:has(.stock-ov) .notice,#view:has(.stock-ov) .alert{padding:5px 12px!important;margin-bottom:6px!important;font-size:12.5px}
   #view:has(.stock-ov) .stock-ov .stock-ov-kpi{padding:6px 10px!important}
   #view:has(.stock-ov) .stock-ov .stock-ov-kpi strong{font-size:17px!important}
   #view:has(.stock-ov) .stock-ov .panel h3{margin:0 0 4px!important}
   #view:has(.stock-ov) .stock-ov svg{max-height:120px}
  }`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  async function doOut() {
    if (!confirm("Log out from this computer?")) return;
    try { const c = window.PB_CLOUD_CLIENT; if (c) await c.auth.signOut(); } catch (e) { console.error(e); }
    sessionStorage.removeItem("pb_live");
    location.reload();
  }
  function inject() {
    const grid = document.querySelector(".settings-grid");
    if (!grid || document.getElementById("pb-acct")) return;
    const hd = grid.parentElement.querySelector(".pagehead, .page-head") || grid.parentElement.querySelector("h1, h2")?.parentElement;
    const host = hd;
    const name = window.PB_CLOUD_NAME || "User", role = window.PB_CLOUD_ROLE || "";
    const ini = name.split(/\s+/).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
    const box = document.createElement("div"); box.id = "pb-acct"; box.className = "pb-acct";
    box.innerHTML = `<span class="av">${ini}</span><div><b></b><small></small></div><button class="pb-out" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg>Sign out</button>`;
    box.querySelector("b").textContent = name; box.querySelector("small").textContent = role ? role[0].toUpperCase() + role.slice(1) : "Signed in";
    const em = document.createElement("span"); em.className = "em"; em.textContent = "Logged in as …";
    box.querySelector("div").appendChild(em);
    try { const c = window.PB_CLOUD_CLIENT; if (c) c.auth.getUser().then((r) => { const e = r && r.data && r.data.user && (r.data.user.email || r.data.user.phone); em.textContent = e ? "Logged in as " + e : "Logged in"; }).catch(() => { em.textContent = "Logged in"; }); else em.textContent = "Logged in"; } catch (e) { em.textContent = "Logged in"; }
    box.querySelector(".pb-out").onclick = doOut;
    if (host && host !== grid) { host.style.display = "flex"; host.style.alignItems = "center"; host.appendChild(box); }
    else grid.parentElement.insertBefore(box, grid);
  }
  function coll() {
    const ps = [...document.querySelectorAll(".settings-grid>.panel")];
    ps.forEach((p, i) => {
      if (i === 0 || i === ps.length - 1 || p.dataset.pbc) return;
      const h = p.querySelector(":scope>h3"); if (!h) return;
      p.dataset.pbc = 1; p.classList.add("pb-coll");
      const n = p.querySelectorAll(".pill,.chip,.tag,[onclick*='remove'],[onclick*='del']").length;
      h.insertAdjacentHTML("beforeend", `<span class="pb-cnt">${n || ""}</span><span class="pb-chev">▸</span>`);
      if (!n) h.querySelector(".pb-cnt").remove();
      h.onclick = () => p.classList.toggle("open");
    });
  }
  const INFO = {
    "Payment Methods": ["💳", "Manage payment methods (Cash, Bank, Mobile, etc.) used for transactions."],
    "Expense Categories": ["🧾", "Manage expense categories for better cost tracking and reporting."],
    "Units": ["⚖️", "Manage measurement units (KG, Ton, Pcs, Sqft, etc.) for materials and items."],
    "Worker Team Category": ["👥", "Manage worker team categories for better organization."],
    "Labour Team Categories": ["👷", "Manage labour team categories for project and site management."],
    "Company Staff Designation": ["🪪", "Manage staff designations for employee management."],
    "Labour Trade / Designation": ["🛠️", "Manage labour trade and designations for skilled and unskilled workers."],
  };
  function hd(icon, t, s) { const d = document.createElement("div"); d.className = "pbs-hd"; d.innerHTML = `<span class="ic">${icon}</span><div><b></b><small></small></div>`; d.querySelector("b").textContent = t; d.querySelector("small").textContent = s; return d; }
  function ensureCompanyPrintFields(comp) {
    const form = comp.querySelector(".formgrid");
    if (!form) return;
    const data = (typeof db !== "undefined" ? db : window.db) || {};
    const settings = data.settings || {};
    const addField = (id, title, type, value) => {
      if (form.querySelector(`#${id}`)) return;
      const field = document.createElement("div");
      field.className = type === "textarea" ? "field full" : "field";
      const label = document.createElement("label");
      label.htmlFor = id;
      label.textContent = title;
      const input = document.createElement(type);
      input.id = id;
      if (type === "textarea") {
        input.rows = 2;
        input.maxLength = 240;
      }
      input.value = value || "";
      field.append(label, input);
      form.appendChild(field);
    };
    addField(
      "sCompanyRegistration",
      "Company Registration / Tax ID",
      "input",
      settings.companyRegistration || settings.companyRegistrationNo || settings.companyRegistrationNumber || settings.registrationNumber || settings.companyTRN || settings.trn || settings.companyVAT || settings.companyVatNumber || settings.vatNumber || settings.companyTaxNumber || settings.taxNumber
    );
    addField("sCompanyPrintFooter", "Print Footer Text", "textarea", settings.printFooter);
  }
  function remodel() {
    const grid = document.querySelector(".settings-grid");
    if (!grid || grid.dataset.pbr) return;
    const ps = [...grid.children].filter((x) => x.classList.contains("panel"));
    if (ps.length < 3) return;
    grid.dataset.pbr = 1; grid.classList.add("pbs");
    const comp = ps[0], dm = ps[ps.length - 1], cfg = ps.slice(1, -1);
    ensureCompanyPrintFields(comp);
    comp.dataset.pbc = dm.dataset.pbc = 1;
    comp.classList.add("pbs-comp");
    const data = (typeof db !== "undefined" ? db : window.db) || {};
    const s = data.settings || {};
    const sum = document.createElement("div"); sum.className = "pbs-sum";
    sum.innerHTML = `<span class="lg">🏢</span><div class="in"><b></b><small></small></div><button type="button" class="mg">✎ Edit Company Profile</button>`;
    sum.querySelector("b").textContent = s.companyName || "Company Profile";
    sum.querySelector("small").textContent = [s.companyAddress, s.companyPhone, s.companyEmail].filter(Boolean).join(" · ") || "Click to add address, phone, email, logo";
    const tog = () => comp.classList.toggle("open");
    sum.onclick = tog;
    comp.prepend(sum);
    comp.querySelector(":scope>h3")?.remove();
    const sec = document.createElement("div"); sec.className = "panel"; sec.dataset.pbc = 1;
    sec.appendChild(hd("🗂️", "Configuration Categories", "Manage your system configurations and master data"));
    const cards = document.createElement("div"); cards.className = "pbs-cards"; sec.appendChild(cards);
    grid.insertBefore(sec, dm);
    cfg.forEach((p) => {
      p.dataset.pbc = 1; p.className = "pbs-card";
      const t = (p.querySelector(":scope>h3") || {}).textContent || "";
      const [ic, ds] = INFO[t.trim()] || ["⚙️", "Manage these settings."];
      const n = p.querySelectorAll(".pill").length;
      const ch = document.createElement("div"); ch.className = "ch";
      ch.innerHTML = `<span class="ci">${ic}</span><div class="ct"><b></b><p></p><button type="button" class="mg">Manage ›</button></div><span class="cn">${n} Items</span>`;
      ch.querySelector("b").textContent = t; ch.querySelector("p").textContent = ds;
      ch.querySelector(".mg").onclick = () => p.classList.toggle("open");
      p.prepend(ch); cards.appendChild(p);
    });
    // Data management: three boxes, same buttons moved (handlers unchanged)
    const btns = [...dm.querySelectorAll(":scope>.btn, :scope>label.btn")];
    const notes = [...dm.querySelectorAll(":scope>p")];
    const pick = (re) => btns.filter((b) => re.test(b.textContent));
    const box = document.createElement("div"); box.className = "pbs-dm";
    box.innerHTML = `<div class="bk"><b>⬇ Backup</b><p>Create a backup of your current data. Keep it safe for future use.</p></div><div class="rs"><b>♻ Restore</b><p>Restore your data from a backup file. This will replace current data.</p></div><div class="dz"><b>⚠ Danger Zone</b><p>These actions are irreversible. Please be careful.</p></div>`;
    const [bk, rs, dz] = box.children;
    pick(/Download|Save Safety/).forEach((b) => bk.appendChild(b));
    pick(/Restore|Safety Copies/).forEach((b) => rs.appendChild(b));
    pick(/Reset/).forEach((b) => dz.appendChild(b));
    dm.querySelector(":scope>h3")?.remove(); notes.forEach((x) => x.remove());
    dm.append(hd("🗄️", "Data Management", "Backup, restore and manage your application data safely."), box);
    const nt = document.createElement("p"); nt.className = "pbs-note"; nt.textContent = notes[1] ? notes[1].textContent : ""; dm.appendChild(nt);
    dm.querySelectorAll(":scope>.btn").forEach((b) => bk.appendChild(b));
  }
  new MutationObserver(() => { remodel(); inject(); coll(); }).observe(document.documentElement, { childList: true, subtree: true });
})();
