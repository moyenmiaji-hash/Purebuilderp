# Audit Trail ও Role-Based Access — প্রথম ধাপের রিপোর্ট ও পরিকল্পনা

## এখন অ্যাপ কীভাবে চলে (পরীক্ষা করে যা পেয়েছি)
- সব ERP data (প্রজেক্ট, হিসাব, BOQ, ইনভয়েস, স্টক, স্টাফ) Cloud-এ **একটাই বড় ফাইলের মতো এক সারিতে** রাখা হয়।
- Login আছে; প্রত্যেক ব্যবহারকারীর একটা profile আছে: role (admin / manager / accountant ইত্যাদি), status, permissions।
- এখন role অনুযায়ী শুধু মেনু লুকানো হয়। Data এক জায়গায় থাকায় যে login করতে পারে, সে আসলে পুরো data পড়তে পারে।
- এই Cloud-টা আপনার নিজের সংযোগ করা; আমি সরাসরি এর ভেতরের নিয়ম (policy) দেখতে বা বদলাতে পারি না, শুধু SQL লিখে দিতে পারি যা আপনি চালাবেন।

## বড় ঝুঁকি
প্রজেক্ট-ভিত্তিক আসল নিরাপত্তা (একজন Foreman অন্য প্রজেক্টের data কোনোভাবেই না পায়) এক সারির data দিয়ে করা যায় না। এর জন্য data-কে আলাদা টেবিলে ভাগ করতে হবে — এটা বড় ও ঝুঁকিপূর্ণ বদল, তাই ধাপে ধাপে।

## ধাপগুলো (প্রতিটা ধাপের আগে আপনার অনুমতি নেব)

**ধাপ ১ — Audit Trail (নিরাপদ, পুরনো data ছোঁয় না)**
- নতুন `audit_log` টেবিল: কে, কোন role, কখন, কোন module, কোন record, আগের মান → নতুন মান, কারণ, সফল/ব্যর্থ।
- প্রতিবার Cloud-এ save হলে সার্ভার নিজে আগের আর নতুন data তুলনা করে কী বদলেছে লিখে রাখবে — তাই কেউ এড়িয়ে যেতে পারবে না।
- কেউ audit log বদলাতে বা মুছতে পারবে না; শুধু Admin/Auditor দেখতে পারবে।
- Delete / void / approve / reject / বড় টাকার বদলে "কারণ" লিখতে হবে।
- Access পাতার ভেতরে নতুন "Audit Trail" অংশ: তারিখ, ব্যবহারকারী, প্রজেক্ট, module, কাজের ধরন, record ID দিয়ে খোঁজা; আগে/পরে পাশাপাশি; পাতা ভাগ; Excel export।

**ধাপ ২ — Role ও অনুমতি**
- Role: Owner/Admin, Supervisor, Project Manager, Accountant, Foreman, Read-only/Auditor (আগের role গুলো একই নামে থাকবে)।
- প্রতিটা module-এ আলাদা: দেখা, তৈরি, বদল, মোছা, অনুমোদন, export, user ম্যানেজ।
- Role আলাদা টেবিলে থাকবে, Admin পাতা থেকে বদলাবে; বদলানো audit-এ উঠবে।
- সার্ভারের save ফাংশন নিজে যাচাই করবে অনুমতি না থাকলে বদল আটকাবে (শুধু বোতাম লুকানো না)।

**ধাপ ৩ — প্রজেক্ট অনুযায়ী access (বড় বদল)**
- `project_members` টেবিল: কোন স্টাফ কোন প্রজেক্টে।
- Data-কে প্রজেক্ট অনুযায়ী আলাদা অংশে ভাগ করা, যাতে Cloud-এর নিয়মই অন্য প্রজেক্টের data আটকায়।
- পুরনো এক-সারির data রেখে দেওয়া হবে (মোছা হবে না) যতক্ষণ না নতুন ব্যবস্থা পুরো যাচাই হয়।

## নিরাপত্তা ও ফেরত যাওয়ার উপায়
- প্রতিটা ধাপের আগে পুরো data-র backup ফাইল ও Cloud-এ একটা কপি।
- প্রতিটা SQL-এর সাথে "ফেরত নেওয়ার" SQL।
- কোনো পুরনো নিয়ম বন্ধ করা হবে না যতক্ষণ নতুনটা যাচাই না হয়। গোপন key কখনো অ্যাপে থাকবে না।

## পরীক্ষা
- Admin, Accountant, Project Manager, Foreman — চারটা আলাদা টেস্ট অ্যাকাউন্ট লাগবে (আপনাকে বানাতে হবে বা অনুমতি দিতে হবে)।
- যাচাই: অনুমতিহীন কেউ পড়তে/বদলাতে/মুছতে পারে না; Foreman শুধু নিজের প্রজেক্টের Site Progress দিতে পারে; login, হিসাব, ইনভয়েস, প্রজেক্ট, Site Progress আগের মতো চলে।

## Technical details
- Existing: `erp_cloud_state(data jsonb, revision)` single row, `erp_state_save(p_expected, p_data)` RPC, `profiles(role,status,permissions)`.
- Stage 1: `audit_log` (insert only via SECURITY DEFINER inside `erp_state_save`; diff of `projects/transactions/boq/invoices/...` arrays by `id`); RLS select via `has_role(auth.uid(),'admin'|'auditor')`; no update/delete grants. Reason passed as new optional RPC param `p_reason`.
- Stage 2: `user_roles` + `app_role` enum + `has_role()`; permission matrix jsonb in `role_permissions`; `erp_state_save` rejects changes to modules the caller can't edit.
- Stage 3: split JSON into per-project rows (`erp_project_state`) with RLS on `project_members`; client merges rows on load.
- Migrations delivered as SQL files with rollback scripts; run only after user approval.
