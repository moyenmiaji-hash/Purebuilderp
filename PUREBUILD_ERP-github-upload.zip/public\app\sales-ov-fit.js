/* Sales & Invoiced Overview tab: fit on one desktop screen (display only). Other Sales tabs keep the scroll layout. */
(function(){
  var F='html body.sales-mode:has(#sovSearch)';
  var css=`@media (min-width:1000px) and (min-height:600px){
html:has(#sovSearch){overflow:hidden!important;height:100vh!important}
${F}{height:100vh!important;overflow:hidden!important}
${F} .app{height:100vh!important}
${F} .main,${F} .content{height:100vh!important;max-height:100vh!important;overflow:hidden!important;display:flex!important;flex-direction:column!important;min-height:0!important}
${F} #view{flex:1 1 auto!important;min-height:0!important;overflow:hidden!important;display:flex!important;flex-direction:column!important}
${F} #view>.sov{flex:1 1 auto!important;min-height:0!important;display:flex!important;flex-direction:column!important;gap:8px!important;overflow:hidden!important}
${F} #view .sov>*{flex:0 0 auto!important;margin-top:0!important;margin-bottom:0!important}
${F} #view .sov-kpi{padding:8px 14px!important}
${F} #view .sov-kpi b{font-size:18px!important}
${F} #view .sov-sec>div{padding:6px 12px!important}
${F} #view .sov-main{flex:1 1 auto!important;min-height:0!important;display:grid!important;grid-template-columns:minmax(0,1fr) 290px!important;gap:10px!important;overflow:hidden!important}
${F} #view .sov-table{display:flex!important;flex-direction:column!important;min-height:0!important;overflow:hidden!important;margin:0!important}
${F} #view .sov-wrap{flex:1 1 auto!important;min-height:0!important;overflow:auto!important;max-height:none!important}
${F} #view .sov-wrap thead th{position:sticky!important;top:0!important;z-index:2}
${F} #view .sov-wrap td,${F} #view .sov-wrap th{padding-top:6px!important;padding-bottom:6px!important}
${F} #view .sov-side{display:flex!important;flex-direction:column!important;gap:8px!important;min-height:0!important;overflow:auto!important;max-height:none!important}
${F} #view .sov-side>*{min-height:0!important;flex:0 0 auto!important;margin:0!important}
${F} #view .sov-side .sov-det{max-height:none!important;overflow:visible!important}
${F} #view .sov-qa{display:grid!important;grid-template-columns:1fr 1fr!important;gap:6px!important}
${F} #view .sov-qa h4{grid-column:1/-1;margin:0 0 2px!important}
${F} #view .sov-qa .btn{margin:0!important;padding:7px 8px!important;font-size:12px!important}
}`;
  var s=document.createElement('style');s.id='pbSalesOvFit';s.textContent=css;document.head.appendChild(s);
})();
