# Locations & Allocation: পুরো Location গাছ (Project → Building → Floor → Room → Zone)

লাল ভুল বার্তাটা আসল কোড-ভুল না, এটা নোটের লেখা। নোটে প্রথমে দেখে-বুঝে পরিকল্পনা দিতে বলা হয়েছে, তাই আগে পরিকল্পনা। পুরনো কোনো তথ্য মোছা বা বদলানো হবে না, নতুন মেনু যোগ হবে না।

## এখন যা আছে
- প্রতিটা প্রজেক্টে Building → Floor → Room আগে থেকেই রাখা যায়, Site বাছাই সব ট্যাবে কাজ করে।
- Transaction, Stock, Daily Report, Invoice, Payable-এ শুধু Building রাখা হয়; Floor/Room রাখা হয় না।
- Zone (ঐচ্ছিক ৪র্থ ধাপ) নেই।

## ধাপ ১: Location গাছ (Locations & Allocation-এর ভেতরে)
- খোলা-বন্ধ করা যায় এমন গাছ: Building → Floor → Room → Zone, উপরে খোঁজার ঘর।
- প্রতিটা ধাপে Add / Edit / View / Deactivate। Deactivate করলে লুকায়, মোছে না; যেখানে হিসাব আছে তা ঠিক থাকে।
- ধরন বাছাই: Floor, Basement, Roof, Parking, Lift, Stairs, Corridor, Outdoor, Custom।
- একই ঘরের ভেতরে একই নাম দুবার হবে না।

## ধাপ ২: ধাপে ধাপে বাছাই (একটাই ছোট বাছাই-অংশ, সব ফর্মে একই)
- Building বাছলে শুধু তার Floor, Floor বাছলে শুধু তার Room, তারপর Zone। সব ঐচ্ছিক।
- বসবে: BOQ, Foreman/Daily Report, Stock In/Out, Transaction Entry (Labour/Equipment/Expense), Invoice, Bill, Drawings।
- হাজিরা (attendance) এখন Site ছাড়া রাখা হয় — সেখানে ঐচ্ছিক Location যোগ হবে।

## ধাপ ৩: Location অনুযায়ী হিসাব
- Locations & Allocation-এ প্রতিটা Floor/Room সারিতে: BOQ পরিমাণ, কাজ হয়েছে, বাকি, %, মাল বের হয়েছে, Labour/Equipment/অন্য খরচ।
- উপরে Building / Floor / Room ফিল্টার; Reports পাতায় একই ফিল্টার।

## ধাপ ৪ (আলাদা, আপনার অনুমতি লাগবে): Cloud-এ নিরাপত্তা
- এখন সব তথ্য একটা ভাগে Cloud-এ যায়, তাই "শুধু নিজের প্রজেক্ট/Building দেখা" সার্ভারে আটকাতে তথ্য ভাগ করে রাখতে হবে। এটা আগের পরিকল্পনার ধাপ ২–৩ (Role ও প্রজেক্ট-ভিত্তিক Access)-এর সাথে করা ভালো। এবার শুধু অ্যাপের ভেতরের কাজ হবে; Cloud-এ কিছু চালানো হবে না।

## যা করা হবে না
- পুরনো তথ্য মোছা/বদলানো, নতুন মেনু, হিসাবের নিয়ম বদল, Cloud-এ বিপজ্জনক পরিবর্তন।

## পরীক্ষা
- আলাদা টেস্ট ব্রাউজারে নকল তথ্য দিয়ে: দুই Building, কয়েকটা Floor/Room, প্রতিটায় BOQ + খরচ + মাল দিয়ে হিসাব আলাদা ঠিক আসে কিনা।

## Technical details
- Keep `db.projectLocations[pid]` shape; zones and type/active flags go in side map `db.locationMeta[pid]["building|floor|room"]` (`{type, active, zones:[]}`), per AGENTS.md.
- New optional side fields on records: `floor`, `room`, `zone` next to existing `building`. Absent = unassigned. `matchLocation(rec, {b,f,r,z})` extends `matchBuilding`.
- One reusable `locPicker(prefix, pid, sel)` cascading selects used by all forms.
- Bump `PB_SAFETY_VERSION`. Pages via `setPage()` only. Server-side access (stage 4) deferred to the roles/permissions stage.
