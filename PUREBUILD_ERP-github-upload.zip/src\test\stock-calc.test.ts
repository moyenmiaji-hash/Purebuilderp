import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const src = readFileSync(path.resolve(__dirname, "../../public/app/stock-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const c = box["PBStockCalc"];
const key = (x: any) => x.item + "|" + x.unit;

describe("warehouse stock statement", () => {
  const rows = [
    { date: "2026-09-10", item: "Cement", unit: "bag", direction: "In", qty: 100 },
    { date: "2026-09-20", item: "Cement", unit: "bag", direction: "Out", qty: 30 },
    { date: "2026-10-02", item: "Cement", unit: "bag", direction: "In", qty: 50 },
    { date: "2026-10-05", item: "Cement", unit: "bag", direction: "Out", qty: 20 },
    { date: "2026-10-06", item: "Cement", unit: "bag", direction: "In", qty: 5, movement: "Return" },
    { date: "2026-10-07", item: "Cement", unit: "bag", direction: "Out", qty: 2, movement: "Wastage" },
    { date: "2026-10-08", item: "Cement", unit: "bag", direction: "In", qty: 3, movement: "AdjIn" },
  ];
  it("closing = opening + received + returns + adj+ − issued − damaged − adj−", () => {
    const [r] = c.statement(rows, { from: "2026-10-01", to: "2026-10-31" }, key);
    expect(r.opening).toBe(70);
    expect(r.received).toBe(50);
    expect(r.issued).toBe(20);
    expect(r.returned).toBe(5);
    expect(r.damaged).toBe(2);
    expect(r.adjIn).toBe(3);
    expect(r.closing).toBe(106);
  });
  it("All History has zero opening and same closing", () => {
    const [r] = c.statement(rows, { from: "", to: "" }, key);
    expect(r.opening).toBe(0);
    expect(r.closing).toBe(106);
  });
  it("ledger running balance follows date order", () => {
    const l = c.ledger(rows, key);
    expect(l.map((x: any) => x.balance)).toEqual([100, 70, 120, 100, 105, 103, 106]);
  });
  it("cannot issue more than available, even across two lines", () => {
    const s = c.issueShortages([{ key: "Cement|bag", qty: 60 }, { key: "Cement|bag", qty: 50 }], { "Cement|bag": 106 });
    expect(s).toHaveLength(1);
    expect(s[0].need).toBe(110);
    expect(c.issueShortages([{ key: "Cement|bag", qty: 106 }], { "Cement|bag": 106 })).toHaveLength(0);
  });
  it("last month range and voucher numbering", () => {
    expect(c.periodRange("lastMonth", "2026-10-30")).toEqual({ from: "2026-09-01", to: "2026-09-30" });
    expect(c.nextNo("GRN", ["GRN-0001", "GRN-0009", "ISS-0020"])).toBe("GRN-0010");
  });
});
