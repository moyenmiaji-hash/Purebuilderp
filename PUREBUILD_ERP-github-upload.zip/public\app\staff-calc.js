/* Foreman phone app: live "today's calculation" card under each BOQ work item
   in the daily report. Display only — reads the read-only fields team-staff.js
   already fills (BOQ qty, reported, approved, completed today). Ids, saving and
   validation stay unchanged. Formulas in boq-calc.js (foremanCalc). */
(function () {
  if (window.__pbStaffCalc) return; window.__pbStaffCalc = 1;
  function num(el) { var v = el && parseFloat(String(el.value || '').replace(/,/g, '')); return isFinite(v) ? v : 0; }
  function unitOf(el) { var m = el && /[-\d.,]+\s*(.*)$/.exec(String(el.value || '')); return m ? m[1].trim() : ''; }
  function F(v) { v = Math.round((Number(v) || 0) * 100) / 100; return v.toLocaleString(); }
  function E(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function paint(row) {
    var calc = window.PB_BOQ_CALC; if (!calc) return;
    var sel = row.querySelector('[data-boq-item]'), totalEl = row.querySelector('[data-total]');
    var box = row.querySelector('.sc-card');
    if (!sel || !sel.value || !totalEl || !totalEl.value) { if (box) box.hidden = true; return; }
    if (!box) {
      box = document.createElement('div'); box.className = 'sc-card'; box.setAttribute('aria-live', 'polite');
      var grid = row.querySelector('.grid'); (grid ? grid.parentNode : row).insertBefore(box, grid ? grid.nextSibling : null);
    }
    box.hidden = false;
    var todayEl = row.querySelector('[data-today]');
    var r = calc.foremanCalc({ quantity: num(totalEl), approved: num(row.querySelector('[data-approved]')), reported: num(row.querySelector('[data-reported]')) }, num(todayEl));
    var u = E(unitOf(totalEl));
    var key = [r.quantity, r.approved, r.pending, r.today, r.over].join('|');
    if (box.dataset.k === key) return; box.dataset.k = key;
    box.innerHTML =
      '<div class="sc-head"><span class="sc-ic">📐</span><b>Today\'s calculation</b><span class="sc-pct">' + r.pctBefore.toFixed(1) + '% → <b>' + r.pctAfter.toFixed(1) + '%</b></span></div>' +
      '<div class="sc-bar" role="img" aria-label="Progress after today ' + r.pctAfter.toFixed(1) + ' percent">' +
        '<i class="a" style="width:' + r.pctApproved.toFixed(2) + '%"></i><i class="p" style="width:' + r.pctPending.toFixed(2) + '%"></i><i class="t" style="width:' + r.pctToday.toFixed(2) + '%"></i></div>' +
      '<div class="sc-legend"><span><i class="a"></i>Approved</span><span><i class="p"></i>Waiting approval</span><span><i class="t"></i>Today</span><span><i class="r"></i>Left</span></div>' +
      '<div class="sc-grid">' +
        '<div><small>BOQ total</small><b>' + F(r.quantity) + ' ' + u + '</b></div>' +
        '<div class="a"><small>Approved</small><b>' + F(r.approved) + ' ' + u + '</b></div>' +
        '<div class="p"><small>Waiting</small><b>' + F(r.pending) + ' ' + u + '</b></div>' +
        '<div class="t"><small>Today</small><b>+' + F(r.today) + ' ' + u + '</b></div>' +
        '<div class="s"><small>Total after today</small><b>' + F(r.after) + ' ' + u + '</b></div>' +
        '<div class="r"><small>Left after today</small><b>' + F(r.leftAfter) + ' ' + u + '</b></div>' +
      '</div>' +
      '<div class="sc-sum">' + (r.today > 0
        ? F(r.approved + r.pending) + ' + ' + F(r.today) + ' = <b>' + F(r.after) + ' ' + u + '</b> of ' + F(r.quantity) + ' ' + u + ' · ' + F(r.leftAfter) + ' ' + u + ' left'
        : 'Enter today\'s quantity — you can add up to <b>' + F(r.leftBefore) + ' ' + u + '</b>') + '</div>' +
      (r.over ? '<div class="sc-warn">⚠ More than the remaining BOQ quantity (' + F(r.leftBefore) + ' ' + u + '). Please check.</div>' : '') +
      '<div class="sc-note">Added to BOQ only after the office approves.</div>';
  }
  function all() { document.querySelectorAll('#boq-progress-lines .report-item').forEach(function (row) { try { paint(row); } catch (e) {} }); }
  function soon() { setTimeout(all, 0); }
  function boot() {
    var box = document.getElementById('boq-progress-lines'); if (!box) return;
    box.addEventListener('input', soon); box.addEventListener('change', soon);
    var form = document.getElementById('report-form'); if (form) form.addEventListener('change', soon);
    new MutationObserver(function (m) { if (m.some(function (x) { return x.target === box; })) soon(); }).observe(box, { childList: true });
    /* values are also filled by code without events (site load) — light refresh */
    setInterval(function () { if (!document.hidden && box.offsetParent) all(); }, 1200);
    all();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
