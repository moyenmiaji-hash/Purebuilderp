import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const src = readFileSync(path.resolve(__dirname, "../../public/app/wh-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const c = box["PBWhCalc"];
const key = (x: any) => x.item + "|" + x.unit;

describe("central warehouse balance", () => {
  it("opening + GRN + returns − issues − damage − adjustments", () => {
    const rows = [
      { item: "Cement", unit: "Bag", direction: "In", movement: "Opening", qty: 50 },
      { item: "Cement", unit: "Bag", direction: "In", movement: "GRN", qty: 200, rate: 18 },
      { item: "Cement", unit: "Bag", direction: "Out", movement: "Issue", qty: 120 },
      { item: "Cement", unit: "Bag", direction: "In", movement: "Return", qty: 10 },
      { item: "Cement", unit: "Bag", direction: "Out", movement: "Damage", qty: 5 },
      { item: "Cement", unit: "Bag", direction: "Out", movement: "AdjOut", qty: 3 },
    ];
    const s = c.centralStatement(rows, key)[0];
    expect(s.available).toBe(132);
    expect(s.received).toBe(200);
    expect(s.avgRate).toBe(18);
  });
  it("a reversal row undoes the original", () => {
    const rows = [
      { item: "Steel", unit: "Ton", direction: "In", movement: "GRN", qty: 10 },
      { item: "Steel", unit: "Ton", direction: "Out", movement: "GRN", qty: 10, reversal: true },
    ];
    const s = c.centralStatement(rows, key)[0];
    expect(s.received).toBe(0);
    expect(s.available).toBe(0);
  });
});

describe("foreman site formula", () => {
  it("closing = opening + received + returns from warehouse − used − damaged − transferred out", () => {
    expect(c.siteClosing({ opening: 100, received: 50, returnsFromWh: 5, used: 60, damaged: 4, transferredOut: 10 })).toBe(81);
  });
  it("blocks impossible stock", () => {
    expect(c.checkSiteLine({ opening: 10, used: 11 })).not.toBe("");
    expect(c.checkSiteLine({ opening: 10, used: -1 })).not.toBe("");
    expect(c.checkSiteLine({ opening: 10, used: 10 })).toBe("");
  });
});

describe("units", () => {
  it("converts ton to kg and cum to cft", () => {
    expect(c.convert(2, "Ton", "Kg")).toBe(2000);
    expect(c.convert(1, "m³", "CFT")).toBeCloseTo(35.3147, 3);
  });
  it("refuses to mix bags with kg unless a rule exists", () => {
    expect(c.convert(1, "Bag", "Kg")).toBeNull();
    expect(c.convert(2, "Bag", "Kg", [{ from: "Bag", to: "Kg", factor: 50 }])).toBe(100);
  });
});

describe("purchase receiving", () => {
  it("open qty never goes below zero and counts pending GRNs", () => {
    expect(c.purchaseOpen(100, 60, 30)).toBe(10);
    expect(c.purchaseOpen(100, 80, 30)).toBe(0);
  });
  it("detects an already posted voucher", () => {
    expect(c.isPosted("v1", [{ whVoucherId: "v1" }])).toBe(true);
    expect(c.isPosted("v1", [{ whVoucherId: "v1", reversal: true }])).toBe(false);
  });
});

describe("site material receiving", () => {
  it("supplier delivery adds only accepted qty, never damaged", () => {
    expect(c.receivingPost("supplier", 100, 90, 6)).toEqual({ inQty: 90, damageOut: 0, shortOut: 0 });
  });
  it("central delivery: already in site stock, damage and shortage go out", () => {
    // dispatched 100, received 96 (4 short), 6 damaged, 90 accepted
    expect(c.receivingPost("central", 100, 90, 6)).toEqual({ inQty: 0, damageOut: 6, shortOut: 4 });
  });
  it("central delivery fully accepted posts nothing (no double count)", () => {
    expect(c.receivingPost("central", 50, 50, 0)).toEqual({ inQty: 0, damageOut: 0, shortOut: 0 });
  });
  it("shortage is expected minus received, never negative", () => {
    expect(c.receivingShortage(100, 96)).toBe(4);
    expect(c.receivingShortage(100, 110)).toBe(0);
  });
});
