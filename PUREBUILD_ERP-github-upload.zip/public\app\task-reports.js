// Task Management → Performance Reports. Read-only over the task data already loaded by foreman-tasks.js (PB_TASKS_STATE).
// Formulas live in task-calc.js. Nothing is written anywhere.
(function () {
  const C = () => window.PB_TASK_CALC;
  const S = () => window.PB_TASKS_STATE || { tasks: [], updates: [], foremen: [], projects: [] };
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const Q = (n) => (n == null || !Number.isFinite(Number(n)) ? "—" : Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 }));
  const P = (n) => (n == null ? "No Data" : `${Math.round(n)}%`);
  const fName = (id) => S().foremen.find((x) => x.user_id === id)?.display_name || "Staff";
  const pName = (id) => S().projects.find((p) => p.id === id)?.name || "—";
  const taskNo = (t) => `TSK-${String(t.task_no || 0).padStart(3, "0")}`;
  const TABS = [["foreman", "Foreman performance"], ["daily", "Daily target vs actual"], ["period", "Weekly / monthly"], ["project", "Project completion"], ["overdue", "Overdue tasks"], ["workers", "Worker productivity"]];
  const r = { tab: "foreman", range: "month", from: "", to: "" };

  function range() {
    const td = C().dubaiToday();
    if (r.range === "custom" && r.from && r.to) return [r.from, r.to];
    if (r.range === "week") { const d = (new Date(td + "T00:00:00Z").getUTCDay() + 6) % 7; return [C().addDays(td, -d), td]; }
    if (r.range === "last30") return [C().addDays(td, -29), td];
    return [td.slice(0, 8) + "01", td];
  }
  const tasks = () => S().tasks.filter((t) => t.status !== "cancelled");

  // Each report → { head: [...], rows: [[...]], foot? }
  function build() {
    const [from, to] = range(), td = C().dubaiToday(), T = tasks(), U = S().updates;
    if (r.tab === "foreman") {
      const ids = [...new Set(T.map((t) => t.assigned_to))];
      const rows = ids.map((id) => {
        const p = C().foremanPeriod(T, U, id, from, to, td);
        const planned = p.groups.reduce((a, g) => a + g.planned, 0), appr = p.groups.reduce((a, g) => a + g.approved, 0);
        const units = p.groups.map((g) => `${Q(g.approved)} / ${Q(g.planned)} ${g.unit}`).join(" · ");
        return { id, p, ach: C().pct(appr, planned), units };
      }).sort((a, b) => (b.ach ?? -1) - (a.ach ?? -1));
      return { head: ["Rank", "Foreman", "Tasks", "Completed", "In progress", "Overdue", "Approved / Planned", "Achievement", "On-time rate", "Missing reports", "Missed targets"],
        rows: rows.map((x, i) => [i + 1, fName(x.id), x.p.tasks, x.p.completed, x.p.inProgress, x.p.overdue, x.units || "—", P(x.ach), P(x.p.onTimeRate), x.p.missingReports, x.p.missedTargets]),
        bars: rows.map((x) => [fName(x.id), x.ach]) };
    }
    if (r.tab === "daily") {
      const rows = C().dailyRows(T, U, from, to);
      return { head: ["Date", "Task", "Foreman", "Project", "Daily target", "Reported", "Approved", "Waiting", "Achievement", "Workers"],
        rows: rows.map((x) => [x.date, `${taskNo(x.task)} ${x.task.title}`, fName(x.task.assigned_to), pName(x.task.project_id), `${Q(x.target)} ${x.task.unit}`, Q(x.reported), Q(x.approved), Q(x.pending), P(x.achievement), x.workers || "—"]) };
    }
    if (r.tab === "period") {
      const td0 = C().dubaiToday(), out = [];
      const mode = r.range === "week" ? "week" : "month";
      for (let i = 0; i < 6; i++) {
        let a, b;
        if (mode === "week") { const d = (new Date(td0 + "T00:00:00Z").getUTCDay() + 6) % 7; a = C().addDays(td0, -d - 7 * i); b = C().addDays(a, 6); }
        else { const dt = new Date(td0 + "T00:00:00Z"); dt.setUTCDate(1); dt.setUTCMonth(dt.getUTCMonth() - i); a = dt.toISOString().slice(0, 10); const e = new Date(dt); e.setUTCMonth(e.getUTCMonth() + 1); e.setUTCDate(0); b = e.toISOString().slice(0, 10); }
        const ids = [...new Set(T.map((t) => t.assigned_to))];
        let planned = 0, appr = 0; ids.forEach((id) => C().foremanPeriod(T, U, id, a, b, td0).groups.forEach((g) => { planned += g.planned; appr += g.approved; }));
        const reports = U.filter((u) => u.report_date >= a && u.report_date <= b);
        out.push([mode === "week" ? `Week of ${a}` : a.slice(0, 7), `${a} → ${b}`, reports.length, reports.filter((u) => u.review_status === "approved").length, Q(planned), Q(appr), P(C().pct(appr, planned))]);
      }
      return { head: [mode === "week" ? "Week" : "Month", "Dates", "Reports", "Approved reports", "Planned qty", "Approved qty", "Achievement"], rows: out, note: "Tip: choose \"This week\" above to see weeks, any other period shows months. Quantities of different units are added together here; see Foreman performance for per-unit figures." };
    }
    if (r.tab === "project") {
      const rows = C().projectRows(T, U, td);
      return { head: ["Project / Site", "Unit", "Tasks", "Completed", "Overdue", "Target", "Approved", "Completion"],
        rows: rows.map((x) => [pName(x.project), x.unit, x.tasks, x.completed, x.overdue, Q(x.target), Q(x.approved), P(x.completion)]), bars: rows.map((x) => [`${pName(x.project)} (${x.unit})`, x.completion]) };
    }
    if (r.tab === "overdue") {
      const rows = T.map((t) => ({ t, s: C().taskStats(t, U, td) })).filter((x) => x.s.overdue).sort((a, b) => a.t.due_date.localeCompare(b.t.due_date));
      return { head: ["Task", "Title", "Foreman", "Project", "Due date", "Days late", "Target", "Approved", "Remaining", "Completion", "Last delay reason"],
        rows: rows.map(({ t, s }) => [taskNo(t), t.title, fName(t.assigned_to), pName(t.project_id), t.due_date, C().daysBetween(t.due_date, td) - 1, `${Q(s.target)} ${t.unit}`, Q(s.approved), Q(s.remaining), P(s.overallPct), s.delayReason || "—"]) };
    }
    const rows = C().productivity(T, U, from, to).sort((a, b) => (b.perWorker ?? 0) - (a.perWorker ?? 0));
    return { head: ["Foreman", "Unit", "Approved qty", "Reports", "Worker-days", "Man-hours", "Qty per worker-day", "Qty per man-hour"],
      rows: rows.map((x) => [fName(x.foreman), x.unit, Q(x.qty), x.reports, x.workerDays, Q(x.manHours), Q(x.perWorker), Q(x.perHour)]),
      note: "Only approved reports where the foreman entered the number of workers are counted." };
  }

  const css = document.createElement("style");
  css.textContent = `.tr-ov{position:fixed;inset:0;background:rgba(10,20,35,.55);z-index:9000;display:flex;align-items:flex-start;justify-content:center;padding:24px 12px;overflow:auto}
.tr-box,.tr-box td,.tr-box span,.tr-box h3,.tr-flt{color:#1b2a3d}.tr-box{background:#fff;border-radius:14px;width:min(1180px,100%);box-shadow:0 20px 60px rgba(0,0,0,.3);display:flex;flex-direction:column;max-height:calc(100vh - 48px)}
.tr-hd{display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid #e5ebf2}.tr-hd h3{margin:0;flex:1;font-size:17px}
.tr-tabs{display:flex;gap:4px;flex-wrap:wrap;padding:8px 16px;border-bottom:1px solid #e5ebf2}.tr-tabs button{border:0;background:#f2f6fb;padding:7px 11px;border-radius:8px;font-weight:700;font-size:12px;cursor:pointer;color:#3c4f68}.tr-tabs button.on{background:#0f3d6e;color:#fff}
.tr-flt{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:8px 16px;font-size:12px}.tr-flt select,.tr-flt input{padding:5px 7px;border:1px solid #d4dde8;border-radius:7px}
.tr-body{padding:4px 16px 16px;overflow:auto}.tr-body table{width:100%;border-collapse:collapse;font-size:12px}.tr-body th{background:#0f3d6e;color:#fff;text-align:left;padding:7px;font-size:11px;position:sticky;top:0}.tr-body td{padding:6px 7px;border-bottom:1px solid #edf1f6}
.tr-bars{display:grid;gap:5px;margin:6px 0 12px}.tr-bars div{display:grid;grid-template-columns:200px 1fr 60px;gap:8px;align-items:center;font-size:12px}.tr-bars i{display:block;height:9px;border-radius:5px;background:#e6ecf3;overflow:hidden}.tr-bars i b{display:block;height:100%;background:#2563eb}
.tr-note{font-size:11px;color:#6b7c93;margin:6px 0}`;
  document.head.appendChild(css);

  function draw() {
    const ov = document.querySelector(".tr-ov"); if (!ov) return;
    const [from, to] = range(), rep = build();
    ov.querySelectorAll(".tr-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === r.tab));
    ov.querySelector("#trRange").textContent = `${from} → ${to}`;
    ov.querySelector(".tr-body").innerHTML = (rep.bars?.length ? `<div class="tr-bars">${rep.bars.map(([l, v]) => `<div><span>${E(l)}</span><i><b style="width:${Math.max(0, Math.min(100, v ?? 0))}%;background:${(v ?? 0) >= 100 ? "#16a34a" : (v ?? 0) >= 70 ? "#2563eb" : "#f59e0b"}"></b></i><b>${P(v)}</b></div>`).join("")}</div>` : "")
      + (rep.note ? `<div class="tr-note">${E(rep.note)}</div>` : "")
      + `<table><thead><tr>${rep.head.map((h) => `<th>${E(h)}</th>`).join("")}</tr></thead><tbody>${rep.rows.map((row) => `<tr>${row.map((c) => `<td>${E(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${rep.head.length}" style="text-align:center;color:#8794a6;padding:20px">No data for this period.</td></tr>`}</tbody></table>`;
  }
  function csv() {
    const rep = build(), q = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const txt = [rep.head, ...rep.rows].map((row) => row.map(q).join(",")).join("\r\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + txt], { type: "text/csv" }));
    a.download = `task-report-${r.tab}-${range().join("_")}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function print() {
    const rep = build(), [from, to] = range(), title = TABS.find((t) => t[0] === r.tab)[1];
    const co = (window.db && db.settings && (db.settings.companyName || db.settings.company)) || "PURE_BUILD";
    const html = `<html><head><title>${E(title)}</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Arial,sans-serif;color:#111;font-size:11px}h1{font-size:16px;margin:0}h2{font-size:13px;margin:4px 0 10px;color:#0f3d6e}table{width:100%;border-collapse:collapse}th{background:#0f3d6e;color:#fff;text-align:left;padding:5px;font-size:10px}td{padding:4px 5px;border-bottom:1px solid #ddd}thead{display:table-header-group}tr{page-break-inside:avoid}.m{color:#666;font-size:10px;margin-bottom:8px}</style></head><body>
<h1>${E(co)}</h1><h2>Task Performance Report — ${E(title)}</h2><div class="m">Period: ${E(from)} → ${E(to)} · Printed ${E(new Date().toLocaleString())}${rep.note ? " · " + E(rep.note) : ""}</div>
<table><thead><tr>${rep.head.map((h) => `<th>${E(h)}</th>`).join("")}</tr></thead><tbody>${rep.rows.map((row) => `<tr>${row.map((c) => `<td>${E(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${rep.head.length}">No data.</td></tr>`}</tbody></table></body></html>`;
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0;right:0;bottom:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 250);
  }
  function open() {
    if (!S().loaded) { (window.toast || alert)("Tasks are still loading. Try again in a moment."); return; }
    document.querySelector(".tr-ov")?.remove();
    const ov = document.createElement("div"); ov.className = "tr-ov";
    ov.innerHTML = `<div class="tr-box"><div class="tr-hd"><h3>📈 Task Performance Reports</h3><button class="btn small" data-a="csv">⬇ CSV</button><button class="btn small" data-a="print">🖨 Print</button><button class="btn small" data-a="close">✕</button></div>
<div class="tr-tabs">${TABS.map(([k, l]) => `<button type="button" data-t="${k}">${l}</button>`).join("")}</div>
<div class="tr-flt">Period <select id="trSel">${[["week", "This week"], ["month", "This month"], ["last30", "Last 30 days"], ["custom", "Custom dates"]].map(([v, l]) => `<option value="${v}" ${v === r.range ? "selected" : ""}>${l}</option>`).join("")}</select>
<span id="trCustom" style="display:${r.range === "custom" ? "inline-flex" : "none"};gap:6px;align-items:center"><input type="date" id="trFrom" value="${r.from}"> to <input type="date" id="trTo" value="${r.to}"></span><b id="trRange" style="margin-left:auto;color:#55677f"></b></div>
<div class="tr-body"></div></div>`;
    document.body.appendChild(ov);
    ov.addEventListener("click", (e) => {
      if (e.target === ov) ov.remove();
      const t = e.target.closest("[data-t]"); if (t) { r.tab = t.dataset.t; draw(); }
      const a = e.target.closest("[data-a]")?.dataset.a; if (a === "close") ov.remove(); if (a === "csv") csv(); if (a === "print") print();
    });
    ov.querySelector("#trSel").onchange = (e) => { r.range = e.target.value; ov.querySelector("#trCustom").style.display = r.range === "custom" ? "inline-flex" : "none"; draw(); };
    ov.querySelector("#trFrom").onchange = (e) => { r.from = e.target.value; draw(); };
    ov.querySelector("#trTo").onchange = (e) => { r.to = e.target.value; draw(); };
    draw();
  }
  window.PB_TASK_REPORTS = open;
})();
