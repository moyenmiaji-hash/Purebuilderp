# Room-wise BOQ ও কাজের ব্যবস্থা (Room 801-এর মতো)

লাল ভুল বার্তাটা আসল কোড-ভুল না, এটা নোটের লেখা। নোটে যা চাওয়া হয়েছে তার পরিকল্পনা নিচে। পুরনো কোনো তথ্য মুছবে না, নতুন মেনু আসবে না।

## ১. Room-এ ক্লিক করলে আলাদা Room পাতা
- Projects → Site → Locations & Allocation-এ Building → Floor → Room কার্ড আকারে দেখাবে।
- Room (যেমন Room 801) চাপলে একটা বড় প্যানেল খুলবে: Project, Building, Floor, Room; মোট আইটেম, Approved পরিমাণ, BOQ টাকা, অগ্রগতি %।
- বোতাম: Add Work Item, View Details, Edit, Add Progress।

## ২. এক রুমে অনেক কাজ
- প্রতিটা কাজে: Category (Civil, Brickwork, Plaster, Tiles, Painting, Electrical, Plumbing, Finishing বা নিজের লেখা), কাজের নাম, Specification, Unit, পরিমাণ, Rate, মোট টাকা (নিজে হিসাব), সম্পন্ন, বাকি, %, শুরু/শেষ তারিখ, নোট, ফাইল।
- এগুলো আগের BOQ আইটেম হিসেবেই সেভ হবে, তাই BOQ পাতা, Quotation, Invoice, Reports সবখানে একই আইটেম দেখাবে, ডুপ্লিকেট হবে না।

## ৩. View Details ও Add Progress
- View Details: পরিমাণ, টাকা, অগ্রগতির ইতিহাস, ওই রুমের মালামাল/শ্রমিক/খরচ, Revision ইতিহাস, ফাইল।
- Add Progress: তারিখ + পরিমাণ দিলে সম্পন্ন পরিমাণ বাড়বে, বাকি ও % নতুন হিসাব হবে। বাকির চেয়ে বেশি দেওয়া যাবে না। আগের ইতিহাস থাকবে।
- Office থেকে দেওয়া Progress আর ফোরম্যানের Approve হওয়া রিপোর্ট দুটোই একই ইতিহাসে আসবে।

## ৪. Cloud ও অনুমতি
- আইটেম Cloud-এ আগের মতো ERP তথ্যের সাথে সেভ হয় এবং ফোরম্যানের জন্য BOQ তালিকায় যায় (শুধু Approved/Revised)। নতুন তথ্যের জায়গা লাগলে শুধু নতুন ঘর যোগ হবে, কিছু মুছবে না।
- বদলাতে পারবেন Admin/Manager; Accountant দেখতে পারবেন; স্টাফ শুধু নিজের প্রজেক্টে Progress জমা দিতে পারবেন (এখনকার নিয়ম)।

## ৫. পরীক্ষা
- আলাদা পরীক্ষার ব্রাউজারে নকল তথ্যে: রুম তৈরি, কয়েকটা কাজ যোগ, Details, Edit, Progress, রিফ্রেশে তথ্য ঠিক থাকে কিনা, মোট ঠিক আসে কিনা।
- আপনার আসল তথ্যে হাত দেওয়া হবে না। Publish আপনি নিজে করবেন।

## Technical details
- Reuse `db.boq[]` records; add optional side fields only: `category`, `spec`, `startDate`, `endDate`, `notes`, `attachments[]`, `progressLog[{date,qty,by,note,source}]`. Old items load unchanged.
- Room panel in `public/app/index.html` inside existing Locations tab; pages via `setPage()`.
- Sync via existing `team-erp.js` `team_boq_items` upsert (`metadata` jsonb carries new fields) — no migration expected.
- Bump `PB_SAFETY_VERSION`.
