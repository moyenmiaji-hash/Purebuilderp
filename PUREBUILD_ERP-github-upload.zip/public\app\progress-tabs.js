/* Site Progress tabs: only re-arranges the boxes progress() already draws into 4 tabs.
   No data is read or written except the remembered tab name (sessionStorage). */
(function () {
  const MAIN = [["foreman", "👷 Foreman Updates"], ["manual", "✍️ Manual Update"]];
  let more = false;
  try { more = localStorage.getItem("PB_PROGRESS_MORE") === "1"; } catch (e) {}
  const TABS = [
    ["overview", "📊 Dashboard"],
    ["boqwork", "📐 BOQ Work Progress"],
    ["daily", "📋 Daily & Task Progress"],
    ["schedule", "🗓 Schedule & Manpower"],
    ["photos", "📷 Photos & Graph"],
    ["reports", "📑 Reports & Print"],
  ];
  let active = "foreman";
  try { active = sessionStorage.getItem("PB_PROGRESS_TAB") || "foreman"; } catch (e) {}
  if (!more && !MAIN.some(([k]) => k === active)) active = "foreman";
  const ALIAS = { work: "boqwork", buildings: "boqwork", today: "daily", register: "daily" };
  if (ALIAS[active]) active = ALIAS[active];

  const css = document.createElement("style");
  css.textContent = `
  .pt-bar{display:flex;gap:6px;margin:6px 0 8px;padding:5px;background:#fff;border:1px solid #e3e9f1;border-radius:12px;flex-wrap:wrap}
  .pt-bar button{flex:1;min-width:120px;border:0;background:transparent;padding:9px 12px;border-radius:9px;font-weight:700;font-size:13px;color:#4a5b72;cursor:pointer}
  .pt-bar button:hover{background:#f2f6fb}
  .pt-bar button.on{background:#0f3d6e;color:#fff;box-shadow:0 2px 8px rgba(15,61,110,.25)}
  #view.pt-on .progress-main-grid{display:grid!important;grid-template-columns:2fr 1fr;gap:12px;height:auto!important;max-height:none!important;align-items:start}
  #view.pt-on .progress-left,#view.pt-on .progress-right{display:contents!important}
  #view.pt-on .progress-main-grid>*>.panel,#view.pt-on .progress-bottom-grid>.panel{height:auto!important;max-height:none!important}
  #view.pt-on [data-pt]{display:none!important}
  #view.pt-on [data-pt].pt-show{display:block!important}
  #view.pt-on .pp-grid3[data-pt].pt-show{display:grid!important}
  #view.pt-on .pp-host{grid-column:1/-1}
  #view.pt-on .progress-summary[data-pt].pt-show{display:grid!important}
  #view.pt-on .progress-bottom-grid[data-pt].pt-show{display:grid!important;height:auto!important}
  #view.pt-on .pt-wide{grid-column:1/-1}
  #view.pt-on .trade-table{font-size:13px}
  #view.pt-on .progress-summary .kpi strong{font-size:22px}
  #view.pt-on .progress-summary .kpi small{font-size:11px}
  `;
  document.head.appendChild(css);

  function apply() {
    const v = document.getElementById("view");
    const sum = v && v.querySelector(".progress-summary");
    if (!sum) { v && v.classList.remove("pt-on"); return; }
    const mark = (el, t, wide) => { if (el) { el.dataset.pt = t; if (wide) el.classList.add("pt-wide"); } };
    const left = v.querySelectorAll(".progress-left > .panel");
    const right = v.querySelectorAll(".progress-right > .panel");
    mark(sum, "overview");
    left.forEach((p) => {
      if (p.classList.contains("work-detail-panel")) mark(p, "buildings", true);
      else if (p.querySelector(".activity-grid")) mark(p, "today");
      else mark(p, "overview");
    });
    right.forEach((p) => {
      if (p.querySelector(".today-activity-grid")) mark(p, "today");
      else mark(p, "overview");
    });
    mark(v.querySelector(".progress-bottom-grid"), "photos");

    let bar = v.querySelector(".pt-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "pt-bar";
      bar.addEventListener("click", (e) => {
        const b = e.target.closest("button[data-k]");
        if (!b) return;
        if (b.dataset.k === "__more") {
          more = !more; try { localStorage.setItem("PB_PROGRESS_MORE", more ? "1" : "0"); } catch (e2) {}
          if (!more && !MAIN.some(([k]) => k === active)) active = "foreman";
          drawBar(bar); show(); return;
        }
        active = b.dataset.k;
        try { sessionStorage.setItem("PB_PROGRESS_TAB", active); } catch (e2) {}
        show();
      });
      sum.insertAdjacentElement("beforebegin", bar);
    }
    drawBar(bar);
    v.classList.add("pt-on");
    try { window.PB_PROGRESS_PRO && window.PB_PROGRESS_PRO.inject(v); } catch (e) { console.warn(e); }
    try { window.PB_PROGRESS_SUITE && window.PB_PROGRESS_SUITE.inject(v); } catch (e) { console.warn(e); }
    try { window.PB_SIMPLE_PROGRESS && window.PB_SIMPLE_PROGRESS.inject(v); } catch (e) { console.warn(e); }
    try { window.PB_SCHEDULE && window.PB_SCHEDULE.inject(v); } catch (e) { console.warn(e); }
    try { window.PB_PROGRESS_EXTRAS && window.PB_PROGRESS_EXTRAS.inject(v); } catch (e) { console.warn(e); }
    try { window.PB_WORK_REGISTER && window.PB_WORK_REGISTER.inject(v); } catch (e) { console.warn(e); }
    show();
  }

  function drawBar(bar) {
    const list = MAIN.concat(more ? TABS : []);
    bar.innerHTML = list.map(([k, l]) => `<button type="button" data-k="${k}">${l}</button>`).join("") + `<button type="button" class="sp-more" data-k="__more">${more ? "▲ Fewer views" : "▼ More views (dashboard, reports…)"}</button>`;
  }

  function show() {
    const v = document.getElementById("view");
    v.querySelectorAll(".pt-bar button").forEach((b) => b.classList.toggle("on", b.dataset.k === active));
    v.querySelectorAll("[data-pt]").forEach((el) => el.classList.toggle("pt-show", (ALIAS[el.dataset.pt] || el.dataset.pt) === active));
  }

  window.PB_PROGRESS_TABS_SHOW = show;
  window.PB_PROGRESS_TABS_SET = (k) => { active = ALIAS[k] || k; try { sessionStorage.setItem("PB_PROGRESS_TAB", k); } catch (e) {} show(); };
  function hook() {
    const orig = window.progress;
    if (typeof orig !== "function" || orig.__pt) return;
    const wrapped = function () {
      const r = orig.apply(this, arguments);
      try { apply(); } catch (e) { console.warn("progress-tabs", e); }
      return r;
    };
    wrapped.__pt = true;
    window.progress = wrapped;
  }
  hook();
  window.addEventListener("load", hook);
  // Leaving the page: drop the tab class so other pages are untouched.
  new MutationObserver(() => {
    const v = document.getElementById("view");
    if (v && v.classList.contains("pt-on") && !v.querySelector(".progress-summary")) v.classList.remove("pt-on");
  }).observe(document.getElementById("view") || document.body, { childList: true });
})();
