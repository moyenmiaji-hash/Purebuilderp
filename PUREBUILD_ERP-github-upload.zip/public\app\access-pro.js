/* Access Management page look (display only). Wraps access(): header, KPI cards, real tabs (Users / Invitations / Audit Trail / Sessions / Cloud Integration)
   that show only the selected tab's existing panels, user search/filter/sort. All buttons, forms and Cloud logic stay the existing ones. */
(function(){
  if(typeof window.access!=='function')return;
  var orig=window.access, TAB='inv';
  var TABS=[['users','Users','M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 21a8 8 0 0 1 16 0'],['inv','Invitations','M4 6h16v12H4zM4 7l8 6 8-6'],['audit','Audit Trail','M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z'],['sess','Sessions','M15 7a4 4 0 1 1-3.9 4.9L4 19v2h3v-2h2v-2h2l1.1-1.1'],['cloud','Cloud Integration','M7 18a5 5 0 1 1 1-9.9A6 6 0 0 1 19 10a4 4 0 0 1-1 8z']];
  var ic=function(d){return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="'+d+'"/></svg>'};
  var EMPTY={inv:'Staff invitations need the Cloud Team connection. Sign in under Cloud Integration first.',sess:'Logged-in accounts appear here for a Cloud admin. Sign in under Cloud Integration first.',audit:'Audit Trail is loading…',cloud:'Cloud connection is loading…'};
  function isAccess(){return (window.page||'')==='access'||location.hash==='#access'}
  function tag(){var v=document.getElementById('view');if(!v||!v.querySelector('.acx-head'))return;
    var root=v.querySelector(':scope>.access-fit-shell')||v;
    [...root.children].forEach(function(c){if(c.classList.contains('acx-head')||c.classList.contains('pagehead')||c.classList.contains('acx-empty'))return;
      if(c.id==='pb-audit-trail'){c.dataset.acxt='audit';return}
      if(c.id==='pb-cloud-access'){c.removeAttribute('data-acxt');[...c.children].forEach(function(p){p.dataset.acxt=p.querySelector('#pb-cloud-invite')?'inv':p.querySelector('#pb-staff-accounts')?'sess':'cloud'});return}
    if(c.querySelector('h3')&&c.querySelector('h3').textContent.trim()==='User Activity'){c.dataset.acxt='audit';return}
    c.dataset.acxt='users'});
    var e=root.querySelector('.acx-empty');if(!e){e=document.createElement('div');e.className='acx-empty';var h=root.querySelector('.acx-head');h?h.after(e):root.prepend(e)}
    var has=root.querySelector('[data-acxt="'+TAB+'"]');e.style.display=has?'none':'';if(e.dataset.k===TAB)return fin(v);e.dataset.k=TAB;e.innerHTML='<div>'+ic(TABS.find(function(t){return t[0]===TAB})[2])+'</div><p>'+(EMPTY[TAB]||'Nothing to show.')+'</p>'+(TAB!=='cloud'&&TAB!=='users'?'<button class="btn small" data-go>Go to Cloud Integration</button>':'');
    var g=e.querySelector('[data-go]');if(g)g.onclick=function(){set('cloud')};fin(v)}
  function fin(v){
    v.querySelectorAll('.acx-tabs button').forEach(function(b){b.classList.toggle('on',b.dataset.t===TAB)});
    var sh=v.querySelector('.access-fit-shell');if(sh&&sh.style.zoom&&sh.style.zoom!=='1')sh.style.zoom='1';document.body.classList.remove('ap-fit')}
  function set(t){TAB=t;document.body.dataset.acx=t;tag()}
  if(typeof window.accessFit==='function'){var af=window.accessFit;window.accessFit=function(){af.apply(this,arguments);tag()}}
  window.access=function(){orig.apply(this,arguments);try{
    var v=document.getElementById('view'),us=(typeof db!=='undefined'&&db.users)||[];document.body.dataset.acx=TAB;
    var act=us.filter(function(u){return !/inactive|suspend|block/i.test(u.status||'')}).length,
        pend=us.filter(function(u){return /pending|invited/i.test(u.status||'')}).length,
        adm=us.filter(function(u){return /admin/i.test(u.role||'')}).length;
    var hd=v.querySelector('.pagehead');
    if(hd){var t=hd.querySelector('h1,h2');if(t)t.textContent='Access Management';var s=hd.querySelector('p');if(s)s.textContent='Manage team members, access permissions and security.'}
    var k=document.createElement('div');k.className='acx-head';
    var card=function(c,d,l,n,s){return '<div class="acx-kpi '+c+'"><i>'+ic(d)+'</i><div><small>'+l+'</small><b>'+n+'</b><span>'+s+'</span></div></div>'};
    k.innerHTML='<div class="acx-kpis">'+card('b',TABS[0][2],'Total Users',us.length,'All local accounts')+card('g','M5 12l5 5 9-10','Active Users',act,'Can use the ERP')+card('a',TABS[1][2],'Pending Invitations',pend,'Awaiting first login')+card('p',TABS[2][2],'Administrators',adm,'Full access')+'</div><nav class="acx-tabs">'+TABS.map(function(x){return '<button data-t="'+x[0]+'">'+ic(x[2])+'<span>'+x[1]+'</span></button>'}).join('')+'</nav>';
    if(hd)hd.after(k);else v.prepend(k);
    k.querySelectorAll('.acx-tabs button').forEach(function(b){b.onclick=function(){set(b.dataset.t)}});
    var tb=v.querySelector('.panel table.table');if(tb){var pn=tb.closest('.panel');pn.classList.add('acx-users');
      var roles=[...new Set(us.map(function(u){return u.role}).filter(Boolean))];
      var bar=document.createElement('div');bar.className='acx-bar';bar.innerHTML='<div><h3>Team members</h3><small>'+us.length+' users</small></div><input type="search" placeholder="Search name, email, role…"><select><option value="">All roles</option>'+roles.map(function(r){return '<option>'+esc(r)+'</option>'}).join('')+'</select><select><option value="">All status</option><option>Active</option><option>Inactive</option></select>';
      pn.prepend(bar);
      tb.querySelectorAll('tbody tr').forEach(function(tr){var c=tr.cells;if(c.length<7)return;var n=c[0].textContent.trim();var ini=n.split(/\s+/).map(function(w){return w[0]||''}).join('').slice(0,2).toUpperCase();
        c[0].innerHTML='<div class="acx-who"><span class="acx-av">'+esc(ini)+'</span><div><b>'+esc(n)+'</b><small>'+c[1].innerHTML+'</small></div></div>';c[1].classList.add('acx-hide');
        c[2].innerHTML='<span class="acx-role">'+esc(c[2].textContent)+'</span>';c[5].classList.add('acx-perm');c[5].title=c[5].textContent});
      var h1=tb.querySelector('thead th:nth-child(1)'),h2=tb.querySelector('thead th:nth-child(2)');if(h1)h1.textContent='User';if(h2)h2.classList.add('acx-hide');
      var f=bar.querySelectorAll('input,select'),run=function(){var q=f[0].value.toLowerCase(),r=f[1].value,st=f[2].value,n=0;tb.querySelectorAll('tbody tr').forEach(function(tr){var c=tr.cells,ok=(!q||tr.textContent.toLowerCase().includes(q))&&(!r||c[2].textContent.trim()===r)&&(!st||c[3].textContent.trim()===st);tr.style.display=ok?'':'none';if(ok)n++});bar.querySelector('small').textContent=n+' of '+us.length+' users'};
      f.forEach(function(x){x.oninput=run;x.onchange=run});
      [0,2,3].forEach(function(i){var th=tb.querySelector('thead th:nth-child('+(i+1)+')');if(!th)return;th.classList.add('acx-sort');th.onclick=function(){var b=tb.tBodies[0],d=th.dataset.d=th.dataset.d==='1'?'-1':'1';[...b.rows].sort(function(a,c){return a.cells[i].textContent.localeCompare(c.cells[i].textContent)*d}).forEach(function(r){b.appendChild(r)})}})}
    tag();
  }catch(e){console.warn('access-pro',e)}};
  var q=0;new MutationObserver(function(){if(q||!isAccess())return;q=requestAnimationFrame(function(){q=0;tag()})}).observe(document.documentElement,{childList:true,subtree:true});
  if(isAccess())window.access();
  var T=TABS.map(function(t){return 'body[data-acx="'+t[0]+'"] #view [data-acxt]:not([data-acxt="'+t[0]+'"])'}).join(',');
  var css=T+`{display:none!important}
body:has(.acx-head) .access-fit-shell{zoom:1!important}
body:has(.acx-head) #view{font-size:14px}
.acx-head{display:grid;gap:14px;margin:4px 0 14px}
.acx-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.acx-kpi{display:flex;gap:12px;align-items:center;background:#fff;border:1px solid #e6ebf2;border-radius:10px;padding:14px 16px;box-shadow:0 1px 2px rgba(15,27,61,.04);transition:box-shadow .15s,transform .15s}
.acx-kpi:hover{box-shadow:0 6px 16px rgba(15,27,61,.07);transform:translateY(-1px)}
.acx-kpi i{width:36px;height:36px;border-radius:9px;display:grid;place-items:center;background:#eef4ff;color:#2563eb;flex:none}
.acx-kpi.g i{background:#eafaf1;color:#16a34a}.acx-kpi.a i{background:#fff6e6;color:#d97706}.acx-kpi.p i{background:#f1efff;color:#6d28d9}
.acx-kpi small{display:block;font-size:12px;color:#64748b;font-weight:500}
.acx-kpi b{display:block;font-size:22px;font-weight:650;color:#0f1b3d;line-height:1.25}.acx-kpi span{font-size:12px;color:#94a3b8}
.acx-tabs{display:flex;gap:2px;border-bottom:1px solid #e6ebf2;overflow-x:auto;scrollbar-width:none}
.acx-tabs button{display:flex;align-items:center;gap:7px;border:0;background:none;padding:10px 14px;font:500 14px/1 inherit;color:#64748b;border-bottom:2px solid transparent;margin-bottom:-1px;cursor:pointer;white-space:nowrap;transition:color .15s,border-color .15s}
.acx-tabs button:hover{color:#0f1b3d}
.acx-tabs button.on{color:#2563eb;border-bottom-color:#2563eb;font-weight:600}
body:has(.acx-head) #view [data-acxt]{animation:acxIn .18s ease}
@keyframes acxIn{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:none}}
body:has(.acx-head) #view .panel,body:has(.acx-head) #pb-audit-trail .card{border-radius:10px!important;border:1px solid #e6ebf2!important;box-shadow:0 1px 2px rgba(15,27,61,.04)!important;padding:16px 18px!important;margin:0 0 12px!important;background:#fff}
body:has(.acx-head) #pb-audit-trail .card{margin-top:0!important}
body:has(.acx-head) #pb-cloud-access .panel>div>div>b,body:has(.acx-head) #pb-cloud-access .panel>b{font-size:15px;font-weight:600;color:#0f1b3d}
body:has(.acx-head) #pb-cloud-access .muted{font-size:13px}
body:has(.acx-head) #pb-cloud-invite .field{font-size:13px;font-weight:500;color:#334155}
body:has(.acx-head) #pb-cloud-invite input,body:has(.acx-head) #pb-cloud-invite select,body:has(.acx-head) .pb-audit-filters input,body:has(.acx-head) .pb-audit-filters select{height:38px!important;border:1px solid #dbe3ee!important;border-radius:8px!important;font-size:13px}
body:has(.acx-head) #view .table{font-size:13.5px!important}
.acx-empty{background:#fff;border:1px dashed #d5deea;border-radius:10px;padding:34px 20px;text-align:center;color:#64748b;margin-bottom:12px}
.acx-empty>div{width:44px;height:44px;margin:0 auto 10px;border-radius:50%;background:#f1f5f9;display:grid;place-items:center;color:#2563eb}
.acx-empty p{margin:0 0 10px;font-size:14px}
.acx-bar{display:flex;gap:8px;align-items:center;margin:0 0 12px;flex-wrap:wrap}
.acx-bar>div{margin-right:auto}.acx-bar h3{margin:0;font-size:16px;font-weight:600;color:#0f1b3d}.acx-bar small{color:#94a3b8;font-size:12px}
.acx-bar input,.acx-bar select{height:36px;border:1px solid #dbe3ee;border-radius:8px;padding:0 10px;font-size:13px;background:#fff;color:#0f1b3d}
.acx-bar input{width:260px;flex:0 0 auto}.acx-bar select{flex:0 0 auto;width:auto}
.acx-users .tablewrap{border:1px solid #eef2f7;border-radius:8px;overflow:auto}
.acx-users table.table th{background:#f8fafc!important;color:#64748b!important;font-size:12px!important;font-weight:600!important;border-bottom:1px solid #e6ebf2!important;padding:10px 12px!important;white-space:nowrap}
.acx-users table.table td{border-bottom:1px solid #f1f5f9!important;padding:11px 12px!important;vertical-align:middle;color:#1e293b}
.acx-users table.table tbody tr:last-child td{border-bottom:0!important}
.acx-users table.table tbody tr{transition:background .12s}.acx-users table.table tbody tr:hover{background:#f7faff}
.acx-sort{cursor:pointer}.acx-sort:hover{color:#2563eb!important}
.acx-hide{display:none!important}
.acx-who{display:flex;align-items:center;gap:10px}.acx-who b{display:block;font-weight:600;color:#0f1b3d}.acx-who small{display:block;color:#64748b;font-size:12.5px}
.acx-av{flex:none;display:grid;place-items:center;width:34px;height:34px;border-radius:50%;background:#e8efff;color:#1d4ed8;font-size:12px;font-weight:600}
.acx-role{display:inline-block;padding:3px 10px;border-radius:999px;background:#eef4ff;color:#1d4ed8;font-size:12px;font-weight:600}
.acx-perm{max-width:300px!important;font-size:12px!important;color:#64748b!important;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
body.dark-theme .acx-kpi,body.dark-theme .acx-empty,body.dark-theme .acx-bar input,body.dark-theme .acx-bar select{background:#0f1b2d;border-color:#22324a;color:#e2ecf8}
body.dark-theme .acx-kpi b,body.dark-theme .acx-bar h3,body.dark-theme .acx-who b{color:#e2ecf8}
@media(max-width:1000px){.acx-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:640px){.acx-kpi{padding:10px 12px}.acx-kpi b{font-size:18px}.acx-tabs button span{font-size:13px}.acx-bar input{min-width:0;width:100%}
.acx-users table.table thead{display:none}.acx-users table.table tr{display:block;padding:10px 0;border-bottom:1px solid #eef2f7}.acx-users table.table td{display:block;border:0!important;padding:3px 10px!important}.acx-users .acx-perm{max-width:none!important}}
@media print{.acx-head,.acx-bar,.acx-empty{display:none}}`;
  var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
})();
