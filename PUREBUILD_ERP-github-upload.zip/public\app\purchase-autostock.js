/* Material purchases (Transaction Entry / Ledger, type Purchase, category Material*, any status Due/Paid/Cash)
   show in site stock automatically: one db.stock In row per purchase, tagged autoFromPurchase + sourcePurchaseId.
   Skipped when the purchase is already received another way (manual Receive, Central GRN voucher, site GRN).
   The auto row follows later edits of qty/material/unit/site; if the purchase is deleted its auto row is removed
   (it is only a mirror of the purchase). */
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const isMat = (t) => t && t.type === "Purchase" && /^material/i.test(t.category || "") && String(t.material || "").trim() && n(t.qty) > 0;
  function sync() {
    if (typeof db === "undefined" || !db) return false;
    db.stock = Array.isArray(db.stock) ? db.stock : [];
    const tx = new Map((db.transactions || []).filter(isMat).map((t) => [String(t.id), t]));
    let changed = false;
    // keep auto rows in step with their purchase
    for (let i = db.stock.length - 1; i >= 0; i--) {
      const r = db.stock[i]; if (!r.autoFromPurchase) continue;
      const t = tx.get(String(r.sourcePurchaseId));
      if (!t) { db.stock.splice(i, 1); changed = true; continue; }
      const want = { date: t.date, projectId: t.projectId, item: String(t.material).trim(), unit: String(t.unit || "").trim(), qty: n(t.qty), rate: n(t.rate), supplier: t.supplier || "", building: t.building || "" };
      for (const k in want) if (r[k] !== want[k]) { r[k] = want[k]; changed = true; }
    }
    const linked = new Set();
    db.stock.forEach((r) => r.sourcePurchaseId && linked.add(String(r.sourcePurchaseId)));
    (db.whLedger || []).forEach((r) => r.sourcePurchaseId && linked.add(String(r.sourcePurchaseId)));
    (db.whVouchers || []).forEach((v) => v.purchaseId && v.status !== "Rejected" && linked.add(String(v.purchaseId)));
    (db.stockVouchers || []).forEach((v) => (v.purchaseId || v.sourcePurchaseId) && v.status !== "Cancelled" && linked.add(String(v.purchaseId || v.sourcePurchaseId)));
    tx.forEach((t, k) => {
      if (linked.has(k) || !t.projectId) return;
      db.stock.push({ id: typeof id === "function" ? id() : k + "-auto", autoFromPurchase: true, sourcePurchaseId: t.id, date: t.date, projectId: t.projectId, ...(t.building ? { building: t.building } : {}),
        item: String(t.material).trim(), unit: String(t.unit || "").trim(), qty: n(t.qty), ...(n(t.rate) ? { rate: n(t.rate) } : {}), direction: "In", source: "Purchase", supplier: t.supplier || "",
        ref: t.journalNo || t.invoiceNo || "", note: "Auto from material purchase" + (t.status ? " (" + t.status + ")" : "") });
      changed = true;
    });
    return changed;
  }
  window.PB_PURCHASE_AUTO = { sync, isAuto: (pid) => (db.stock || []).some((r) => r.autoFromPurchase && String(r.sourcePurchaseId) === String(pid)) };
  const boot = setInterval(() => {
    if (typeof window.save !== "function" || typeof db === "undefined") return; clearInterval(boot);
    const o = window.save;
    window.save = function () { try { sync(); } catch (e) { console.error("purchase-autostock", e); } return o.apply(this, arguments); };
    const os = window.stock; if (typeof os === "function") window.stock = function () { try { sync(); } catch (e) {} return os.apply(this, arguments); };
    try { if (sync()) { window.save(); if (typeof render === "function") render(); } } catch (e) { console.error(e); }
  }, 300);
})();
