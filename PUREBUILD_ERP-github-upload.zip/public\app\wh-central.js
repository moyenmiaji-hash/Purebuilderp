/* PURE_BUILD Smart Warehouse (central store + site integration).
   - Central Warehouse ledger lives in side list db.whLedger (rows like db.stock, location 'CENTRAL').
   - Vouchers (Opening, Purchase GRN, Issue to Site, Return, Damage, Adjustment) live in db.whVouchers and post
     ledger rows ONLY when Admin/Manager approves, exactly once (rows tagged whVoucherId). Corrections = reversal rows
     with a reason; nothing is edited or deleted.
   - Foreman phone stock updates come from Cloud table site_stock_submissions; approval posts db.stock rows tagged
     cloudStockSubId once. "Received" on the phone is a confirmation only (the Issue Voucher already added it).
   Formulas: wh-calc.js (tested in src/test/wh-calc.test.ts). */
(function () {
  const W = () => window.PBWhCalc;
  if (typeof window.stock !== "function") return;
  const today = () => new Date().toISOString().slice(0, 10);
  const L = () => (db.whLedger = Array.isArray(db.whLedger) ? db.whLedger : []);
  const V = () => (db.whVouchers = Array.isArray(db.whVouchers) ? db.whVouchers : []);
  const RULES = () => (db.whUnitRules = Array.isArray(db.whUnitRules) ? db.whUnitRules : []);
  const MIN = () => (db.whMin = db.whMin && typeof db.whMin === "object" && !Array.isArray(db.whMin) ? db.whMin : {});
  const mats = () => (Array.isArray(db.materials) ? db.materials : []);
  const canApprove = () => !window.PB_CLOUD_ROLE || ["admin", "manager"].includes(window.PB_CLOUD_ROLE);
  const who = () => window.PB_CLOUD_NAME || "Office";
  const low = (s) => String(s || "").trim().toLowerCase();
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const matOf = (x) => mats().find((m) => m.id === x.materialId) || mats().find((m) => low(m.name) === low(x.item) && low(m.unit) === low(x.unit));
  const matKey = (x) => { const m = matOf(x); return m ? "id:" + m.id : "n:" + low(x.item) + "|" + low(x.unit); };
  const sgn = (x) => (x.direction === "In" ? 1 : -1);
  const centralBal = (mk) => L().filter((x) => matKey(x) === mk).reduce((a, x) => a + sgn(x) * n(x.qty), 0);
  const siteBal = (pid, x) => (db.stock || []).filter((r) => r.projectId === pid && matKey(r) === matKey(x)).reduce((a, r) => a + sgn(r) * n(r.qty), 0);
  const allRows = () => L().concat(db.stock || []);
  const KIND = {
    OPEN: { t: "Opening Stock", p: "OPN", ic: "📥" }, CGRN: { t: "Purchase GRN → Central", p: "CGRN", ic: "🚚" },
    CISS: { t: "Material Issue → Site", p: "MIV", ic: "📤" }, CRET: { t: "Return Site → Central", p: "RET", ic: "↩️" },
    DMG: { t: "Damaged Material", p: "DMG", ic: "⚠️" }, ADJ: { t: "Adjustment (with reason)", p: "ADJ", ic: "⚖️" },
  };
  const nextNo = (p) => { let mx = 0; V().forEach((v) => { const m = String(v.no || "").match(/^([A-Z]+)-(\d+)$/); if (m && m[1] === p) mx = Math.max(mx, +m[2]); }); return p + "-" + String(mx + 1).padStart(4, "0"); };
  const projOpts = (sel, blank) => (blank ? `<option value="">${blank}</option>` : "") + (db.projects || []).map((p) => `<option value="${esc(p.id)}" ${p.id === sel ? "selected" : ""}>${esc(p.name)}</option>`).join("");
  const locName = (v) => (v.location === "SITE" || ["CISS", "CRET"].includes(v.kind)) ? projectName(v.projectId) + (v.building ? " / " + v.building : "") : "Central Warehouse";

  /* ---------- purchases (shared with Purchase Receipts tab) ---------- */
  const purchases = () => (db.transactions || []).filter((t) => t.type === "Purchase" && /^material/i.test(t.category || "") && String(t.material || "").trim() && n(t.qty) > 0);
  const receivedFor = (pid) => (db.stock || []).filter((x) => String(x.sourcePurchaseId || "") === String(pid) && x.direction === "In").reduce((a, x) => a + n(x.qty), 0)
    + L().filter((x) => String(x.sourcePurchaseId || "") === String(pid)).reduce((a, x) => a + sgn(x) * n(x.qty), 0);
  const pendingFor = (pid, skip) => V().filter((v) => v.kind === "CGRN" && v.status === "Pending" && v.purchaseId === pid && v.id !== skip).reduce((a, v) => a + v.lines.reduce((b, l) => b + n(l.qty), 0), 0);
  const openFor = (t, skip) => W().purchaseOpen(t.qty, receivedFor(t.id), pendingFor(t.id, skip));
  window.PB_WH_RECEIVED_FOR = receivedFor;
  if (typeof window.purchasedMaterialRows === "function" && !window.purchasedMaterialRows._wh) {
    const o = window.purchasedMaterialRows;
    window.purchasedMaterialRows = function () { return o.apply(this, arguments).map((r) => { const c = L().filter((x) => String(x.sourcePurchaseId || "") === String(r.id)).reduce((a, x) => a + sgn(x) * n(x.qty), 0); return c ? { ...r, received: r.received + c, remaining: Math.max(0, r.qty - r.received - c) } : r; }); };
    window.purchasedMaterialRows._wh = 1;
  }

  /* ---------- rate & value ---------- */
  function rateOf(mk) {
    let q = 0, a = 0;
    L().forEach((x) => { if (!x.reversal && x.direction === "In" && n(x.rate) > 0 && matKey(x) === mk) { q += n(x.qty); a += n(x.qty) * n(x.rate); } });
    (db.stock || []).forEach((x) => { if (!x.reversal && x.direction === "In" && n(x.rate) > 0 && matKey(x) === mk) { q += n(x.qty); a += n(x.qty) * n(x.rate); } });
    purchases().forEach((t) => { if (matKey({ item: t.material, unit: t.unit }) === mk) { q += n(t.qty); a += n(t.amount) || n(t.qty) * n(t.rate); } });
    return q ? a / q : 0;
  }

  /* ---------- posting ---------- */
  // which side loses quantity for a voucher (used for availability checks)
  function losses(v, rev) {
    const out = [];
    const site = v.location === "SITE" || ["CISS", "CRET"].includes(v.kind);
    v.lines.forEach((l) => {
      const cOut = !rev ? ["CISS"].includes(v.kind) || (v.kind === "DMG" && !site) || (v.kind === "ADJ" && !site && v.dir === "Out")
        : ["OPEN", "CGRN", "CRET"].includes(v.kind) || (v.kind === "ADJ" && !site && v.dir === "In");
      const sOut = !rev ? v.kind === "CRET" || (v.kind === "DMG" && site) || (v.kind === "ADJ" && site && v.dir === "Out")
        : v.kind === "CISS" || (v.kind === "ADJ" && site && v.dir === "In");
      if (cOut) out.push({ where: "C", l });
      if (sOut) out.push({ where: "S", l });
    });
    return out;
  }
  function shortage(v, rev) {
    const need = new Map();
    losses(v, rev).forEach(({ where, l }) => { const k = where + "|" + matKey(l); need.set(k, { where, l, q: ((need.get(k) || {}).q || 0) + n(l.qty) }); });
    for (const { where, l, q } of need.values()) {
      const have = where === "C" ? centralBal(matKey(l)) : siteBal(v.projectId, l);
      if (q > have + 1e-9) return `Not enough ${l.item} ${where === "C" ? "in Central Warehouse" : "at " + projectName(v.projectId)}: need ${fmt(q)}, only ${fmt(have)} ${l.unit}`;
    }
    return "";
  }
  function post(v, rev) {
    const flip = (d) => (rev ? (d === "In" ? "Out" : "In") : d);
    const site = v.location === "SITE" || ["CISS", "CRET"].includes(v.kind);
    const now = new Date().toISOString();
    v.lines.forEach((l, i) => {
      const base = { date: rev ? today() : v.date, materialId: l.materialId, item: l.item, unit: l.unit, qty: n(l.qty), whVoucherId: v.id, whLine: i, ref: v.no, enteredBy: v.createdBy, approvedBy: who(), postedAt: now, ...(rev ? { reversal: true, reason: v.reverseReason } : {}) };
      const note = (rev ? "Reversal of " : "") + v.no + (v.remarks ? " · " + v.remarks : "");
      const C = (dir, movement, extra) => L().push({ ...base, id: id(), location: "CENTRAL", direction: flip(dir), movement, ...(n(l.rate) ? { rate: n(l.rate) } : {}), ...(extra || {}), note });
      const S = (dir, extra) => db.stock.push({ ...base, id: id(), projectId: v.projectId, ...(v.building ? { building: v.building } : {}), direction: flip(dir), ...(extra || {}), note });
      if (v.kind === "OPEN") C("In", "Opening");
      if (v.kind === "CGRN") C("In", "GRN", { supplier: v.supplier, ...(v.purchaseId ? { sourcePurchaseId: v.purchaseId } : {}) });
      if (v.kind === "CISS") { C("Out", "Issue", { projectId: v.projectId, foreman: v.foreman }); S("In", { source: "Central Issue", foreman: v.foreman, ...(n(l.rate) ? { rate: n(l.rate) } : {}) }); }
      if (v.kind === "CRET") { S("Out", { source: "Return to Central", movement: "Transfer" }); C("In", "Return", { projectId: v.projectId }); }
      if (v.kind === "DMG") { if (site) S("Out", { source: "Damage", movement: "Wastage" }); else C("Out", "Damage"); }
      if (v.kind === "ADJ") { if (site) S(v.dir, { source: "Adjustment", movement: v.dir === "In" ? "AdjIn" : "AdjOut" }); else C(v.dir, v.dir === "In" ? "AdjIn" : "AdjOut"); }
    });
  }
  const logH = (v, what, note) => { v.history = Array.isArray(v.history) ? v.history : []; v.history.push({ at: new Date().toISOString(), by: who(), what, ...(note ? { note } : {}) }); };
  function approve(vid) {
    const v = V().find((x) => x.id === vid);
    if (!v || v.status !== "Pending") { toast("This voucher is not waiting for approval"); render(); return; }
    if (!canApprove()) { toast("Only Admin / Manager can approve"); return; }
    if (W().isPosted(v.id, allRows())) { v.status = "Approved"; save(); render(); toast("Already posted — not counted again"); return; }
    if (v.kind === "CGRN" && v.purchaseId) { const t = purchases().find((t) => t.id === v.purchaseId); const q = v.lines.reduce((a, l) => a + n(l.qty), 0); if (t && q > W().purchaseOpen(t.qty, receivedFor(t.id), pendingFor(t.id, v.id)) + 1e-9) { toast("This purchase is already received. Approving would count it twice."); return; } }
    const s = shortage(v, false); if (s) { toast(s); return; }
    if (!confirm(`Approve ${v.no}? Stock will change now.`)) return;
    post(v, false); Object.assign(v, { status: "Approved", approvedBy: who(), approvedAt: new Date().toISOString() }); logH(v, "Approved");
    save(); render(); toast(v.no + " approved — stock updated");
  }
  function reject(vid) {
    const v = V().find((x) => x.id === vid); if (!v || v.status !== "Pending") return;
    if (!canApprove()) { toast("Only Admin / Manager can reject"); return; }
    const r = prompt(`Reject ${v.no}? Write the reason:`); if (!r || !r.trim()) return;
    Object.assign(v, { status: "Rejected", rejectReason: r.trim(), rejectedBy: who(), rejectedAt: new Date().toISOString() }); logH(v, "Rejected", r.trim());
    save(); render(); toast(v.no + " rejected");
  }
  function reverse(vid) {
    const v = V().find((x) => x.id === vid); if (!v || v.status !== "Approved") return;
    if (!canApprove()) { toast("Only Admin / Manager can correct an approved voucher"); return; }
    if (allRows().some((x) => x.whVoucherId === v.id && x.reversal)) { toast("Already reversed"); return; }
    const s = shortage(v, true); if (s) { toast("Cannot reverse: " + s); return; }
    const r = prompt(`Correct ${v.no}? A reversal entry is posted (nothing is deleted). Then make a new voucher with the right numbers.\nReason:`); if (!r || !r.trim()) return;
    v.reverseReason = r.trim(); post(v, true); Object.assign(v, { status: "Reversed", reversedBy: who(), reversedAt: new Date().toISOString() }); logH(v, "Reversed", r.trim());
    save(); render(); toast(v.no + " reversed");
  }

  /* ---------- voucher form ---------- */
  let saving = false;
  function unitOpts(m, sel) { const us = [...new Set([m ? m.unit : "", ...((db.settings && db.settings.units) || []), "Bag", "Pcs", "Nos", "Kg", "Ton", "CFT", "CUM", "m³", "m²", "m", "Litre"].filter(Boolean))]; return us.map((u) => `<option ${u === (sel || (m && m.unit)) ? "selected" : ""}>${esc(u)}</option>`).join(""); }
  function lineRow(kind, l) {
    const m = l && mats().find((x) => x.id === l.materialId);
    const rate = ["OPEN", "CGRN", "CISS"].includes(kind);
    return `<tr class="whl"><td><select class="select whl-m" onchange="WHX.lineChg(this)"><option value="">Select material</option>${mats().map((x) => `<option value="${esc(x.id)}" ${m && m.id === x.id ? "selected" : ""}>${esc(x.name)}${x.code ? " · " + esc(x.code) : ""} (${esc(x.unit)})</option>`).join("")}</select></td>
      <td><input type="number" class="whl-q" min="0" step="any" value="${l ? esc(l.enteredQty ?? l.qty) : ""}" oninput="WHX.lineChg(this)"></td><td><select class="select whl-u" onchange="WHX.lineChg(this)">${unitOpts(m, l && l.enteredUnit)}</select></td>
      ${rate ? `<td><input type="number" class="whl-r" min="0" step="any" value="${l && l.rate ? esc(l.rate) : ""}"></td>` : ""}<td class="whl-h muted" style="font-size:11.5px">—</td><td><button type="button" class="btn small" onclick="this.closest('tr').remove()">✕</button></td></tr>`;
  }
  function lineChg(el) {
    const tr = el.closest("tr"), m = mats().find((x) => x.id === tr.querySelector(".whl-m").value), h = tr.querySelector(".whl-h");
    if (el.classList.contains("whl-m")) tr.querySelector(".whl-u").innerHTML = unitOpts(m);
    if (!m) { h.textContent = "—"; return; }
    const q = n(tr.querySelector(".whl-q").value), u = tr.querySelector(".whl-u").value, c = W().convert(q, u, m.unit, RULES());
    const kind = document.getElementById("whKind")?.value, pid = document.getElementById("whProj")?.value, loc = document.getElementById("whLoc")?.value;
    const site = ["CISS", "CRET"].includes(kind) ? false : loc && loc !== "CENTRAL";
    const avC = centralBal("id:" + m.id), avS = pid ? siteBal(pid, { materialId: m.id, item: m.name, unit: m.unit }) : 0;
    const av = kind === "CRET" || site ? `Site has ${fmt(avS)} ${m.unit}` : `Central has ${fmt(avC)} ${m.unit}`;
    h.innerHTML = c === null ? `<span style="color:#dc2626">Cannot mix ${esc(u)} with ${esc(m.unit)} — add a unit rule</span>` : `${u !== m.unit ? `= <b>${fmt(c)} ${esc(m.unit)}</b> · ` : ""}${av}`;
  }
  function form(kind, preset) {
    if (!mats().length) { toast("Add a material first in Material Master"); try { openStockMaterial(); } catch (e) {} return; }
    const k = KIND[kind], p = preset || {};
    const f = (lbl, html, full) => `<div class="field${full ? " full" : ""}"><label>${lbl}</label>${html}</div>`;
    const loc = ["DMG", "ADJ"].includes(kind) ? f("Location *", `<select id="whLoc" class="select" onchange="document.getElementById('whProjWrap').style.display=this.value==='CENTRAL'?'none':''"><option value="CENTRAL">Central Warehouse</option><option value="SITE">A project site</option></select>`) : "";
    const needProj = ["CISS", "CRET", "DMG", "ADJ"].includes(kind);
    const bl = typeof projectBuildings === "function" && p.projectId ? projectBuildings(p.projectId) : [];
    const open = kind === "CGRN" ? purchases().filter((t) => openFor(t) > 0) : [];
    const staff = [...new Set([...(db.users || []).map((u) => u.name), ...V().map((v) => v.foreman)].filter(Boolean))];
    const body = `<input type="hidden" id="whKind" value="${kind}"><div class="formgrid">
      ${f("Date *", `<input id="whDate" type="date" value="${p.date || today()}">`)}
      ${f("Reference no.", `<input id="whRef" maxlength="80" placeholder="Challan / DN / note no." value="${esc(p.ref || "")}">`)}
      ${kind === "CGRN" ? f("Link to purchase (partial delivery OK)", `<select id="whPur" class="select" onchange="WHX.purPick(this.value)"><option value="">— No purchase link —</option>${open.map((t) => `<option value="${esc(t.id)}" ${p.purchaseId === t.id ? "selected" : ""}>${esc(t.date)} · ${esc(t.supplier || "Supplier")} · ${esc(t.material)} · open ${fmt(openFor(t))} ${esc(t.unit)}</option>`).join("")}</select>`, true) + f("Supplier *", `<input id="whSup" maxlength="120" value="${esc(p.supplier || "")}">`) + f("Invoice no.", `<input id="whInv" maxlength="80" value="${esc(p.invoice || "")}">`) : ""}
      ${loc}
      ${needProj ? `<div class="field" id="whProjWrap" style="${["DMG", "ADJ"].includes(kind) ? "display:none" : ""}"><label>Project / site *</label><select id="whProj" class="select" onchange="WHX.projChg(this.value)">${projOpts(p.projectId, "Select project")}</select></div><div class="field"><label>Building / site</label><select id="whBld" class="select"><option value="">— Any —</option>${bl.map((b) => `<option>${esc(b)}</option>`).join("")}</select></div>` : ""}
      ${kind === "CISS" ? f("Receiving foreman *", `<input id="whFore" list="whForeL" maxlength="80"><datalist id="whForeL">${staff.map((s) => `<option value="${esc(s)}">`).join("")}</datalist>`) + f("Delivery date", `<input id="whDel" type="date" value="${today()}">`) : ""}
      ${kind === "ADJ" ? f("Direction *", `<select id="whDir" class="select"><option value="In">Add (+)</option><option value="Out">Remove (−)</option></select>`) : ""}
      ${f(["DMG", "ADJ", "CRET"].includes(kind) ? "Reason *" : "Remarks", `<input id="whRem" maxlength="300">`, true)}
    </div>
    <div class="tablewrap" style="margin-top:8px"><table class="table"><thead><tr><th>Material *</th><th>Qty *</th><th>Unit</th>${["OPEN", "CGRN", "CISS"].includes(kind) ? "<th>Rate (AED)</th>" : ""}<th>Check</th><th></th></tr></thead><tbody id="whLines">${(p.lines && p.lines.length ? p.lines : [null]).map((l) => lineRow(kind, l)).join("")}</tbody></table></div>
    <button type="button" class="btn small" style="margin-top:6px" onclick="document.getElementById('whLines').insertAdjacentHTML('beforeend',WHX.lineRow('${kind}'))">＋ Add line</button>
    <p class="muted" style="margin:8px 0 0;font-size:12px">Saved as <b>Pending</b>. Stock changes only after Admin / Manager approval, once. ${kind === "CGRN" ? "Paying the supplier never adds stock — only this receipt does." : ""}</p>`;
    openModal(k.ic + " " + k.t + " · " + nextNo(k.p), body, () => saveVoucher(kind));
    setTimeout(() => document.querySelectorAll("#whLines tr .whl-m").forEach((s) => s.value && lineChg(s)), 30);
  }
  function purPick(pid) {
    const t = purchases().find((x) => x.id === pid); if (!t) return;
    let m = mats().find((x) => low(x.name) === low(t.material) && low(x.unit) === low(t.unit));
    if (!m) { m = { id: id(), name: String(t.material).trim(), code: "", category: t.category || "Material", unit: String(t.unit || "").trim() || "Nos", minStock: 0 }; db.materials = mats(); db.materials.push(m); }
    document.getElementById("whSup").value = t.supplier || ""; document.getElementById("whInv").value = t.invoiceNo || t.reference || "";
    document.getElementById("whLines").innerHTML = lineRow("CGRN", { materialId: m.id, qty: openFor(t), rate: n(t.rate) || (n(t.amount) / n(t.qty)) });
    lineChg(document.querySelector("#whLines .whl-m"));
  }
  function projChg(pid) { const s = document.getElementById("whBld"); if (s && typeof projectBuildings === "function") s.innerHTML = `<option value="">— Any —</option>` + projectBuildings(pid).map((b) => `<option>${esc(b)}</option>`).join(""); document.querySelectorAll("#whLines .whl-m").forEach((x) => x.value && lineChg(x)); }
  function saveVoucher(kind) {
    if (saving) return false;
    const g = (i) => (document.getElementById(i)?.value || "").trim();
    const date = g("whDate"); if (!date) { toast("Date is required"); return false; }
    if (date > today()) { toast("Date cannot be in the future"); return false; }
    const location = ["DMG", "ADJ"].includes(kind) ? g("whLoc") : ["CISS", "CRET"].includes(kind) ? "SITE" : "CENTRAL";
    const projectId = location === "SITE" ? g("whProj") : "";
    if (location === "SITE" && !projectId) { toast("Choose the project / site"); return false; }
    if (kind === "CGRN" && !g("whSup")) { toast("Supplier is required"); return false; }
    if (kind === "CISS" && !g("whFore")) { toast("Receiving foreman is required"); return false; }
    if (["DMG", "ADJ", "CRET"].includes(kind) && !g("whRem")) { toast("Please write the reason"); return false; }
    const lines = [];
    for (const tr of document.querySelectorAll("#whLines .whl")) {
      const m = mats().find((x) => x.id === tr.querySelector(".whl-m").value), q = Number(tr.querySelector(".whl-q").value), u = tr.querySelector(".whl-u").value;
      if (!m && !q) continue;
      if (!m || !Number.isFinite(q) || q <= 0) { toast("Each line needs a material and a quantity above zero"); return false; }
      const c = W().convert(q, u, m.unit, RULES()); if (c === null) { toast(`Cannot mix ${u} with ${m.unit}. Add a unit rule in Central Warehouse → Unit rules.`); return false; }
      const rate = n(tr.querySelector(".whl-r")?.value); if (rate < 0) { toast("Rate cannot be negative"); return false; }
      const rateBase = rate && u !== m.unit && c ? rate * q / c : rate;
      lines.push({ materialId: m.id, item: m.name, unit: m.unit, qty: +c.toFixed(6), enteredQty: q, enteredUnit: u, rate: kind === "CISS" && !rate ? +rateOf("id:" + m.id).toFixed(4) : +rateBase.toFixed(4) });
    }
    if (!lines.length) { toast("Add at least one material line"); return false; }
    const v = { id: id(), kind, no: nextNo(KIND[kind].p), date, location, projectId, building: g("whBld"), supplier: g("whSup"), invoice: g("whInv"), purchaseId: g("whPur"), foreman: g("whFore"), deliveryDate: g("whDel"), dir: g("whDir") || "In", ref: g("whRef"), remarks: g("whRem"), lines, status: "Pending", createdBy: who(), createdAt: new Date().toISOString() };
    if (v.purchaseId) { const t = purchases().find((x) => x.id === v.purchaseId), q = lines.reduce((a, l) => a + l.qty, 0); if (t && q > openFor(t) + 1e-9) { toast(`Only ${fmt(openFor(t))} ${t.unit} of this purchase is still open`); return false; } }
    if (v.ref && V().some((x) => x.kind === kind && x.status !== "Rejected" && low(x.ref) === low(v.ref) && x.date === date && (x.projectId || "") === projectId)) { if (!confirm("A voucher with the same reference and date already exists. Save another one anyway?")) return false; }
    const s = shortage(v, false); if (s) { toast(s); return false; }
    saving = true; logH(v, "Created");
    try { V().push(v); save(); render(); toast(v.no + " saved — waiting for approval"); } finally { setTimeout(() => (saving = false), 700); }
    return true;
  }
  function view(vid) {
    const v = V().find((x) => x.id === vid); if (!v) return;
    const kv = (a, b) => b ? `<div style="display:flex;justify-content:space-between;border-bottom:1px dashed #e5e7eb;padding:4px 0"><small class="muted">${a}</small><b>${esc(b)}</b></div>` : "";
    openModal(KIND[v.kind].ic + " " + v.no + " · " + KIND[v.kind].t, `<div class="formgrid"><div>${kv("Status", v.status)}${kv("Date", v.date)}${kv("Location", locName(v))}${kv("Supplier", v.supplier)}${kv("Invoice", v.invoice)}${kv("Receiving foreman", v.foreman)}${kv("Delivery date", v.deliveryDate)}${kv("Reference", v.ref)}${kv("Reason / remarks", v.remarks)}</div><div>${kv("Created by", v.createdBy)}${kv("Created", (v.createdAt || "").slice(0, 16).replace("T", " "))}${kv("Approved by", v.approvedBy)}${kv("Approved", (v.approvedAt || "").slice(0, 16).replace("T", " "))}${kv("Rejected reason", v.rejectReason)}${kv("Reversal reason", v.reverseReason)}</div></div>
      <div class="tablewrap" style="margin-top:8px"><table class="table"><thead><tr><th>Material</th><th class="n">Qty</th><th>Unit</th><th class="n">Rate</th><th class="n">Amount</th></tr></thead><tbody>${v.lines.map((l) => `<tr><td>${esc(l.item)}${l.enteredUnit && l.enteredUnit !== l.unit ? `<br><small class="muted">entered ${fmt(l.enteredQty)} ${esc(l.enteredUnit)}</small>` : ""}</td><td class="n">${fmt(l.qty)}</td><td>${esc(l.unit)}</td><td class="n">${l.rate ? fmt(l.rate) : "—"}</td><td class="n">${l.rate ? money(l.qty * l.rate) : "—"}</td></tr>`).join("")}</tbody></table></div>
      <h4 style="margin:10px 0 4px">History</h4>${(v.history || []).map((h) => `<div class="muted" style="font-size:12px">${esc((h.at || "").slice(0, 16).replace("T", " "))} · <b>${esc(h.what)}</b> by ${esc(h.by)}${h.note ? " — " + esc(h.note) : ""}</div>`).join("") || '<div class="muted">—</div>'}`, null);
    document.getElementById("modalSave").style.display = "none";
  }

  /* ---------- Cloud foreman stock updates ---------- */
  const CS = { list: [], rcv: [], projects: [], loaded: false, err: "" };
  const C = () => window.PB_CLOUD_CLIENT;
  async function loadCloud(force) {
    if (!C() || (CS.loading && !force)) return; CS.loading = true;
    try {
      const [a, b] = await Promise.all([C().from("site_stock_submissions").select("*").order("created_at", { ascending: false }).limit(300), C().from("team_projects").select("id,name,local_project_id")]);
      if (a.error) throw a.error; CS.list = (a.data || []).filter((s) => s.kind !== "receiving"); CS.rcv = (a.data || []).filter((s) => s.kind === "receiving"); CS.projects = b.data || []; CS.err = ""; CS.loaded = true;
    } catch (e) { CS.err = e.message || String(e); CS.loaded = true; }
    CS.loading = false;
    if ((typeof page !== "undefined" ? page : "") === "stock" && ["wapprove", "wcentral", "wreceive"].includes(window.stockTab)) render();
  }
  const cproj = (pid) => CS.projects.find((p) => p.id === pid) || {};
  const subPosted = (sid) => (db.stock || []).some((x) => x.cloudStockSubId === sid) || L().some((x) => x.cloudStockSubId === sid);
  function subCheck(s) {
    const pid = cproj(s.project_id).local_project_id; if (!pid || !(db.projects || []).some((p) => p.id === pid)) return { err: "This site is not linked to a project in the office ERP yet." };
    if (s.kind === "daily") for (const l of s.lines || []) { const out = n(l.used) + n(l.damaged) + n(l.returned), have = siteBal(pid, { item: l.item, unit: l.unit }); if (out > have + 1e-9) return { pid, err: `Not enough ${l.item} on site: used+damaged+returned ${fmt(out)}, stock ${fmt(have)} ${l.unit}` }; }
    return { pid, err: "" };
  }
  function postSub(s, pid) {
    if (subPosted(s.id)) return false;
    const base = (l, i) => { const m = matOf(l); return { date: s.work_date, projectId: pid, ...(m ? { materialId: m.id, item: m.name, unit: m.unit } : { item: String(l.item).trim(), unit: String(l.unit || "").trim() }), cloudStockSubId: s.id, whLine: i, foreman: s.submitted_name || "Foreman", enteredBy: s.submitted_name || "Foreman", approvedBy: who(), postedAt: new Date().toISOString(), ref: "FSU-" + String(s.id).slice(0, 8).toUpperCase() }; };
    (s.lines || []).forEach((l, i) => {
      const b = base(l, i), note = (s.remarks ? s.remarks + " · " : "") + "Foreman stock update";
      if (s.kind === "site_purchase") { if (n(l.qty) > 0) db.stock.push({ ...b, id: id(), direction: "In", qty: n(l.qty), ...(n(l.rate) ? { rate: n(l.rate) } : {}), source: "Site Purchase", supplier: s.supplier || "", note: "Site purchase" + (s.invoice_no ? " · inv " + s.invoice_no : "") }); return; }
      if (n(l.used) > 0) db.stock.push({ ...b, id: id(), direction: "Out", qty: n(l.used), source: "Foreman Usage", note });
      if (n(l.damaged) > 0) db.stock.push({ ...b, id: id(), direction: "Out", qty: n(l.damaged), source: "Foreman Damage", movement: "Wastage", note });
      if (n(l.returned) > 0) { db.stock.push({ ...b, id: id(), direction: "Out", qty: n(l.returned), source: "Return to Central", movement: "Transfer", note }); L().push({ ...b, id: id(), location: "CENTRAL", direction: "In", qty: n(l.returned), movement: "Return", note: "Returned from " + projectName(pid) }); }
    });
    return true;
  }
  async function subApprove(sid) {
    const s = CS.list.find((x) => x.id === sid); if (!s) return;
    if (!canApprove()) { toast("Only Admin / Manager can approve"); return; }
    const ck = subCheck(s); if (ck.err) { toast(ck.err); return; }
    if (!confirm("Approve this foreman stock update? Site stock will change now.")) return;
    const { error } = await C().rpc("review_site_stock_update", { p_id: sid, p_decision: "approved", p_note: "" });
    if (error) { toast(error.message); return; }
    s.review_status = "approved"; postSub(s, ck.pid); save();
    await C().rpc("mark_site_stock_posted", { p_id: sid }); s.posted_to_stock = true;
    render(); toast("Approved — site stock updated");
  }
  async function subReject(sid) {
    if (!canApprove()) { toast("Only Admin / Manager can reject"); return; }
    const r = prompt("Reject this foreman stock update? Write the reason:"); if (!r || !r.trim()) return;
    const { error } = await C().rpc("review_site_stock_update", { p_id: sid, p_decision: "rejected", p_note: r.trim() });
    if (error) { toast(error.message); return; } loadCloud(true); toast("Rejected");
  }
  async function subPost(sid) {
    const s = CS.list.find((x) => x.id === sid); if (!s || s.review_status !== "approved") return;
    const ck = subCheck(s); if (ck.err) { toast(ck.err); return; }
    if (postSub(s, ck.pid)) save(); await C().rpc("mark_site_stock_posted", { p_id: sid }); s.posted_to_stock = true; render(); toast("Posted to site stock");
  }
  async function subPhoto(path) { const { data, error } = await C().storage.from("site-progress-photos").createSignedUrl(path, 600); if (error) { toast(error.message); return; } window.open(data.signedUrl, "_blank"); }
  function subView(sid) {
    const s = CS.list.find((x) => x.id === sid); if (!s) return;
    const d = s.kind === "daily";
    openModal(`${d ? "📦 Foreman daily stock" : "🛒 Site purchase"} · ${esc(cproj(s.project_id).name || "Site")} · ${s.work_date}`, `<p class="muted" style="margin:0 0 6px">By <b>${esc(s.submitted_name || "Foreman")}</b> · ${esc(String(s.created_at).slice(0, 16).replace("T", " "))} · Status <b>${esc(s.review_status)}</b>${s.supplier ? " · Supplier " + esc(s.supplier) : ""}${s.invoice_no ? " · Inv " + esc(s.invoice_no) : ""}</p>
      <div class="tablewrap"><table class="table"><thead><tr><th>Material</th>${d ? "<th class='n'>Opening</th><th class='n'>Received*</th><th class='n'>Used</th><th class='n'>Damaged</th><th class='n'>Returned</th><th class='n'>Closing</th>" : "<th class='n'>Qty</th><th class='n'>Rate</th><th class='n'>Amount</th>"}</tr></thead><tbody>${(s.lines || []).map((l) => `<tr><td><b>${esc(l.item)}</b> <small class="muted">${esc(l.unit)}</small></td>${d ? `<td class="n">${fmt(l.opening)}</td><td class="n">${fmt(l.received)}</td><td class="n">${fmt(l.used)}</td><td class="n">${fmt(l.damaged)}</td><td class="n">${fmt(l.returned)}</td><td class="n"><b>${fmt(l.closing)}</b></td>` : `<td class="n">${fmt(l.qty)}</td><td class="n">${fmt(l.rate)}</td><td class="n">${money(n(l.qty) * n(l.rate))}</td>`}</tr>`).join("")}</tbody></table></div>
      ${d ? '<p class="muted" style="font-size:12px">* Received is a confirmation only — the Issue Voucher already added it, so it is not counted twice.</p>' : ""}
      ${s.remarks ? `<p><b>Remarks:</b> ${esc(s.remarks)}</p>` : ""}${s.review_note ? `<p><b>Office note:</b> ${esc(s.review_note)}</p>` : ""}
      ${(s.photos || []).length ? `<div style="display:flex;gap:6px;flex-wrap:wrap">${s.photos.map((p, i) => `<button type="button" class="btn small" onclick="WHX.subPhoto('${esc(p.path)}')">📷 Photo ${i + 1}</button>`).join("")}</div>` : ""}`, null);
    document.getElementById("modalSave").style.display = "none";
  }

  /* ---------- UI pieces ---------- */
  const pill = (s) => `<span class="pill ${{ Pending: "amber", pending: "amber", Approved: "green", approved: "green", Rejected: "red", rejected: "red", Reversed: "" }[s] || ""}">${esc(s)}</span>`;
  function centralRowsStat() { return W().centralStatement(L(), matKey).map((r) => { const m = matOf(r); return { ...r, m, name: m ? m.name : r.item, unit: m ? m.unit : r.unit, cat: m ? m.category || "" : "", code: m ? m.code || "" : "", min: n(MIN()[m ? m.id : r.key]), rate: rateOf(r.key) }; }); }
  function kpis() {
    const cs = centralRowsStat(), siteSum = (typeof stockSummary === "function" ? stockSummary(db.stock || []) : []);
    const val = cs.reduce((a, r) => a + Math.max(0, r.available) * r.rate, 0) + siteSum.reduce((a, r) => a + Math.max(0, r.current) * rateOf(matKey(r)), 0);
    const inQ = allRows().filter((x) => x.direction === "In").reduce((a, x) => a + n(x.qty), 0), outQ = allRows().filter((x) => x.direction !== "In").reduce((a, x) => a + n(x.qty), 0);
    const lowN = cs.filter((r) => r.min > 0 && r.available <= r.min).length;
    const pend = V().filter((v) => v.status === "Pending").length + (db.stockVouchers || []).filter((v) => v.status === "Pending").length + CS.list.filter((s) => s.review_status === "pending").length;
    const dmg = allRows().filter((x) => /damage|wastage/i.test((x.movement || "") + " " + (x.source || "")) && !x.reversal).reduce((a, x) => a + n(x.qty), 0);
    const c = (cls, ic, l, v, s, go) => `<button type="button" class="wh-k ${cls}" ${go ? `onclick="stockGo('${go}')"` : ""}><i>${ic}</i><small>${l}</small><strong>${v}</strong><span>${s}</span></button>`;
    return `<div class="wh-kpis">${c("k1", "🧱", "Material types", mats().length, "In master", "catalog")}${c("k2", "💰", "Stock value", money(val), "Central + all sites")}${c("k3", "🏬", "Central available", fmt(cs.reduce((a, r) => a + Math.max(0, r.available), 0)), "qty, all units")}${c("k4", "⬇️", "Total stock in", fmt(inQ), "all locations", "wreports")}${c("k5", "⬆️", "Total stock out", fmt(outQ), "all locations", "wreports")}${c("k6", "🏗️", "Site stock", fmt(siteSum.reduce((a, r) => a + Math.max(0, r.current), 0)), siteSum.length + " item lines", "project")}${c("k7", "📉", "Low (central)", lowN, lowN ? "Below minimum" : "All fine")}${c("k8", "⏳", "Pending approvals", pend, "All types", "wapprove")}${c("k9", "⚠️", "Damaged", fmt(dmg), "qty, all locations", "wreports")}</div>`;
  }
  function centralTab() {
    const rows = centralRowsStat().sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const btn = (k) => `<button type="button" class="btn small ${k === "CGRN" || k === "CISS" ? "primary" : ""}" onclick="WHX.form('${k}')">${KIND[k].ic} ${KIND[k].t}</button>`;
    return kpis() + `<section class="panel"><div class="toolbar"><h3 style="margin:0">🏬 Central Warehouse stock</h3><div style="display:flex;gap:6px;flex-wrap:wrap">${["CGRN", "CISS", "CRET", "DMG", "ADJ", "OPEN"].map(btn).join("")}</div></div>
      <p class="muted" style="margin:0 0 6px;font-size:12px">Available = Opening + Approved GRN + Approved Returns − Approved Site Issues − Damage − Other approved outgoing. Only approved vouchers count.</p>
      <div class="tablewrap"><table class="table"><thead><tr><th>Material</th><th>Unit</th><th class="n">Opening</th><th class="n">Received</th><th class="n">To sites</th><th class="n">Returned</th><th class="n">Damaged</th><th class="n">Adj ±</th><th class="n">Available</th><th class="n">Avg rate</th><th class="n">Value</th><th class="n">Minimum</th><th>Status</th></tr></thead><tbody>${rows.map((r) => { const lowS = r.available <= 0 ? ["red", "Out"] : r.min > 0 && r.available <= r.min ? ["amber", "Low"] : ["green", "OK"]; return `<tr><td><b>${esc(r.name)}</b>${r.code ? `<br><small class="muted">${esc(r.code)}</small>` : ""}</td><td>${esc(r.unit)}</td><td class="n">${fmt(r.opening)}</td><td class="n">${fmt(r.received)}</td><td class="n">${fmt(r.issued)}</td><td class="n">${fmt(r.returned)}</td><td class="n">${fmt(r.damaged)}</td><td class="n">${fmt(r.adjIn - r.adjOut)}</td><td class="n"><b>${fmt(r.available)}</b></td><td class="n">${r.rate ? fmt(r.rate) : "—"}</td><td class="n">${money(Math.max(0, r.available) * r.rate)}</td><td class="n">${r.m ? `<input type="number" min="0" step="any" value="${r.min || ""}" style="width:70px" onchange="WHX.setMin('${esc(r.m.id)}',this.value)">` : "—"}</td><td><span class="pill ${lowS[0]}">${lowS[1]}</span></td></tr>`; }).join("") || '<tr><td colspan="13" class="empty">Central Warehouse is empty. Start with “Opening Stock” or a “Purchase GRN → Central”.</td></tr>'}</tbody></table></div></section>
      <section class="panel"><div class="toolbar"><h3 style="margin:0">⚖️ Unit rules</h3><button type="button" class="btn small" onclick="WHX.addRule()">＋ Add rule</button></div><p class="muted" style="margin:0 0 6px;font-size:12px">Built in: 1 Ton = 1000 Kg · 1 CUM = 35.3147 CFT · 1 m² = 10.7639 sft · 1 m = 3.28 ft. Different units (e.g. Bag and Kg) are never mixed unless you add a rule here.</p>${RULES().map((r, i) => `<span class="pill" style="margin:2px">1 ${esc(r.from)} = ${fmt(r.factor)} ${esc(r.to)} <a href="#" onclick="event.preventDefault();WHX.delRule(${i})" title="Remove rule">✕</a></span>`).join("") || '<span class="muted">No extra rules.</span>'}</section>`;
  }
  function voucherTab() {
    const F = (window.WH_VF = window.WH_VF || { st: "", k: "" });
    const list = V().filter((v) => (!F.st || v.status === F.st) && (!F.k || v.kind === F.k) && (!selectedProject || !v.projectId || v.projectId === selectedProject)).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return `<section class="panel"><div class="toolbar"><h3 style="margin:0">🧾 Warehouse vouchers</h3><div style="display:flex;gap:6px;flex-wrap:wrap"><select class="select" onchange="WH_VF.k=this.value;render()"><option value="">All types</option>${Object.entries(KIND).map(([k, o]) => `<option value="${k}" ${F.k === k ? "selected" : ""}>${o.t}</option>`).join("")}</select><select class="select" onchange="WH_VF.st=this.value;render()">${["", "Pending", "Approved", "Rejected", "Reversed"].map((s) => `<option value="${s}" ${F.st === s ? "selected" : ""}>${s || "All status"}</option>`).join("")}</select>${["CGRN", "CISS"].map((k) => `<button type="button" class="btn small primary" onclick="WHX.form('${k}')">＋ ${KIND[k].t}</button>`).join("")}</div></div>
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Voucher</th><th>Type</th><th>Location</th><th>Supplier / Foreman</th><th>Materials</th><th>Status</th><th>Action</th></tr></thead><tbody>${list.map((v) => `<tr><td>${esc(v.date)}</td><td><b>${esc(v.no)}</b>${v.ref ? `<br><small class="muted">${esc(v.ref)}</small>` : ""}</td><td>${KIND[v.kind].ic} ${esc(KIND[v.kind].t)}</td><td>${esc(locName(v))}</td><td>${esc(v.supplier || v.foreman || "—")}</td><td>${esc(v.lines.map((l) => l.item + " " + fmt(l.qty) + " " + l.unit).join(", "))}</td><td>${pill(v.status)}</td><td style="white-space:nowrap"><button class="btn small" onclick="WHX.view('${v.id}')">View</button>${v.status === "Pending" && canApprove() ? ` <button class="btn small primary" onclick="WHX.approve('${v.id}')">Approve</button> <button class="btn small danger" onclick="WHX.reject('${v.id}')">Reject</button>` : ""}${v.status === "Approved" && canApprove() ? ` <button class="btn small" onclick="WHX.reverse('${v.id}')" title="Post a reversal with reason">Correct</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="8" class="empty">No warehouse vouchers yet.</td></tr>'}</tbody></table></div></section>`;
  }
  function approveTab() {
    const F = (window.WH_AF = window.WH_AF || { st: "pending" });
    const st = F.st, cap = (s) => s[0].toUpperCase() + s.slice(1);
    const rows = [];
    V().filter((v) => low(v.status) === st).forEach((v) => rows.push({ at: v.createdAt, date: v.date, type: KIND[v.kind].t, ic: KIND[v.kind].ic, ref: v.no, loc: locName(v), by: v.createdBy, what: v.lines.map((l) => l.item + " " + fmt(l.qty) + " " + l.unit).join(", "), status: v.status, act: `<button class="btn small" onclick="WHX.view('${v.id}')">View</button>${st === "pending" && canApprove() ? ` <button class="btn small primary" onclick="WHX.approve('${v.id}')">Approve</button> <button class="btn small danger" onclick="WHX.reject('${v.id}')">Reject</button>` : ""}` }));
    (db.stockVouchers || []).filter((v) => low(v.status === "Cancelled" ? "rejected" : v.status) === st).forEach((v) => rows.push({ at: v.createdAt, date: v.date, type: v.kind === "GRN" ? "Site GRN (direct to site)" : "Site Issue / Usage", ic: v.kind === "GRN" ? "🚚" : "📤", ref: v.no, loc: projectName(v.projectId), by: v.createdBy, what: (v.lines || []).map((l) => l.item + " " + fmt(l.qty) + " " + l.unit).join(", "), status: v.status, act: `<button class="btn small" onclick="SPX.view('${v.id}')">View</button>${st === "pending" && canApprove() ? ` <button class="btn small primary" onclick="SPX.approve('${v.id}')">Approve</button>` : ""}` }));
    CS.list.filter((s) => s.review_status === st).forEach((s) => rows.push({ at: s.created_at, date: s.work_date, type: s.kind === "daily" ? "Foreman daily usage / damage / return" : "Site purchase (foreman)", ic: s.kind === "daily" ? "👷" : "🛒", ref: "FSU-" + String(s.id).slice(0, 8).toUpperCase(), loc: cproj(s.project_id).name || "Site", by: s.submitted_name || "Foreman", what: (s.lines || []).map((l) => s.kind === "daily" ? `${l.item}: used ${fmt(l.used)}${n(l.damaged) ? ", damaged " + fmt(l.damaged) : ""}${n(l.returned) ? ", returned " + fmt(l.returned) : ""}` : `${l.item} ${fmt(l.qty)} ${l.unit}`).join(" · "), status: cap(s.review_status), act: `<button class="btn small" onclick="WHX.subView('${s.id}')">View</button>${st === "pending" && canApprove() ? ` <button class="btn small primary" onclick="WHX.subApprove('${s.id}')">Approve</button> <button class="btn small danger" onclick="WHX.subReject('${s.id}')">Reject</button>` : ""}${st === "approved" && !subPosted(s.id) && canApprove() ? ` <button class="btn small primary" onclick="WHX.subPost('${s.id}')">Post to stock</button>` : ""}` }));
    rows.sort((a, b) => String(b.at || "").localeCompare(String(a.at || "")));
    const cnt = (s) => V().filter((v) => low(v.status) === s).length + (db.stockVouchers || []).filter((v) => low(v.status === "Cancelled" ? "rejected" : v.status) === s).length + CS.list.filter((x) => x.review_status === s).length;
    return `<section class="panel"><div class="toolbar"><h3 style="margin:0">✅ Approval Center</h3><div class="wh-seg">${["pending", "approved", "rejected"].map((s) => `<button type="button" class="${st === s ? "on" : ""}" onclick="WH_AF.st='${s}';render()">${cap(s)} <em>${cnt(s)}</em></button>`).join("")}<button type="button" class="btn small" onclick="WHX.reload()">↻ Refresh</button></div></div>
      <p class="muted" style="margin:0 0 6px;font-size:12px">Purchase GRN, Warehouse Stock In, Material Issue, Foreman daily usage, Damage, Returns and Site purchases in one list. Approved quantities are never edited — use “Correct” to post a reversal with reason. Staff material/expense requests stay in <a href="#" onclick="event.preventDefault();document.getElementById('pb-sa-nav')?.click()">Staff Approvals</a>.</p>
      ${CS.err ? `<div class="notice">Foreman updates could not load: ${esc(CS.err)}</div>` : !CS.loaded && C() ? '<div class="muted">Loading foreman updates…</div>' : ""}
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Type</th><th>Ref</th><th>Location</th><th>By</th><th>Materials</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.date)}</td><td>${r.ic} ${esc(r.type)}</td><td><b>${esc(r.ref)}</b></td><td>${esc(r.loc)}</td><td>${esc(r.by || "—")}</td><td style="max-width:320px">${esc(r.what)}</td><td>${pill(r.status)}</td><td style="white-space:nowrap">${r.act}</td></tr>`).join("") || `<tr><td colspan="8" class="empty">Nothing ${st}.</td></tr>`}</tbody></table></div></section>`;
  }

  /* ---------- reports ---------- */
  const RF = (window.WH_RF = window.WH_RF || { r: "material", from: "", to: "", proj: "", mat: "", cat: "", sup: "", fore: "", type: "", month: false });
  function norm() {
    const out = [];
    L().forEach((x) => out.push({ x, central: true, date: x.date, mk: matKey(x), item: (matOf(x) || x).name || x.item, unit: x.unit, qty: n(x.qty), dir: x.direction, type: (x.reversal ? "Reversal · " : "") + ({ Opening: "Opening stock", GRN: "Purchase GRN", Issue: "Issue to site", Return: "Return from site", Damage: "Damage", AdjIn: "Adjustment +", AdjOut: "Adjustment −" }[x.movement] || x.movement || "Central"), from: x.direction === "In" ? (x.movement === "GRN" ? x.supplier || "Supplier" : x.movement === "Return" ? projectName(x.projectId) : "—") : "Central Warehouse", to: x.direction === "In" ? "Central Warehouse" : x.movement === "Issue" ? projectName(x.projectId) : x.movement === "Damage" ? "Damaged" : "—", project: x.projectId || "", supplier: x.supplier || "", foreman: x.foreman || "", by: x.enteredBy || "", appr: x.approvedBy || "", ref: x.ref || "", rate: n(x.rate) }));
    (db.stock || []).forEach((x) => {
      const src = x.source || x.movement || (x.sourcePurchaseId ? "Purchase Receipt" : x.sourceReportId ? "Foreman report" : "Stock " + x.direction);
      const sup = x.supplier || (x.sourcePurchaseId ? ((db.transactions || []).find((t) => String(t.id) === String(x.sourcePurchaseId)) || {}).supplier || "" : "");
      out.push({ x, central: false, date: x.date, mk: matKey(x), item: (matOf(x) || x).name || x.item, unit: x.unit, qty: n(x.qty), dir: x.direction, type: (x.reversal ? "Reversal · " : "") + src, from: x.direction === "In" ? (src === "Central Issue" ? "Central Warehouse" : sup || src) : projectName(x.projectId), to: x.direction === "In" ? projectName(x.projectId) : /return/i.test(src) ? "Central Warehouse" : /wastage|damage/i.test(src + (x.movement || "")) ? "Damaged" : "Used / out", project: x.projectId, supplier: sup, foreman: x.foreman || (x.sourceReportId || x.cloudStockSubId ? x.enteredBy || "" : ""), by: x.enteredBy || "", appr: x.approvedBy || "", ref: x.ref || x.voucherId || "", rate: n(x.rate) });
    });
    return out;
  }
  function filtered() {
    return norm().filter((r) => (!RF.from || r.date >= RF.from) && (!RF.to || r.date <= RF.to) && (!RF.proj || (RF.proj === "CENTRAL" ? r.central : r.project === RF.proj)) && (!RF.mat || r.mk === RF.mat) && (!RF.cat || ((matOf(r.x) || {}).category || "") === RF.cat) && (!RF.sup || r.supplier === RF.sup) && (!RF.fore || r.foreman === RF.fore) && (!RF.type || r.type === RF.type));
  }
  const REPORTS = { material: "Material-wise stock", project: "Project-wise stock", warehouse: "Warehouse-wise stock", foreman: "Foreman-wise material usage", pvc: "Purchase vs consumption", damage: "Damaged material", supplier: "Supplier purchase history", value: "Stock valuation", movement: "Daily / monthly movement", ledger: "Full stock movement ledger" };
  function report() {
    const rows = filtered(), by = (keyFn) => { const m = new Map(); rows.forEach((r) => { const k = keyFn(r); if (!m.has(k)) m.set(k, []); m.get(k).push(r); }); return m; };
    const bal = (a) => a.reduce((s, r) => s + (r.dir === "In" ? 1 : -1) * r.qty, 0);
    const sumQ = (a, f) => a.filter(f).reduce((s, r) => s + r.qty, 0);
    const used = (r) => !r.central && r.dir !== "In" && !/return|transfer|wastage|damage/i.test(r.type + (r.x.movement || ""));
    const dmg = (r) => /damage|wastage/i.test(r.type + " " + (r.x.movement || ""));
    switch (RF.r) {
      case "material": return { head: ["Material", "Unit", "Central", "All sites", "Total", "Avg rate", "Value (AED)"], rows: [...by((r) => r.mk).values()].map((a) => { const c = bal(a.filter((r) => r.central)), s = bal(a.filter((r) => !r.central)), rt = rateOf(a[0].mk); return [a[0].item, a[0].unit, fmt(c), fmt(s), fmt(c + s), rt ? fmt(rt) : "—", money(Math.max(0, c + s) * rt)]; }) };
      case "project": return { head: ["Project", "Material", "Unit", "In", "Out", "Balance"], rows: [...by((r) => (r.central ? "~" : r.project) + "|" + r.mk).values()].filter((a) => !a[0].central).map((a) => [projectName(a[0].project), a[0].item, a[0].unit, fmt(sumQ(a, (r) => r.dir === "In")), fmt(sumQ(a, (r) => r.dir !== "In")), fmt(bal(a))]) };
      case "warehouse": return { head: ["Location", "Material lines", "Qty on hand (all units)", "Value (AED)"], rows: [...by((r) => (r.central ? "CENTRAL" : r.project)).entries()].map(([k, a]) => { const per = [...by((r) => ((r.central ? "CENTRAL" : r.project) === k ? r.mk : "~")).entries()].filter(([m]) => m !== "~"); const q = per.map(([m, b]) => [m, bal(b.filter((r) => (r.central ? "CENTRAL" : r.project) === k))]); return [k === "CENTRAL" ? "Central Warehouse" : projectName(k), q.filter((x) => x[1] > 0).length, fmt(q.reduce((s, x) => s + Math.max(0, x[1]), 0)), money(q.reduce((s, x) => s + Math.max(0, x[1]) * rateOf(x[0]), 0))]; }) };
      case "foreman": return { head: ["Foreman", "Project", "Material", "Unit", "Used", "Damaged", "Returned"], rows: [...by((r) => (r.foreman || "—") + "|" + r.project + "|" + r.mk).values()].filter((a) => !a[0].central && a.some((r) => r.dir !== "In") && a[0].foreman).map((a) => [a[0].foreman, projectName(a[0].project), a[0].item, a[0].unit, fmt(sumQ(a, used)), fmt(sumQ(a, (r) => r.dir !== "In" && dmg(r))), fmt(sumQ(a, (r) => r.dir !== "In" && /return/i.test(r.type)))]) };
      case "pvc": { const pur = new Map(); purchases().filter((t) => (!RF.from || t.date >= RF.from) && (!RF.to || t.date <= RF.to) && (!RF.sup || t.supplier === RF.sup)).forEach((t) => { const k = matKey({ item: t.material, unit: t.unit }); const o = pur.get(k) || { item: t.material, unit: t.unit, q: 0, a: 0 }; o.q += n(t.qty); o.a += n(t.amount); pur.set(k, o); }); const keys = new Set([...pur.keys(), ...rows.map((r) => r.mk)]); return { head: ["Material", "Unit", "Purchased", "Purchase AED", "Received in stock", "Consumed on site", "Damaged", "Purchased − consumed"], rows: [...keys].map((k) => { const a = rows.filter((r) => r.mk === k), p = pur.get(k) || { q: 0, a: 0 }, f = a[0] || { item: p.item, unit: p.unit }; const rec = sumQ(a, (r) => r.dir === "In" && !r.x.reversal && (/GRN|Purchase|Site Purchase/i.test(r.type))); const con = sumQ(a, used); return [f.item, f.unit, fmt(p.q), money(p.a), fmt(rec), fmt(con), fmt(sumQ(a, (r) => r.dir !== "In" && dmg(r))), fmt(p.q - con)]; }) }; }
      case "damage": return { head: ["Date", "Location", "Material", "Qty", "Unit", "By", "Ref", "Note"], rows: rows.filter((r) => r.dir !== "In" && dmg(r)).map((r) => [r.date, r.central ? "Central Warehouse" : projectName(r.project), r.item, fmt(r.qty), r.unit, r.foreman || r.by, r.ref, r.x.note || ""]) };
      case "supplier": return { head: ["Date", "Supplier", "Project", "Material", "Qty", "Unit", "Rate", "Amount", "Invoice", "Received"], rows: purchases().filter((t) => (!RF.from || t.date >= RF.from) && (!RF.to || t.date <= RF.to) && (!RF.sup || t.supplier === RF.sup) && (!RF.proj || t.projectId === RF.proj)).sort((a, b) => String(a.supplier || "").localeCompare(String(b.supplier || "")) || String(b.date).localeCompare(String(a.date))).map((t) => [t.date, t.supplier || "—", projectName(t.projectId), t.material, fmt(t.qty), t.unit || "", fmt(t.rate), money(t.amount), t.invoiceNo || t.reference || "", fmt(receivedFor(t.id))]) };
      case "value": return { head: ["Material", "Unit", "Qty on hand", "Avg rate", "Value (AED)"], rows: [...by((r) => r.mk).values()].map((a) => { const q = bal(a), rt = rateOf(a[0].mk); return [a[0].item, a[0].unit, fmt(q), rt ? fmt(rt) : "—", money(Math.max(0, q) * rt)]; }).concat([["Total", "", "", "", money([...by((r) => r.mk).values()].reduce((s, a) => s + Math.max(0, bal(a)) * rateOf(a[0].mk), 0))]]) };
      case "movement": return { head: [RF.month ? "Month" : "Date", "Material", "Unit", "In", "Out", "Net"], rows: [...by((r) => String(r.date).slice(0, RF.month ? 7 : 10) + "|" + r.mk).values()].sort((a, b) => String(b[0].date).localeCompare(String(a[0].date))).map((a) => { const i = sumQ(a, (r) => r.dir === "In"), o = sumQ(a, (r) => r.dir !== "In"); return [String(a[0].date).slice(0, RF.month ? 7 : 10), a[0].item, a[0].unit, fmt(i), fmt(o), fmt(i - o)]; }) };
      default: return { head: ["Tx ID", "Date / time", "Material", "From", "To", "Qty", "Unit", "Type", "Project", "Supplier / Foreman", "Created by", "Approved by", "Ref"], rows: rows.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).map((r) => ["TX-" + String(r.x.id || "").replace(/-/g, "").slice(-8).toUpperCase(), r.date + (r.x.postedAt ? " " + r.x.postedAt.slice(11, 16) : ""), r.item, r.from, r.to, (r.dir === "In" ? "+" : "−") + fmt(r.qty), r.unit, r.type, r.central && !r.project ? "Central" : projectName(r.project), r.supplier || r.foreman || "", r.by, r.appr, r.ref]) };
    }
  }
  function reportsTab() {
    const all = norm(), uniq = (f) => [...new Set(all.map(f).filter(Boolean))].sort();
    const sel = (k, opts, blank) => `<select class="select" onchange="WH_RF.${k}=this.value;render()"><option value="">${blank}</option>${opts.map(([v, l]) => `<option value="${esc(v)}" ${RF[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
    const t = report();
    return `<section class="panel"><div class="toolbar" style="flex-wrap:wrap;gap:6px"><h3 style="margin:0">📊 Smart reports</h3><div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn small" onclick="WHX.csv()">⬇ Excel / CSV</button><button class="btn small primary" onclick="WHX.print()">🖨 Print / PDF</button></div></div>
      <div class="wh-rtabs">${Object.entries(REPORTS).map(([k, l], i) => `<button type="button" class="${RF.r === k ? "on" : ""}" onclick="WH_RF.r='${k}';render()">${i + 1}. ${l}</button>`).join("")}</div>
      <div class="wh-filters"><label>From <input type="date" value="${RF.from}" onchange="WH_RF.from=this.value;render()"></label><label>To <input type="date" value="${RF.to}" onchange="WH_RF.to=this.value;render()"></label>
      ${sel("proj", [["CENTRAL", "Central Warehouse"], ...(db.projects || []).map((p) => [p.id, p.name])], "All locations")}${sel("mat", uniq((r) => r.mk).map((k) => [k, (all.find((r) => r.mk === k) || {}).item + " (" + (all.find((r) => r.mk === k) || {}).unit + ")"]), "All materials")}${sel("cat", [...new Set(mats().map((m) => m.category).filter(Boolean))].sort().map((c) => [c, c]), "All categories")}${sel("sup", [...new Set([...uniq((r) => r.supplier), ...purchases().map((t) => t.supplier).filter(Boolean)])].sort().map((s) => [s, s]), "All suppliers")}${sel("fore", uniq((r) => r.foreman).map((s) => [s, s]), "All foremen")}${sel("type", uniq((r) => r.type).map((s) => [s, s]), "All types")}
      ${RF.r === "movement" ? `<label><input type="checkbox" ${RF.month ? "checked" : ""} onchange="WH_RF.month=this.checked;render()"> Monthly</label>` : ""}<button class="btn small" onclick="Object.assign(WH_RF,{from:'',to:'',proj:'',mat:'',cat:'',sup:'',fore:'',type:''});render()">Clear</button></div>
      <div class="tablewrap"><table class="table wh-rep"><thead><tr>${t.head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${t.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${t.head.length}" class="empty">No records for these filters.</td></tr>`}</tbody></table></div></section>`;
  }
  function csv() { const t = report(), q = (v) => '"' + String(v ?? "").replace(/"/g, '""') + '"'; const blob = new Blob(["\ufeff" + [t.head, ...t.rows].map((r) => r.map(q).join(",")).join("\r\n")], { type: "text/csv;charset=utf-8" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `warehouse-${RF.r}-${today()}.csv`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 30000); toast("CSV downloaded"); }
  function print() {
    const t = report(), s = db.settings || {}, w = window.open("", "_blank"); if (!w) { toast("Allow pop-ups to print"); return; }
    const flt = [RF.from && "From " + RF.from, RF.to && "To " + RF.to, RF.proj && (RF.proj === "CENTRAL" ? "Central Warehouse" : projectName(RF.proj)), RF.sup, RF.fore, RF.type].filter(Boolean).join(" · ");
    w.document.write(`<!doctype html><html><head><title>${esc(REPORTS[RF.r])}</title><style>@page{size:A4 ${t.head.length > 8 ? "landscape" : "portrait"};margin:12mm}body{font-family:Arial,sans-serif;font-size:11px;color:#111}h1{font-size:16px;margin:0}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #ccc;padding:4px 6px;text-align:left}th{background:#f1f0f8}thead{display:table-header-group}tr{break-inside:avoid}.m{color:#555}</style></head><body><div style="display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #5B3FC4;padding-bottom:6px"><div><h1>${esc(s.companyName || "PURE_BUILD")}</h1><div class="m">${esc([s.companyAddress, s.companyPhone, s.companyEmail].filter(Boolean).join(" · "))}</div></div><div style="text-align:right"><b>${esc(REPORTS[RF.r])}</b><div class="m">${esc(flt || "All records")} · Printed ${today()}</div></div></div><table><thead><tr>${t.head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${t.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table><script>setTimeout(()=>print(),300)<\/script></body></html>`);
    w.document.close();
  }
  function addRule() {
    openModal("Add unit rule", `<div class="formgrid"><div class="field"><label>1 of unit *</label><input id="wrF" placeholder="e.g. Bag"></div><div class="field"><label>equals *</label><input id="wrK" type="number" min="0" step="any" placeholder="50"></div><div class="field"><label>of unit *</label><input id="wrT" placeholder="e.g. Kg"></div></div><p class="muted">Example: 1 Bag = 50 Kg (cement). Rules apply both ways.</p>`, () => {
      const f = document.getElementById("wrF").value.trim(), t = document.getElementById("wrT").value.trim(), k = Number(document.getElementById("wrK").value);
      if (!f || !t || !(k > 0)) { toast("Fill both units and a number above zero"); return false; }
      if (W().unitKey(f) === W().unitKey(t)) { toast("Units must be different"); return false; }
      RULES().push({ from: f, to: t, factor: k, by: who(), at: new Date().toISOString() }); save(); render(); toast("Unit rule saved"); return true;
    });
  }
  function delRule(i) { if (!confirm("Remove this unit rule? Saved vouchers keep their converted numbers.")) return; RULES().splice(i, 1); save(); render(); }
  function setMin(mid, v) { const x = Number(v); if (!Number.isFinite(x) || x < 0) { toast("Minimum must be zero or more"); render(); return; } MIN()[mid] = x; save(); toast("Central minimum saved"); render(); }

  window.WHX = { form, lineRow, lineChg, purPick, projChg, approve, reject, reverse, view, setMin, addRule, delRule, csv, print, subView, subApprove, subReject, subPost, subPhoto, reload: () => loadCloud(true), cloud: () => CS, load: loadCloud, matOf, siteBal, cproj };

  const css = document.createElement("style");
  css.textContent = `.wh-kpis{display:grid;grid-template-columns:repeat(9,minmax(0,1fr));gap:8px;margin:0 0 10px}.wh-k{position:relative;text-align:left;border:1px solid #E4E1F3;border-radius:14px;padding:9px 10px 9px 12px;background:#fff;cursor:pointer;display:flex;flex-direction:column;gap:1px;min-width:0;border-left:4px solid var(--c)}
  .wh-k i{font-style:normal;font-size:16px}.wh-k small{font-size:10.5px;color:#6b6889;font-weight:700;text-transform:uppercase;letter-spacing:.02em}.wh-k strong{font-size:16px;color:#29283A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.wh-k span{font-size:10.5px;color:#8a87a6}
  .wh-k.k1{--c:#7C5CE0}.wh-k.k2{--c:#16a34a}.wh-k.k3{--c:#2563eb}.wh-k.k4{--c:#0891b2}.wh-k.k5{--c:#db2777}.wh-k.k6{--c:#d97706}.wh-k.k7{--c:#dc2626}.wh-k.k8{--c:#9333ea}.wh-k.k9{--c:#ea580c}
  @media(max-width:1300px){.wh-kpis{grid-template-columns:repeat(5,minmax(0,1fr))}}@media(max-width:700px){.wh-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
  .wh-seg{display:flex;gap:6px;align-items:center}.wh-seg button:not(.btn){border:1px solid #DCD8EE;background:#fff;border-radius:10px;padding:6px 12px;font-weight:700;cursor:pointer}.wh-seg button.on{background:linear-gradient(135deg,#7C5CE0,#5B3FC4);color:#fff;border-color:transparent}.wh-seg em{font-style:normal;background:rgba(0,0,0,.08);border-radius:8px;padding:0 6px;margin-left:4px}
  .wh-rtabs{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0}.wh-rtabs button{border:1px solid #DCD8EE;background:#fff;border-radius:9px;padding:5px 9px;font-size:12px;font-weight:600;cursor:pointer}.wh-rtabs button.on{background:#5B3FC4;color:#fff;border-color:#5B3FC4}
  .wh-filters{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:4px 0 8px}.wh-filters label{display:flex;gap:4px;align-items:center;font-size:12px}.wh-filters input[type=date],.wh-filters .select{height:32px;padding:4px 8px;max-width:170px}
  .wh-rep td,.wh-rep th{white-space:nowrap}`;
  document.head.appendChild(css);

  const MINE = { wcentral: centralTab, wvouchers: voucherTab, wapprove: approveTab, wreports: reportsTab };
  const TABS = [["wcentral", "🏬 Central Warehouse"], ["wvouchers", "🧾 Vouchers"], ["wapprove", "✅ Approval Center"], ["wreports", "📊 Reports"]];
  const orig = window.stock;
  window.stock = function () {
    const T = window.stockTab, mine = !!MINE[T];
    orig.apply(this, arguments);
    const view = document.getElementById("view"), nav = view && view.querySelector(".stock-tabs"); if (!nav) return;
    const pend = V().filter((v) => v.status === "Pending").length + CS.list.filter((s) => s.review_status === "pending").length + (db.stockVouchers || []).filter((v) => v.status === "Pending").length;
    const tools = nav.querySelector(".stock-tab-tools");
    const html = TABS.map(([k, l]) => `<button type="button" class="wh-tab ${T === k ? "active" : ""}" onclick="stockGo('${k}')"><span>${l}</span>${k === "wapprove" && pend ? ` <em>${pend}</em>` : ""}</button>`).join("");
    if (tools) tools.insertAdjacentHTML("beforebegin", html); else nav.insertAdjacentHTML("beforeend", html);
    if (!mine) return;
    nav.querySelectorAll(":scope > button.active:not(.wh-tab)").forEach((b) => b.classList.remove("active"));
    if (tools) tools.style.display = "none";
    const body = view.querySelector(".stock-tab-body"); if (!body) return;
    body.className = "stock-tab-body stock-tab-" + T;
    try { body.innerHTML = MINE[T](); } catch (e) { console.error("wh-central", e); body.innerHTML = '<div class="panel"><div class="empty">This section could not be shown. Your data is safe.</div></div>'; }
    if ((T === "wapprove" || T === "wcentral") && !CS.loaded && !CS.loading) loadCloud();
  };
  setInterval(() => { if ((typeof page !== "undefined" ? page : "") === "stock" && C() && document.visibilityState === "visible") loadCloud(); }, 90000);
})();
