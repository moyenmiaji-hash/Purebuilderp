// Foreman Task / Target Management (office side). Data lives in Cloud tables foreman_tasks / foreman_task_updates / foreman_task_events.
// All writes go through Cloud functions that check Admin/Manager permission; this file never edits the local ERP data.
(function () {
  const C = () => window.PB_TASK_CALC;
  // The office data is a top-level `let db`, which is not on window; read it by name.
  const LDB = () => { try { return (typeof db !== "undefined" && db) || window.db || {}; } catch { return window.db || {}; } };
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const Q = (n) => (n == null || !Number.isFinite(Number(n)) ? "—" : Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 }));
  const P = (n) => (n == null ? "No Data" : `${Math.round(n)}%`);
  const STATUS = { assigned: ["Assigned", "blue"], in_progress: ["In Progress", "green"], submitted: ["Pending Review", "amber"], rejected: ["Returned", "red"], completed: ["Completed", "green"], cancelled: ["Cancelled", ""] };
  const PRIO = { Low: "blue", Medium: "amber", High: "red", Urgent: "red" };
  const UNITS = ["m³", "m²", "ft²", "kg", "ton", "m", "pcs", "nos", "LS"];
  const CATS = ["Concrete Work", "Steel Fixing", "Brickwork", "Plaster", "Tiles", "Painting", "Electrical", "Plumbing", "Carpentry", "Finishing", "Excavation", "Other"];
  const DELAYS = { material: "Material shortage", labour: "Insufficient workers", equipment: "Equipment failure", weather: "Weather conditions", design: "Design changes", client: "Client instructions", other: "Other" };
  const PAGE_SIZE = 10;

  const st = window.PB_TASKS_STATE = {
    loaded: false, loading: false, error: "", tasks: [], updates: [], foremen: [], projects: [], boq: [], events: [],
    f: { q: "", project: "", building: "", foreman: "", status: "", priority: "", from: "", to: "" },
    sort: { key: "created_at", dir: -1 }, pg: 1, foremanView: "", foremanTab: "all",
  };
  const client = () => window.PB_CLOUD_CLIENT;
  const canManage = () => ["admin", "manager"].includes(window.PB_CLOUD_ROLE);
  const today = () => C().dubaiToday();
  const fName = (id) => st.foremen.find((x) => x.user_id === id)?.display_name || "Staff";
  const proj = (id) => st.projects.find((p) => p.id === id);
  const initials = (n) => String(n || "?").split(/\s+/).map((x) => x[0]).join("").slice(0, 2).toUpperCase();
  const statsOf = (t) => C().taskStats(t, st.updates, today());
  const taskNo = (t) => `TSK-${String(t.task_no || 0).padStart(3, "0")}`;
  const note = (msg, bad) => { if (typeof window.toast === "function") window.toast(msg); else alert(msg); if (bad) console.warn(msg); };
  const errText = (e) => String(e?.message || e || "Something went wrong").replace(/^.*?ERROR:\s*/, "");

  async function load(force) {
    let c = client();
    for (let i = 0; !c && i < 160; i += 1) { await new Promise((r) => setTimeout(r, 50)); c = client(); }
    if (!c) { st.error = "Cloud is not connected."; return; }
    if (force) st.error = "";
    if (st.loading || (st.loaded && !force)) return;
    st.loading = true;
    try {
      const { data: { session } } = await c.auth.getSession();
      if (!session) { st.error = "signin"; return; }
      const [t, u, f, p, b, ev] = await Promise.all([
        c.from("foreman_tasks").select("*").order("created_at", { ascending: false }),
        c.from("foreman_task_updates").select("*").order("report_date", { ascending: false }),
        c.rpc("get_task_foremen"),
        c.from("team_projects").select("id, local_project_id, name").order("name"),
        c.from("team_boq_items").select("id, project_id, local_boq_id, item_code, description, unit, quantity, completed_qty, metadata").eq("is_active", true).order("sort_order"),
        c.from("foreman_task_events").select("*").order("created_at", { ascending: false }).limit(8),
      ]);
      const bad = [t, u, f, p, b, ev].find((r) => r.error);
      if (bad) throw bad.error;
      Object.assign(st, { tasks: t.data || [], updates: u.data || [], foremen: f.data || [], projects: p.data || [], boq: b.data || [], events: ev.data || [], loaded: true, error: "" });
    } catch (e) { st.error = errText(e); }
    finally { st.loading = false; }
  }

  // ---------- filters ----------
  function filtered() {
    const f = st.f, q = f.q.trim().toLowerCase(), td = today();
    let list = st.tasks.filter((t) => {
      if (f.project && t.project_id !== f.project) return false;
      if (f.building && (t.building || "") !== f.building) return false;
      if (f.foreman && t.assigned_to !== f.foreman) return false;
      if (f.priority && t.priority !== f.priority) return false;
      if (f.status === "overdue") { if (!statsOf(t).overdue) return false; }
      else if (f.status && t.status !== f.status) return false;
      if (f.from && t.due_date < f.from) return false;
      if (f.to && t.start_date > f.to) return false;
      if (q && ![t.title, t.description, t.category, t.building, t.floor, taskNo(t), fName(t.assigned_to), proj(t.project_id)?.name].join(" ").toLowerCase().includes(q)) return false;
      return true;
    });
    if (st.foremanView) {
      list = list.filter((t) => t.assigned_to === st.foremanView);
      const tab = st.foremanTab, wk0 = C().addDays(td, -((new Date(td + "T00:00:00Z").getUTCDay() + 6) % 7)), wk1 = C().addDays(wk0, 6);
      list = list.filter((t) => tab === "all" ? true
        : tab === "today" ? t.start_date <= td && t.due_date >= td && !["completed", "cancelled"].includes(t.status)
        : tab === "week" ? t.start_date <= wk1 && t.due_date >= wk0
        : tab === "progress" ? ["in_progress", "rejected", "assigned"].includes(t.status)
        : tab === "review" ? t.status === "submitted"
        : tab === "completed" ? t.status === "completed"
        : tab === "overdue" ? statsOf(t).overdue : true);
    }
    const k = st.sort.key, d = st.sort.dir;
    const val = (t) => k === "progress" ? (statsOf(t).overallPct ?? -1) : k === "foreman" ? fName(t.assigned_to) : k === "project" ? proj(t.project_id)?.name || "" : k === "priority" ? ["Low", "Medium", "High", "Urgent"].indexOf(t.priority) : t[k] ?? "";
    return list.sort((a, b) => (val(a) > val(b) ? 1 : val(a) < val(b) ? -1 : 0) * d);
  }

  // ---------- page ----------
  function kpiCard(icon, label, value, sub, cls, onclick, tip) {
    return `<button type="button" class="ft-kpi ${cls}" ${onclick ? `onclick="${onclick}"` : ""} ${tip ? `title="${E(tip)}"` : ""}><span class="ft-ico">${icon}</span><div><small>${label}${tip ? ' <i class="ft-i">i</i>' : ""}</small><b>${value}</b>${sub ? `<em>${sub}</em>` : ""}</div></button>`;
  }
  function pill(t) {
    const [l, c] = STATUS[t.status] || [t.status, ""];
    const s = statsOf(t);
    return `<span class="pill ${c}">${l}</span>${s.overdue ? ' <span class="pill red">Overdue</span>' : ""}${s.over ? ' <span class="pill amber" title="Approved work is more than the target. Please check.">Check: over target</span>' : ""}`;
  }
  function bar(p) { const w = p == null ? 0 : Math.max(0, Math.min(100, p)); return `<div class="ft-bar"><i style="width:${w}%;background:${w >= 100 ? "#16a34a" : w >= 50 ? "#2563eb" : "#f59e0b"}"></i></div><small>${P(p)}</small>`; }

  function page() {
    const view = document.getElementById("view");
    if (!view) return;
    if (!st.loaded && !st.error) { view.innerHTML = shell(`<div class="panel"><div class="empty">Loading tasks from Cloud…</div></div>`); load().then(page); return; }
    if (st.error === "signin") { view.innerHTML = shell(`<div class="panel"><div class="notice"><b>Sign in to Cloud first</b><p>Open <b>Access</b> → Cloud Team and sign in with your Admin account. Tasks are saved in Cloud so foremen can see them on their phone.</p><button class="btn primary" onclick="setPage('access');render()">Go to Access</button> <button class="btn" onclick="PB_TASKS_RELOAD()">Try again</button></div></div>`); return; }
    if (st.error) { view.innerHTML = shell(`<div class="panel"><div class="notice dangertext"><b>Tasks could not load</b><p>${E(st.error)}</p><button class="btn" onclick="PB_TASKS_RELOAD()">Try again</button></div></div>`); return; }
    const k = C().dashboardKpis(st.tasks, st.updates, today());
    const list = filtered(), pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    st.pg = Math.min(st.pg, pages);
    const rows = list.slice((st.pg - 1) * PAGE_SIZE, st.pg * PAGE_SIZE);
    const pend = st.updates.filter((u) => u.review_status === "submitted");
    const fv = st.foremanView;
    const pct = (n) => (k.total ? `${Math.round((n / k.total) * 100)}%` : "");
    const kpis = `<div class="ft-kpis">
      ${kpiCard("▦", "Total Tasks", k.total, "", "blue", "PB_TASKS_SET('status','')")}
      ${kpiCard("➜", "Assigned", k.assigned, pct(k.assigned), "blue", "PB_TASKS_SET('status','assigned')")}
      ${kpiCard("▶", "In Progress", k.inProgress, pct(k.inProgress), "green", "PB_TASKS_SET('status','in_progress')")}
      ${kpiCard("◷", "Pending Review", k.submitted, pend.length ? `${pend.length} update${pend.length > 1 ? "s" : ""} waiting` : "", "amber", "PB_TASKS_SET('status','submitted')")}
      ${kpiCard("✓", "Completed", k.completed, pct(k.completed), "green", "PB_TASKS_SET('status','completed')")}
      ${kpiCard("!", "Overdue", k.overdue, pct(k.overdue), "red", "PB_TASKS_SET('status','overdue')", "Due date has passed and the task is not completed and approved (Dubai date).")}
      ${kpiCard("◎", "Avg. Target Achievement", P(k.avgAchievement), "", "purple", "", "For each started task: approved quantity ÷ target × 100, then the average. Only approved work counts.")}
      ${kpiCard("👷", "Active Foremen", k.activeForemen, "", "blue", "PB_TASKS_FOREMEN()", "Foremen who have at least one open task.")}
    </div>`;
    const opt = (arr, cur, all) => `<option value="">${all}</option>` + arr.map(([v, l]) => `<option value="${E(v)}" ${v === cur ? "selected" : ""}>${E(l)}</option>`).join("");
    const foremenUniq = [...new Map(st.foremen.map((x) => [x.user_id, x.display_name])).entries()];
    const buildings = [...new Set(st.tasks.filter((t) => !st.f.project || t.project_id === st.f.project).map((t) => t.building).filter(Boolean))].sort();
    const filters = `<div class="ft-filters">
      <input class="input" placeholder="Search tasks, foreman, project…" value="${E(st.f.q)}" oninput="PB_TASKS_SET('q',this.value,true)">
      <select class="input" onchange="PB_TASKS_SET('project',this.value)">${opt(st.projects.map((p) => [p.id, p.name]), st.f.project, "All Projects")}</select>
      <select class="input" onchange="PB_TASKS_SET('building',this.value)">${opt(buildings.map((b) => [b, b]), st.f.building, "All Sites / Buildings")}</select>
      ${fv ? "" : `<select class="input" onchange="PB_TASKS_SET('foreman',this.value)">${opt(foremenUniq, st.f.foreman, "All Foremen")}</select>`}
      <select class="input" onchange="PB_TASKS_SET('status',this.value)">${opt([...Object.entries(STATUS).map(([v, [l]]) => [v, l]), ["overdue", "Overdue"]], st.f.status, "All Status")}</select>
      <select class="input" onchange="PB_TASKS_SET('priority',this.value)">${opt(["Low", "Medium", "High", "Urgent"].map((x) => [x, x]), st.f.priority, "All Priority")}</select>
      <input class="input" type="date" title="From" value="${E(st.f.from)}" onchange="PB_TASKS_SET('from',this.value)">
      <input class="input" type="date" title="To" value="${E(st.f.to)}" onchange="PB_TASKS_SET('to',this.value)">
      <button class="btn small" onclick="PB_TASKS_CLEAR()">Clear</button>
    </div>`;
    const th = (key, l) => `<th class="ft-sort" onclick="PB_TASKS_SORT('${key}')">${l}${st.sort.key === key ? (st.sort.dir > 0 ? " ▲" : " ▼") : ""}</th>`;
    const table = `<div class="tablewrap"><table class="table ft-table"><thead><tr>${th("task_no", "ID")}${th("title", "Task Title")}${th("project", "Project / Site")}${fv ? "" : th("foreman", "Foreman")}<th>Target</th><th>Approved</th><th>Remaining</th>${th("due_date", "Dates")}${th("progress", "Progress")}${th("priority", "Status / Priority")}</tr></thead><tbody>
      ${rows.map((t) => { const s = statsOf(t), p = proj(t.project_id); return `<tr class="dl-row" style="cursor:pointer" onclick="if(!event.target.closest('button'))PB_TASK_OPEN('${t.id}')">
        <td><button type="button" class="btn small" style="padding:3px 7px;font-weight:800" title="Open task" onclick="PB_TASK_OPEN('${t.id}')">${taskNo(t)}</button></td><td><b>${E(t.title)}</b><small class="ft-sub">${E(t.category || "")}${s.delayReason ? ` · ⚠ ${E(DELAYS[s.delayReason] || s.delayReason)}` : ""}</small></td>
        <td>${E(p?.name || "—")}<small class="ft-sub">${E([t.building, t.floor].filter(Boolean).join(" · ") || "All site")}</small></td>
        ${fv ? "" : `<td><span class="ft-av">${initials(fName(t.assigned_to))}</span>${E(fName(t.assigned_to))}</td>`}
        <td>${Q(t.target_qty)} ${E(t.unit)}<small class="ft-sub">${t.period === "total" ? "Total" : t.period === "weekly" ? "Weekly" : "Daily"}${t.period_target ? ` ${Q(t.period_target)}` : ""}</small></td>
        <td>${Q(s.approved)}${s.pending ? `<small class="ft-sub">+${Q(s.reported - s.approved)} waiting</small>` : ""}</td><td>${Q(s.remaining)}</td>
        <td>${E(t.start_date.slice(5))} → <b>${E(t.due_date.slice(5))}</b><small class="ft-sub">${E(t.due_date.slice(0, 4))}</small></td><td class="ft-prog">${bar(s.overallPct)}<small class="ft-sub">${s.lastUpdate ? "Last: " + E(String(s.lastUpdate).slice(5, 10)) : "No update yet"}</small></td><td>${pill(t)} <span class="pill ${PRIO[t.priority] || ""}">${E(t.priority)}</span></td>
</tr>`; }).join("") || `<tr><td colspan="10" class="empty">${st.tasks.length ? "No task matches these filters." : "No tasks yet. Press “+ New Task” to assign work to a foreman."}</td></tr>`}
    </tbody></table></div>
    <div class="ft-pager"><span>Showing ${list.length ? (st.pg - 1) * PAGE_SIZE + 1 : 0}–${Math.min(st.pg * PAGE_SIZE, list.length)} of ${list.length} tasks</span><span>${Array.from({ length: pages }, (_, i) => `<button class="btn small ${i + 1 === st.pg ? "primary" : ""}" onclick="PB_TASKS_PG(${i + 1})">${i + 1}</button>`).join(" ")}</span></div>`;
    const fvHead = fv ? (() => { const all = st.tasks.filter((t) => t.assigned_to === fv), tabs = [["all", "All Tasks"], ["today", "Today's Tasks"], ["week", "This Week"], ["progress", "In Progress"], ["review", "Pending Review"], ["completed", "Completed"], ["overdue", "Overdue"]];
      return `<div class="ft-fvhead"><span class="ft-av big">${initials(fName(fv))}</span><div><b>${E(fName(fv))}</b><small>${all.length} task${all.length === 1 ? "" : "s"} · ${E([...new Set(all.map((t) => proj(t.project_id)?.name).filter(Boolean))].join(", ") || "No site yet")}</small></div><button class="btn small" onclick="PB_TASKS_FV('')">‹ All foremen</button></div><div class="ft-tabs">${tabs.map(([v, l]) => `<button class="${st.foremanTab === v ? "on" : ""}" onclick="PB_TASKS_FTAB('${v}')">${l}</button>`).join("")}</div>`; })() : "";
    const side = `<div class="ft-side">
      <div class="panel"><div class="panel-head"><h3>Quick Actions</h3></div>
        ${canManage() ? `<button class="btn primary ft-wide" onclick="PB_TASK_NEW()">＋ Assign New Task</button>` : `<p class="ft-sub">Only Admin or Manager can assign tasks.</p>`}
        <button class="btn ft-wide" onclick="PB_TASKS_FOREMEN()">👷 Foreman task lists</button>
        <button class="btn ft-wide" onclick="PB_TASKS_SET('status','submitted')">◷ Waiting for approval (${pend.length})</button>
        <button class="btn ft-wide" onclick="PB_TASK_REPORTS && PB_TASK_REPORTS()">📈 Performance Reports</button>
        <button class="btn ft-wide" onclick="PB_TASKS_CSV()">⬇ Download CSV</button>
        <button class="btn ft-wide" onclick="PB_TASKS_RELOAD()">⟳ Refresh</button>
        <details class="ft-help"><summary>ⓘ How numbers are calculated</summary><ul>
          <li><b>Achievement</b> = approved quantity ÷ target × 100.</li><li><b>Daily achievement</b> = approved today ÷ daily target × 100.</li>
          <li><b>Remaining</b> = target − approved (never below 0; above target is flagged “Check”).</li><li><b>Overdue</b> = due date passed and not completed (Dubai date).</li>
          <li>Quantities sent by the foreman count only after Admin/Manager approval. Cancelled tasks are not counted.</li><li>“No Data” means there is nothing to calculate yet — it is not 0%.</li></ul></details>
      </div>
      <div class="panel"><div class="panel-head"><h3>Recent Activity</h3></div>${st.events.map((e) => { const t = st.tasks.find((x) => x.id === e.task_id); return `<div class="ft-act" onclick="${t ? `PB_TASK_OPEN('${t.id}')` : ""}"><b>${E(evLabel(e))}</b><small>${E(t?.title || "")} · ${E(new Date(e.created_at).toLocaleString())}</small></div>`; }).join("") || '<div class="empty">No activity yet.</div>'}</div>
    </div>`;
    view.innerHTML = shell(`${kpis}<div class="ft-grid"><div class="panel ft-main">${fvHead}${filters}<div class="panel-head"><h3>${fv ? "Tasks of this foreman" : "Task List"}</h3></div>${table}</div>${side}</div>`);
  }
  function shell(body) {
    const actions = `<button class="btn" onclick="setPage('projects');render()">‹ Projects / Sites</button>${canManage() && st.loaded ? ' <button class="btn primary" onclick="PB_TASK_NEW()">＋ New Task</button>' : ""}`;
    const h = typeof window.head === "function" ? window.head("Foreman Task / Target Management", "Assign tasks and targets to site foremen. Track progress, approvals and delays.", actions) : `<h2>Foreman Task / Target Management</h2>`;
    return `<div class="ft-page">${h}${body}</div>`;
  }
  function evLabel(e) {
    const who = e.actor ? fName(e.actor) : "";
    return ({ assigned: "New task assigned", reassigned: "Task reassigned", target_revised: "Target / due date revised", edited: "Task edited", started: "Foreman started work", submitted: "Progress submitted", approved: "Progress approved", rejected: "Progress rejected", completed: "Task completed", cancelled: "Task cancelled", in_progress: "Task reopened", files_added: "Files added" }[e.event_type] || e.event_type) + (who && who !== "Staff" ? ` · ${who}` : "");
  }

  // ---------- modal ----------
  function modal(title, body, wide) {
    document.querySelector(".ft-ov")?.remove();
    const ov = document.createElement("div"); ov.className = "ft-ov";
    ov.innerHTML = `<div class="ft-modal ${wide ? "wide" : ""}" role="dialog" aria-label="${E(title)}"><div class="ft-mh"><h3>${E(title)}</h3><button class="btn small" data-close aria-label="Close">✕</button></div><div class="ft-mb">${body}</div></div>`;
    ov.addEventListener("click", (e) => { if (e.target === ov || e.target.closest("[data-close]")) ov.remove(); });
    document.body.append(ov);
    return ov;
  }
  const busy = (btn, on) => { if (btn) { btn.disabled = on; btn.dataset.l ||= btn.textContent; btn.textContent = on ? "Saving…" : btn.dataset.l; } };

  function localBuildings(pid) {
    const lp = proj(pid)?.local_project_id;
    const b = new Set(typeof window.projectBuildings === "function" && lp ? window.projectBuildings(lp) : []);
    st.boq.filter((x) => x.project_id === pid && x.metadata?.building).forEach((x) => b.add(x.metadata.building));
    return [...b].sort();
  }
  function localFloors(pid, building) {
    const lp = proj(pid)?.local_project_id, set = new Set();
    (LDB().boq || []).forEach((x) => { if (String(x.projectId) === String(lp) && (!building || x.building === building) && x.floor) set.add(x.floor); });
    st.boq.forEach((x) => { if (x.project_id === pid && (!building || x.metadata?.building === building) && x.metadata?.floor) set.add(x.metadata.floor); });
    return [...set].sort();
  }

  function taskForm(t) {
    const v = (k, d = "") => E(t?.[k] ?? d);
    const pid = t?.project_id || st.f.project || st.projects[0]?.id || "";
    const sel = (name, opts, cur, req) => `<select class="input" name="${name}" ${req ? "required" : ""}>${opts.map(([a, b]) => `<option value="${E(a)}" ${String(a) === String(cur ?? "") ? "selected" : ""}>${E(b)}</option>`).join("")}</select>`;
    const td = today();
    return `<form class="ft-form" id="ftForm">
      <label class="span2">Task Title *<input class="input" name="title" required maxlength="160" value="${v("title")}"></label>
      <label>Project / Site *${sel("project_id", st.projects.map((p) => [p.id, p.name]), pid, true)}</label>
      <label>Building / Site<input class="input" name="building" list="ftBld" value="${v("building")}" placeholder="All site"><datalist id="ftBld"></datalist></label>
      <label>Floor<input class="input" name="floor" list="ftFlr" value="${v("floor")}"><datalist id="ftFlr"></datalist></label>
      <label>Work location / Room<input class="input" name="location" value="${v("location")}"></label>
      <label>Assigned Foreman *<select class="input" name="assigned_to" required></select></label>
      <label>Work Type *<input class="input" name="category" list="ftCat" required value="${v("category")}"><datalist id="ftCat">${CATS.map((c) => `<option value="${c}">`).join("")}</datalist></label>
      <label class="span2">Linked BOQ Item (optional)<select class="input" name="boq_item_id"></select></label>
      <div class="ft-boqbal" id="ftBoqBal" hidden></div>
      ${t ? "" : `<style>#ftMulti{border:1px solid #dcd9e7;border-radius:12px;padding:10px 12px;max-height:300px;overflow:auto;background:#f7f6fb}#ftMulti>b{font-size:13px}#ftMultiList .ftm-g{display:flex;justify-content:space-between;font-weight:800;font-size:12.5px;color:#4c3fa0;margin:10px 0 4px;padding-bottom:3px;border-bottom:1px solid #e3e0ef}#ftMultiList .ftm-g span{background:#ece9fb;border-radius:999px;padding:0 8px;font-size:11px}#ftMultiList label.ftm-i{display:grid!important;grid-template-columns:20px 80px 1fr auto 78px 78px 78px 110px;gap:8px;align-items:center;padding:6px 8px;margin:2px 0;border-radius:8px;font-weight:500!important;font-size:12.5px!important;cursor:pointer;background:#fff;border:1px solid transparent}#ftMultiList label.ftm-i:hover{border-color:#c9c1f2}#ftMultiList label.ftm-i:has(input:checked){background:#eeeafd;border-color:#8875dc}#ftMultiList label.ftm-i.off{opacity:.55;cursor:not-allowed}#ftMultiList input[type=checkbox]{width:16px!important;height:16px!important;min-height:0!important;margin:0!important;padding:0!important;accent-color:#7c6ad6;flex:none}#ftMultiList .ftm-r{font-weight:800;color:#2b2a3a}#ftMultiList .ftm-c{color:#6b6880;font-size:11.5px;white-space:nowrap}#ftMultiList .ftm-n{font-size:11px;color:#6b6880;background:#f3f1fa;border-radius:6px;padding:3px 6px;text-align:center;white-space:nowrap}#ftMultiList .ftm-n b{color:#2b2a3a}#ftMultiList .ftm-n.ok{background:#e3f6ea}#ftMultiList .ftm-n.ok b{color:#157a3b}#ftMultiList .ftm-n.zero{background:#fde8e8}#ftMultiList .ftm-n.zero b{color:#b42318}#ftMultiList .ftm-q{width:110px!important;min-height:30px!important;height:30px;padding:3px 8px!important;font-size:12.5px!important;border:1px solid #c9c1f2!important;border-radius:8px!important;background:#fff!important}#ftMultiList .ftm-q:disabled{opacity:.35}#ftMultiList .ftm-o{background:#fdecc8;color:#8a5a00;border-radius:999px;padding:1px 8px;font-size:10.5px;font-weight:700}</style><div class="span2" id="ftMulti"><b>➕ Also assign more BOQ items (one task each, same foreman & dates)</b><div id="ftMultiList" style="margin-top:6px;font-size:12.5px"></div></div>`}
      <label>Start Date *<input class="input" type="date" name="start_date" required value="${v("start_date", td)}"></label>
      <label>Due Date *<input class="input" type="date" name="due_date" required value="${v("due_date", td)}"></label>
      <label>Priority *${sel("priority", ["Low", "Medium", "High", "Urgent"].map((x) => [x, x]), t?.priority || "Medium", true)}</label>
      <label>Total Target Quantity *<input class="input" type="number" name="target_qty" min="0.01" step="any" required value="${v("target_qty")}"></label>
      <label>Unit *<input class="input" name="unit" list="ftUnit" required value="${v("unit")}"><datalist id="ftUnit">${UNITS.map((u) => `<option value="${u}">`).join("")}</datalist></label>
      <label>Target Period *${sel("period", [["daily", "Daily target"], ["weekly", "Weekly target"], ["total", "Total only (spread evenly)"]], t?.period || "daily", true)}</label>
      <label>Daily / Weekly Target<input class="input" type="number" name="period_target" min="0" step="any" value="${v("period_target")}" placeholder="Auto if empty"></label>
      <label>Expected Working Days<input class="input" type="number" name="working_days" min="0" step="1" value="${v("working_days")}"></label>
      <label>Required Workers<input class="input" type="number" name="required_labour" min="0" step="1" value="${v("required_labour")}"></label>
      <label class="span2">Required Materials<input class="input" name="required_materials" value="${v("required_materials")}" placeholder="e.g. Cement 50 bags, Sand 4 m³"></label>
      <label class="span2">Description / Instructions<textarea class="input" name="description" rows="2">${v("description")}</textarea></label>
      <label class="span2">Acceptance Criteria<textarea class="input" name="acceptance_criteria" rows="2" placeholder="When is this work accepted as complete?">${v("acceptance_criteria")}</textarea></label>
      <label>Assigned Team<input class="input" name="assigned_team" placeholder="e.g. Painting Team A" value="${v("assigned_team")}"></label>
      <label class="span2">Additional Notes<textarea class="input" name="notes" rows="2">${v("notes")}</textarea></label>
      ${t ? `<label class="span2 ft-reason">Reason for change <small>(required if target, due date or foreman changes — old values stay in history)</small><input class="input" name="reason"></label>` : `<label class="span2">Attachments (drawings, photos — optional)<input class="input" type="file" name="files" multiple accept="image/*,application/pdf"></label>`}
      <p class="ft-msg span2" id="ftMsg"></p>
      <div class="span2 ft-actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">${t ? "Save Changes" : "Save Task"}</button></div>
    </form>`;
  }
  function wireForm(ov, t) {
    const f = ov.querySelector("#ftForm");
    const refresh = () => {
      const pid = f.project_id.value;
      ov.querySelector("#ftBld").innerHTML = localBuildings(pid).map((b) => `<option value="${E(b)}">`).join("");
      ov.querySelector("#ftFlr").innerHTML = localFloors(pid, f.building.value).map((b) => `<option value="${E(b)}">`).join("");
      const fm = st.foremen.filter((x) => x.project_id === pid), cur = f.assigned_to.value || t?.assigned_to || "";
      f.assigned_to.innerHTML = `<option value="">${fm.length ? "Choose foreman" : "No staff assigned to this site"}</option>` + fm.map((x) => `<option value="${x.user_id}" ${x.user_id === cur ? "selected" : ""}>${E(x.display_name)}</option>`).join("");
      const curB = f.boq_item_id.value || t?.boq_item_id || "";
      const bv = f.building.value.trim().toLowerCase(), fv = f.floor.value.trim().toLowerCase();
      const rows = st.boq.filter((x) => x.project_id === pid).map((x) => { const L = (LDB().boq || []).find((y) => String(y.id) === String(x.local_boq_id)) || {}, m = x.metadata || {}; return { x, b: L.building || m.building || "", fl: L.floor || m.floor || "", rm: L.area || m.area || "" }; })
        .filter((r) => (!bv || !r.b || r.b.toLowerCase() === bv) && (!fv || !r.fl || r.fl.toLowerCase() === fv));
      // Local BOQ lines not yet approved are not sent to staff; show them greyed so every room item is visible.
      const sb = st.boq.find((x) => x.project_id === pid), sl = sb && (LDB().boq || []).find((y) => String(y.id) === String(sb.local_boq_id)); const lp = { id: sl ? (sl.projectId || sl.project) : "__none" };
      const synced = new Set(st.boq.map((x) => String(x.local_boq_id)));
      (LDB().boq || []).filter((L) => !synced.has(String(L.id)) && (L.projectId === lp.id || L.project === lp.id) && (!bv || !L.building || String(L.building).toLowerCase() === bv) && (!fv || !L.floor || String(L.floor).toLowerCase() === fv))
        .forEach((L) => rows.push({ x: { id: "", description: L.description || "", item_code: L.code || L.boqId || L.itemNo || "", unit: L.unit || "" }, b: L.building || "", fl: L.floor || "", rm: L.area || "", off: (L.status || "Draft") }));
      const cmp = (a, b2) => String(a || "").localeCompare(String(b2 || ""), undefined, { numeric: true, sensitivity: "base" });
      rows.sort((a, b2) => cmp(a.b, b2.b) || cmp(a.fl, b2.fl) || cmp(a.rm, b2.rm) || cmp(a.x.item_code, b2.x.item_code));
      const groups = new Map(); rows.forEach((r) => { const k = (r.b || "General") + (r.fl ? " › " + r.fl : ""); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); });
      const lab = (r) => `${r.rm ? "Room " + E(r.rm) + "  ·  " : ""}${E(r.x.description)}  [${E(r.x.item_code || r.x.local_boq_id)} · ${E(r.x.unit || "")}]${r.off ? "  (not approved yet)" : ""}`;
      f.boq_item_id.innerHTML = `<option value=""></option>` + [...groups].map(([k, a]) => `<optgroup label="${E(k)}">` + a.map((r) => `<option value="${r.x.id}" ${r.off ? "disabled" : ""} ${!r.off && r.x.id === curB ? "selected" : ""}>${lab(r)}</option>`).join("") + `</optgroup>`).join("");
      const nums = (r) => { const L = (LDB().boq || []).find((y) => String(y.id) === String(r.x.local_boq_id)) || {}; const q = Number(L.qty ?? r.x.quantity) || 0, d = Number(L.executedQty ?? r.x.completed_qty ?? 0) || 0; const g = r.x.id ? st.tasks.filter((x) => x.boq_item_id === r.x.id && x.status !== "cancelled").reduce((s2, x) => s2 + (Number(x.target_qty) || 0), 0) : 0; return { q, d, l: Math.max(0, q - d - g) }; };
      const ml = ov.querySelector("#ftMultiList");
      if (ml) { const was = new Set([...ml.querySelectorAll("input:checked")].map((i) => i.value)); const wasQ = {}; ml.querySelectorAll(".ftm-q").forEach((q) => { if (q.value) wasQ[q.dataset.q] = q.value; }); ml.innerHTML = rows.length ? [...groups].map(([k, a]) => `<div class="ftm-g">🏢 ${E(k)} <span>${a.length}</span></div>` + a.map((r) => `<label class="ftm-i ${r.off ? "off" : ""}"><input type="checkbox" value="${r.x.id}" ${r.off ? "disabled" : ""} ${was.has(r.x.id) ? "checked" : ""}><span class="ftm-r">${r.rm ? "Room " + E(r.rm) : "—"}</span><span class="ftm-d">${E(r.x.description)}</span><span class="ftm-c">${E(r.x.item_code || "")} · ${E(r.x.unit || "")}</span>${(() => { const n = nums(r); return `<span class="ftm-n">BOQ <b>${Q(n.q)}</b></span><span class="ftm-n">Done <b>${Q(n.d)}</b></span><span class="ftm-n ${n.l > 0 ? "ok" : "zero"}">Left <b>${Q(n.l)}</b></span>`; })()}${r.off ? `<span class="ftm-o">Not approved</span>` : `<input class="ftm-q" type="number" min="0" step="any" placeholder="Target qty" data-q="${r.x.id}" value="${E(wasQ[r.x.id] || "")}" ${was.has(r.x.id) ? "" : "disabled"}>`}</label>`).join("")).join("") : "No BOQ items"; }
    };
    // One selector: the checkbox list replaces the dropdown; first ticked item = linked BOQ, others = extra tasks.
    const mb = ov.querySelector("#ftMulti");
    if (mb) {
      const lb = f.boq_item_id.closest("label"); f.boq_item_id.style.display = "none"; lb.after(mb); lb.style.gridColumn = "1 / -1"; lb.style.marginBottom = "-6px"; mb.style.gridColumn = "1 / -1";
      const hd = mb.querySelector(":scope>b"); if (hd) hd.innerHTML = '<small style="font-weight:600;color:#6b6880">Tick one or more BOQ items and type a target quantity for each — each ticked item becomes its own task (same foreman &amp; dates)</small>';
      const qOf = (id) => mb.querySelector(`.ftm-q[data-q="${id}"]`);
      const syncFirst = () => { try {
        const ticks = [...mb.querySelectorAll("input[type=checkbox]:checked")];
        if (!ticks.length) { f.target_qty.readOnly = false; return; }
        const sum = ticks.reduce((a, c) => { const q = qOf(c.value); return a + (q && q.value !== "" ? Number(q.value) || 0 : 0); }, 0);
        f.target_qty.value = sum ? String(Math.round(sum * 1000) / 1000) : ""; f.target_qty.readOnly = true; f.target_qty.title = "Sum of all ticked BOQ target quantities";
        showBal();
      } catch (e) { console.warn("ft sync", e); } };
      mb.addEventListener("change", (e) => {
        if (!e.target.matches('input[type=checkbox]')) return;
        const q = qOf(e.target.value); if (q) { q.disabled = !e.target.checked; if (e.target.checked) setTimeout(() => q.focus(), 0); }
        const first = mb.querySelector("input[type=checkbox]:checked"); const prev = f.boq_item_id.value; f.boq_item_id.value = first ? first.value : "";
        if (first && prev !== first.value) { f.boq_item_id.onchange && f.boq_item_id.onchange(); const fq = qOf(first.value); if (fq && !fq.value) fq.value = f.target_qty.value; }
        if (q && e.target.checked && !q.value) { const b = st.boq.find((x) => x.id === e.target.value); if (b) { const used = st.tasks.filter((x) => x.boq_item_id === b.id && x.status !== "cancelled").reduce((s2, x) => s2 + (Number(x.target_qty) || 0), 0); const left = Math.max(0, (Number(b.quantity) || 0) - (Number(b.completed_qty) || 0) - used); q.value = left || ""; } }
        syncFirst(); if (!first) showBal();
      });
      mb.addEventListener("input", (e) => { if (e.target.matches(".ftm-q")) syncFirst(); });
      mb.addEventListener("click", (e) => { if (e.target.matches(".ftm-q")) e.preventDefault(); }, true);
      const cur = f.boq_item_id.value; if (cur) { const c = mb.querySelector(`input[value="${cur}"]`); if (c) c.checked = true; }
    }
    f.project_id.onchange = refresh; f.building.onchange = refresh; f.building.oninput = refresh; f.floor.onchange = refresh; f.floor.oninput = refresh;
    f.boq_item_id.onchange = () => {
      const b = st.boq.find((x) => x.id === f.boq_item_id.value); if (!b) return;
      // Fill from the BOQ item added in the room (local record has the full room details).
      const L = (LDB().boq || []).find((x) => String(x.id) === String(b.local_boq_id)) || {}, m = b.metadata || {};
      const set = (n, val) => { if (val != null && String(val).trim() !== "" && f[n]) f[n].value = val; };
      set("building", L.building || m.building); set("floor", L.floor || m.floor);
      set("location", [L.area || m.area, L.zone].filter(Boolean).join(" / "));
      set("category", L.category || m.category); set("unit", L.unit || b.unit);
      set("title", L.description || b.description);
      if (L.spec && !f.description.value) f.description.value = L.spec;
      const bal = boqBal();
      if (bal && bal.boq > 0) set("target_qty", bal.available || bal.boq);
      showBal();
    };
    // BOQ quantity → this target → outstanding, shown live under the BOQ picker.
    const boqBal = () => {
      const b = st.boq.find((x) => x.id === f.boq_item_id.value); if (!b) return null;
      const L = (LDB().boq || []).find((x) => String(x.id) === String(b.local_boq_id)) || {};
      const qty = Number(L.qty ?? b.quantity) || 0, done = Number(L.executedQty ?? b.completed_qty ?? 0) || 0;
      const other = st.tasks.filter((x) => x.boq_item_id === b.id && x.status !== "cancelled" && (!t || x.id !== t.id)).reduce((s2, x) => s2 + (Number(x.target_qty) || 0), 0);
      const fq = ov.querySelector(`#ftMultiList .ftm-q[data-q="${b.id}"]`);
      return Object.assign(C().boqTaskBalance(qty, done, other, fq && !fq.disabled && fq.value !== "" ? fq.value : f.target_qty.value), { unit: L.unit || b.unit || "" });
    };
    const showBal = () => {
      const box = ov.querySelector("#ftBoqBal"), r = boqBal();
      if (!r) { box.hidden = true; box.innerHTML = ""; return; }
      const u = E(r.unit), c = (label, val, cls = "") => `<div class="ft-bb ${cls}"><small>${label}</small><b>${Q(val)} <i>${u}</i></b></div>`;
      box.hidden = false;
      box.innerHTML = c("BOQ Quantity", r.boq) + c("Already Done", r.done) + c("Given to other tasks", r.other) + c("Available to assign", r.available, "blue")
        + c("This Target", r.target, "amber") + c("Outstanding after this", r.outstanding, r.over ? "bad" : "good")
        + (r.over ? `<p class="ft-bbwarn">⚠ Target is ${Q(r.over)} ${u} more than what is left in the BOQ.</p>` : "");
    };
    f.target_qty.addEventListener("input", showBal);
    if (t) f.project_id.disabled = true;
    refresh(); showBal();
    f.onsubmit = async (e) => {
      e.preventDefault();
      const msg = ov.querySelector("#ftMsg"), btn = f.querySelector('[type="submit"]');
      const fd = Object.fromEntries(new FormData(f).entries()); delete fd.files;
      { const fq0 = fd.boq_item_id && ov.querySelector(`#ftMultiList .ftm-q[data-q="${fd.boq_item_id}"]`); if (fq0 && fq0.value !== "") fd.target_qty = fq0.value; }
      const team = String(fd.assigned_team || "").trim(); delete fd.assigned_team;
      if (t) fd.project_id = t.project_id;
      if (Number(fd.target_qty) <= 0) { msg.textContent = "Target quantity must be more than 0."; return; }
      if (fd.due_date < fd.start_date) { msg.textContent = "Due date must be on or after the start date."; return; }
      if (fd.period_target !== "" && Number(fd.period_target) < 0) { msg.textContent = "Daily / weekly target cannot be negative."; return; }
      busy(btn, true); msg.textContent = "";
      try {
        const c = client();
        if (!t) {
          const { data: id, error } = await c.rpc("create_foreman_task", { p: fd });
          if (error) throw error;
          if (team) await c.rpc("set_foreman_task_team", { p_task: id, p_team: team });
          const files = [...(f.files?.files || [])];
          if (files.length) {
            const { data: { session } } = await c.auth.getSession();
            const prof = await c.from("profiles").select("organization_id").eq("id", session.user.id).single();
            const saved = [];
            for (const file of files.slice(0, 10)) {
              if (file.size > 10 * 1024 * 1024) continue;
              const path = `${prof.data.organization_id}/${fd.project_id}/task-${id}/${Date.now()}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
              const up = await c.storage.from("site-progress-photos").upload(path, file, { contentType: file.type, upsert: false });
              if (!up.error) saved.push({ path, name: file.name, content_type: file.type, size: file.size });
            }
            if (saved.length) await c.rpc("add_foreman_task_attachments", { p_task: id, p_files: saved });
          }
          // Extra BOQ items ticked: one task each with the BOQ's remaining quantity.
          const extra = [...ov.querySelectorAll("#ftMultiList input:checked")].map((i) => i.value).filter((x) => x && x !== fd.boq_item_id);
          let made = 1, skipped = 0;
          for (const bid of extra) {
            const b = st.boq.find((x) => x.id === bid); if (!b) continue;
            const used = st.tasks.filter((x) => x.boq_item_id === bid && x.status !== "cancelled").reduce((s2, x) => s2 + (Number(x.target_qty) || 0), 0);
            const left = Math.max(0, (Number(b.quantity) || 0) - (Number(b.completed_qty) || 0) - used);
            const qi = ov.querySelector(`#ftMultiList .ftm-q[data-q="${bid}"]`), typed = qi && qi.value !== "" ? Number(qi.value) : null;
            const tq = typed != null && typed > 0 ? typed : left;
            if (tq <= 0) { skipped++; continue; }
            const L = (LDB().boq || []).find((x) => String(x.id) === String(b.local_boq_id)) || {}, m = b.metadata || {};
            const p2 = { ...fd, boq_item_id: bid, title: L.description || b.description || fd.title, unit: L.unit || b.unit || fd.unit, target_qty: String(tq), period_target: "",
              building: L.building || m.building || fd.building, floor: L.floor || m.floor || fd.floor, location: [L.area || m.area, L.zone].filter(Boolean).join(" / ") || fd.location, category: L.category || m.category || fd.category };
            const r2 = await c.rpc("create_foreman_task", { p: p2 });
            if (r2.error) { skipped++; continue; }
            made++; if (team) await c.rpc("set_foreman_task_team", { p_task: r2.data, p_team: team });
          }
          note(made > 1 ? `${made} tasks assigned to foreman` + (skipped ? ` (${skipped} skipped: nothing left)` : "") : "Task assigned to foreman");
        } else {
          const reason = fd.reason; delete fd.reason; delete fd.project_id;
          const { data, error } = await c.rpc("update_foreman_task", { p_task: t.id, p: fd, p_reason: reason || "" });
          if (error) throw error;
          let teamSaved = false;
          if (team !== (t.assigned_team || "")) { const r = await c.rpc("set_foreman_task_team", { p_task: t.id, p_team: team }); if (r.error) throw r.error; teamSaved = !!r.data?.saved; }
          note(data?.saved || teamSaved ? "Task updated · old values kept in history" : "Nothing changed");
        }
        ov.remove(); await load(true); page();
      } catch (err) { msg.textContent = errText(err); busy(btn, false); }
    };
  }
  function newTask() {
    if (!canManage()) return note("Only Admin or Manager can assign tasks.");
    if (!st.projects.length) return note("No Cloud project yet. Use Access → Sync projects & BOQ first.");
    const ov = modal("Assign New Task", taskForm(null), true); wireForm(ov, null);
  }
  function editTask(id) { const t = st.tasks.find((x) => x.id === id); if (!t) return; const ov = modal(`Edit ${taskNo(t)}`, taskForm(t), true); wireForm(ov, t); }

  async function openTask(id) {
    const t = st.tasks.find((x) => x.id === id); if (!t) return;
    const s = statsOf(t), p = proj(t.project_id), ups = st.updates.filter((u) => u.task_id === id);
    const boq = st.boq.find((b) => b.id === t.boq_item_id);
    const ov = modal(`${taskNo(t)} · ${t.title}`, `<div class="empty">Loading…</div>`, true);
    const c = client();
    const [{ data: evs }, urls] = await Promise.all([
      c.from("foreman_task_events").select("*").eq("task_id", id).order("created_at", { ascending: false }),
      (async () => { const m = {}; const paths = [...(t.attachments || []), ...ups.flatMap((u) => u.photos || [])].map((x) => x.path).filter(Boolean); if (paths.length) { const { data } = await c.storage.from("site-progress-photos").createSignedUrls(paths, 600); (data || []).forEach((d) => { if (d.signedUrl) m[d.path] = d.signedUrl; }); } return m; })(),
    ]);
    const mg = canManage(), open = !["completed", "cancelled"].includes(t.status);
    const fileLink = (x) => urls[x.path] ? (/^image\//.test(x.content_type || "") ? `<a href="${urls[x.path]}" target="_blank" rel="noopener"><img src="${urls[x.path]}" alt="${E(x.name || "photo")}" class="ft-thumb"></a>` : `<a href="${urls[x.path]}" target="_blank" rel="noopener">📄 ${E(x.name || "file")}</a>`) : "";
    const row = (l, v) => `<div class="ft-kv"><span>${l}</span><b>${v}</b></div>`;
    ov.querySelector(".ft-mb").innerHTML = `
      <div class="ft-dtop">${pill(t)} <span class="pill ${PRIO[t.priority] || ""}">${E(t.priority)}</span>
        ${mg && open ? `<button class="btn small" onclick="PB_TASK_EDIT('${id}')">✎ Edit / Reassign</button> <button class="btn small" onclick="PB_TASK_STATUS('${id}','completed')">✓ Mark Completed</button> <button class="btn small danger" onclick="PB_TASK_STATUS('${id}','cancelled')">Cancel task</button>` : ""}
        ${mg && !open ? `<button class="btn small" onclick="PB_TASK_STATUS('${id}','in_progress')">↺ Reopen</button>` : ""}</div>
      <div class="ft-dgrid">
        <div class="ft-stat"><small>Total Target</small><b>${Q(t.target_qty)} ${E(t.unit)}</b>${Number(t.original_target_qty) !== Number(t.target_qty) ? `<em>Original ${Q(t.original_target_qty)}</em>` : ""}</div>
        <div class="ft-stat"><small>Daily Target</small><b>${Q(C().dailyTarget(t))} ${E(t.unit)}</b></div>
        <div class="ft-stat"><small>Reported (all)</small><b>${Q(s.reported)}</b></div>
        <div class="ft-stat good"><small>Approved</small><b>${Q(s.approved)}</b></div>
        <div class="ft-stat"><small>Remaining</small><b>${Q(s.remaining)}</b>${s.over ? "<em>Over target — check</em>" : ""}</div>
        <div class="ft-stat"><small>Overall Achievement</small><b>${P(s.overallPct)}</b></div>
        <div class="ft-stat"><small>Today Achievement</small><b>${P(s.dailyPct)}</b><em>${Q(s.todayApproved)} of ${Q(s.todayPlanned)}</em></div>
        <div class="ft-stat"><small>Days reported / missed target / no report</small><b>${s.workingDays} / ${s.missedTargets} / ${s.missingReports}</b></div>
      </div>
      <div class="ft-cols"><div>
        ${row("Foreman", E(fName(t.assigned_to)))}${row("Team", E(t.assigned_team || "—"))}${row("Project / Site", E(p?.name || "—"))}${row("Location", E([t.building, t.floor, t.location].filter(Boolean).join(" · ") || "All site"))}
        ${row("Work type", E(t.category || "—"))}${row("BOQ item", boq ? E(`${boq.item_code || boq.local_boq_id} · ${boq.description}`) : "—")}
        ${row("Dates", `${E(t.start_date)} → ${E(t.due_date)}${t.original_due_date && t.original_due_date !== t.due_date ? ` <small>(original ${E(t.original_due_date)})</small>` : ""}`)}
        ${row("Workers / Days", `${t.required_labour ?? "—"} / ${t.working_days ?? "—"}`)}${row("Materials", E(t.required_materials || "—"))}
      </div><div>
        ${t.description ? `<p><b>Instructions</b><br>${E(t.description)}</p>` : ""}${t.acceptance_criteria ? `<p><b>Acceptance criteria</b><br>${E(t.acceptance_criteria)}</p>` : ""}${t.notes ? `<p><b>Notes</b><br>${E(t.notes)}</p>` : ""}
        ${(t.attachments || []).length ? `<p><b>Files</b></p><div class="ft-files">${t.attachments.map(fileLink).join("")}</div>` : ""}
      </div></div>
      <h4>Progress submissions</h4>
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Reported</th><th>Approved</th><th>Note / Delay / Problems</th><th>Photos</th><th>Status</th><th>Review</th></tr></thead><tbody>
      ${ups.map((u) => `<tr><td>${E(u.report_date)}</td><td>${Q(u.reported_qty)} ${E(t.unit)}${u.ask_complete ? '<small class="ft-sub">Foreman says finished</small>' : ""}${u.workers != null || u.work_hours != null ? `<small class="ft-sub">👷 ${u.workers ?? "—"} workers · ${u.work_hours ?? "—"} hrs</small>` : ""}</td><td>${u.review_status === "approved" ? Q(u.approved_qty) : "—"}</td>
        <td>${E(u.note || "")}${u.delay_reason ? `<small class="ft-sub">⚠ ${E(DELAYS[u.delay_reason] || u.delay_reason)}${u.delay_external ? " (outside foreman's control)" : ""}</small>` : ""}${(u.blockers || []).length ? `<small class="ft-sub">Problems: ${E(u.blockers.join(", "))}</small>` : ""}</td>
        <td><div class="ft-files">${(u.photos || []).map(fileLink).join("") || "—"}</div></td>
        <td><span class="pill ${u.review_status === "approved" ? "green" : u.review_status === "rejected" ? "red" : "amber"}">${u.review_status === "submitted" ? "Waiting" : u.review_status === "approved" ? "Approved" : "Returned for correction"}</span>${u.review_note ? `<small class="ft-sub">${E(u.review_note)}</small>` : ""}</td>
        <td>${u.review_status === "submitted" && mg ? `<div class="ft-rev"><input class="input" type="number" min="0" max="${u.reported_qty}" step="any" value="${u.reported_qty}" id="aq-${u.id}" title="Approved quantity (0 to reported)"><input class="input" id="rn-${u.id}" placeholder="Comment (required to return)"><label><input type="checkbox" id="cp-${u.id}" ${u.ask_complete ? "checked" : ""}> Task fully completed</label><button class="btn small primary" onclick="PB_TASK_REVIEW('${u.id}','approved')">✓ Approve</button><button class="btn small danger" onclick="PB_TASK_REVIEW('${u.id}','rejected')" title="Foreman can fix and send again for the same date">↩ Return for correction</button></div>` : u.reviewed_at ? `<small>${E(new Date(u.reviewed_at).toLocaleString())}</small>` : "—"}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">The foreman has not sent any progress yet.</td></tr>'}
      </tbody></table></div>
      <h4>Task history</h4>
      <div class="ft-hist">${(evs || []).map((e) => `<div><b>${E(evLabel(e))}</b> <small>${E(new Date(e.created_at).toLocaleString())}</small>${e.reason ? `<div>Reason: ${E(e.reason)}</div>` : ""}${e.old_values && Object.keys(e.old_values).length ? `<div class="ft-sub">Before: ${E(fmtVals(e.old_values))}</div>` : ""}${e.new_values && Object.keys(e.new_values).length ? `<div class="ft-sub">After: ${E(fmtVals(e.new_values))}</div>` : ""}</div>`).join("") || '<div class="empty">No history.</div>'}</div>`;
  }
  function fmtVals(o) { return Object.entries(o).filter(([k]) => k !== "update_id").map(([k, v]) => `${k.replace(/_/g, " ")}: ${k === "assigned_to" ? fName(v) : typeof v === "object" ? JSON.stringify(v) : v}`).join(" · "); }

  async function review(uid, decision) {
    const aq = document.getElementById(`aq-${uid}`)?.value, rn = document.getElementById(`rn-${uid}`)?.value || "", cp = document.getElementById(`cp-${uid}`)?.checked;
    if (decision === "rejected" && !rn.trim()) return note("Please write what the foreman must correct.");
    const u = st.updates.find((x) => x.id === uid);
    if (decision === "approved" && (aq === "" || Number(aq) < 0 || Number(aq) > Number(u?.reported_qty))) return note("Approved quantity must be between 0 and the reported quantity.");
    const { error } = await client().rpc("review_foreman_task_update", { p_update: uid, p_decision: decision, p_approved_qty: decision === "approved" ? Number(aq) : null, p_note: rn, p_complete: decision === "approved" && !!cp });
    if (error) return note(errText(error), true);
    note(decision === "approved" ? "Progress approved" : "Sent back to foreman for correction");
    await load(true); page(); openTask(u.task_id);
  }
  async function setStatus(id, s) {
    let reason = "";
    if (s === "cancelled") { reason = prompt("Why is this task cancelled? (History is kept)") || ""; if (!reason.trim()) return; }
    else if (s === "in_progress") { reason = prompt("Why are you reopening this task?") || ""; if (!reason.trim()) return; }
    else if (!confirm("Mark this task as completed? Do this only when the acceptance criteria are met.")) return;
    const { error } = await client().rpc("set_foreman_task_status", { p_task: id, p_status: s, p_reason: reason });
    if (error) return note(errText(error), true);
    note("Task status updated"); await load(true); page(); openTask(id);
  }
  function csv() {
    const rows = [["Task ID", "Title", "Project", "Building", "Floor", "Foreman", "Work Type", "Target", "Unit", "Approved", "Remaining", "Achievement %", "Start", "Due", "Status", "Overdue", "Priority"]];
    filtered().forEach((t) => { const s = statsOf(t); rows.push([taskNo(t), t.title, proj(t.project_id)?.name || "", t.building || "", t.floor || "", fName(t.assigned_to), t.category || "", t.target_qty, t.unit, s.approved, s.remaining, s.overallPct == null ? "No Data" : s.overallPct.toFixed(1), t.start_date, t.due_date, STATUS[t.status]?.[0] || t.status, s.overdue ? "Yes" : "No", t.priority]); });
    const blob = new Blob([rows.map((r) => r.map((x) => `"${String(x ?? "").replace(/"/g, '""')}"`).join(",")).join("\n")], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `foreman-tasks-${today()}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function foremenList() {
    const ids = [...new Set([...st.foremen.map((x) => x.user_id), ...st.tasks.map((t) => t.assigned_to)])];
    modal("Foreman task lists", `<div class="ft-flist">${ids.map((id) => { const mine = st.tasks.filter((t) => t.assigned_to === id && t.status !== "cancelled"); const od = mine.filter((t) => statsOf(t).overdue).length; return `<button class="ft-fcard" onclick="document.querySelector('.ft-ov')?.remove();PB_TASKS_FV('${id}')"><span class="ft-av big">${initials(fName(id))}</span><div><b>${E(fName(id))}</b><small>${mine.length} tasks · ${mine.filter((t) => t.status === "completed").length} completed · ${od} overdue</small></div></button>`; }).join("") || '<div class="empty">No foremen yet. Invite staff from Access → Cloud Team and assign them to a site.</div>'}</div>`);
  }

  Object.assign(window, {
    PB_TASKS_PAGE: page,
    PB_TASKS_RELOAD: async () => { st.error = ""; st.loaded = false; await load(true); page(); },
    PB_TASKS_SET: (k, v, keepFocus) => { st.f[k] = v; if (k === "project") st.f.building = ""; st.pg = 1; if (keepFocus) { clearTimeout(st.qt); st.qt = setTimeout(() => { page(); const i = document.querySelector(".ft-filters input"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 250); } else page(); },
    PB_TASKS_CLEAR: () => { st.f = { q: "", project: "", building: "", foreman: "", status: "", priority: "", from: "", to: "" }; st.pg = 1; page(); },
    PB_TASKS_SORT: (k) => { st.sort = { key: k, dir: st.sort.key === k ? -st.sort.dir : 1 }; page(); },
    PB_TASKS_PG: (n) => { st.pg = n; page(); },
    PB_TASKS_FV: (id) => { st.foremanView = id; st.foremanTab = "all"; st.pg = 1; page(); },
    PB_TASKS_FTAB: (v) => { st.foremanTab = v; st.pg = 1; page(); },
    PB_TASKS_FOREMEN: foremenList, PB_TASKS_CSV: csv,
    PB_TASK_NEW: newTask, PB_TASK_EDIT: editTask, PB_TASK_OPEN: openTask, PB_TASK_REVIEW: review, PB_TASK_STATUS: setStatus,
  });

  const css = document.createElement("style");
  css.textContent = `
  .ft-kpis{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:10px;margin-bottom:12px}
  .ft-kpi{display:flex;gap:10px;align-items:center;text-align:left;border:1px solid #e3e8f0;border-radius:14px;padding:12px;background:#fff;cursor:pointer;min-width:0;font:inherit}
  .ft-kpi:hover{box-shadow:0 4px 14px rgba(15,28,46,.08)}
  .ft-kpi .ft-ico{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;font-weight:900;flex:0 0 36px;color:#fff;background:#2563eb}
  .ft-kpi.green .ft-ico{background:#16a34a}.ft-kpi.amber .ft-ico{background:#f59e0b}.ft-kpi.red .ft-ico{background:#dc2626}.ft-kpi.purple .ft-ico{background:#7c3aed}
  .ft-kpi.green{background:#f3fbf6}.ft-kpi.amber{background:#fffaf0}.ft-kpi.red{background:#fff5f5}.ft-kpi.purple{background:#f8f5ff}.ft-kpi.blue{background:#f5f9ff}
  .ft-kpi small{display:block;font-size:11px;color:#55657a;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ft-kpi b{display:block;font-size:20px;color:#0f1c2e}.ft-kpi em{display:block;font-style:normal;font-size:11px;color:#6b7a8f}
  .ft-i{font-style:normal;display:inline-grid;place-items:center;width:13px;height:13px;border-radius:50%;background:#cbd5e1;color:#0f1c2e;font-size:9px}
  .ft-grid{display:grid;grid-template-columns:minmax(0,1fr) 240px;gap:12px;align-items:start}
  .ft-filters{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}.ft-filters .input{width:auto;min-width:0;flex:1 1 120px;height:34px;padding:4px 8px;font-size:12.5px}.ft-filters input[type=date]{flex:0 1 135px}.ft-filters input:not([type]){flex:2 1 180px}
  .ft-table td,.ft-table th{white-space:nowrap;font-size:12px;vertical-align:top;padding:8px 7px}.ft-table td:nth-child(2),.ft-table td:nth-child(3){white-space:normal;min-width:120px}.ft-table .pill{font-size:10.5px}.ft-table td:last-child{white-space:normal;min-width:120px}.ft-table td:last-child .pill{margin:0 2px 3px 0}
  .ft-sort{cursor:pointer;user-select:none}.ft-sub{display:block;color:#6b7a8f;font-size:11px;white-space:normal}
  .ft-av{display:inline-grid;place-items:center;width:24px;height:24px;border-radius:50%;background:#1e3a60;color:#fff;font-size:10px;font-weight:800;margin-right:6px}.ft-av.big{width:40px;height:40px;font-size:14px;margin:0}
  .ft-prog{min-width:90px}.ft-bar{height:7px;border-radius:9px;background:#e5eaf1;overflow:hidden;width:52px;display:inline-block;vertical-align:middle;margin-right:6px}.ft-bar i{display:block;height:100%}
  .ft-pager{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 2px;font-size:12px;color:#55657a;flex-wrap:wrap}
  .ft-side .panel{margin-bottom:12px}.ft-wide{width:100%;margin-bottom:6px;justify-content:flex-start}
  .ft-help{font-size:12px;margin-top:6px}.ft-help ul{padding-left:16px;margin:6px 0}.ft-help li{margin:3px 0}
  .ft-act{padding:7px 0;border-bottom:1px solid #eef2f7;cursor:pointer}.ft-act b{display:block;font-size:12.5px}.ft-act small{color:#6b7a8f;font-size:11px}
  .ft-fvhead{display:flex;gap:10px;align-items:center;margin-bottom:8px}.ft-fvhead div{flex:1}.ft-fvhead small{display:block;color:#6b7a8f}
  .ft-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px}.ft-tabs button{border:1px solid #dbe3ee;background:#fff;border-radius:999px;padding:5px 11px;font-size:12px;font-weight:700;cursor:pointer}.ft-tabs button.on{background:#2563eb;color:#fff;border-color:#2563eb}
  .ft-ov{position:fixed;inset:0;background:rgba(15,28,46,.45);z-index:9000;display:flex;align-items:flex-start;justify-content:center;padding:28px 12px;overflow:auto}
  .ft-modal{background:#fff;border-radius:16px;width:min(640px,100%);box-shadow:0 20px 60px rgba(0,0,0,.25)}.ft-modal.wide{width:min(1040px,100%)}
  .ft-mh{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid #eef2f7}.ft-mh h3{margin:0;font-size:16px}.ft-mb{padding:14px 18px}
  .ft-boqbal{grid-column:1/-1;display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:8px}.ft-boqbal[hidden]{display:none}.ft-bb{background:#fff;border:1px solid #e5eaf1;border-radius:10px;padding:6px 9px;min-width:0}.ft-bb small{display:block;font-size:10.5px;color:#64748b;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ft-bb b{font-size:15px;color:#0f172a;font-variant-numeric:tabular-nums}.ft-bb b i{font-style:normal;font-size:11px;color:#64748b;font-weight:600}.ft-bb.blue{border-color:#bfdbfe;background:#eff6ff}.ft-bb.amber{border-color:#fde68a;background:#fffbeb}.ft-bb.good{border-color:#bbf7d0;background:#f0fdf4}.ft-bb.good b{color:#15803d}.ft-bb.bad{border-color:#fecaca;background:#fef2f2}.ft-bb.bad b{color:#b91c1c}.ft-bbwarn{grid-column:1/-1;margin:0;color:#b91c1c;font-size:12px;font-weight:700}@media(max-width:900px){.ft-boqbal{grid-template-columns:repeat(3,minmax(0,1fr))}}
  .ft-form{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.ft-form label{display:grid;gap:4px;font-size:12px;font-weight:700;color:#334155}.ft-form .span2{grid-column:span 2}
  .ft-form .ft-reason,.ft-form .ft-msg,.ft-form .ft-actions{grid-column:1/-1}.ft-msg{color:#b91c1c;margin:0;font-size:13px;min-height:1em}.ft-actions{display:flex;justify-content:flex-end;gap:8px}
  .ft-dtop{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:10px}
  .ft-dgrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:12px}.ft-stat{border:1px solid #e3e8f0;border-radius:12px;padding:9px}.ft-stat.good{background:#f3fbf6}.ft-stat small{display:block;font-size:11px;color:#55657a}.ft-stat b{font-size:16px}.ft-stat em{display:block;font-style:normal;font-size:11px;color:#b45309}
  .ft-cols{display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:13px}.ft-kv{display:flex;justify-content:space-between;gap:8px;border-bottom:1px dashed #e5eaf1;padding:5px 0}.ft-kv span{color:#55657a}
  .ft-files{display:flex;flex-wrap:wrap;gap:6px}.ft-thumb{width:54px;height:54px;object-fit:cover;border-radius:8px;border:1px solid #e3e8f0}
  .ft-rev{display:grid;gap:4px;min-width:170px}.ft-rev .input{height:30px;padding:3px 6px}.ft-rev label{font-size:11px}
  .ft-hist>div{border-left:3px solid #2563eb;padding:4px 10px;margin:6px 0;font-size:12.5px}
  .ft-flist{display:grid;gap:8px}.ft-fcard{display:flex;gap:10px;align-items:center;border:1px solid #e3e8f0;border-radius:12px;padding:10px;background:#fff;cursor:pointer;text-align:left;font:inherit}.ft-fcard small{display:block;color:#6b7a8f}
  .ft-mb h4{margin:14px 0 6px}
  /* polish p61 */
  .ft-kpis{gap:8px}.ft-kpi{padding:10px;gap:8px;border-radius:12px}.ft-kpi .ft-ico{width:32px;height:32px;flex-basis:32px}
  .ft-kpi small{white-space:normal;line-height:1.2;font-size:10.5px;overflow:visible}.ft-kpi b{font-size:19px;line-height:1.15}
  .ft-filters{flex-wrap:nowrap;align-items:center}.ft-filters .input{flex:1 1 0;height:34px;border-radius:9px}.ft-filters input:not([type]){flex:1.8 1 0}.ft-filters input[type=date]{flex:0 0 128px}.ft-filters .btn{height:34px;flex:0 0 auto}
  @media(max-width:1250px){.ft-filters{flex-wrap:wrap}.ft-filters .input{flex:1 1 140px}}
  @media(max-width:1300px){.ft-kpis{grid-template-columns:repeat(4,minmax(0,1fr))}}
  .ft-modal.wide{width:min(1000px,100%)}.ft-ov{align-items:center;padding:16px 12px}.ft-ov .ft-modal{max-height:calc(100vh - 32px);display:flex;flex-direction:column}.ft-ov .ft-mb{overflow:auto}
  .ft-form{gap:8px 12px;align-items:start}.ft-form label{font-size:11.5px;gap:3px}
  .ft-form .input,.ft-form select,.ft-form input{width:100%;box-sizing:border-box;height:36px;padding:6px 10px;font-size:13px;border:1px solid #d6dee9;border-radius:9px;background:#fff;margin:0}
  .ft-form textarea.input{height:54px;min-height:54px;resize:vertical}
  .ft-form input[type=file]{padding:5px 8px}
  .ft-form .input:focus{outline:none;border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
  .ft-actions{border-top:1px solid #eef2f7;padding-top:10px;margin-top:2px}
  @media(max-width:760px){.ft-form{grid-template-columns:1fr 1fr}.ft-filters{flex-wrap:wrap}}
  body.dark-theme .ft-kpi,body.dark-theme .ft-modal,body.dark-theme .ft-fcard,body.dark-theme .ft-form .input,body.dark-theme .ft-tabs button{background:#142235;border-color:#2a4163;color:#e3edf8}
  body.dark-theme .ft-kpi b,body.dark-theme .ft-modal,body.dark-theme .ft-mh h3{color:#f1f6fc}body.dark-theme .ft-kpi small,body.dark-theme .ft-kpi em,body.dark-theme .ft-sub,body.dark-theme .ft-stat small,body.dark-theme .ft-kv span,body.dark-theme .ft-form label{color:#a9bbd0}
  body.dark-theme .ft-kpi.green{background:#10291d}body.dark-theme .ft-kpi.amber{background:#2d2312}body.dark-theme .ft-kpi.red{background:#2e1517}body.dark-theme .ft-kpi.purple{background:#221a3a}body.dark-theme .ft-kpi.blue{background:#13253d}
  body.dark-theme .ft-ov .input,body.dark-theme .ft-ov select,body.dark-theme .ft-ov textarea,body.dark-theme .ft-ov .btn:not(.primary):not(.danger){background:#0f1b2b!important;color:#e3edf8!important;border-color:#2a4163!important}body.dark-theme .ft-ov input::placeholder,body.dark-theme .ft-ov textarea::placeholder{color:#7f93ab}body.dark-theme .ft-ov input[type=date]{color-scheme:dark}
  body.dark-theme .ft-stat,body.dark-theme .ft-mh,body.dark-theme .ft-kv{border-color:#2a4163}body.dark-theme .ft-stat.good{background:#10291d}body.dark-theme .ft-bar{background:#2a4163}body.dark-theme .ft-tabs button.on{background:#2563eb;color:#fff}
  @media (max-width:1280px){.ft-kpis{grid-template-columns:repeat(4,minmax(0,1fr))}.ft-grid{grid-template-columns:1fr}}
  @media (min-width:1000px){.ft-page{max-width:100%;overflow:hidden}.ft-page .tablewrap{max-height:calc(100vh - 330px);overflow:auto}.ft-page .ft-table{font-size:12px}.ft-page .ft-table th,.ft-page .ft-table td{padding:6px 7px;white-space:nowrap}.ft-page .ft-table td:nth-child(2){white-space:normal;min-width:160px}.ft-page .ft-table thead th{position:sticky;top:0;z-index:1}.ft-grid{grid-template-columns:minmax(0,1fr) 210px}.ft-kpi{padding:8px}.ft-kpi b{font-size:17px}}
  @media (min-width:1000px){.ft-side{max-height:calc(100vh - 230px);overflow:auto;position:sticky;top:0}.ft-side .panel{padding:10px}.ft-side .ft-wide{padding:7px 10px;margin-bottom:4px}.ft-act{padding:5px 0;font-size:12px}}
  @media (max-width:720px){.ft-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.ft-form,.ft-dgrid{grid-template-columns:1fr 1fr}.ft-cols{grid-template-columns:1fr}}
  `;
  document.head.append(css);
  if ((location.hash || '').replace('#', '') === 'tasks') { try { page(); } catch (e) {} }
})();
