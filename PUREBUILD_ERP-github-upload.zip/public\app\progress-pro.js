/* Site Progress Pro: extra read-only panels for the Site Progress tabs
   (dashboard alerts/forecast/links/search, Building→Floor→Room map, today's list, photo gallery, reports & print).
   Reads db.boq / db.progress / db.progressDrafts only; never writes saved data. */
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const iso = (d) => d.toISOString().slice(0, 10);
  const todayS = () => iso(new Date());
  const ui = { bld: "", floor: "", room: "", q: "", rp: "month", rg: "building", from: "", to: "", ph: "" };

  const css = document.createElement("style");
  css.textContent = `
.pp-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.pp-host>.panel{margin:0}
.pp-grid2{display:grid;grid-template-columns:1.3fr 1fr;gap:12px}
.pp-grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.pp-h{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;flex-wrap:wrap}
.pp-h h3{margin:0;font-size:15px}.pp-h small{color:#6b7c93}
.pp-links{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.pp-links button{border:1px solid #dbe6f2;background:linear-gradient(180deg,#fff,#f4f8fd);border-radius:10px;padding:10px;text-align:left;cursor:pointer;font-weight:800;color:#12233d;font-size:12.5px}
.pp-links button small{display:block;font-weight:600;color:#6b7c93;font-size:10.5px;margin-top:2px}
.pp-links button:hover{border-color:#2182df;box-shadow:0 3px 10px rgba(33,130,223,.15)}
.pp-alert{display:flex;gap:8px;align-items:flex-start;padding:7px 9px;border-radius:9px;font-size:12px;margin-bottom:6px;border:1px solid}
.pp-alert.red{background:#fdecec;border-color:#f3c0c0;color:#8a1f1f}.pp-alert.amber{background:#fff6e5;border-color:#f1d09a;color:#7a4b00}.pp-alert.green{background:#eaf7f0;border-color:#b9e2cb;color:#16603e}
.pp-big{font-size:26px;font-weight:900;color:#0f3d6e;line-height:1.1}
.pp-kv{display:flex;justify-content:space-between;font-size:12px;padding:5px 0;border-bottom:1px dashed #e3e9f1}
.pp-search{display:flex;gap:8px;align-items:center}.pp-search input{flex:1;padding:9px 12px;border-radius:10px;border:1px solid #cfdcec;font-size:13px}
.pp-res{max-height:220px;overflow:auto;margin-top:6px}
.pp-bcards{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
.pp-card{border:1px solid #dbe6f2;border-radius:12px;padding:10px 12px;cursor:pointer;background:#fff;transition:.15s}
.pp-card:hover{border-color:#2182df;transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,61,110,.1)}
.pp-card.on{border-color:#0f3d6e;box-shadow:0 0 0 2px #0f3d6e inset}
.pp-card b{display:block;font-size:13.5px;color:#12233d}.pp-card small{color:#6b7c93;font-size:11px}
.pp-pct{font-size:20px;font-weight:900;color:#0f5fae}
.pp-crumb{display:flex;gap:6px;align-items:center;font-size:12.5px;margin-bottom:8px;flex-wrap:wrap}.pp-crumb a{color:#0f5fae;font-weight:800;cursor:pointer}
.pp-rooms{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:8px}
.pp-room{border-radius:10px;padding:9px;cursor:pointer;border:1px solid;font-size:12px}
.pp-room b{display:block;font-size:13px}.pp-room.done{background:#e6f6ee;border-color:#9fd8b8;color:#145c3a}.pp-room.mid{background:#fff4dc;border-color:#f0cf87;color:#6d4700}.pp-room.none{background:#f1f3f6;border-color:#d7dde5;color:#55657a}
.pp-room.on{outline:2px solid #0f3d6e}
.pp-legend{display:flex;gap:12px;font-size:11px;color:#5a6b82}.pp-legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:4px;vertical-align:-1px}
.pp-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.pp-gal figure{margin:0;border:1px solid #e3e9f1;border-radius:10px;overflow:hidden;cursor:pointer;background:#fff}
.pp-gal img{width:100%;height:110px;object-fit:cover;display:block}.pp-gal figcaption{font-size:10.5px;padding:5px 7px;color:#4a5b72}
.pp-filters{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pp-filters select,.pp-filters input{padding:7px 9px;border-radius:9px;border:1px solid #cfdcec;font-size:12px}
.pp-chart{display:flex;align-items:flex-end;gap:3px;height:120px;padding:6px 0;border-bottom:1px solid #e3e9f1}
.pp-chart div{flex:1;background:linear-gradient(180deg,#2182df,#0f5fae);border-radius:3px 3px 0 0;min-height:2px;position:relative}
.pp-chart div:hover:after{content:attr(data-t);position:absolute;bottom:100%;left:50%;transform:translateX(-50%);background:#12233d;color:#fff;font-size:10px;padding:3px 6px;border-radius:5px;white-space:nowrap}
@media(max-width:1000px){.pp-grid2,.pp-grid3{grid-template-columns:1fr}.pp-links{grid-template-columns:1fr 1fr}}
`;
  document.head.appendChild(css);

  // ---------- data ----------
  function boqList() {
    const pid = selectedProject; const pb = typeof progressBuilding !== "undefined" ? progressBuilding : "";
    return (db.boq || []).filter((b) => b.projectId === pid && (typeof matchBuilding !== "function" || matchBuilding(b, pb)));
  }
  const pct = (b) => (n(b.qty) ? Math.min(100, (n(b.executedQty) / n(b.qty)) * 100) : 0);
  const room = (b) => b.area || b.room || "—";
  function agg(list) {
    const v = list.reduce((a, b) => a + n(b.amount || n(b.qty) * n(b.rate)), 0), d = list.reduce((a, b) => a + n(b.executedQty) * n(b.rate), 0);
    const q = list.reduce((a, b) => a + n(b.qty), 0), dq = list.reduce((a, b) => a + Math.min(n(b.qty), n(b.executedQty)), 0);
    const p = v ? Math.min(100, (d / v) * 100) : q ? (dq / q) * 100 : 0;
    return { value: v, done: d, pct: p, count: list.length };
  }
  function reports() { return (db.progress || []).filter((x) => x.projectId === selectedProject); }
  function lastDate(b) { let m = ""; reports().forEach((x) => { if ((x.boqId === b.id || x.boqId === b.boqId) && n(x.todayQty) > 0 && String(x.date) > m) m = String(x.date); }); return m; }
  const daysAgo = (d) => (d ? Math.round((new Date(todayS()) - new Date(d)) / 864e5) : null);

  // ---------- dashboard ----------
  function dashHtml() {
    const list = boqList(), a = agg(list), p = (db.projects || []).find((x) => x.id === selectedProject) || {};
    const alerts = [];
    let expected = null;
    if (p.start && p.end) {
      const s = new Date(p.start), e = new Date(p.end), t = new Date(todayS());
      if (e > s) expected = Math.max(0, Math.min(100, ((t - s) / (e - s)) * 100));
      if (expected != null && a.pct + 10 < expected) alerts.push(["red", `Project is behind plan: ${a.pct.toFixed(1)}% done, plan says ${expected.toFixed(0)}% by today.`]);
      if (t > e && a.pct < 100) alerts.push(["red", `End date ${p.end} has passed and work is not finished.`]);
    }
    const stale = list.filter((b) => { const pr = pct(b); if (pr <= 0 || pr >= 100) return false; const d = daysAgo(lastDate(b)); return d == null || d > 7; });
    if (stale.length) alerts.push(["amber", `${stale.length} work item(s) started but no update for more than 7 days.`]);
    const notStarted = list.filter((b) => pct(b) <= 0).length;
    if (notStarted) alerts.push(["amber", `${notStarted} work item(s) not started yet.`]);
    const pending = reports().filter((x) => ["Submitted", "Pending", "Pending Approval"].includes(x.approvalStatus)).length;
    if (pending) alerts.push(["amber", `${pending} progress report(s) waiting for approval.`]);
    if (!alerts.length) alerts.push(["green", "All good — no delays found."]);

    // forecast from last 30 days
    const since = iso(new Date(Date.now() - 30 * 864e5));
    const last30 = reports().filter((x) => String(x.date) >= since).reduce((s, x) => s + n(x.todayQty) * n(x.rate), 0);
    const remainV = Math.max(0, a.value - a.done), perDay = last30 / 30;
    let fc = "—", fcNote = "Not enough recent work to estimate.";
    if (a.pct >= 100) { fc = "Completed"; fcNote = "All work done."; }
    else if (perDay > 0) { const dd = Math.ceil(remainV / perDay), f = new Date(Date.now() + dd * 864e5); fc = iso(f); fcNote = `About ${dd} day(s) at the last 30 days' speed (${money(perDay)}/day).`; if (p.end && fc > p.end) fcNote += ` This is after the planned end date ${p.end}.`; }

    const links = [["boq", "📋 BOQ", "All work items & quantities"], ["tasks", "🎯 Tasks", "Foreman tasks & targets"], ["stock", "📦 Warehouse / Stock", "Materials in & out"], ["labour", "👷 Labour & HR", "Workers & attendance"], ["billing", "🧾 Sales & Billing", "Bill the work done"], ["transactions", "💳 Expenses", "Site costs & payments"]];
    return `<div class="pp-grid3" data-pt="overview">
<div class="panel"><div class="pp-h"><h3>⚠ Alerts</h3><small>${esc(p.name || "")}</small></div>${alerts.map(([c, t]) => `<div class="pp-alert ${c}">${c === "green" ? "✓" : c === "red" ? "●" : "▲"} <span>${esc(t)}</span></div>`).join("")}
${stale.length ? `<div style="font-size:11px;font-weight:800;color:#36507a;margin:8px 0 4px">NO UPDATE FOR 7+ DAYS</div>${stale.slice(0, 5).map((b) => { const d = daysAgo(lastDate(b)); return `<div class="pp-kv"><span>${esc(b.boqId || "")} · ${esc(String(b.description || "").slice(0, 28))}</span><b>${d == null ? "never" : d + " days"}</b></div>`; }).join("")}` : ""}</div>
<div class="panel"><div class="pp-h"><h3>📅 Finish Forecast</h3></div><div class="pp-big">${esc(fc)}</div><div style="font-size:11.5px;color:#6b7c93;margin:3px 0 8px">${esc(fcNote)}</div>
<div class="pp-kv"><span>Work done</span><b>${a.pct.toFixed(1)}%</b></div>${expected != null ? `<div class="pp-kv"><span>Plan for today</span><b>${expected.toFixed(1)}%</b></div>` : ""}<div class="pp-kv"><span>Remaining value</span><b>${money(remainV)}</b></div><div class="pp-kv"><span>Done in last 30 days</span><b>${money(last30)}</b></div><div class="pp-kv"><span>Planned end</span><b>${esc(p.end || "—")}</b></div></div>
<div class="panel"><div class="pp-h"><h3>🔗 Quick Links</h3></div><div class="pp-links">${links.map(([k, l, s]) => `<button type="button" onclick="setPage('${k}')">${l}<small>${s}</small></button>`).join("")}</div></div>
</div>
<div class="panel" data-pt="overview"><div class="pp-search"><b style="font-size:13px">🔍</b><input id="ppQ" placeholder="Search work: BOQ ID, room, building, trade or work name…" value="${esc(ui.q)}"></div><div id="ppRes" class="pp-res">${searchHtml()}</div></div>`;
  }
  function searchHtml() {
    const q = ui.q.trim().toLowerCase(); if (!q) return "";
    const hits = boqList().filter((b) => [b.boqId, b.description, b.category, b.building, b.floor, b.area, b.room].join(" ").toLowerCase().includes(q)).slice(0, 30);
    if (!hits.length) return '<div class="empty">Nothing found.</div>';
    return `<table class="table"><thead><tr><th>BOQ</th><th>Work</th><th>Location</th><th>Done</th><th>%</th><th></th></tr></thead><tbody>${hits.map((b) => `<tr><td><b>${esc(b.boqId || "")}</b></td><td>${esc(b.description || "")}</td><td>${esc([b.building, b.floor, room(b)].filter((x) => x && x !== "—").join(" / ") || "—")}</td><td>${fmt(b.executedQty || 0)} / ${fmt(b.qty || 0)} ${esc(b.unit || "")}</td><td><b>${pct(b).toFixed(0)}%</b></td><td><button class="btn small" onclick="PB_PROGRESS_PRO.goRoom('${esc(b.building || "")}','${esc(b.floor || "")}','${esc(room(b))}')">Show</button></td></tr>`).join("")}</tbody></table>`;
  }

  // ---------- building map ----------
  function mapHtml() {
    const list = boqList(); const by = (arr, f) => arr.reduce((m, b) => { const k = f(b) || "—"; (m[k] = m[k] || []).push(b); return m; }, {});
    const nc = (x, y) => String(x).localeCompare(String(y), undefined, { numeric: true });
    const blds = by(list, (b) => b.building || "General");
    if (ui.bld && !blds[ui.bld]) { ui.bld = ""; ui.floor = ""; ui.room = ""; }
    const crumb = `<div class="pp-crumb"><a onclick="PB_PROGRESS_PRO.nav('','','')">All buildings</a>${ui.bld ? ` › <a onclick="PB_PROGRESS_PRO.nav('${esc(ui.bld)}','','')">${esc(ui.bld)}</a>` : ""}${ui.floor ? ` › <a onclick="PB_PROGRESS_PRO.nav('${esc(ui.bld)}','${esc(ui.floor)}','')">${esc(ui.floor)}</a>` : ""}${ui.room ? ` › <b>${esc(ui.room)}</b>` : ""}</div>`;
    const card = (k, items, on, click) => { const a = agg(items); return `<div class="pp-card ${on ? "on" : ""}" onclick="${click}"><b>${esc(k)}</b><div class="pp-pct">${a.pct.toFixed(1)}%</div><div class="progress"><i style="width:${a.pct}%"></i></div><small>${a.count} work(s) · ${money(a.done)} of ${money(a.value)}</small></div>`; };
    let body = `<div class="pp-bcards">${Object.keys(blds).sort(nc).map((k) => card(k, blds[k], k === ui.bld, `PB_PROGRESS_PRO.nav('${esc(k)}','','')`)).join("") || '<div class="empty">No BOQ items for this site.</div>'}</div>`;
    if (ui.bld) {
      const floors = by(blds[ui.bld], (b) => b.floor || "—");
      if (ui.floor && !floors[ui.floor]) { ui.floor = ""; ui.room = ""; }
      body += `<div style="font-size:11px;font-weight:800;color:#36507a;margin:12px 0 6px">FLOORS IN ${esc(ui.bld).toUpperCase()}</div><div class="pp-bcards">${Object.keys(floors).sort(nc).map((k) => card(k, floors[k], k === ui.floor, `PB_PROGRESS_PRO.nav('${esc(ui.bld)}','${esc(k)}','')`)).join("")}</div>`;
      if (ui.floor) {
        const rooms = by(floors[ui.floor], room);
        body += `<div class="pp-h" style="margin-top:12px"><div style="font-size:11px;font-weight:800;color:#36507a">ROOMS ON ${esc(ui.floor).toUpperCase()}</div><div class="pp-legend"><span><i style="background:#9fd8b8"></i>Done</span><span><i style="background:#f0cf87"></i>Working</span><span><i style="background:#d7dde5"></i>Not started</span></div></div><div class="pp-rooms">${Object.keys(rooms).sort(nc).map((k) => { const a = agg(rooms[k]), c = a.pct >= 99.95 ? "done" : a.pct > 0 ? "mid" : "none"; return `<div class="pp-room ${c} ${k === ui.room ? "on" : ""}" onclick="PB_PROGRESS_PRO.nav('${esc(ui.bld)}','${esc(ui.floor)}','${esc(k)}')"><b>${esc(k)}</b>${a.pct.toFixed(0)}% · ${a.count} work(s)</div>`; }).join("")}</div>`;
        if (ui.room && rooms[ui.room]) {
          body += `<div class="pp-h" style="margin-top:12px"><h3>Room ${esc(ui.room)} — works</h3><div style="display:flex;gap:6px"><button class="btn small" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ Daily Update</button><button class="btn small" onclick="PB_ROOM_REGISTER&&PB_ROOM_REGISTER.open()">▦ Room Work Register</button><button class="btn small" onclick="setPage('boq')">Open BOQ →</button></div></div>
<table class="table"><thead><tr><th>BOQ</th><th>Trade</th><th>Work</th><th>Qty</th><th>Done</th><th>Remaining</th><th>Progress</th><th>Last update</th></tr></thead><tbody>${rooms[ui.room].map((b) => { const p = pct(b), ld = lastDate(b); return `<tr><td><b>${esc(b.boqId || "")}</b></td><td>${esc(b.category || "—")}</td><td>${esc(b.description || "")}</td><td>${fmt(b.qty || 0)} ${esc(b.unit || "")}</td><td>${fmt(b.executedQty || 0)}</td><td>${fmt(Math.max(0, n(b.qty) - n(b.executedQty)))}</td><td style="min-width:110px"><div class="progress"><i style="width:${p}%"></i></div><b>${p.toFixed(1)}%</b></td><td>${esc(ld || "—")}</td></tr>`; }).join("")}</tbody></table>`;
        }
      }
    }
    return `<div class="panel" data-pt="buildings"><div class="pp-h"><h3>🏢 Building → Floor → Room</h3><small>Click a building, then a floor, then a room</small></div>${crumb}${body}</div>`;
  }

  // ---------- today ----------
  function todayHtml() {
    const t = todayS(), list = reports().filter((x) => x.date === t), drafts = (db.progressDrafts || []).filter((d) => d.projectId === selectedProject && d.status === "Draft");
    const pending = reports().filter((x) => ["Submitted", "Pending", "Pending Approval"].includes(x.approvalStatus));
    const val = list.reduce((s, x) => s + n(x.todayQty) * n(x.rate), 0);
    return `<div class="panel" data-pt="today"><div class="pp-h"><h3>☀ Today — ${esc(t)}</h3><div style="display:flex;gap:6px"><button class="btn du-btn" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ Daily Progress Update</button><button class="btn small" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.history()">Previous / Drafts (${drafts.length})</button></div></div>
<div class="pp-grid3" style="margin-bottom:8px"><div class="pp-kv"><span>Updates today</span><b>${list.length}</b></div><div class="pp-kv"><span>Value done today</span><b>${money(val)}</b></div><div class="pp-kv"><span>Waiting approval</span><b>${pending.length}</b></div></div>
<table class="table"><thead><tr><th>Work</th><th>Location</th><th>Qty today</th><th>Value</th><th>By</th><th>Source</th><th></th></tr></thead><tbody>${list.map((x) => `<tr><td>${esc(x.boqCode || "")} ${esc(String(x.title || "").slice(0, 34))}</td><td>${esc(x.location || [x.building, x.floor, x.room].filter(Boolean).join(" / ") || "—")}</td><td>${fmt(x.todayQty || 0)} ${esc(x.unit || "")}</td><td>${money(n(x.todayQty) * n(x.rate))}</td><td>${esc(x.foreman || x.submittedBy || "—")}</td><td><span class="pill">${String(x.id || "").startsWith("cloud-") ? "Staff" : "Office"}</span></td><td><button class="btn small" onclick="viewProgressDetail('${esc(x.id)}')">View</button></td></tr>`).join("") || '<tr><td colspan="7" class="empty">No work entered today yet.</td></tr>'}</tbody></table></div>`;
  }

  // ---------- photos ----------
  function photosHtml() {
    const q = ui.ph.trim().toLowerCase();
    const all = reports().flatMap((x) => (Array.isArray(x.photoData) ? x.photoData : []).map((src, i) => ({ src, id: x.id, i, date: x.date, t: x.title || "Site photo", loc: x.location || [x.building, x.floor, x.room].filter(Boolean).join(" / ") })))
      .filter((p) => !q || [p.date, p.t, p.loc].join(" ").toLowerCase().includes(q)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    // 30-day chart
    const days = []; for (let i = 29; i >= 0; i--) days.push(iso(new Date(Date.now() - i * 864e5)));
    const perDay = days.map((d) => reports().filter((x) => x.date === d).reduce((s, x) => s + n(x.todayQty) * n(x.rate), 0)), mx = Math.max(1, ...perDay);
    return `<div class="panel" data-pt="photos"><div class="pp-h"><h3>📈 Work value done — last 30 days</h3><small>Hover a bar to see the day</small></div><div class="pp-chart">${perDay.map((v, i) => `<div style="height:${(v / mx) * 100}%" data-t="${days[i]} · ${money(v)}"></div>`).join("")}</div><div style="display:flex;justify-content:space-between;font-size:10px;color:#6b7c93"><span>${days[0]}</span><span>${days[29]}</span></div></div>
<div class="panel" data-pt="photos"><div class="pp-h"><h3>📷 Photo Gallery (${all.length})</h3><div class="pp-filters"><input id="ppPh" placeholder="Search date, room, work…" value="${esc(ui.ph)}"></div></div><div class="pp-gal">${all.slice(0, 60).map((p) => `<figure onclick="PB_PROGRESS_PRO.photo('${esc(p.id)}',${p.i})"><img src="${p.src}" alt="site photo" loading="lazy"><figcaption><b>${esc(p.date)}</b> · ${esc(String(p.t).slice(0, 26))}<br>${esc(p.loc || "")}</figcaption></figure>`).join("") || '<div class="empty">No photos yet.</div>'}</div></div>`;
  }
  function photo(rid, i) {
    const x = reports().find((r) => r.id === rid); if (!x) return;
    openModal(`${x.date} · ${x.title || "Site photo"}`, `<img src="${x.photoData[i]}" style="width:100%;max-height:75vh;object-fit:contain;border-radius:10px"><div class="muted" style="margin-top:6px">${esc(x.location || "")} · ${esc(x.foreman || "")}</div>`, () => true);
    const s = document.getElementById("modalSave"); if (s) s.style.display = "none";
  }

  // ---------- reports ----------
  function period() {
    const t = new Date(todayS());
    if (ui.rp === "today") return [todayS(), todayS()];
    if (ui.rp === "week") { const d = new Date(t); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return [iso(d), todayS()]; }
    if (ui.rp === "month") return [todayS().slice(0, 8) + "01", todayS()];
    return [ui.from || todayS().slice(0, 8) + "01", ui.to || todayS()];
  }
  function reportData() {
    const [f, t] = period(), boq = boqList(), ids = new Set(boq.flatMap((b) => [b.id, b.boqId]));
    const rows = reports().filter((x) => String(x.date) >= f && String(x.date) <= t && n(x.todayQty) > 0 && (!x.boqId || ids.has(x.boqId)));
    const find = (x) => boq.find((b) => b.id === x.boqId || b.boqId === x.boqId) || {};
    const key = (x) => { const b = find(x); return ui.rg === "trade" ? b.category || "Other" : ui.rg === "date" ? x.date : x.building || b.building || "General"; };
    const g = {}; rows.forEach((x) => { const k = key(x); (g[k] = g[k] || { n: 0, v: 0, items: [] }); g[k].n++; g[k].v += n(x.todayQty) * n(x.rate); g[k].items.push(x); });
    return { f, t, rows, g, find };
  }
  function reportsHtml() {
    const d = reportData(), tot = d.rows.reduce((s, x) => s + n(x.todayQty) * n(x.rate), 0), a = agg(boqList());
    const keys = Object.keys(d.g).sort((x, y) => String(x).localeCompare(String(y), undefined, { numeric: true }));
    return `<div class="panel" data-pt="reports"><div class="pp-h"><h3>📑 Progress Reports</h3><div class="pp-filters">
<select id="ppRp"><option value="today">Today</option><option value="week">This week</option><option value="month">This month</option><option value="custom">Custom dates</option></select>
${ui.rp === "custom" ? `<input type="date" id="ppFrom" value="${esc(d.f)}"><input type="date" id="ppTo" value="${esc(d.t)}">` : ""}
<select id="ppRg"><option value="building">By building</option><option value="trade">By trade</option><option value="date">By date</option></select>
<button class="btn small" onclick="PB_PROGRESS_PRO.print()">🖨 Print</button><button class="btn small" onclick="PB_PROGRESS_PRO.csv()">⬇ Excel (CSV)</button></div></div>
<div class="pp-grid3" style="margin-bottom:10px"><div class="pp-kv"><span>Period</span><b>${esc(d.f)} → ${esc(d.t)}</b></div><div class="pp-kv"><span>Entries</span><b>${d.rows.length}</b></div><div class="pp-kv"><span>Work value done</span><b>${money(tot)}</b></div></div>
<div class="pp-grid2"><div><table class="table"><thead><tr><th>${ui.rg === "trade" ? "Trade" : ui.rg === "date" ? "Date" : "Building"}</th><th>Entries</th><th>Value done</th><th>Share</th></tr></thead><tbody>${keys.map((k) => `<tr><td><b>${esc(k)}</b></td><td>${d.g[k].n}</td><td>${money(d.g[k].v)}</td><td style="min-width:120px"><div class="progress"><i style="width:${tot ? (d.g[k].v / tot) * 100 : 0}%"></i></div></td></tr>`).join("") || '<tr><td colspan="4" class="empty">No work in this period.</td></tr>'}</tbody></table></div>
<div><div class="pp-kv"><span>Whole site done (all time)</span><b>${a.pct.toFixed(1)}%</b></div><div class="pp-kv"><span>Total BOQ value</span><b>${money(a.value)}</b></div><div class="pp-kv"><span>Done value</span><b>${money(a.done)}</b></div><div class="pp-kv"><span>Remaining value</span><b>${money(Math.max(0, a.value - a.done))}</b></div></div></div>
<div style="font-size:11px;font-weight:800;color:#36507a;margin:12px 0 6px">ALL ENTRIES IN THIS PERIOD</div>
<table class="table"><thead><tr><th>Date</th><th>BOQ</th><th>Work</th><th>Location</th><th>Qty</th><th>Value</th><th>By</th></tr></thead><tbody>${d.rows.slice().sort((x, y) => String(y.date).localeCompare(String(x.date))).map((x) => `<tr><td>${esc(x.date)}</td><td>${esc(x.boqCode || d.find(x).boqId || "")}</td><td>${esc(String(x.title || d.find(x).description || "").slice(0, 40))}</td><td>${esc(x.location || "—")}</td><td>${fmt(x.todayQty)} ${esc(x.unit || "")}</td><td>${money(n(x.todayQty) * n(x.rate))}</td><td>${esc(x.foreman || "—")}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">No entries.</td></tr>'}</tbody></table></div>`;
  }
  function csv() {
    const d = reportData(), q = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;
    const lines = [["Date", "BOQ", "Work", "Location", "Qty", "Unit", "Value (AED)", "By"].map(q).join(",")].concat(d.rows.map((x) => [x.date, x.boqCode || d.find(x).boqId, x.title || d.find(x).description, x.location, n(x.todayQty), x.unit, (n(x.todayQty) * n(x.rate)).toFixed(2), x.foreman].map(q).join(",")));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv" })); a.download = `site-progress-${d.f}_${d.t}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function print() {
    const d = reportData(), s = db.settings || {}, p = (db.projects || []).find((x) => x.id === selectedProject) || {}, a = agg(boqList()), tot = d.rows.reduce((t, x) => t + n(x.todayQty) * n(x.rate), 0);
    const keys = Object.keys(d.g).sort();
    const html = `<html><head><title>Site Progress Report</title><style>@page{size:A4;margin:14mm}body{font-family:Arial,sans-serif;color:#12233d;font-size:11px}h1{margin:0;font-size:18px}.hd{display:flex;gap:12px;align-items:center;border-bottom:2px solid #0f3d6e;padding-bottom:8px;margin-bottom:10px}.hd img{height:46px}table{width:100%;border-collapse:collapse;margin:8px 0}th{background:#0f3d6e;color:#fff;text-align:left;padding:5px;font-size:10px}td{padding:5px;border-bottom:1px solid #dde4ee}thead{display:table-header-group}.k{display:flex;gap:8px;margin:8px 0}.k div{flex:1;border:1px solid #dde4ee;border-radius:6px;padding:6px}.k b{display:block;font-size:14px}.sig{display:flex;justify-content:space-between;margin-top:40px}.sig div{border-top:1px solid #12233d;width:30%;text-align:center;padding-top:4px}</style></head><body>
<div class="hd">${s.companyLogo ? `<img src="${s.companyLogo}">` : ""}<div><h1>${esc(s.companyName || "PURE_BUILD")}</h1><div>Site Progress Report · ${esc(p.name || "")} · ${esc(d.f)} to ${esc(d.t)}</div></div></div>
<div class="k"><div>Site done<b>${a.pct.toFixed(1)}%</b></div><div>Total BOQ<b>${money(a.value)}</b></div><div>Done this period<b>${money(tot)}</b></div><div>Remaining<b>${money(Math.max(0, a.value - a.done))}</b></div></div>
<table><thead><tr><th>${ui.rg === "trade" ? "Trade" : ui.rg === "date" ? "Date" : "Building"}</th><th>Entries</th><th>Value done</th></tr></thead><tbody>${keys.map((k) => `<tr><td>${esc(k)}</td><td>${d.g[k].n}</td><td>${money(d.g[k].v)}</td></tr>`).join("")}<tr><td><b>Total</b></td><td><b>${d.rows.length}</b></td><td><b>${money(tot)}</b></td></tr></tbody></table>
<table><thead><tr><th>Date</th><th>BOQ</th><th>Work</th><th>Location</th><th>Qty</th><th>Value</th><th>By</th></tr></thead><tbody>${d.rows.map((x) => `<tr><td>${esc(x.date)}</td><td>${esc(x.boqCode || "")}</td><td>${esc(x.title || "")}</td><td>${esc(x.location || "")}</td><td>${fmt(x.todayQty)} ${esc(x.unit || "")}</td><td>${money(n(x.todayQty) * n(x.rate))}</td><td>${esc(x.foreman || "")}</td></tr>`).join("") || '<tr><td colspan="7">No entries.</td></tr>'}</tbody></table>
<div class="sig"><div>Prepared by</div><div>Site Engineer</div><div>Project Manager</div></div></body></html>`;
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  // ---------- mount ----------
  function inject(v) {
    v.querySelectorAll(".pp-host").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum || !selectedProject) return;
    const host = document.createElement("div"); host.className = "pp-host";
    try { host.innerHTML = dashHtml() + mapHtml() + todayHtml() + photosHtml() + reportsHtml(); } catch (e) { console.warn("progress-pro", e); return; }
    sum.insertAdjacentElement("afterend", host);
    const rp = host.querySelector("#ppRp"); if (rp) rp.value = ui.rp; const rg = host.querySelector("#ppRg"); if (rg) rg.value = ui.rg;
    const re = () => refresh();
    rp && rp.addEventListener("change", (e) => { ui.rp = e.target.value; re(); });
    rg && rg.addEventListener("change", (e) => { ui.rg = e.target.value; re(); });
    host.querySelector("#ppFrom")?.addEventListener("change", (e) => { ui.from = e.target.value; re(); });
    host.querySelector("#ppTo")?.addEventListener("change", (e) => { ui.to = e.target.value; re(); });
    host.querySelector("#ppQ")?.addEventListener("input", (e) => { ui.q = e.target.value; document.getElementById("ppRes").innerHTML = searchHtml(); });
    let tm; host.querySelector("#ppPh")?.addEventListener("input", (e) => { ui.ph = e.target.value; clearTimeout(tm); tm = setTimeout(() => { re(); const i = document.getElementById("ppPh"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); });
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }
  function nav(b, f, r) { ui.bld = b; ui.floor = f; ui.room = r; refresh(); }
  function goRoom(b, f, r) { ui.bld = b || "General"; ui.floor = f || "—"; ui.room = r; window.PB_PROGRESS_TABS_SET && window.PB_PROGRESS_TABS_SET("buildings"); refresh(); }
  window.PB_PROGRESS_PRO = { inject, nav, goRoom, photo, print, csv };
})();
