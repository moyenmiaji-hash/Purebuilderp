/* Dashboard scroll layout: page scrolls normally, side menu stays fixed, Project Financial Overview full width. Display only. */
(function(){
  var css=`
html:has(body.dashboard-mode){overflow-x:hidden!important;overflow-y:auto!important;height:auto!important}
html body.dashboard-mode{height:auto!important;min-height:100vh!important;overflow:visible!important}
html body.dashboard-mode .app,html body.dashboard-mode .main,html body.dashboard-mode .content,html body.dashboard-mode #view{height:auto!important;max-height:none!important;overflow:visible!important;zoom:1!important}
html body.dashboard-mode .sidebar{position:sticky!important;top:0!important;height:100vh!important;max-height:100vh!important;align-self:flex-start!important;overflow-y:auto!important}
html body.dashboard-mode .app{grid-template-rows:auto!important;min-height:100vh!important}
html body.dashboard-mode .main,html body.dashboard-mode #view{flex:1 1 auto!important;min-height:0!important}
html body.dashboard-mode #view>*{flex:0 0 auto!important}
html body.dashboard-mode #view .dashboard-row{flex:0 0 auto!important;height:auto!important;min-height:0!important;max-height:none!important;margin-bottom:14px!important;gap:14px!important}
html body.dashboard-mode #view .dashboard-row>.dashboard-panel{height:auto!important;max-height:none!important;min-height:280px!important}
html body.dashboard-mode #view .dashboard-row>.dashboard-panel:not(.project-financial-panel){border-radius:14px!important;box-shadow:0 4px 16px -8px color-mix(in oklab,currentColor 25%,transparent)!important}
html body.dashboard-mode #view .project-financial-panel{border-radius:14px!important}
html body.dashboard-mode #view .overview-row{display:grid!important;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr)!important}
html body.dashboard-mode #view .dashboard-row>.dashboard-panel{width:auto!important;max-width:none!important;margin:0!important}
html body.dashboard-mode #view .overview-row>.dashboard-panel:nth-child(2){grid-column:1!important;grid-row:2!important}
html body.dashboard-mode #view .overview-row>.dashboard-panel:nth-child(3){grid-column:2!important;grid-row:2!important}
html body.dashboard-mode #view .overview-row>.project-financial-panel{grid-column:1/-1!important;grid-row:1!important;min-height:0!important}
html body.dashboard-mode #view .project-financial-panel .pf-scroll{min-height:220px!important;height:auto!important}
html body.dashboard-mode #view .project-financial-panel .pf-scroll{max-height:400px!important;overflow:auto!important}
html body.dashboard-mode #view .project-financial-panel table{width:100%!important;table-layout:auto!important}
html body.dashboard-mode #view .project-financial-panel th,html body.dashboard-mode #view .project-financial-panel td{font-size:13px!important;padding:10px 12px!important;white-space:nowrap!important;overflow:visible!important;text-overflow:clip!important;max-width:none!important}
html body.dashboard-mode #view .analysis-row{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important}
@media (max-width:1250px){html body.dashboard-mode #view .analysis-row{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
html body.dashboard-mode #view .activity-row{display:grid!important;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr) minmax(0,1fr)!important}
@media (max-width:1100px){html body.dashboard-mode #view .overview-row,html body.dashboard-mode #view .analysis-row,html body.dashboard-mode #view .activity-row{grid-template-columns:minmax(0,1fr)!important}}
@media print{html body.dashboard-mode .sidebar{position:static!important;height:auto!important}}
`;
  var s=document.createElement('style');s.id='pbDashScroll';s.textContent=css;document.head.appendChild(s);
  function off(){document.body.classList.remove('dash-fit');var c=document.querySelector('body.dashboard-mode .content');if(c){c.style.removeProperty('--dz');c.style.removeProperty('min-height')}}
  window.dashFit=off;
  new MutationObserver(function(){if(document.body.classList.contains('dash-fit'))off()}).observe(document.body,{attributes:true,attributeFilter:['class']});
  off();
})();
