// Labour & HR Report Center — professional ERP look (p66).
// Display-only layer on top of hrBuildReport(): adds report descriptions, icons,
// attendance rate, status quick-filters, avatars and friendly dates. No data is changed.
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const DESC = {
    "Monthly Attendance": "Every attendance entry in the selected month — who worked, where, and for how many hours.",
    "Daily Attendance": "Who was present, absent or on leave on one chosen day.",
    "Employee-wise Attendance": "One line per employee: total days present, absent, on leave and hours worked.",
    "OT Report": "Overtime hours worked and what that overtime costs.",
    "Project-wise Labour": "How many people and hours each project/site used.",
    "Designation-wise Labour": "Labour grouped by job title (mason, helper, foreman…).",
    "Supplier Labour Report": "Workers supplied by labour suppliers and their hours.",
    "Monthly Payroll": "Salary sheet for the month — gross, deductions, net, paid and balance.",
    "Project Labour Cost": "Total labour cost charged to each project/site.",
    "Supplier Payable": "Amount owed to each labour supplier.",
    "Leave Summary": "All leave requests with type, days and approval status.",
    "Leave Balance": "Leave allowed, taken and still remaining for each employee.",
    "Expired Documents": "Visas, IDs and permits that have already expired — action needed.",
    "Expiring Within 30 Days": "Documents that will expire soon — renew them in time.",
  };
  const SV = (d) => `<svg viewBox="0 0 24 24" width="18" height="18" style="width:100%;height:100%;max-width:40px;max-height:40px" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const IC = {
    Attendance: SV('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>'),
    Labour: SV('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'),
    "Payroll & Cost": SV('<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>'),
    Leave: SV('<path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><path d="M6 2v2M10 2v2M14 2v2"/>'),
    Documents: SV('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 13h6M9 17h6"/>'),
  };
  const GICON = IC;
  const RICON = (t) => /Attend|OT/.test(t) ? IC.Attendance : /Payroll|Cost|Payable/.test(t) ? IC["Payroll & Cost"] : /Leave/.test(t) ? IC.Leave : /Document|Expir/.test(t) ? IC.Documents : IC.Labour;
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const WD = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const initials = (n) => String(n || "").trim().split(/\s+/).slice(0, 2).map((w) => w[0] || "").join("").toUpperCase() || "?";
  const hue = (n) => { let h = 0; for (const c of String(n)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const fmtN = (v) => (typeof fmt === "function" ? fmt(v) : Number(v || 0).toLocaleString());
  const fmtM = (v) => (typeof money === "function" ? money(v) : "AED " + Number(v || 0).toLocaleString());

  function sidebar() {
    document.querySelectorAll(".hrr-group>small").forEach((s) => {
      if (s.dataset.pro) return; s.dataset.pro = 1;
      const g = s.textContent.trim(); s.innerHTML = `<span class="hrp-gi">${GICON[g] || "•"}</span>${E(g)}`;
    });
    document.querySelectorAll(".hrr-item").forEach((b) => { if (!b.title) b.title = DESC[b.dataset.r] || ""; });
  }

  function enhance() {
    const out = document.getElementById("hrReportOutput"); if (!out) return;
    const R = window.hrLastReport; if (!R || out.dataset.proFor === String(R.__k)) return;
    sidebar();
    const type = R.type, d = R.d;
    // Header: icon + plain-language description
    const head = out.querySelector(".hrr-head>div");
    if (head && !out.querySelector(".hrp-ico")) {
      head.insertAdjacentHTML("beforebegin", `<div class="hrp-ico">${RICON(type)}</div>`);
      const h3 = head.querySelector("h3");
      if (h3 && DESC[type]) h3.insertAdjacentHTML("afterend", `<p class="hrp-desc">${E(DESC[type])}</p>`);
    }
    out.querySelectorAll(".hrr-stat small").forEach((el) => { el.title = el.textContent; el.textContent = el.textContent.replace(/^Total (Regular|OT) Hours$/, "$1 Hours"); });
    // Table cells: avatars, friendly dates, dim zeros
    const ths = [...out.querySelectorAll(".hrr-table thead th")].map((t) => t.textContent.trim());
    const ci = (n) => ths.indexOf(n);
    const iEmp = ci("Employee"), iDate = ci("Date"), iStat = ci("Status");
    const trs = [...out.querySelectorAll(".hrr-table tbody tr")].filter((tr) => !tr.querySelector(".hrr-empty"));
    trs.forEach((tr, k) => {
      const tds = tr.children; tr.dataset.i = k;
      if (iEmp > -1 && tds[iEmp]) { const n = tds[iEmp].textContent.trim(); if (n && n !== "—") tds[iEmp].innerHTML = `<span class="hrp-av" style="--h:${hue(n)}">${E(initials(n))}</span><b class="hrp-nm">${E(n)}</b>`; }
      if (iDate > -1 && tds[iDate]) { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(tds[iDate].textContent.trim()); if (m) { const dt = new Date(+m[1], +m[2] - 1, +m[3]); tds[iDate].innerHTML = `<span class="hrp-dt">${+m[3]} ${MON[+m[2] - 1]} ${m[1]}</span><small class="hrp-wd">${WD[dt.getDay()]}</small>`; } }
      if (iStat > -1 && tds[iStat]) tr.dataset.st = tds[iStat].textContent.trim();
      [...tds].forEach((td) => { if (td.classList.contains("hrr-num") && /^(AED\s*)?0(\.0+)?$/.test(td.textContent.trim())) td.classList.add("hrp-zero"); });
    });
    // Status quick-filter + attendance rate
    if (iStat > -1 && trs.length) {
      const cnt = {}; trs.forEach((tr) => { const s = tr.dataset.st || "—"; cnt[s] = (cnt[s] || 0) + 1; });
      const present = Object.entries(cnt).filter(([s]) => /present|on duty/i.test(s)).reduce((a, [, v]) => a + v, 0);
      if (/Attendance/.test(type) && type !== "Employee-wise Attendance") {
        const rate = Math.round((present / trs.length) * 100);
        const stats = out.querySelector(".hrr-stats");
        if (stats) stats.insertAdjacentHTML("beforeend", `<div class="hrr-stat ${rate >= 80 ? "green" : rate >= 50 ? "amber" : "red"} hrp-rate"><small>Attendance Rate</small><b>${rate}%</b><i style="--w:${rate}%"></i></div>`);
      }
      const tw = out.querySelector(".tablewrap");
      const chips = [["All", trs.length], ...Object.entries(cnt).sort((a, b) => b[1] - a[1])];
      tw.insertAdjacentHTML("beforebegin", `<div class="hrp-chips hrp-noprint"><span class="hrp-chl">Quick filter:</span>${chips.map(([s, n], j) => `<button type="button" class="hrp-chip ${j ? "s-" + (/present|approved|paid|duty|return/i.test(s) && !/partial/i.test(s) ? "g" : /absent|reject|expired/i.test(s) ? "r" : /leave|pending|soon|late|partial/i.test(s) ? "a" : "b") : "on"}" data-s="${j ? E(s) : ""}">${E(s)} <em>${n}</em></button>`).join("")}<span class="hrp-show" id="hrpShow">Showing ${trs.length} of ${trs.length}</span></div>`);
      out.querySelectorAll(".hrp-chip").forEach((b) => (b.onclick = () => filterBy(out, b, trs, R)));
    } else {
      const tw = out.querySelector(".tablewrap");
      if (tw && trs.length) tw.insertAdjacentHTML("beforebegin", `<div class="hrp-chips hrp-noprint"><span class="hrp-show">${trs.length} record${trs.length > 1 ? "s" : ""}</span></div>`);
    }
    out.dataset.proFor = String(R.__k);
  }

  function filterBy(out, btn, trs, R) {
    const s = btn.dataset.s;
    out.querySelectorAll(".hrp-chip").forEach((b) => b.classList.toggle("on", b === btn));
    let shown = 0; const vis = [];
    trs.forEach((tr) => { const ok = !s || tr.dataset.st === s; tr.style.display = ok ? "" : "none"; if (ok) { shown++; vis.push(R.d.rows[+tr.dataset.i]); } });
    const sh = out.querySelector("#hrpShow"); if (sh) sh.textContent = `Showing ${shown} of ${trs.length}`;
    // keep the TOTAL row correct for the visible rows
    const ft = out.querySelectorAll(".hrr-table tfoot td");
    if (ft.length) R.d.cols.forEach((c, k) => {
      if (!R.sumCols.includes(c)) return; const td = ft[k + 1]; if (!td) return;
      const t = vis.reduce((a, r) => a + Number((r && r[c]) || 0), 0);
      td.innerHTML = `<b>${R.d.money.includes(c) ? fmtM(t) : fmtN(t)}</b>`;
    });
  }

  let seq = 0;
  function wrap() {
    if (typeof window.hrBuildReport === "function" && !window.hrBuildReport.__pro) {
      const orig = window.hrBuildReport;
      window.hrBuildReport = function () { let r; try { r = orig.apply(this, arguments); } catch (e) { console.error("hr report", e); const o = document.getElementById("hrReportOutput"); if (o) o.innerHTML = `<div class="empty" style="padding:30px;text-align:center"><b>This report could not be built.</b><br><small>${String(e && e.message || e).replace(/[<>&]/g, "")}</small><br><button class="btn" onclick="hrBuildReport()">Try again</button></div>`; return; } if (window.hrLastReport) window.hrLastReport.__k = ++seq; try { enhance(); } catch (e) { console.warn("hr-report-pro", e); } return r; };
      window.hrBuildReport.__pro = true; window.hrBuildReport.__pb = true;
    }
    if (typeof window.hrPrintReport === "function" && !window.hrPrintReport.__pro) {
      const op = window.hrPrintReport;
      window.hrPrintReport = function () {
        const out = document.getElementById("hrReportOutput"); const hid = out ? [...out.querySelectorAll(".hrp-noprint")] : [];
        const marks = hid.map((el) => { const m = document.createComment("x"); el.replaceWith(m); return [m, el]; });
        try { return op.apply(this, arguments); } finally { marks.forEach(([m, el]) => m.replaceWith(el)); }
      };
      window.hrPrintReport.__pro = true;
    }
  }
  wrap(); document.addEventListener("DOMContentLoaded", wrap); window.addEventListener("load", wrap);
  const obs = () => { const v = document.getElementById("view"); if (v) new MutationObserver(() => { wrap(); const ho = document.getElementById("hrReportOutput"); if (ho) { sidebar(); setTimeout(() => { if (ho.isConnected && !ho.innerHTML.trim() && typeof window.hrBuildReport === "function") window.hrBuildReport(); }, 400); } }).observe(v, { childList: true }); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", obs); else obs();

  const css = `
  #view .hrr-out .hrr-head{align-items:center;gap:12px;justify-content:flex-start!important}
  #view .hrp-ico{width:44px;height:44px;flex:0 0 44px;border-radius:12px;display:grid;place-items:center;padding:10px;box-sizing:border-box;color:#1d4ed8;background:linear-gradient(140deg,#eaf1fe,#dbe7fd);border:1px solid #cfdcf6}
  #view .hrp-desc{margin:0 0 3px;font-size:12.5px;color:#475569;-webkit-text-fill-color:#475569}
  #view .hrr-out .hrr-head h3{font-size:19px!important}
  #view .hrr-stat{position:relative;overflow:hidden;box-shadow:0 4px 12px -10px rgba(20,33,61,.4)}
  #view .hrr-stat.red{--c:#dc2626}
  #view .hrr-stat b{font-size:20px!important;font-variant-numeric:tabular-nums}
  #view .hrp-rate i{position:absolute;left:0;bottom:0;height:4px;width:var(--w);background:var(--c);border-radius:0 3px 0 0}
  #view .hrp-chips{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:0 0 8px}
  #view .hrp-chl{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:#64748b}
  #view .hrp-chip{--c:#2563eb;border:1px solid #dbe3ef;background:#fff;color:#334155;-webkit-text-fill-color:#334155;border-radius:999px;padding:4px 11px;font-size:12px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px}
  #view .hrp-chip em{font-style:normal;background:#eef2f7;border-radius:999px;padding:0 7px;font-size:11px;color:#14213d}
  #view .hrp-chip::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--c)}
  #view .hrp-chip.s-g{--c:#16a34a}#view .hrp-chip.s-r{--c:#dc2626}#view .hrp-chip.s-a{--c:#e0a10f}#view .hrp-chip.s-b{--c:#2563eb}
  #view .hrp-chip:hover{border-color:var(--c)}
  #view .hrp-chip.on{background:#14213d;border-color:#14213d;color:#fff;-webkit-text-fill-color:#fff}
  #view .hrp-chip.on em{background:rgba(255,255,255,.2);color:#fff;-webkit-text-fill-color:#fff}
  #view .hrp-show{margin-left:auto;font-size:12px;color:#64748b;font-weight:600}
  #view .hrr-table thead th{font-size:11.5px!important;letter-spacing:.04em;text-transform:uppercase;padding:9px 10px!important}
  #view .hrr-table tbody tr:hover td{background:#eef4ff!important}
  #view .hrp-av{display:inline-grid;place-items:center;width:26px;height:26px;border-radius:50%;margin-right:8px;font-size:10.5px;font-weight:800;vertical-align:middle;background:hsl(var(--h) 70% 92%);color:hsl(var(--h) 55% 32%)!important;-webkit-text-fill-color:hsl(var(--h) 55% 32%)!important}
  #view .hrp-nm{font-weight:700;vertical-align:middle}
  #view .hrp-dt{font-weight:600}#view .hrp-wd{margin-left:6px;font-size:11px;color:#94a3b8!important;-webkit-text-fill-color:#94a3b8!important}
  #view#view .hrr-table td.hrp-zero{color:#b6c0ce!important;-webkit-text-fill-color:#b6c0ce!important}
  #view .hrr-table .pill{display:inline-flex;align-items:center;gap:5px;min-width:74px;justify-content:center;border-radius:999px;font-weight:700;font-size:11.5px;padding:3px 10px}
  #view .hrr-table .pill::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
  @media(min-width:1100px){
   #view .hrr-stats{grid-template-columns:none!important;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr)}
   #view .hrr-toolbar{flex-wrap:nowrap!important;gap:8px!important}
   #view .hrr-toolbar .hrr-f select,#view .hrr-toolbar .hrr-f input{min-width:0;max-width:190px}
   #view .hrr-toolbar .hrr-grow input{max-width:none}
   #view .hrr-toolbar .hrr-grow{flex:1 1 140px;min-width:120px}
   #view .hrr-actions{flex:0 0 auto}
   #view .hrr-actions .btn{height:36px!important;padding:0 12px!important;font-size:13px!important;white-space:nowrap}
  }
  #view .hrr-stat small{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #view .hrr-group>small{display:flex!important;align-items:center;gap:6px}
  #view .hrp-gi{width:13px;height:13px;display:inline-block;color:#64748b}
  #view .hrr-item.active{box-shadow:inset 0 0 0 1px #bfd3fb}
  `;
  const st = document.createElement("style"); st.id = "pb-hr-report-pro"; st.textContent = css; document.head.appendChild(st);
})();
