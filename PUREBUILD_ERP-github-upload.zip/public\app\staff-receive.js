/* Staff phone: Site Material Receiving (Central Warehouse delivery / Direct supplier / Approved site purchase).
   Sends kind 'receiving' to submit_site_stock_update; nothing changes stock until Admin/Manager approves in
   Warehouse → Site Receiving (office posts the difference via PBWhCalc.receivingPost). Incoming deliveries come from get_site_incoming. */
(function () {
  const cl = () => window.PB_STAFF_CLIENT;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const f2 = (v) => Number(n(v).toFixed(3)).toLocaleString("en-US");
  const today = () => new Date(Date.now() + 4 * 3600e3).toISOString().slice(0, 10);
  const SRC = { central: "🏬 Central Warehouse delivery", supplier: "🚚 Direct supplier delivery", site_purchase: "🛒 Approved site purchase" };
  let sites = [], inc = { central: [], purchases: [], site_purchases: [] }, src = "central", sending = false;

  function build() {
    if ($("pbr-form")) return;
    const s = document.createElement("form"); s.id = "pbr-form"; s.className = "card"; s.dataset.tab = "receive"; s.noValidate = true;
    s.innerHTML = `<div class="body"><div class="section-title"><span>📥</span><h2>Site Material Receiving</h2></div>
      <div class="pbr-kpis" id="pbr-kpis"></div>
      <p class="hint">Count what really arrived. Only the quantity the office approves as “accepted” goes into site stock. Damaged and short material is recorded separately.</p>
      <div class="field"><label>Assigned site *</label><select id="pbr-site"></select></div>
      <div class="field"><label>Material source *</label><select id="pbr-src">${Object.entries(SRC).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></div>
      <div class="field"><label id="pbr-ref-l">Delivery *</label><select id="pbr-ref"></select></div>
      <div class="field"><label>Receiving date *</label><input id="pbr-date" type="date"></div>
      <div class="pbs-g2"><div class="field"><label>Supplier / delivery by</label><input id="pbr-sup" maxlength="120"></div><div class="field"><label>Invoice / challan no.</label><input id="pbr-inv" maxlength="60"></div></div>
      <div id="pbr-lines"></div>
      <button type="button" class="btn" id="pbr-add" style="width:100%;margin:6px 0" hidden>＋ Add material</button>
      <div class="field"><label>Photos — materials</label><input id="pbr-ph1" type="file" accept="image/*" multiple></div>
      <div class="field"><label>Photos — truck</label><input id="pbr-ph2" type="file" accept="image/*" multiple></div>
      <div class="field"><label>Photo — delivery challan</label><input id="pbr-ph3" type="file" accept="image/*" multiple></div>
      <div class="field"><label>Remarks</label><textarea id="pbr-rem" rows="2" maxlength="400"></textarea></div>
      <button type="submit" class="submit">Submit receiving report</button><div class="notice" id="pbr-msg"></div>
      <h3 style="margin:16px 0 6px">Recent receiving</h3><div id="pbr-hist" class="hint">—</div></div>`;
    document.querySelector("main.shell").appendChild(s);
    $("pbr-site").onchange = loadInc;
    $("pbr-src").onchange = () => { src = $("pbr-src").value; drawRef(); };
    $("pbr-ref").onchange = drawLines;
    $("pbr-add").onclick = () => $("pbr-lines").insertAdjacentHTML("beforeend", lineHtml({}, true));
    $("pbr-lines").addEventListener("input", (e) => { if (e.target.classList.contains("pr-rc")) { const d = e.target.closest(".pbs-line"), ex = d.querySelector(".pr-ex"); if (ex && ex.value !== "") d.querySelector(".pr-sh").value = Math.max(0, n(ex.value) - n(e.target.value)) || ""; } check(); });
    s.onsubmit = (e) => { e.preventDefault(); send(); };
  }
  function lineHtml(l, free) {
    const name = free ? `<div class="pbs-g2"><input class="pr-i" placeholder="Material name" maxlength="80" value="${esc(l.item || "")}"><input class="pr-u" placeholder="Unit" maxlength="20" value="${esc(l.unit || "")}"></div>`
      : `<b>${esc(l.item)}</b> <small>${esc(l.unit)}</small><input type="hidden" class="pr-i" value="${esc(l.item)}"><input type="hidden" class="pr-u" value="${esc(l.unit)}">`;
    const ex = l.expected != null ? `<label>${src === "central" ? "Dispatched" : "Ordered"}<input type="number" class="pr-ex" value="${n(l.expected)}" readonly></label>` : `<label>Expected<input type="number" class="pr-ex" min="0" step="any" inputmode="decimal"></label>`;
    return `<div class="pbs-line">${name}<div class="pbs-g4">${ex}<label>Received *<input type="number" class="pr-rc" min="0" step="any" inputmode="decimal"></label><label>Accepted *<input type="number" class="pr-ac" min="0" step="any" inputmode="decimal"></label><label>Damaged<input type="number" class="pr-dm" min="0" step="any" inputmode="decimal"></label></div>
      <div class="pbs-g2"><label>Shortage<input type="number" class="pr-sh" min="0" step="any" inputmode="decimal"></label><span></span></div><div class="pbs-c"></div></div>`;
  }
  function check() {
    document.querySelectorAll("#pbr-lines .pbs-line").forEach((d) => {
      const g = (k) => n(d.querySelector(k)?.value), c = d.querySelector(".pbs-c");
      const err = g(".pr-ac") + g(".pr-dm") > g(".pr-rc") + 1e-9 ? "Accepted + damaged is more than received" : "";
      c.innerHTML = err ? `<span class="pbs-err">${err}</span>` : g(".pr-rc") ? `Into site stock after approval: <b>${f2(g(".pr-ac"))}</b>` : "";
      d.classList.toggle("bad", !!err);
    });
  }
  function refList() {
    if (src === "central") return inc.central.map((v) => ({ id: v.id, label: `${v.no} · ${v.date} · ${(v.lines || []).map((l) => l.item).join(", ")}`, lines: (v.lines || []).map((l) => ({ item: l.item, unit: l.unit, expected: l.qty })) }));
    if (src === "site_purchase") return inc.site_purchases.map((v) => ({ id: v.id, label: `${v.date} · ${v.supplier || "Shop"}${v.invoice ? " · " + v.invoice : ""}`, sup: v.supplier, inv: v.invoice, lines: (v.lines || []).map((l) => ({ item: l.item, unit: l.unit, expected: l.qty })) }));
    return inc.purchases.map((t) => ({ id: t.id, label: `PO ${t.date} · ${t.item} ${f2(t.qty)} ${t.unit || ""} · ${t.supplier || ""}`, sup: t.supplier, inv: t.invoice, lines: [{ item: t.item, unit: t.unit || "", expected: t.qty }] }));
  }
  function drawRef() {
    const L = refList();
    $("pbr-ref-l").textContent = src === "central" ? "Issue voucher from warehouse *" : src === "site_purchase" ? "Approved site purchase *" : "Purchase order / reference";
    $("pbr-ref").innerHTML = (src === "supplier" ? `<option value="">No purchase order — send for Admin review</option>` : `<option value="">${L.length ? "Choose the delivery" : "Nothing waiting to be received"}</option>`) + L.map((r) => `<option value="${esc(r.id)}">${esc(r.label)}</option>`).join("");
    drawLines();
  }
  function drawLines() {
    const r = refList().find((x) => x.id === $("pbr-ref").value);
    if (r) { if (r.sup) $("pbr-sup").value = r.sup; if (r.inv && !$("pbr-inv").value) $("pbr-inv").value = r.inv; }
    $("pbr-add").hidden = !(src === "supplier" && !r);
    $("pbr-lines").innerHTML = r ? r.lines.map((l) => lineHtml(l)).join("") : src === "supplier" ? lineHtml({}, true) : "";
    check();
  }
  async function loadSites() {
    const c = cl(), u = (await c.auth.getUser()).data.user; if (!u) return;
    const { data: m } = await c.from("team_project_members").select("project_id").eq("user_id", u.id).eq("status", "active");
    const ids = (m || []).map((x) => x.project_id);
    const { data } = ids.length ? await c.from("team_projects").select("id,name").in("id", ids) : { data: [] };
    sites = data || [];
    $("pbr-site").innerHTML = `<option value="">Choose your site</option>` + sites.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
    if (sites.length === 1) $("pbr-site").value = sites[0].id;
    $("pbr-date").value = today(); $("pbr-date").max = today();
    loadInc(); loadHist();
  }
  async function loadInc() {
    const pid = $("pbr-site").value; inc = { central: [], purchases: [], site_purchases: [] };
    if (pid) { const { data, error } = await cl().rpc("get_site_incoming", { p_project_id: pid }); if (!error && data) inc = { central: data.central || [], purchases: data.purchases || [], site_purchases: data.site_purchases || [] }; }
    drawRef();
  }
  async function loadHist() {
    const { data } = await cl().from("site_stock_submissions").select("id,project_id,work_date,source,ref_label,lines,approved_lines,review_status,review_note,created_at").eq("kind", "receiving").order("created_at", { ascending: false }).limit(40);
    const rows = data || [], nm = (id) => (sites.find((s) => s.id === id) || {}).name || "Site", sum = (r, k, arr) => (arr || r.lines || []).reduce((a, l) => a + n(l[k]), 0);
    const k = (ic, l, v) => `<div><i>${ic}</i><small>${l}</small><b>${v}</b></div>`;
    $("pbr-kpis").innerHTML = k("📅", "Today received", rows.filter((r) => r.work_date === today()).length) + k("⏳", "Waiting approval", rows.filter((r) => r.review_status === "pending").length)
      + k("✅", "Accepted (approved)", f2(rows.filter((r) => r.review_status === "approved").reduce((a, r) => a + sum(r, "accepted", r.approved_lines), 0))) + k("⚠️", "Damaged", f2(rows.reduce((a, r) => a + sum(r, "damaged"), 0)));
    $("pbr-hist").innerHTML = rows.slice(0, 12).map((r) => `<div class="pbs-h"><b>RCV-${String(r.id).slice(0, 8).toUpperCase()}</b> · ${esc(nm(r.project_id))} · ${r.work_date}<span class="pbs-st ${r.review_status}">${r.review_status === "pending" ? "Waiting" : r.review_status === "approved" ? "Approved" : "Rejected"}</span><small>${esc(SRC[r.source] || "")} — ${esc((r.lines || []).map((l) => `${l.item} ${f2(l.received)}`).join(", "))}${r.review_note ? " — Office: " + esc(r.review_note) : ""}</small></div>`).join("") || "Nothing received yet.";
  }
  async function send() {
    if (sending) return; const msg = $("pbr-msg"); msg.textContent = "";
    const pid = $("pbr-site").value, d = $("pbr-date").value, ref = $("pbr-ref").value;
    if (!pid) { msg.textContent = "Choose your site."; return; }
    if (!d || d > today()) { msg.textContent = "Choose a date that is not in the future."; return; }
    if (src !== "supplier" && !ref) { msg.textContent = "Choose the delivery you are receiving."; return; }
    const lines = [];
    for (const el of document.querySelectorAll("#pbr-lines .pbs-line")) {
      const g = (k) => el.querySelector(k)?.value ?? "", item = g(".pr-i").trim(), unit = g(".pr-u").trim();
      const exRaw = g(".pr-ex"), o = { expected: exRaw === "" ? null : n(exRaw), received: n(g(".pr-rc")), accepted: n(g(".pr-ac")), damaged: n(g(".pr-dm")), shortage: n(g(".pr-sh")) };
      if (!item && !o.received) continue;
      if (!item || !unit) { msg.textContent = "Write the material name and unit."; return; }
      if (g(".pr-rc") === "" || g(".pr-ac") === "") { msg.textContent = item + ": enter received and accepted quantity (0 if nothing)."; return; }
      if (Object.values(o).some((v) => v != null && v < 0)) { msg.textContent = "Quantities cannot be negative."; return; }
      if (o.accepted + o.damaged > o.received + 1e-9) { msg.textContent = item + ": accepted + damaged is more than received."; return; }
      lines.push({ item, unit, ...o });
    }
    if (!lines.length) { msg.textContent = "Enter at least one material."; return; }
    const ph = [["pbr-ph1", "material"], ["pbr-ph2", "truck"], ["pbr-ph3", "challan"]];
    if (!ph.some(([i]) => ($(i).files || []).length)) { msg.textContent = "Add at least one photo (material, truck or challan)."; return; }
    sending = true; const btn = document.querySelector("#pbr-form button[type=submit]"); btn.disabled = true; msg.textContent = "Sending…";
    try {
      const key = "rcv-" + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random());
      const photos = [], prof = window.PB_STAFF_PROFILE || {};
      for (const [i, cat] of ph) for (const file of [...($(i).files || [])].slice(0, 4)) {
        const path = `${prof.organization_id}/${pid}/receive-${key}/${cat}-${Date.now()}-${file.name.replace(/[^\w.-]+/g, "_")}`;
        const { error } = await cl().storage.from("site-progress-photos").upload(path, file, { contentType: file.type, upsert: false });
        if (error) throw error; photos.push({ path, category: cat, original_name: file.name, size: file.size });
      }
      const label = (refList().find((x) => x.id === ref) || {}).label || (src === "supplier" ? "Unlinked supplier delivery" : "");
      const { error } = await cl().rpc("submit_site_stock_update", { p_project_id: pid, p: { idempotency_key: key, kind: "receiving", source: src, ref_id: ref || null, ref_label: label, work_date: d, lines, supplier: $("pbr-sup").value.trim(), invoice_no: $("pbr-inv").value.trim(), remarks: $("pbr-rem").value.trim(), photos } });
      if (error) throw error;
      msg.textContent = "✅ Receiving report sent. Stock changes after office approval.";
      ["pbr-rem", "pbr-sup", "pbr-inv", "pbr-ph1", "pbr-ph2", "pbr-ph3"].forEach((i) => ($(i).value = ""));
      loadInc(); loadHist();
    } catch (e) { msg.textContent = "Could not send: " + (e.message || e); }
    finally { sending = false; btn.disabled = false; }
  }
  function addQuick() { document.querySelectorAll(".fw-quick").forEach((q) => { if (!q.querySelector("[data-goto=receive]")) q.insertAdjacentHTML("beforeend", `<button type="button" data-goto="receive">📥<span>Receive material</span></button>`); }); }

  const css = document.createElement("style");
  css.textContent = `.pbr-kpis{display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-bottom:8px}.pbr-kpis div{border:1px solid #E4E1F3;border-radius:12px;padding:8px;background:#fff;display:flex;flex-direction:column}.pbr-kpis i{font-style:normal}.pbr-kpis small{font-size:11px;color:#6b6889;font-weight:700}.pbr-kpis b{font-size:17px}
  .fw-quick button[data-goto=receive]{background:linear-gradient(150deg,#16a34a,#14532d)!important;border-color:#22c55e!important}`;
  document.head.appendChild(css);

  const boot = setInterval(() => {
    if (!cl() || !document.querySelector("main.shell") || !document.querySelector("#pbs-stock")) return; clearInterval(boot);
    build(); addQuick(); setInterval(addQuick, 2000);
    if (window.PB_STAFF_PROFILE) loadSites(); window.addEventListener("pb:staff-ready", loadSites);
  }, 200);
})();
