-- Additive security hardening. Apply only after the existing ERP migrations.
BEGIN;

CREATE OR REPLACE FUNCTION public.pb_current_organization_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT p.organization_id
  FROM public.profiles p
  WHERE p.id = auth.uid() AND p.status = 'active'
$$;

CREATE OR REPLACE FUNCTION public.pb_is_active_user()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.status = 'active'
  )
$$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT _user_id = auth.uid()
    AND public.pb_is_active_user()
    AND EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid() AND ur.role = _role
    )
$$;

CREATE OR REPLACE FUNCTION public.is_office_user(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT _user_id = auth.uid()
    AND public.pb_is_active_user()
    AND EXISTS (
      SELECT 1 FROM public.user_roles ur
      WHERE ur.user_id = auth.uid()
        AND (
          ur.role IN ('manager', 'accountant')
          OR ur.role = 'admin'
        )
    )
$$;

CREATE OR REPLACE FUNCTION public.pb_is_member(_project uuid, _user uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT _user = auth.uid()
    AND public.pb_is_active_user()
    AND EXISTS (
      SELECT 1
      FROM public.team_project_members m
      JOIN public.team_projects p ON p.id = m.project_id
      WHERE m.project_id = _project
        AND m.user_id = auth.uid()
        AND m.status = 'active'
        AND m.organization_id = public.pb_current_organization_id()
        AND p.organization_id = public.pb_current_organization_id()
    )
$$;

REVOKE ALL ON FUNCTION public.pb_current_organization_id() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pb_is_active_user() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_office_user(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pb_is_member(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pb_current_organization_id() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.pb_is_active_user() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.is_office_user(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.pb_is_member(uuid, uuid) TO authenticated, service_role;

DROP POLICY IF EXISTS "Admins update profiles" ON public.profiles;
CREATE POLICY "Admins update profiles" ON public.profiles
  FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin')
    AND organization_id = public.pb_current_organization_id()
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'admin')
    AND organization_id = public.pb_current_organization_id()
  );

-- Guard every tenant-keyed relation against cross-company reads and writes,
-- even when an older permissive policy grants office access.
DO $$
DECLARE
  t record;
  predicate text;
BEGIN
  FOR t IN
    SELECT c.relname,
      EXISTS (
        SELECT 1 FROM pg_attribute a
        WHERE a.attrelid = c.oid AND a.attname = 'organization_id'
          AND a.atttypid = 'uuid'::regtype AND NOT a.attisdropped
      ) AS has_organization_id,
      EXISTS (
        SELECT 1 FROM pg_attribute a
        WHERE a.attrelid = c.oid AND a.attname = 'project_id'
          AND a.atttypid = 'uuid'::regtype AND NOT a.attisdropped
      ) AS has_project_id
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public'
      AND c.relkind IN ('r', 'p')
      AND (
        EXISTS (
          SELECT 1 FROM pg_attribute a
          WHERE a.attrelid = c.oid AND a.attname = 'organization_id'
            AND a.atttypid = 'uuid'::regtype AND NOT a.attisdropped
        )
        OR EXISTS (
          SELECT 1 FROM pg_attribute a
          WHERE a.attrelid = c.oid AND a.attname = 'project_id'
            AND a.atttypid = 'uuid'::regtype AND NOT a.attisdropped
        )
      )
  LOOP
    predicate := 'public.pb_is_active_user()';
    IF t.has_organization_id THEN
      predicate := predicate || format(
        ' AND %I.organization_id = public.pb_current_organization_id()',
        t.relname
      );
    END IF;
    IF t.has_project_id THEN
      predicate := predicate || format(
        ' AND EXISTS (SELECT 1 FROM public.team_projects tenant_project WHERE tenant_project.id = %I.project_id AND tenant_project.organization_id = public.pb_current_organization_id())',
        t.relname
      );
    END IF;

    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t.relname);
    EXECUTE format('DROP POLICY IF EXISTS pb_tenant_guard ON public.%I', t.relname);
    EXECUTE format(
      'CREATE POLICY pb_tenant_guard ON public.%I AS RESTRICTIVE FOR ALL TO authenticated USING (%s) WITH CHECK (%s)',
      t.relname,
      predicate,
      predicate
    );
  END LOOP;
END
$$;

-- Rows without a project_id inherit their tenant boundary from the parent row.
DO $$
BEGIN
  IF to_regclass('public.site_progress_report_boq_lines') IS NOT NULL THEN
    ALTER TABLE public.site_progress_report_boq_lines ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.site_progress_report_boq_lines;
    CREATE POLICY pb_tenant_guard ON public.site_progress_report_boq_lines
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.site_progress_reports r
          WHERE r.id = report_id AND r.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.site_progress_reports r
          WHERE r.id = report_id AND r.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;

  IF to_regclass('public.site_material_request_lines') IS NOT NULL THEN
    ALTER TABLE public.site_material_request_lines ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.site_material_request_lines;
    CREATE POLICY pb_tenant_guard ON public.site_material_request_lines
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.site_material_requests r
          WHERE r.id = request_id AND r.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.site_material_requests r
          WHERE r.id = request_id AND r.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;

  IF to_regclass('public.foreman_task_updates') IS NOT NULL THEN
    ALTER TABLE public.foreman_task_updates ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.foreman_task_updates;
    CREATE POLICY pb_tenant_guard ON public.foreman_task_updates
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.foreman_tasks t
          WHERE t.id = task_id AND t.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.foreman_tasks t
          WHERE t.id = task_id AND t.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;

  IF to_regclass('public.foreman_task_events') IS NOT NULL THEN
    ALTER TABLE public.foreman_task_events ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.foreman_task_events;
    CREATE POLICY pb_tenant_guard ON public.foreman_task_events
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.foreman_tasks t
          WHERE t.id = task_id AND t.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.foreman_tasks t
          WHERE t.id = task_id AND t.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;

  IF to_regclass('public.erp_site_attendance_history') IS NOT NULL THEN
    ALTER TABLE public.erp_site_attendance_history ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.erp_site_attendance_history;
    CREATE POLICY pb_tenant_guard ON public.erp_site_attendance_history
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1
          FROM public.erp_site_attendance a
          JOIN public.team_projects p ON p.id = a.project_id
          WHERE a.id = attendance_id
            AND p.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1
          FROM public.erp_site_attendance a
          JOIN public.team_projects p ON p.id = a.project_id
          WHERE a.id = attendance_id
            AND p.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;

  IF to_regclass('public.erp_attendance_workers') IS NOT NULL THEN
    ALTER TABLE public.erp_attendance_workers ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS pb_tenant_guard ON public.erp_attendance_workers;
    CREATE POLICY pb_tenant_guard ON public.erp_attendance_workers
      AS RESTRICTIVE FOR ALL TO authenticated
      USING (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.team_projects p
          WHERE p.local_project_id = project_legacy_id
            AND p.organization_id = public.pb_current_organization_id()
        )
      )
      WITH CHECK (
        public.pb_is_active_user()
        AND EXISTS (
          SELECT 1 FROM public.team_projects p
          WHERE p.local_project_id = project_legacy_id
            AND p.organization_id = public.pb_current_organization_id()
        )
      );
  END IF;
END
$$;

CREATE OR REPLACE FUNCTION public.pb_storage_project_access(_object_name text)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
DECLARE
  folders text[] := storage.foldername(_object_name);
  project_id uuid;
  task_id uuid;
BEGIN
  IF NOT public.pb_is_active_user()
    OR coalesce(array_length(folders, 1), 0) < 2
    OR folders[1] <> public.pb_current_organization_id()::text
    OR folders[2] !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  THEN
    RETURN false;
  END IF;
  project_id := folders[2]::uuid;
  IF coalesce(folders[3], '') LIKE 'task-%' THEN
    IF folders[3] !~* '^task-[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$' THEN
      RETURN false;
    END IF;
    task_id := substring(folders[3] FROM 6)::uuid;
  END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.team_projects p
    WHERE p.id = project_id
      AND p.organization_id = public.pb_current_organization_id()
      AND (
        public.is_office_user(auth.uid())
        OR public.pb_is_member(project_id, auth.uid())
      )
      AND (
        task_id IS NULL
        OR EXISTS (
          SELECT 1 FROM public.foreman_tasks t
          WHERE t.id = task_id
            AND t.project_id = project_id
            AND (
              t.assigned_to = auth.uid()
              OR public.is_office_user(auth.uid())
            )
        )
      )
  );
END
$$;

CREATE OR REPLACE FUNCTION public.pb_storage_document_access(_object_name text)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
DECLARE
  folders text[] := storage.foldername(_object_name);
  project_id uuid;
BEGIN
  IF NOT public.pb_is_active_user()
    OR coalesce(array_length(folders, 1), 0) < 1
    OR folders[1] !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  THEN
    RETURN false;
  END IF;
  project_id := folders[1]::uuid;
  RETURN EXISTS (
    SELECT 1 FROM public.team_projects p
    WHERE p.id = project_id
      AND p.organization_id = public.pb_current_organization_id()
      AND (
        public.is_office_user(auth.uid())
        OR public.pb_is_member(project_id, auth.uid())
      )
  );
END
$$;

REVOKE ALL ON FUNCTION public.pb_storage_project_access(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.pb_storage_document_access(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.pb_storage_project_access(text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.pb_storage_document_access(text) TO authenticated, service_role;

DROP POLICY IF EXISTS "members upload photos" ON storage.objects;
DROP POLICY IF EXISTS "read photos" ON storage.objects;
DROP POLICY IF EXISTS "office upload task files" ON storage.objects;
DROP POLICY IF EXISTS "foreman reads own task files" ON storage.objects;
CREATE POLICY "company project photos upload" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'site-progress-photos'
    AND public.pb_storage_project_access(name)
  );
CREATE POLICY "company project photos read" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'site-progress-photos'
    AND public.pb_storage_project_access(name)
  );

DROP POLICY IF EXISTS "office upload project docs" ON storage.objects;
DROP POLICY IF EXISTS "read project docs" ON storage.objects;
CREATE POLICY "company project documents upload" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'project-documents'
    AND public.is_office_user(auth.uid())
    AND public.pb_storage_document_access(name)
  );
CREATE POLICY "company project documents read" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'project-documents'
    AND public.pb_storage_document_access(name)
  );

UPDATE storage.buckets
SET public = false,
    file_size_limit = 10485760,
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
WHERE id = 'site-progress-photos';

UPDATE storage.buckets
SET public = false,
    file_size_limit = 26214400,
    allowed_mime_types = ARRAY[
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/webp',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ]
WHERE id = 'project-documents';

CREATE TABLE IF NOT EXISTS public.audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  organization_id uuid,
  actor_id uuid,
  actor_role text,
  module text NOT NULL,
  record_id text,
  action text NOT NULL,
  status text NOT NULL DEFAULT 'success'
);
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS organization_id uuid;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS actor_id uuid;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS actor_role text;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS module text;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS record_id text;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE public.audit_log ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'success';
CREATE INDEX IF NOT EXISTS audit_log_org_created_idx
  ON public.audit_log (organization_id, created_at DESC);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.audit_log FROM anon, authenticated;
GRANT SELECT ON public.audit_log TO authenticated;
GRANT SELECT, INSERT ON public.audit_log TO service_role;
REVOKE UPDATE, DELETE, TRUNCATE ON public.audit_log FROM service_role;

CREATE OR REPLACE FUNCTION public.pb_audit_log_immutable()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  RAISE EXCEPTION 'Audit log records are immutable';
END
$$;

DROP TRIGGER IF EXISTS pb_audit_log_immutable ON public.audit_log;
CREATE TRIGGER pb_audit_log_immutable
  BEFORE UPDATE OR DELETE ON public.audit_log
  FOR EACH ROW EXECUTE FUNCTION public.pb_audit_log_immutable();

CREATE OR REPLACE FUNCTION public.audit_can_read()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
  SELECT public.pb_is_active_user()
    AND (
      public.has_role(auth.uid(), 'admin')
      OR public.has_role(auth.uid(), 'auditor')
    )
$$;

DROP POLICY IF EXISTS "Admins and auditors read audit log" ON public.audit_log;
CREATE POLICY "Admins and auditors read audit log" ON public.audit_log
  FOR SELECT TO authenticated
  USING (
    public.audit_can_read()
    AND organization_id = public.pb_current_organization_id()
  );

CREATE OR REPLACE FUNCTION public.pb_log_security_event(
  p_actor uuid,
  p_organization uuid,
  p_action text,
  p_record_id text,
  p_module text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF coalesce(auth.role(), '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  IF p_action NOT IN (
    'user_created',
    'user_disabled',
    'user_reactivated',
    'password_reset'
  ) THEN
    RAISE EXCEPTION 'invalid audit action';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = p_actor
      AND p.organization_id = p_organization
      AND p.status = 'active'
      AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'invalid audit actor';
  END IF;
  INSERT INTO public.audit_log (
    organization_id, actor_id, actor_role, module, record_id, action
  )
  VALUES (p_organization, p_actor, 'admin', p_module, p_record_id, p_action);
END
$$;
REVOKE ALL ON FUNCTION public.pb_log_security_event(uuid, uuid, text, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.pb_log_security_event(uuid, uuid, text, text, text) TO service_role;

-- Remove historical hard-coded-email promotion logic from deployed projects.
CREATE OR REPLACE FUNCTION public.pb_handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (
    NEW.id,
    coalesce(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END
$$;

COMMIT;
