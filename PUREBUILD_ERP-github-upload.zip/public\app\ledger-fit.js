/* Ledger table fits one screen: fixed column widths, long text cut with "…" (full text on hover). Display-only. */
(function () {
  var T = "#view table.table:has(#ledgerRows)";
  var css = `
${T}{table-layout:fixed!important;width:100%!important;min-width:0!important}
${T} th,${T} td{white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;padding-left:6px!important;padding-right:6px!important;max-width:none!important}
${T} th[data-col="1"]{width:8%}${T} th[data-col="2"]{width:12%}${T} th[data-col="3"]{width:9%}${T} th[data-col="4"]{width:9%}
${T} th[data-col="5"]{width:11%}${T} th[data-col="6"]{width:16%}${T} th[data-col="7"],${T} th[data-col="8"],${T} th[data-col="9"]{width:9.5%}
${T} th[data-col="10"]{width:6.5%}
${T} .lf-num{text-align:right!important;white-space:nowrap!important;overflow:visible!important;text-overflow:clip!important;padding-right:12px!important;font-variant-numeric:tabular-nums;font-size:12.5px}
${T} th.lf-num{font-size:10px!important}
${T} td.lf-num *{display:inline!important;margin:0!important;float:none!important}
${T} td{vertical-align:middle!important}
${T} td.lf-txt{white-space:normal!important;overflow-wrap:anywhere!important;word-break:break-word!important;text-overflow:clip!important;line-height:1.35}
${T} tr.lf-open td{font-weight:700}
${T} td[data-col="10"],${T} th[data-col="10"]{text-align:center!important}
${T} td .btn{max-width:100%;overflow:hidden;text-overflow:ellipsis}
#view .tablewrap:has(#ledgerRows){overflow-x:hidden!important}
@media (max-width:1100px){${T}{font-size:11px!important}${T} th[data-col="4"],${T} td[data-col="4"]{display:none}${T} .lf-num{font-size:11.5px}}
@media (max-width:820px){#view .tablewrap:has(#ledgerRows){overflow-x:auto!important}${T}{min-width:760px!important}}
`;
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  function tag(tr) {
    var c = 1; Array.prototype.forEach.call(tr.children, function (td) {
      var span = td.colSpan || 1; td.setAttribute("data-col", c);
      var end = c + span - 1; td.classList.toggle("lf-num", c >= 7 && end <= 9); td.classList.toggle("lf-txt", end <= 6);
      if (span > 1 && c <= 6) tr.classList.add("lf-open"); c = end + 1;
    });
  }
  function tip() {
    var b = document.getElementById("ledgerRows"); if (!b) return;
    var t = b.closest("table"); if (t) t.querySelectorAll("tr").forEach(function (tr) { if (tr.getAttribute("data-lf") !== String(tr.children.length)) { tag(tr); tr.setAttribute("data-lf", tr.children.length); } });
    b.querySelectorAll("td").forEach(function (td) { if (!td.title && td.textContent.trim().length > 12) td.title = td.textContent.trim(); });
  }
  new MutationObserver(tip).observe(document.body, { childList: true, subtree: true });
})();
