/* Site Progress → "Schedule & Manpower" tab.
   Schedule: per-BOQ planned start/finish kept in side map db.boqPlan[boqId] = {start,end} (only new data written);
   falls back to project start/end. Actual start/finish come from saved progress. Gantt is drawn from these.
   Manpower: read-only over db.labour for the selected project/date (never writes cost or payroll). */
(function () {
  const C = () => window.PBProgressCalc;
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : n(v).toFixed(2));
  const F = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));
  const today = () => new Date().toISOString().slice(0, 10);
  const ui = { st: "", q: "", day: "", mFrom: "", mTo: "" };

  const css = document.createElement("style");
  css.textContent = `
.sm-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.sm-g{position:relative;height:16px;background:#f1f5f9;border-radius:4px;min-width:260px}
.sm-g .p{position:absolute;top:2px;height:5px;background:#94a3b8;border-radius:3px}
.sm-g .a{position:absolute;top:9px;height:5px;border-radius:3px;background:#2182df}
.sm-g .a.l{background:#dc2626}.sm-g .a.d{background:#16a34a}
.sm-g .t{position:absolute;top:-2px;bottom:-2px;width:2px;background:#f59e0b}
.sm-lg{display:flex;gap:12px;font-size:11px;color:#64748b;align-items:center}.sm-lg i{display:inline-block;width:14px;height:5px;border-radius:3px;margin-right:4px;vertical-align:middle}
.sm-ms{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.sm-ms div{flex:1;min-width:150px;border:1px solid #e3e9f1;border-radius:10px;padding:8px 10px;background:#f8fafc;font-size:12px}
.sm-ms b{display:block;font-size:13px;color:#12233d}.sm-ms .ok{border-left:4px solid #16a34a}.sm-ms .no{border-left:4px solid #94a3b8}
.sm-host .ps-k{grid-template-columns:repeat(5,minmax(0,1fr))}
body.dark-theme .sm-g{background:#22364d}body.dark-theme .sm-ms div{background:#17283c;border-color:#344960}body.dark-theme .sm-ms b{color:#e2ecf8}
`;
  document.head.appendChild(css);

  const proj = () => (db.projects || []).find((p) => p.id === selectedProject) || {};
  const plan = (b) => { const m = (db.boqPlan || {})[b.id] || {}, p = proj(); return { start: m.start || p.start || "", end: m.end || p.end || "", own: !!(m.start || m.end) }; };

  function rows() {
    const pid = selectedProject, t = today(), prog = (db.progress || []).filter((x) => x.projectId === pid && n(x.todayQty) > 0 && !/reject/i.test(String(x.approvalStatus || "")));
    return (db.boq || []).filter((b) => b.projectId === pid && C().approvedish(b)).map((b) => {
      const c = C().itemCalc(b), pl = plan(b);
      const mine = prog.filter((x) => x.boqId === b.id).sort((a, z) => String(a.date).localeCompare(String(z.date)));
      const aStart = mine[0] ? String(mine[0].date).slice(0, 10) : "";
      let aFin = "";
      if (c.pct >= 100 && mine.length) { let run = 0; for (const x of mine) { run += n(x.todayQty); if (run >= c.qty - 1e-9) { aFin = String(x.date).slice(0, 10); break; } } aFin = aFin || String(mine[mine.length - 1].date).slice(0, 10); }
      const plannedPct = C().planned(pl.start, pl.end, t);
      const delay = C().delayDays(pl.end, aFin, c.pct, t);
      const dur = pl.start && pl.end ? C().dayDiff(pl.start, pl.end) + 1 : null;
      const st = c.pct >= 100 ? (delay > 0 ? "Completed late" : "Completed") : delay > 0 ? "Delayed" : c.pct > 0 ? (plannedPct != null && c.pct + 10 < plannedPct ? "Behind" : "In Progress") : pl.start && t >= pl.start ? "Not Started (due)" : "Not Started";
      return { b, c, pl, aStart, aFin, plannedPct, delay, dur, st, loc: [b.building, b.floor, b.area || b.room].filter(Boolean).join(" · ") };
    });
  }
  const badge = (s) => `<span class="ps-b ${/late|Delayed|Behind/.test(s) ? "r" : /due/.test(s) ? "a" : /Completed/.test(s) ? "g" : "s"}">${E(s)}</span>`;

  function schedHtml() {
    const all = rows(), t = today();
    const list = all.filter((r) => (!ui.st || r.st === ui.st) && (!ui.q || (r.b.boqId + " " + r.b.description + " " + r.loc).toLowerCase().includes(ui.q.toLowerCase())));
    const ds = all.flatMap((r) => [r.pl.start, r.pl.end, r.aStart, r.aFin]).filter(Boolean).concat([t]).sort();
    const s0 = ds[0], s1 = ds[ds.length - 1], span = Math.max(1, C().dayDiff(s0, s1) + 1);
    const x = (d) => Math.max(0, Math.min(100, (C().dayDiff(s0, d) / span) * 100));
    const bar = (r) => {
      const p = r.pl.start && r.pl.end ? `<span class="p" style="left:${x(r.pl.start)}%;width:${Math.max(1, x(r.pl.end) - x(r.pl.start) + 100 / span)}%"></span>` : "";
      const ae = r.aFin || (r.aStart ? t : "");
      const a = r.aStart ? `<span class="a ${r.delay > 0 ? "l" : r.aFin ? "d" : ""}" style="left:${x(r.aStart)}%;width:${Math.max(1, x(ae) - x(r.aStart) + 100 / span)}%"></span>` : "";
      return `<div class="sm-g">${p}${a}<span class="t" style="left:${x(t)}%"></span></div>`;
    };
    const cnt = (f) => all.filter(f).length;
    const p = proj(), sts = ["Not Started", "Not Started (due)", "In Progress", "Behind", "Delayed", "Completed", "Completed late"];
    const ms = [25, 50, 75, 100].map((m) => { const done = C().weighted(all.map((r) => r.b)) >= m; return `<div class="${done ? "ok" : "no"}"><b>${done ? "✔" : "○"} ${m}% complete</b>${done ? "Reached" : "Not yet"}</div>`; }).join("");
    return `<div class="panel ps-p" data-pt="schedule"><div class="ps-h"><div><h3>🗓 Work Schedule &amp; Gantt</h3><small>${E(p.name || "")} · Project ${E(p.start || "?")} → ${E(p.end || "?")}. Grey = plan, blue = actual work, red = late, green = finished, orange line = today.</small></div>
<div class="ps-f"><select id="smSt"><option value="">All status</option>${sts.map((s) => `<option ${ui.st === s ? "selected" : ""}>${s}</option>`).join("")}</select><input id="smQ" placeholder="Search work…" value="${E(ui.q)}"><button class="btn small" id="smCsv">CSV</button><button class="btn small" id="smPr">Print</button></div></div>
<div class="ps-k"><div><small>Activities</small><b>${all.length}</b></div><div class="g"><small>Completed</small><b>${cnt((r) => r.c.pct >= 100)}</b></div><div><small>In progress</small><b>${cnt((r) => r.c.pct > 0 && r.c.pct < 100)}</b></div><div class="r"><small>Delayed</small><b>${cnt((r) => r.delay > 0)}</b></div><div class="a"><small>Own dates set</small><b>${cnt((r) => r.pl.own)} / ${all.length}</b></div></div>
<div class="sm-ms">${ms}</div>
<div class="ps-t" style="max-height:520px;overflow:auto"><table id="smTbl"><thead><tr><th>BOQ ID</th><th>Activity</th><th>Plan start</th><th>Plan finish</th><th class="r">Days</th><th>Actual start</th><th>Actual finish</th><th class="r">Plan %</th><th class="r">Actual %</th><th class="r">Delay</th><th>Status</th><th style="min-width:280px">Gantt <span class="sm-lg">${E(s0)} → ${E(s1)}</span></th><th></th></tr></thead><tbody>
${list.map((r) => `<tr><td>${E(r.b.boqId || "—")}</td><td><b>${E(r.b.description || "Work")}</b><br><small style="color:#64748b">${E(r.loc || "General")}</small></td><td>${E(r.pl.start || "—")}${r.pl.own ? "" : r.pl.start ? ' <small style="color:#94a3b8">(project)</small>' : ""}</td><td>${E(r.pl.end || "—")}</td><td class="r">${r.dur ?? "—"}</td><td>${E(r.aStart || "—")}</td><td>${E(r.aFin || "—")}</td><td class="r">${r.plannedPct == null ? "—" : r.plannedPct.toFixed(0) + "%"}</td><td class="r"><b>${r.c.pct.toFixed(1)}%</b></td><td class="r" style="${r.delay ? "color:#b91c1c;font-weight:800" : ""}">${r.delay ? r.delay + " d" : "—"}</td><td>${badge(r.st)}</td><td>${bar(r)}</td><td><button class="btn small" onclick="PB_SCHEDULE.edit('${E(r.b.id)}')">Dates</button></td></tr>`).join("") || '<tr><td colspan="13" class="empty">No approved BOQ work for this project.</td></tr>'}
</tbody></table></div></div>`;
  }

  function labourRows() {
    const pid = selectedProject, d = ui.day || today();
    const from = ui.mFrom || d, to = ui.mTo || d;
    return (db.labour || []).filter((x) => x.projectId === pid && String(x.date || "") >= from && String(x.date || "") <= to);
  }
  function manHtml() {
    const d = ui.day || today(), list = labourRows(), s = C().labourSummary(list), range = ui.mFrom || ui.mTo;
    const roles = {}; list.forEach((x) => { if (/absent|leave/i.test(String(x.status || ""))) return; const k = x.role || "General"; const u = x.workerId ? 1 : n(x.units); const r = (roles[k] = roles[k] || { w: 0, h: 0, ot: 0 }); r.w += u; r.h += n(x.hours); r.ot += n(x.overtime); });
    return `<div class="panel ps-p" data-pt="schedule"><div class="ps-h"><div><h3>👷 Manpower &amp; Labour</h3><small>Read from Labour &amp; HR attendance (nothing new is saved; cost is not added again anywhere).</small></div>
<div class="ps-f"><label style="font-size:12px">Day</label><input type="date" id="smD" value="${E(range ? "" : d)}"><label style="font-size:12px">or From</label><input type="date" id="smF" value="${E(ui.mFrom)}"><input type="date" id="smT" value="${E(ui.mTo)}"><button class="btn small" id="smTd">Today</button><button class="btn small" onclick="typeof setPage==='function'&&setPage('labour')">Open Labour &amp; HR</button></div></div>
<div class="ps-k"><div><small>Total workers</small><b>${F(s.workers)}</b><i>${s.entries} entries</i></div><div class="g"><small>Present</small><b>${F(s.present)}</b></div><div class="r"><small>Absent / Leave</small><b>${F(s.absent)}</b></div><div><small>Skilled / Unskilled</small><b>${F(s.skilled)} / ${F(s.unskilled)}</b></div><div><small>Hours / OT</small><b>${F(s.hours)}h / ${F(s.overtime)}h</b></div></div>
<div class="ps-k" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="a"><small>Labour cost (${range ? "period" : "day"})</small><b>${M(s.cost)}</b><i>days × rate + OT hours × OT rate</i></div><div><small>Teams / trades</small><b>${Object.keys(roles).length}</b></div></div>
<div class="ps-t"><table><thead><tr><th>Trade / Team</th><th class="r">Workers</th><th class="r">Hours</th><th class="r">OT</th></tr></thead><tbody>${Object.entries(roles).map(([k, r]) => `<tr><td>${E(k)}</td><td class="r">${F(r.w)}</td><td class="r">${F(r.h)}</td><td class="r">${F(r.ot)}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">No attendance for this date.</td></tr>'}</tbody></table></div></div>`;
  }

  function edit(bid) {
    const b = (db.boq || []).find((x) => x.id === bid); if (!b || typeof openModal !== "function") return;
    const m = (db.boqPlan || {})[bid] || {};
    openModal(`Planned dates — ${E(b.boqId || "")} ${E(b.description || "")}`, `<div class="formgrid"><div class="field"><label>Planned start</label><input id="smPs" type="date" value="${E(m.start || "")}"></div><div class="field"><label>Planned finish</label><input id="smPe" type="date" value="${E(m.end || "")}"></div><div class="field full"><small class="muted">Leave empty to use the project start/end dates. Only these planning dates are saved; BOQ quantities are not changed.</small></div></div>`, () => {
      const s = document.getElementById("smPs").value, e = document.getElementById("smPe").value;
      if (s && e && e < s) { typeof toast === "function" && toast("Finish date must be after start date"); return false; }
      db.boqPlan = db.boqPlan || {};
      if (!s && !e) delete db.boqPlan[bid]; else db.boqPlan[bid] = { start: s, end: e, updatedAt: new Date().toISOString() };
      typeof save === "function" && save(); typeof render === "function" && render(); typeof toast === "function" && toast("Planned dates saved"); return true;
    });
  }
  function csv() {
    const h = ["BOQ ID", "Activity", "Location", "Plan start", "Plan finish", "Days", "Actual start", "Actual finish", "Plan %", "Actual %", "Delay days", "Status"];
    const L = rows().map((r) => [r.b.boqId, r.b.description, r.loc, r.pl.start, r.pl.end, r.dur ?? "", r.aStart, r.aFin, r.plannedPct == null ? "" : r.plannedPct.toFixed(1), r.c.pct.toFixed(1), r.delay, r.st]);
    const t = [h, ...L].map((a) => a.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + t], { type: "text/csv" })); a.download = `work-schedule-${today()}.csv`; a.click();
  }
  function print() {
    const tb = document.getElementById("smTbl"); if (!tb) return; const s = db.settings || {};
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(`<html><head><title>Work Schedule</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Arial;font-size:10px}h1{font-size:16px;margin:0}table{width:100%;border-collapse:collapse}th{background:#14213d;color:#fff;padding:4px;text-align:left;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{padding:3px 4px;border-bottom:1px solid #ddd}thead{display:table-header-group}.sm-g{position:relative;height:14px;background:#eee;min-width:200px}.sm-g span{position:absolute;-webkit-print-color-adjust:exact;print-color-adjust:exact}.p{top:1px;height:5px;background:#94a3b8}.a{top:8px;height:5px;background:#2182df}.a.l{background:#dc2626}.a.d{background:#16a34a}.t{top:0;bottom:0;width:2px;background:#f59e0b}button,.sm-lg{display:none}.ps-b{font-weight:bold}</style></head><body><h1>${E(s.companyName || "PURE_BUILD")} — Work Schedule</h1><p>${E(proj().name || "")} · Printed ${today()}</p>${tb.outerHTML}</body></html>`); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  function inject(v) {
    v.querySelectorAll(".sm-host").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum || !C() || !C().delayDays) return;
    const host = document.createElement("div"); host.className = "sm-host";
    try { host.innerHTML = selectedProject ? schedHtml() + manHtml() : `<div class="panel ps-p" data-pt="schedule"><b>Select a project above to see its schedule and manpower.</b></div>`; } catch (e) { console.warn("schedule-manpower", e); return; }
    sum.insertAdjacentElement("afterend", host);
    const on = (id, ev, fn) => host.querySelector(id)?.addEventListener(ev, fn);
    on("#smSt", "change", (e) => { ui.st = e.target.value; refresh(); });
    let tm; on("#smQ", "input", (e) => { ui.q = e.target.value; clearTimeout(tm); tm = setTimeout(() => { refresh(); const i = document.getElementById("smQ"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); });
    on("#smCsv", "click", csv); on("#smPr", "click", print);
    on("#smD", "change", (e) => { ui.day = e.target.value; ui.mFrom = ui.mTo = ""; refresh(); });
    on("#smF", "change", (e) => { ui.mFrom = e.target.value; refresh(); }); on("#smT", "change", (e) => { ui.mTo = e.target.value; refresh(); });
    on("#smTd", "click", () => { ui.day = ""; ui.mFrom = ui.mTo = ""; refresh(); });
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }
  window.PB_SCHEDULE = { inject, edit, csv, print };
})();
