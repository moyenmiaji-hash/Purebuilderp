/* Office side of staff extras: approve staff expense requests (Accounts Payable page) and
   share existing BOQ drawings with site staff (read-only for them). Never changes saved ERP records. */
(function () {
  const C = () => window.PB_CLOUD_CLIENT;
  const E = (s) => (typeof esc === "function" ? esc(s) : String(s ?? ""));
  const M = (v) => (typeof money === "function" ? money(v) : "AED " + Number(v || 0).toFixed(2));
  let cloudProjects = null, shared = new Set();

  async function projectsMap() {
    if (cloudProjects) return cloudProjects;
    const { data } = await C().from("team_projects").select("id,name,local_project_id");
    return (cloudProjects = data || []);
  }

  /* ---------- Expense requests on Accounts Payable ---------- */
  /* Fixed slot: a KPI card on the AP Dashboard (so the page never jumps); the list opens in a window. */
  window.pbxOpenExp = function () { const o = document.getElementById("pbx-exp-ov"); if (o) o.style.display = "flex"; };
  async function drawExpenses() {
    const kpis = document.querySelector(".apd .apd-kpis");
    if (!C() || !kpis || document.getElementById("pbx-exp-kpi")) return;
    kpis.insertAdjacentHTML("beforeend", `<div class="apd-k" id="pbx-exp-kpi" style="--c:#0f766e" onclick="pbxOpenExp()"><small>Staff Requests</small><b id="pbx-exp-n">…</b><span>Site expense requests</span></div>`);
    window.apDashFit && window.apDashFit();
    let ov = document.getElementById("pbx-exp-ov");
    if (!ov) {
      ov = document.createElement("div"); ov.id = "pbx-exp-ov";
      ov.style.cssText = "position:fixed;inset:0;z-index:9999;background:rgba(10,25,45,.45);display:none;align-items:center;justify-content:center;padding:20px";
      ov.addEventListener("click", (e) => { if (e.target === ov || e.target.closest("[data-exp-close]")) ov.style.display = "none"; });
      document.body.appendChild(ov);
    }
    ov.innerHTML = `<div id="pbx-exp-panel" class="panel" style="width:min(1000px,96vw);max-height:86vh;overflow:auto;padding:16px;border-radius:14px;background:var(--panel,#fff)"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h3 style="margin:0">Staff Expense Requests <small class="muted">from site staff phones</small></h3><button class="btn small" data-exp-close>Close</button></div><div id="pbx-exp-body" class="muted">Loading…</div></div>`;
    const { data, error } = await C().from("site_expense_requests").select("*").order("created_at", { ascending: false }).limit(50);
    const body = document.getElementById("pbx-exp-body"); if (!body) return;
    const nEl = () => document.getElementById("pbx-exp-n");
    if (error) { body.textContent = "Could not load: " + error.message; if (nEl()) nEl().textContent = "—"; return; }
    const pm = await projectsMap(); const pn = (id) => (pm.find((p) => p.id === id) || {}).name || "Site";
    const pend = (data || []).filter((r) => r.review_status === "pending").length;
    if (nEl()) nEl().textContent = pend + " pending";
    body.innerHTML = `<div class="muted" style="margin-bottom:6px">${pend} waiting for approval · approving does not post to the ledger — add the payment in Transaction Entry when paid.</div>
    <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Site</th><th>Category</th><th>Pay to</th><th>For</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead><tbody>${(data || []).map((r) => `<tr><td>${E(r.request_date)}</td><td>${E(pn(r.project_id))}</td><td>${E(r.category)}</td><td>${E(r.payee || "")}</td><td>${E(r.description || "")}${r.review_note ? `<br><small class="muted">Note: ${E(r.review_note)}</small>` : ""}</td><td><b>${M(r.amount)}</b></td><td>${E(r.review_status)}</td><td>${r.review_status === "pending" ? `<button class="btn small primary" data-exp="${r.id}" data-d="approved">Approve</button> <button class="btn small danger" data-exp="${r.id}" data-d="rejected">Reject</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="8" class="empty">No staff expense requests yet.</td></tr>'}</tbody></table></div>`;
  }
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-exp]"); if (!b) return;
    const note = b.dataset.d === "rejected" ? prompt("Reason for rejection:") : "";
    if (b.dataset.d === "rejected" && !note) return;
    const { error } = await C().rpc("review_site_expense_request", { p_id: b.dataset.exp, p_decision: b.dataset.d, p_note: note || "" });
    if (error) return alert(error.message);
    if (typeof toast === "function") toast("Request " + b.dataset.d);
    document.getElementById("pbx-exp-kpi")?.remove(); await drawExpenses(); window.pbxOpenExp();
  });

  /* ---------- Share drawings with staff ---------- */
  async function refreshShared() {
    const { data } = await C().from("project_documents").select("file_path").eq("is_active", true);
    shared = new Set((data || []).map((d) => (d.file_path.split("/")[1] || "").split("__")[0]));
  }
  async function decorateDrawings() {
    const panel = document.querySelector(".boq-drawings-panel"); if (!panel || !C() || panel.dataset.pbx) return;
    panel.dataset.pbx = "1";
    await refreshShared();
    panel.querySelectorAll("button[onclick^=\"del('drawings'\"]").forEach((btn) => {
      const id = (btn.getAttribute("onclick").match(/'drawings','([^']+)'/) || [])[1]; if (!id) return;
      const s = document.createElement("button"); s.className = "btn small";
      s.textContent = shared.has(id) ? "Shared ✓" : "Share to staff"; s.disabled = shared.has(id);
      s.onclick = () => share(id, s); btn.before(s, " ");
    });
  }
  async function share(id, btn) {
    const d = (db.drawings || []).find((x) => x.id === id); if (!d) return;
    if (!d.data) return alert("This drawing has no file attached.");
    const pm = await projectsMap(); const cp = pm.find((p) => String(p.local_project_id) === String(d.projectId));
    if (!cp) return alert("This project is not connected to the staff cloud yet.");
    btn.disabled = true; btn.textContent = "Sharing…";
    try {
      const blob = await (await fetch(d.data)).blob();
      const safe = String(d.fileName || "drawing").replace(/[^\w.\-]/g, "_");
      const path = `${cp.id}/${id}__${safe}`;
      const up = await C().storage.from("project-documents").upload(path, blob, { upsert: false, contentType: blob.type });
      if (up.error && !/exists/i.test(up.error.message)) throw up.error;
      const u = (await C().auth.getUser()).data.user;
      const ins = await C().from("project_documents").insert({ project_id: cp.id, title: `${d.number || ""} ${d.title || ""}`.trim(), doc_type: d.type || "Drawing", file_path: path, file_name: d.fileName, uploaded_by: u.id });
      if (ins.error) throw ins.error;
      btn.textContent = "Shared ✓"; if (typeof toast === "function") toast("Drawing shared with site staff");
    } catch (err) { btn.disabled = false; btn.textContent = "Share to staff"; alert("Could not share: " + (err.message || err)); }
  }

  new MutationObserver(() => { if (!C()) return; if (document.querySelector(".apd")) drawExpenses(); decorateDrawings(); })
    .observe(document.body, { childList: true, subtree: true });
})();
