// Weighted work-stage progress formulas. Pure functions (no DOM) so they can be unit-tested.
(function (root) {
  const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const DEFAULTS = {
    Civil: [["Excavation", 10], ["PCC", 10], ["RCC", 40], ["Brickwork", 20], ["Plaster", 20]],
    MEP: [["Electrical", 50], ["Plumbing", 50]],
    Finishing: [["Flooring", 40], ["Painting", 40], ["Finishing", 20]],
    Painting: [["Primer", 5], ["1st Stucco", 20], ["2nd Stucco", 20], ["Sanding", 5], ["1st Paint", 20], ["Final Paint", 20], ["Snagging", 10]],
    Tiling: [["Surface Prep", 15], ["Adhesive & Laying", 55], ["Grouting", 20], ["Cleaning", 10]],
    Gypsum: [["Framing", 30], ["Board Fixing", 35], ["Jointing", 20], ["Finishing", 15]],
    General: [["Preparation", 20], ["Execution", 70], ["Snagging", 10]],
  };
  function weightTotal(stages) { return (stages || []).reduce((s, x) => s + num(x.weight), 0); }
  function validStages(stages) {
    if (!stages || !stages.length) return "Add at least one stage";
    const names = new Set();
    for (const s of stages) {
      if (!String(s.name || "").trim()) return "Every stage needs a name";
      const k = String(s.name).trim().toLowerCase();
      if (names.has(k)) return "Stage names must be unique";
      names.add(k);
      if (num(s.weight) <= 0) return "Every stage weight must be more than 0";
    }
    if (Math.abs(weightTotal(stages) - 100) > 0.001) return "Stage weights must add up to 100% (now " + weightTotal(stages) + "%)";
    return "";
  }
  // prev / today are maps {stageName: percent of that stage}
  function compute(stages, prev, today) {
    const rows = (stages || []).map((s) => {
      const p = clamp(num(prev && prev[s.name]), 0, 100);
      const t = clamp(num(today && today[s.name]), 0, 100 - p);
      const u = p + t;
      return { name: s.name, weight: num(s.weight), prev: p, today: t, updated: u, remaining: 100 - u, status: u >= 100 ? "Completed" : u > 0 ? "In Progress" : "Not Started" };
    });
    const w = (k) => rows.reduce((s, r) => s + (r.weight * r[k]) / 100, 0);
    const overall = w("updated");
    return { rows, previous: w("prev"), today: w("today"), overall, remaining: 100 - overall, status: overall >= 100 - 1e-9 ? "Completed" : overall > 0 ? "In Progress" : "Not Started" };
  }
  // Quantity to add to the BOQ so executed qty reaches overall %, never above approved qty, never negative.
  function qtyToAdd(overallPct, approvedQty, executedQty) {
    const target = (clamp(num(overallPct), 0, 100) / 100) * Math.max(0, num(approvedQty));
    return Math.max(0, Math.min(target, num(approvedQty)) - num(executedQty));
  }
  const api = { DEFAULTS, weightTotal, validStages, compute, qtyToAdd };
  root.PB_STAGE_CALC = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
