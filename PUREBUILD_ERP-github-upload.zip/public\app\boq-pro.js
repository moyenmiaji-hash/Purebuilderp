/* BOQ & Drawings register look (display only): wraps boq() and decorates the
   rendered BOQ table — clear Done / Left chips, coloured progress with status,
   done value, building progress and a short "how to read" guide.
   Never changes db.boq or any saved record. Formulas in boq-calc.js. */
(function () {
  if (window.__pbBoqPro) return; window.__pbBoqPro = 1;
  var C = function () { return window.PB_BOQ_CALC; };
  function E(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function M(v) { try { return money(v); } catch (e) { return 'AED ' + (Number(v) || 0).toLocaleString(); } }
  function F(v) { v = Number(v) || 0; return (Math.round(v * 100) / 100).toLocaleString(); }
  function items() { try { return db.boq || []; } catch (e) { return []; } }
  var css = document.createElement('style');
  css.id = 'pb-boq-pro';
  css.textContent = [
    '.bq-guide{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 10px;padding:9px 12px;border:1px solid #e6e3f3;border-radius:14px;background:linear-gradient(180deg,#fbfaff,#f4f2fc);font-size:11.5px;color:#4b4a63}',
    '.bq-guide b{color:#29283A}.bq-guide .bq-sep{flex:1}',
    '.bq-cnt{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:999px;background:#fff;border:1px solid #e7e4f0;font-weight:700}',
    '.bq-cnt i{width:9px;height:9px;border-radius:50%;display:inline-block}',
    '.bq-cnt.ns i{background:#b9b6c9}.bq-cnt.ip i{background:#F0B65C}.bq-cnt.dn i{background:#38B98A}',
    '.bq-howto{color:#858398;font-size:11px}',
    '#boqTable tbody tr[data-search]{border-left:4px solid transparent}',
    '#boqTable tbody tr.bq-ns td:first-child{box-shadow:inset 4px 0 0 #cfcbe0}',
    '#boqTable tbody tr.bq-ip td:first-child{box-shadow:inset 4px 0 0 #F0B65C}',
    '#boqTable tbody tr.bq-dn td:first-child{box-shadow:inset 4px 0 0 #38B98A}',
    '.bq-dr{display:flex;flex-direction:column;gap:3px;min-width:96px}',
    '.bq-dr span{display:inline-flex;align-items:center;gap:4px;width:max-content;padding:2px 8px;border-radius:999px;font-size:10.5px;font-weight:700;white-space:nowrap}',
    '.bq-dr .d{background:#e6f7f0;color:#1f8a63}.bq-dr .l{background:#fdf3e2;color:#a46a12}.bq-dr .l.z{background:#eef0f4;color:#7b7f8f}',
    '.bq-pg{min-width:110px}.bq-pg .t{display:flex;justify-content:space-between;align-items:baseline;gap:6px;font-size:10.5px;margin-bottom:3px}',
    '.bq-pg .t b{font-size:12px;color:#29283A}.bq-pg .t em{font-style:normal;font-weight:700;font-size:10px}',
    '.bq-pg .bar{height:7px;border-radius:99px;background:#ecebf4;overflow:hidden;box-shadow:inset 0 1px 2px rgba(41,40,58,.12)}',
    '.bq-pg .bar i{display:block;height:100%;border-radius:99px}',
    '.bq-pg.ns em{color:#858398}.bq-pg.ip em{color:#b57d1d}.bq-pg.dn em{color:#1f8a63}',
    '.bq-pg.ns .bar i{background:#cfcbe0}.bq-pg.ip .bar i{background:linear-gradient(90deg,#F0B65C,#8875DC)}.bq-pg.dn .bar i{background:linear-gradient(90deg,#38B98A,#2fa57a)}',
    '.bq-amt small{display:block;font-size:10px;color:#1f8a63;font-weight:700;margin-top:2px;white-space:nowrap}',
    '.bq-dim-none{color:#a9a7b8}',
    '.bq-grp{display:flex;align-items:center;gap:8px;font-size:11px;color:#4b4a63}.bq-grp .bar{flex:1;max-width:160px;height:6px;border-radius:99px;background:#e4e2ef;overflow:hidden}.bq-grp .bar i{display:block;height:100%;background:linear-gradient(90deg,#8875DC,#38B98A)}',
    '.boq-row-actions .btn .bq-ic{margin-right:3px;font-size:11px}',
    '@media print{.bq-guide{display:none!important}}'
  ].join('\n');
  document.head.appendChild(css);

  function idOf(tr) {
    var b = tr.querySelector('button[onclick^="editBOQ"]');
    var m = b && /editBOQ\('([^']+)'\)/.exec(b.getAttribute('onclick') || '');
    return m ? m[1] : '';
  }
  function cls(state) { return state === 'Completed' ? 'dn' : state === 'In progress' ? 'ip' : 'ns'; }

  function decorate() {
    var table = document.getElementById('boqTable');
    if (!table || table.dataset.bqDone || !C()) return;
    table.dataset.bqDone = '1';
    var all = items(), byId = {};
    all.forEach(function (x) { byId[String(x.id)] = x; });
    var bySite = {}, rows = [];
    table.querySelectorAll('tbody tr[data-search]').forEach(function (tr) {
      var x = byId[idOf(tr)]; if (!x) return;
      var s = C().rowStats(x), k = cls(s.state), unit = E(x.unit || ''), td = tr.children;
      rows.push(s); tr.classList.add('bq-' + k);
      (bySite[tr.dataset.site] = bySite[tr.dataset.site] || []).push(x);
      if (td[3] && /^[\s0\-×x.]*$/.test(td[3].textContent)) td[3].innerHTML = '<span class="bq-dim-none" title="No dimensions entered">—</span>';
      if (td[6] && s.doneValue > 0) { td[6].classList.add('bq-amt'); td[6].insertAdjacentHTML('beforeend', '<small>Done ' + E(M(s.doneValue)) + '</small>'); }
      if (td[7]) td[7].innerHTML = '<div class="bq-dr"><span class="d">✔ ' + F(s.done) + ' ' + unit + ' done</span><span class="l' + (s.left ? '' : ' z') + '">' + (s.left ? '⏳ ' + F(s.left) + ' ' + unit + ' left' : 'Nothing left') + '</span></div>';
      if (td[8]) td[8].innerHTML = '<div class="bq-pg ' + k + '"><div class="t"><b>' + s.pct.toFixed(1) + '%</b><em>' + s.state + '</em></div><div class="bar"><i style="width:' + s.pct.toFixed(1) + '%"></i></div></div>';
      tr.querySelectorAll('.boq-row-actions .btn').forEach(function (b) {
        if (b.querySelector('.bq-ic')) return;
        var t = b.textContent.trim(), ic = t === 'Edit' ? '✎' : t === 'Copy' ? '⧉' : t === 'Delete' ? '🗑' : '';
        if (ic) { b.insertAdjacentHTML('afterbegin', '<span class="bq-ic" aria-hidden="true">' + ic + '</span>'); b.title = t + ' this BOQ item'; }
      });
    });
    table.querySelectorAll('tbody tr.boq-site-row').forEach(function (tr) {
      var list = bySite[tr.dataset.site]; if (!list) return;
      var g = C().groupStats(list), last = tr.lastElementChild;
      if (last) last.innerHTML = '<div class="bq-grp"><span>Building progress <b>' + g.pct.toFixed(1) + '%</b></span><span class="bar"><i style="width:' + g.pct.toFixed(1) + '%"></i></span></div>';
    });
    var tools = document.querySelector('.boq-erp-list-tools');
    if (tools && rows.length && !document.querySelector('.bq-guide')) {
      var cnt = { ns: 0, ip: 0, dn: 0 };
      rows.forEach(function (s) { cnt[cls(s.state)]++; });
      tools.insertAdjacentHTML('afterend', '<div class="bq-guide" role="note"><b>Work status:</b>' +
        '<span class="bq-cnt ns"><i></i>Not started ' + cnt.ns + '</span>' +
        '<span class="bq-cnt ip"><i></i>In progress ' + cnt.ip + '</span>' +
        '<span class="bq-cnt dn"><i></i>Completed ' + cnt.dn + '</span><span class="bq-sep"></span>' +
        '<span class="bq-howto">Done = approved work so far · Left = BOQ qty − done · Foreman updates are added after office approval</span></div>');
    }
  }

  function hook() {
    if (typeof window.boq !== 'function' || window.boq.__bqPro) return false;
    var orig = window.boq;
    window.boq = function () { var r = orig.apply(this, arguments); try { decorate(); } catch (e) { console.error('BOQ look skipped', e); } return r; };
    window.boq.__bqPro = 1;
    return true;
  }
  if (!hook()) { var tries = 0, t = setInterval(function () { if (hook() || ++tries > 40) clearInterval(t); }, 250); }
  /* Re-run when the register is redrawn by something else (filters, sync). */
  var pend = 0;
  new MutationObserver(function () {
    if (pend) return; pend = requestAnimationFrame(function () { pend = 0; try { decorate(); } catch (e) {} });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
