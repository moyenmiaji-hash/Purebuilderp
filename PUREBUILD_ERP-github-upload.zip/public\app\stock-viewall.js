/* PURE_BUILD — Warehouse / Stock "View all" statement view.
   Adds a "View all" button to every Stock tab panel (tables, card lists, charts).
   It opens a full-screen statement with ALL rows (pager ignored), a company header,
   and Print. Read-only: works on a copy of what is on screen, never changes data. */
(function () {
  const isStock = () => /^#stock/i.test(location.hash || "");
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const css = document.createElement("style");
  css.textContent = `
  .pbva-btn{border:1px solid #c79a3b;background:#fff8e8;color:#8a6417;border-radius:8px;padding:5px 11px;font-size:12px;font-weight:700;cursor:pointer;white-space:nowrap;margin-left:6px}
  .pbva-btn:hover{background:#c79a3b;color:#fff}
  #pbvaOv{position:fixed;inset:0;z-index:9000;background:#0b1626cc;display:flex;align-items:stretch;justify-content:center;padding:18px}
  #pbvaOv .pbva-sheet{background:#fff;color:#1f2d3d;width:min(1400px,100%);border-radius:14px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 30px 80px -20px #000a}
  #pbvaOv .pbva-top{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 18px;border-bottom:1px solid #e3e9f2;background:#f7f9fc;flex-wrap:wrap}
  #pbvaOv .pbva-top h2{margin:0;font-size:17px;color:#14233a}
  #pbvaOv .pbva-top small{display:block;color:#6a7a8f;font-size:12px;font-weight:500;margin-top:2px}
  #pbvaOv .pbva-act{display:flex;gap:6px;align-items:center}
  #pbvaOv .pbva-act input{border:1px solid #d9e1ec;border-radius:8px;padding:6px 10px;font-size:12px;min-width:200px;background:#fff;color:#1f2d3d}
  #pbvaOv .pbva-act button{border:1px solid #d9e1ec;background:#fff;color:#1f2d3d;border-radius:8px;padding:6px 12px;font-size:12px;font-weight:700;cursor:pointer}
  #pbvaOv .pbva-act button.pri{background:#14233a;color:#fff;border-color:#14233a}
  #pbvaOv .pbva-body{flex:1;overflow:auto;padding:14px 18px 18px}
  #pbvaOv .pbva-body table{width:100%;border-collapse:collapse;font-size:12.5px;color:#1f2d3d;background:#fff}
  #pbvaOv .pbva-body th{position:sticky;top:-14px;z-index:1;background:#14233a;color:#fff;text-align:left;padding:8px 9px;font-size:11px;letter-spacing:.03em;text-transform:uppercase;white-space:nowrap}
  #pbvaOv .pbva-body td{padding:7px 9px;border-bottom:1px solid #edf1f6;color:#1f2d3d;background:#fff}
  #pbvaOv .pbva-body tr:nth-child(even) td{background:#f9fbfd}
  #pbvaOv .pbva-body .pbva-list>*{border:1px solid #e3e9f2;border-radius:10px;margin-bottom:6px;background:#fff!important;color:#1f2d3d!important}
  #pbvaOv .pbva-body .pbva-list *{color:#1f2d3d!important}
  #pbvaOv .pbva-body svg{max-width:100%;height:auto}
  #pbvaOv .pbva-foot{padding:8px 18px;border-top:1px solid #e3e9f2;font-size:12px;color:#6a7a8f;background:#f7f9fc}
  #pbvaOv .pbva-charts{color:#1f2d3d}
  #pbvaOv .pbva-charts .panel,#pbvaOv .pbva-charts .stock-ov-kpi{background:#fff!important;color:#1f2d3d!important;border:1px solid #e3e9f2!important}
  #pbvaOv .pbva-charts *{color:inherit}
  #pbvaOv .pbva-hide{display:none!important}
  body.pbva-open{overflow:hidden}`;
  document.head.appendChild(css);

  function company() {
    try { const s = (window.db && db.settings) || {}; return { name: s.companyName || "PURE_BUILD", addr: [s.companyAddress, s.companyPhone, s.companyEmail].filter(Boolean).join(" · "), logo: s.companyLogo || s.logo || "" }; }
    catch (e) { return { name: "PURE_BUILD", addr: "", logo: "" }; }
  }
  function filterText() {
    const sels = [...document.querySelectorAll("#view select")].filter((s) => s.offsetParent && !s.closest(".pbpg-bar"));
    return sels.map((s) => s.options[s.selectedIndex]?.text || "").filter((t) => t && !/^all /i.test(t)).join(" · ") || "All projects · All history";
  }
  function titleOf(panel) {
    if (panel.matches(".stock-ov")) return "Stock Charts & Overview";
    const h = panel.querySelector("h1,h2,h3,h4,.title");
    return (h ? h.textContent : "Warehouse / Stock").replace(/\s+/g, " ").trim();
  }
  // Copy of the panel content with every row shown and buttons/inputs turned into plain text.
  function cleanCopy(panel) {
    const out = document.createElement("div");
    if (panel.matches(".stock-ov")) {
      const c = panel.cloneNode(true);
      c.querySelectorAll("button,.pbva-btn,.pbpg-bar").forEach((b) => b.remove());
      c.querySelectorAll(".panel").forEach((x) => { x.style.height = "auto"; x.style.maxHeight = "none"; x.style.overflow = "visible"; });
      c.classList.add("pbva-charts");
      out.appendChild(c);
      return out;
    }
    const items = panel.querySelectorAll("table, .stock-row-list, svg");
    const used = new Set();
    items.forEach((el) => {
      if ([...used].some((u) => u.contains(el))) return;
      if (el.tagName.toLowerCase() === "svg" && el.getBoundingClientRect().width < 120) return; // skip small icons
      used.add(el);
      const c = el.cloneNode(true);
      if (el.matches(".stock-row-list")) c.classList.add("pbva-list");
      c.querySelectorAll(".pbpg-hide").forEach((r) => r.classList.remove("pbpg-hide"));
      c.querySelectorAll(".pbpg-bar,.pbva-btn").forEach((b) => b.remove());
      c.querySelectorAll("input,select,textarea").forEach((i) => {
        const span = document.createElement("span");
        span.textContent = i.tagName === "SELECT" ? (i.options[i.selectedIndex]?.text || "") : i.value;
        i.replaceWith(span);
      });
      c.querySelectorAll("button").forEach((b) => b.remove());
      c.removeAttribute("style");
      out.appendChild(c);
    });
    if (el0(out)) out.innerHTML = `<p style="color:#6a7a8f">Nothing to show for this view.</p>`;
    return out;
  }
  const el0 = (o) => !o.children.length;
  function countRows(box) {
    const t = box.querySelectorAll("tbody tr").length;
    const l = box.querySelectorAll(".pbva-list>*").length;
    return t + l;
  }

  function open(panel) {
    close();
    const co = company();
    const title = titleOf(panel);
    const flt = filterText();
    const content = cleanCopy(panel);
    const total = countRows(content);
    const ov = document.createElement("div");
    ov.id = "pbvaOv";
    ov.className = "pbpg-skip"; // shared pager must not split the full view
    ov.innerHTML = `<div class="pbva-sheet" role="dialog" aria-label="${esc(title)}">
      <div class="pbva-top"><div><h2>${esc(title)} — Statement</h2><small>${esc(co.name)} · ${esc(flt)} · ${total ? total + " rows · " : ""}${new Date().toLocaleString()}</small></div>
      <div class="pbva-act"><input type="search" placeholder="Search in this list…" aria-label="Search"><button type="button" class="pri" data-print>🖨 Print / PDF</button><button type="button" data-close>✕ Close</button></div></div>
      <div class="pbva-body"></div>
      <div class="pbva-foot">${total ? `Showing all ${total} rows. ` : ""}Read-only view — nothing here changes your data.</div></div>`;
    ov.querySelector(".pbva-body").appendChild(content);
    document.body.appendChild(ov);
    document.body.classList.add("pbva-open");
    ov.addEventListener("click", (e) => {
      if (e.target === ov || e.target.closest("[data-close]")) close();
      if (e.target.closest("[data-print]")) print(title, flt, content, total, co);
    });
    const search = ov.querySelector("input[type=search]");
    search.addEventListener("input", () => {
      const q = search.value.trim().toLowerCase();
      let shown = 0;
      content.querySelectorAll("tbody tr, .pbva-list>*").forEach((r) => {
        const hit = !q || r.textContent.toLowerCase().includes(q);
        r.classList.toggle("pbva-hide", !hit);
        if (hit) shown++;
      });
      ov.querySelector(".pbva-foot").textContent = `Showing ${shown} of ${total} rows. Read-only view — nothing here changes your data.`;
    });
    search.focus();
  }
  function close() {
    document.getElementById("pbvaOv")?.remove();
    document.body.classList.remove("pbva-open");
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });

  function print(title, flt, content, total, co) {
    const fr = document.createElement("iframe");
    fr.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0";
    document.body.appendChild(fr);
    const copy = content.cloneNode(true);
    copy.querySelectorAll(".pbva-hide").forEach((r) => r.remove());
    const shown = copy.querySelectorAll("tbody tr, .pbva-list>*").length || total;
    const doc = fr.contentDocument;
    doc.open();
    doc.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>
      @page{size:A4 landscape;margin:12mm}
      body{font-family:Segoe UI,Arial,sans-serif;color:#1f2d3d;font-size:11px;margin:0}
      .hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #14233a;padding-bottom:8px;margin-bottom:10px}
      .hd h1{margin:0;font-size:18px}.hd .s{color:#55657a;font-size:11px}
      .hd img{max-height:46px;margin-right:10px;vertical-align:middle}
      h2{font-size:14px;margin:0 0 4px}
      table{width:100%;border-collapse:collapse;page-break-inside:auto}
      thead{display:table-header-group} tr{page-break-inside:avoid}
      th{background:#14233a!important;color:#fff!important;text-align:left;padding:6px 7px;font-size:10px;text-transform:uppercase;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      td{padding:5px 7px;border-bottom:1px solid #dfe5ee}
      .pbva-list>*{border:1px solid #dfe5ee;border-radius:6px;margin-bottom:4px;padding:4px 8px;page-break-inside:avoid}
      .pbva-list *{color:#1f2d3d!important;background:none!important}
      svg{max-width:100%;height:auto}
      .sig{display:flex;justify-content:space-between;margin-top:40px;font-size:11px}.sig div{border-top:1px solid #1f2d3d;padding-top:4px;width:28%;text-align:center}
      .ft{margin-top:10px;color:#55657a;font-size:10px}
    </style></head><body>
      <div class="hd"><div>${co.logo ? `<img src="${esc(co.logo)}" alt="">` : ""}<h1 style="display:inline-block">${esc(co.name)}</h1><div class="s">${esc(co.addr)}</div></div>
      <div class="s" style="text-align:right">Warehouse / Stock Statement<br>Printed ${esc(new Date().toLocaleString())}</div></div>
      <h2>${esc(title)}</h2><div class="s" style="margin-bottom:8px">${esc(flt)} · ${shown} rows</div>
      ${copy.innerHTML}
      <div class="sig"><div>Prepared by</div><div>Checked by</div><div>Approved by</div></div>
      <div class="ft">Generated by PURE_BUILD ERP</div>
    </body></html>`);
    doc.close();
    setTimeout(() => { fr.contentWindow.focus(); fr.contentWindow.print(); setTimeout(() => fr.remove(), 1500); }, 300);
  }

  function decorate() {
    if (!isStock()) return;
    const ovw = document.querySelector("#view .stock-ov");
    const bar = document.querySelector("#view .stock-tabs");
    if (ovw && ovw.offsetParent && bar && !bar.querySelector(".pbva-btn") && /chart/i.test(bar.querySelector(".active")?.textContent || "")) {
      const b = document.createElement("button");
      b.type = "button"; b.className = "pbva-btn"; b.textContent = "⤢ View all";
      b.title = "Show all charts on one page with print";
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); open(ovw); });
      bar.appendChild(b);
    }
    document.querySelectorAll("#view section.panel, #view .panel").forEach((panel) => {
      if (panel.querySelector(":scope .panel")) return; // only innermost panels
      const big = [...panel.querySelectorAll("svg")].some((g) => g.getBoundingClientRect().width >= 120);
      if (!panel.querySelector("table, .stock-row-list") && !big) return;
      if (panel.querySelector(":scope .pbva-btn")) return;
      const host = panel.querySelector(".toolbar > div:last-child, .toolbar") || panel.querySelector("h1,h2,h3,h4")?.parentElement || panel;
      const b = document.createElement("button");
      b.type = "button";
      b.className = "pbva-btn";
      b.textContent = "⤢ View all";
      b.title = "Show every row on one page with statement and print";
      b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); open(panel); });
      host.appendChild(b);
    });
  }
  let q = false;
  new MutationObserver(() => { if (q) return; q = true; requestAnimationFrame(() => { q = false; decorate(); }); }).observe(document.body, { childList: true, subtree: true });
  window.addEventListener("hashchange", () => { close(); decorate(); });
  decorate();
})();
