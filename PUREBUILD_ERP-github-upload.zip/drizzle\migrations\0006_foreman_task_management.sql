CREATE TABLE public.foreman_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_no bigint GENERATED ALWAYS AS IDENTITY,
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid,
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  building text, floor text, location text,
  title text NOT NULL,
  description text,
  category text,
  boq_item_id uuid REFERENCES public.team_boq_items(id),
  assigned_to uuid NOT NULL,
  assigned_by uuid,
  start_date date NOT NULL,
  due_date date NOT NULL,
  priority text NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High','Urgent')),
  target_qty numeric NOT NULL CHECK (target_qty > 0),
  unit text NOT NULL,
  period text NOT NULL DEFAULT 'daily' CHECK (period IN ('daily','weekly','total')),
  period_target numeric CHECK (period_target IS NULL OR period_target >= 0),
  working_days integer CHECK (working_days IS NULL OR working_days >= 0),
  required_labour integer CHECK (required_labour IS NULL OR required_labour >= 0),
  required_materials text,
  acceptance_criteria text,
  attachments jsonb NOT NULL DEFAULT '[]'::jsonb,
  notes text,
  status text NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned','in_progress','submitted','rejected','completed','cancelled')),
  original_target_qty numeric,
  original_due_date date,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_tasks_assigned_idx ON public.foreman_tasks(assigned_to);
CREATE INDEX foreman_tasks_project_idx ON public.foreman_tasks(project_id);

CREATE TABLE public.foreman_task_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.foreman_tasks(id),
  submitted_by uuid NOT NULL,
  report_date date NOT NULL,
  reported_qty numeric NOT NULL CHECK (reported_qty >= 0),
  approved_qty numeric CHECK (approved_qty IS NULL OR approved_qty >= 0),
  note text,
  delay_reason text,
  delay_external boolean NOT NULL DEFAULT false,
  blockers jsonb NOT NULL DEFAULT '[]'::jsonb,
  photos jsonb NOT NULL DEFAULT '[]'::jsonb,
  ask_complete boolean NOT NULL DEFAULT false,
  review_status text NOT NULL DEFAULT 'submitted' CHECK (review_status IN ('submitted','approved','rejected')),
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_task_updates_task_idx ON public.foreman_task_updates(task_id);
CREATE UNIQUE INDEX foreman_task_updates_one_per_day ON public.foreman_task_updates(task_id, report_date) WHERE review_status <> 'rejected';

CREATE TABLE public.foreman_task_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  task_id uuid NOT NULL REFERENCES public.foreman_tasks(id),
  event_type text NOT NULL,
  old_values jsonb,
  new_values jsonb,
  reason text,
  actor uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_task_events_task_idx ON public.foreman_task_events(task_id);

GRANT SELECT ON public.foreman_tasks TO authenticated;
GRANT SELECT ON public.foreman_task_updates TO authenticated;
GRANT SELECT ON public.foreman_task_events TO authenticated;
GRANT ALL ON public.foreman_tasks TO service_role;
GRANT ALL ON public.foreman_task_updates TO service_role;
GRANT ALL ON public.foreman_task_events TO service_role;

ALTER TABLE public.foreman_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.foreman_task_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.foreman_task_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "office or assigned foreman reads tasks" ON public.foreman_tasks FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR assigned_to = auth.uid());
CREATE POLICY "office or own foreman reads task updates" ON public.foreman_task_updates FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR submitted_by = auth.uid()
    OR EXISTS (SELECT 1 FROM public.foreman_tasks t WHERE t.id = task_id AND t.assigned_to = auth.uid()));
CREATE POLICY "office reads task history" ON public.foreman_task_events FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

-- Only Admin / Manager may assign, change and approve tasks.
CREATE OR REPLACE FUNCTION public.pb_can_manage_tasks(_user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user,'admin') OR public.has_role(_user,'manager')
$$;

CREATE OR REPLACE FUNCTION public.create_foreman_task(p jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE tid uuid; pid uuid := (p->>'project_id')::uuid; who uuid := (p->>'assigned_to')::uuid; tq numeric := (p->>'target_qty')::numeric;
  sd date := (p->>'start_date')::date; dd date := (p->>'due_date')::date; legacy text;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can assign tasks'; END IF;
  IF coalesce(trim(p->>'title'),'') = '' THEN RAISE EXCEPTION 'Task title is required'; END IF;
  IF coalesce(trim(p->>'unit'),'') = '' THEN RAISE EXCEPTION 'Unit is required'; END IF;
  IF tq IS NULL OR tq <= 0 THEN RAISE EXCEPTION 'Target quantity must be more than 0'; END IF;
  IF sd IS NULL OR dd IS NULL OR dd < sd THEN RAISE EXCEPTION 'Due date must be on or after start date'; END IF;
  IF NOT public.pb_is_member(pid, who) THEN RAISE EXCEPTION 'This foreman is not assigned to this site'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = pid;
  INSERT INTO public.foreman_tasks(project_id, local_project_id, building, floor, location, title, description, category, boq_item_id,
    assigned_to, assigned_by, start_date, due_date, priority, target_qty, unit, period, period_target, working_days, required_labour,
    required_materials, acceptance_criteria, attachments, notes, original_target_qty, original_due_date)
  VALUES (pid, legacy, nullif(p->>'building',''), nullif(p->>'floor',''), nullif(p->>'location',''), trim(p->>'title'), nullif(p->>'description',''),
    nullif(p->>'category',''), nullif(p->>'boq_item_id','')::uuid, who, auth.uid(), sd, dd, coalesce(nullif(p->>'priority',''),'Medium'), tq,
    trim(p->>'unit'), coalesce(nullif(p->>'period',''),'daily'), nullif(p->>'period_target','')::numeric, nullif(p->>'working_days','')::int,
    nullif(p->>'required_labour','')::int, nullif(p->>'required_materials',''), nullif(p->>'acceptance_criteria',''),
    coalesce(p->'attachments','[]'::jsonb), nullif(p->>'notes',''), tq, dd)
  RETURNING id INTO tid;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, actor)
    VALUES (tid, 'assigned', jsonb_build_object('assigned_to', who, 'target_qty', tq, 'unit', p->>'unit', 'due_date', dd), auth.uid());
  RETURN tid;
END $$;

CREATE OR REPLACE FUNCTION public.update_foreman_task(p_task uuid, p jsonb, p_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks; nt numeric; nd date; nw uuid; key text; oldv jsonb := '{}'::jsonb; newv jsonb := '{}'::jsonb;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change tasks'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF t.status IN ('completed','cancelled') THEN RAISE EXCEPTION 'Completed or cancelled tasks cannot be changed'; END IF;
  nt := coalesce(nullif(p->>'target_qty','')::numeric, t.target_qty);
  nd := coalesce(nullif(p->>'due_date','')::date, t.due_date);
  nw := coalesce(nullif(p->>'assigned_to','')::uuid, t.assigned_to);
  IF nt <= 0 THEN RAISE EXCEPTION 'Target quantity must be more than 0'; END IF;
  IF nd < t.start_date THEN RAISE EXCEPTION 'Due date must be on or after start date'; END IF;
  IF (nt <> t.target_qty OR nd <> t.due_date OR nw <> t.assigned_to) AND coalesce(trim(p_reason),'') = '' THEN
    RAISE EXCEPTION 'Please write a reason for changing target, due date or foreman';
  END IF;
  IF nw <> t.assigned_to AND NOT public.pb_is_member(t.project_id, nw) THEN RAISE EXCEPTION 'This foreman is not assigned to this site'; END IF;
  FOREACH key IN ARRAY ARRAY['title','description','category','building','floor','location','priority','period','period_target','working_days','required_labour','required_materials','acceptance_criteria','notes'] LOOP
    IF p ? key AND coalesce(p->>key,'') IS DISTINCT FROM coalesce(to_jsonb(t)->>key,'') THEN
      oldv := oldv || jsonb_build_object(key, to_jsonb(t)->key); newv := newv || jsonb_build_object(key, p->key);
    END IF;
  END LOOP;
  IF nt <> t.target_qty THEN oldv := oldv || jsonb_build_object('target_qty', t.target_qty); newv := newv || jsonb_build_object('target_qty', nt); END IF;
  IF nd <> t.due_date THEN oldv := oldv || jsonb_build_object('due_date', t.due_date); newv := newv || jsonb_build_object('due_date', nd); END IF;
  IF nw <> t.assigned_to THEN oldv := oldv || jsonb_build_object('assigned_to', t.assigned_to); newv := newv || jsonb_build_object('assigned_to', nw); END IF;
  IF newv = '{}'::jsonb THEN RETURN jsonb_build_object('saved', false); END IF;
  UPDATE public.foreman_tasks SET
    title = CASE WHEN p ? 'title' AND trim(p->>'title') <> '' THEN trim(p->>'title') ELSE title END,
    description = CASE WHEN p ? 'description' THEN nullif(p->>'description','') ELSE description END,
    category = CASE WHEN p ? 'category' THEN nullif(p->>'category','') ELSE category END,
    building = CASE WHEN p ? 'building' THEN nullif(p->>'building','') ELSE building END,
    floor = CASE WHEN p ? 'floor' THEN nullif(p->>'floor','') ELSE floor END,
    location = CASE WHEN p ? 'location' THEN nullif(p->>'location','') ELSE location END,
    priority = CASE WHEN p->>'priority' IN ('Low','Medium','High','Urgent') THEN p->>'priority' ELSE priority END,
    period = CASE WHEN p->>'period' IN ('daily','weekly','total') THEN p->>'period' ELSE period END,
    period_target = CASE WHEN p ? 'period_target' THEN nullif(p->>'period_target','')::numeric ELSE period_target END,
    working_days = CASE WHEN p ? 'working_days' THEN nullif(p->>'working_days','')::int ELSE working_days END,
    required_labour = CASE WHEN p ? 'required_labour' THEN nullif(p->>'required_labour','')::int ELSE required_labour END,
    required_materials = CASE WHEN p ? 'required_materials' THEN nullif(p->>'required_materials','') ELSE required_materials END,
    acceptance_criteria = CASE WHEN p ? 'acceptance_criteria' THEN nullif(p->>'acceptance_criteria','') ELSE acceptance_criteria END,
    notes = CASE WHEN p ? 'notes' THEN nullif(p->>'notes','') ELSE notes END,
    target_qty = nt, due_date = nd, assigned_to = nw, updated_at = now()
  WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (p_task, CASE WHEN nw <> t.assigned_to THEN 'reassigned' WHEN nt <> t.target_qty OR nd <> t.due_date THEN 'target_revised' ELSE 'edited' END,
      oldv, newv, nullif(trim(p_reason),''), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;

CREATE OR REPLACE FUNCTION public.set_foreman_task_status(p_task uuid, p_status text, p_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change task status'; END IF;
  IF p_status NOT IN ('completed','cancelled','in_progress') THEN RAISE EXCEPTION 'Status not allowed'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF p_status = 'cancelled' AND coalesce(trim(p_reason),'') = '' THEN RAISE EXCEPTION 'Please write why the task is cancelled'; END IF;
  IF p_status = 'in_progress' AND t.status NOT IN ('completed','cancelled') THEN RAISE EXCEPTION 'Only completed or cancelled tasks can be reopened'; END IF;
  IF p_status = 'in_progress' AND coalesce(trim(p_reason),'') = '' THEN RAISE EXCEPTION 'Please write why the task is reopened'; END IF;
  IF EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = p_task AND review_status = 'submitted') AND p_status = 'completed' THEN
    RAISE EXCEPTION 'Review the waiting submissions first';
  END IF;
  UPDATE public.foreman_tasks SET status = p_status, completed_at = CASE WHEN p_status = 'completed' THEN now() ELSE NULL END, updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (p_task, p_status, jsonb_build_object('status', t.status), jsonb_build_object('status', p_status), nullif(trim(p_reason),''), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;

CREATE OR REPLACE FUNCTION public.start_foreman_task(p_task uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks;
BEGIN
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND OR t.assigned_to <> auth.uid() THEN RAISE EXCEPTION 'This task is not assigned to you'; END IF;
  IF t.status <> 'assigned' THEN RETURN jsonb_build_object('saved', false, 'status', t.status); END IF;
  UPDATE public.foreman_tasks SET status = 'in_progress', updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, actor)
    VALUES (p_task, 'started', jsonb_build_object('status', t.status), jsonb_build_object('status','in_progress'), auth.uid());
  RETURN jsonb_build_object('saved', true, 'status', 'in_progress');
END $$;

CREATE OR REPLACE FUNCTION public.submit_foreman_task_update(p_task uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks; uid uuid; q numeric := (p->>'reported_qty')::numeric; d date := coalesce(nullif(p->>'report_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  k text := nullif(p->>'idempotency_key','');
BEGIN
  IF k IS NOT NULL THEN
    SELECT id INTO uid FROM public.foreman_task_updates WHERE idempotency_key = k;
    IF uid IS NOT NULL THEN RETURN jsonb_build_object('saved', true, 'updateId', uid, 'duplicate', true); END IF;
  END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND OR t.assigned_to <> auth.uid() THEN RAISE EXCEPTION 'This task is not assigned to you'; END IF;
  IF NOT public.pb_is_member(t.project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF t.status IN ('completed','cancelled') THEN RAISE EXCEPTION 'This task is already closed'; END IF;
  IF q IS NULL OR q < 0 THEN RAISE EXCEPTION 'Quantity cannot be negative'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF d < t.start_date THEN RAISE EXCEPTION 'Date is before the task start date'; END IF;
  IF nullif(p->>'unit','') IS NOT NULL AND lower(trim(p->>'unit')) <> lower(t.unit) THEN RAISE EXCEPTION 'Unit must be %', t.unit; END IF;
  IF EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = p_task AND report_date = d AND review_status <> 'rejected') THEN
    RAISE EXCEPTION 'An update for this date was already sent';
  END IF;
  INSERT INTO public.foreman_task_updates(task_id, submitted_by, report_date, reported_qty, note, delay_reason, delay_external, blockers, photos, ask_complete, idempotency_key)
    VALUES (p_task, auth.uid(), d, q, nullif(p->>'note',''), nullif(p->>'delay_reason',''), coalesce((p->>'delay_external')::boolean, false),
      coalesce(p->'blockers','[]'::jsonb), coalesce(p->'photos','[]'::jsonb), coalesce((p->>'ask_complete')::boolean,false), k)
    RETURNING id INTO uid;
  UPDATE public.foreman_tasks SET status = 'submitted', updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, reason, actor)
    VALUES (p_task, 'submitted', jsonb_build_object('update_id', uid, 'report_date', d, 'reported_qty', q, 'delay_reason', p->>'delay_reason', 'photos', jsonb_array_length(coalesce(p->'photos','[]'::jsonb))), nullif(p->>'note',''), auth.uid());
  RETURN jsonb_build_object('saved', true, 'updateId', uid);
END $$;

CREATE OR REPLACE FUNCTION public.review_foreman_task_update(p_update uuid, p_decision text, p_approved_qty numeric, p_note text, p_complete boolean)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; aq numeric; nstatus text;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'Invalid decision'; END IF;
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF u.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own work'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id FOR UPDATE;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    aq := coalesce(p_approved_qty, u.reported_qty);
    IF aq < 0 OR aq > u.reported_qty THEN RAISE EXCEPTION 'Approved quantity must be between 0 and the reported quantity'; END IF;
  END IF;
  UPDATE public.foreman_task_updates SET review_status = p_decision, approved_qty = CASE WHEN p_decision='approved' THEN aq ELSE NULL END,
    reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_update;
  IF t.status NOT IN ('completed','cancelled') THEN
    nstatus := CASE WHEN p_decision = 'rejected' THEN 'rejected' WHEN coalesce(p_complete,false) THEN 'completed' ELSE 'in_progress' END;
    IF nstatus <> 'completed' AND EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = t.id AND review_status = 'submitted') THEN nstatus := 'submitted'; END IF;
    UPDATE public.foreman_tasks SET status = nstatus, completed_at = CASE WHEN nstatus='completed' THEN now() ELSE completed_at END, updated_at = now() WHERE id = t.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, p_decision, jsonb_build_object('update_id', u.id, 'reported_qty', u.reported_qty),
      jsonb_build_object('approved_qty', aq, 'completed', coalesce(p_complete,false) AND p_decision='approved'), nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved', true, 'status', p_decision);
END $$;

-- List of assigned foremen for the office task form (names only).
CREATE OR REPLACE FUNCTION public.get_task_foremen()
RETURNS TABLE(user_id uuid, display_name text, project_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT m.user_id, coalesce(p.display_name,'Staff'), m.project_id FROM public.team_project_members m
    LEFT JOIN public.profiles p ON p.id = m.user_id WHERE m.status = 'active';
END $$;

REVOKE EXECUTE ON FUNCTION public.create_foreman_task(jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.update_foreman_task(uuid, jsonb, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.set_foreman_task_status(uuid, text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.start_foreman_task(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.submit_foreman_task_update(uuid, jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.review_foreman_task_update(uuid, text, numeric, text, boolean) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_task_foremen() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.create_foreman_task(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_foreman_task(uuid, jsonb, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_foreman_task_status(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.start_foreman_task(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.submit_foreman_task_update(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.review_foreman_task_update(uuid, text, numeric, text, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_task_foremen() TO authenticated;