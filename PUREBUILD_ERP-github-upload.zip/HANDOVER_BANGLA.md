# PURE_BUILD Security & Cloud Handover

## বর্তমান অবস্থা

- Web address খুললে ERP entry login চায়; ERP ও Cloud Team একই Supabase email/password session ব্যবহার করে। Login-এর পর cloud snapshot UI-এর company-specific storage key-তে load হয়।
- Foreman app-এর Supabase session-ও আলাদা storage key-তে থাকে।
- ERP cloud snapshot organization অনুযায়ী scope করা হয়েছে। পুরনো local browser data আলাদা company key-তে import করার আগে user-কে নির্বাচন করতে হয়; পুরনো copy মুছে ফেলা হয় না।
- Private storage ও basic security headers-এর configuration code-এ আছে।
- Project access ও file upload/update/delete audit-এর জন্য additive migration যোগ হয়েছে।
- Production build ও test suite সফল: `npm run build`, `npm test` (59 tests)।
- Supabase schema migration প্রয়োগ ও যাচাই করা হয়েছে; Cloudflare Worker deploy হয়েছে এবং runtime Supabase secrets configured।
- Production URL: https://tanstack-start-ts.moyenmiaji.workers.dev
- ৯ নভেম্বরের ERP JSON backup record ID ধরে existing cloud data-এর সঙ্গে merge করা হয়েছে; আগের snapshot/history-এর পৃথক safety copy রাখা আছে। এখন cloud-এ ৬টি project, ২১টি BOQ, ৩১টি transaction, ৮টি invoice এবং ১১টি progress record আছে।
- Import backup-এ progress-এর ২টি duplicate ID entry ছিল; data না হারাতে সেগুলো অপরিবর্তিত রাখা হয়েছে। Client handover-এর আগে ওই progress records যাচাই করুন।

## Supabase Migration

### নতুন, খালি project

1. `supabase/migrations/20261110110000_initial_setup.sql` একবার চালান।
2. Supabase Auth dashboard থেকে নিজের Admin user তৈরি করুন।
3. `supabase/bootstrap_first_admin.sql` একবার চালান।
4. `supabase/migrations/20261110161000_security_hardening.sql` চালান।
5. existing Auth users থাকলে initial migration তাদের default non-admin profile তৈরি করবে; নির্ধারিত Admin account-কে আলাদা করে promote করুন।
6. `supabase/migrations/20261110170000_tenant_scoped_erp_state.sql` চালান।
7. `supabase/migrations/20261110180000_audit_project_and_storage_events.sql` চালান।
8. Admin দিয়ে sign in করে Cloud Integration যাচাই করুন।

### আগে থেকে চালু project

1. Database backup নিন এবং বর্তমান schema/migration history যাচাই করুন। Existing project-এ initial setup migration চালাবেন না।
2. Baseline ERP migrations ও `profiles`, `team_project_members`, `audit_log` schema আছে নিশ্চিত করুন।
3. `20261110161000` → `20261110170000` → `20261110180000` এই ক্রমে চালান।
4. Tenant migration পুরনো snapshot/history-এর owner নিশ্চিত করতে না পারলে থেমে যাবে। তখন অনুমান করে organization assign করবেন না; backup ও records মিলিয়ে ownership নির্ধারণ করুন।
5. SQL Editor-এ চালানোর আগে প্রতিটি migration backup/staging project-এ পরীক্ষা করুন।

## Supabase Auth Settings

Hosted Supabase Dashboard-এ আলাদাভাবে সেট করুন; `supabase/config.toml` শুধু local CLI stack-এর জন্য:

- Public email signup বন্ধ; user creation শুধু trusted Admin server API দিয়ে।
- Minimum password 12 characters এবং uppercase, lowercase, digit, symbol বাধ্যতামূলক। Leaked-password protection plan-এ থাকলে চালু করুন।
- Password-only handover flow-এ Admin MFA বাধ্যতামূলক নয়; শক্তিশালী password, CAPTCHA ও sign-in rate limit ব্যবহার করুন।
- CAPTCHA/Turnstile, sign-in rate limit এবং session expiry/inactivity timeout configure করুন। Local defaults: প্রতি IP-তে 5 মিনিটে 10 sign-in/sign-up request, 12 ঘণ্টা session timebox, 1 ঘণ্টা inactivity timeout।
- App domain ও প্রয়োজনীয় recovery redirect URL allowlist-এ যোগ করুন।
- Cloudflare WAF app-এর `/api/*` request রক্ষা করতে পারে; browser থেকে Supabase Auth-এ সরাসরি যাওয়া request Cloudflare দিয়ে যায় না। ওই endpoint-এর rate limit Supabase-এ configure করতে হবে।

Turnstile-এর public site key `public/app/team-cloud-config.js`-এ দিন। CAPTCHA secret Supabase Auth settings-এ দিন; source code-এ নয়।

## Cloudflare Worker Deploy

এটি static-only Pages site নয়; build-এ SSR/API route-সহ Cloudflare Worker তৈরি হয়। Cloudflare Workers-এ deploy command:

```bash
npm run deploy:cloudflare
```

এটি build এবং Nitro deploy চালায়। আগে Wrangler/Cloudflare-এ authenticate করে Worker secrets/bindings যোগ করুন।
- Build variables: `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`
- Worker runtime secrets/bindings: `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` কখনো `VITE_` prefix, browser bundle, Git, screenshot বা chat-এ দেবেন না।
- SSL/TLS mode Full (strict), Always Use HTTPS, HSTS, WAF এবং `/api/*` rate-limit rules Cloudflare dashboard-এ configure করুন।
- Custom domain DNS/SSL ready হওয়ার পর Supabase Auth redirect allowlist-এ সেই HTTPS origin যোগ করুন।

## Handover Verification

- Signed-out browser-এ login form দেখা যায় এবং ERP dashboard দেখা যায় না।
- Entry login-এর পর Access → Cloud Integration-এ একই Supabase session পাওয়া যায়; আলাদা করে আবার sign in দরকার নেই।
- Admin ও Manager login একই email/password session ব্যবহার করে; disabled user sign in করতে পারে না।
- দুটি আলাদা test company/user দিয়ে direct API request করে cross-company read/write প্রত্যাখ্যাত হয়।
- Foreman assigned project ছাড়া data/file access করতে পারে না; Finance ও account management access পায় না।
- Private bucket-এ unauthorized download/delete ব্যর্থ হয়; authorized signed URL স্বল্পমেয়াদি হয়।
- Audit log-এ account, project assignment ও file events-এর actor/company/action পাওয়া যায়।
- Public build-এ exact service-role key নেই।

## সীমাবদ্ধতা: Production-Ready বলার আগে

- ERP financial/project records এখনও tenant-scoped JSON snapshot-এ; per-record/module RLS নয়। Full multi-tenant SaaS-এর জন্য normalized company-owned tables ও data migration বাকি।
- চাওয়া ছয়টি role (`Super Admin`, `Company Admin`, `Manager`, `Accountant`, `Foreman`, `Employee`) আলাদা করে implement হয়নি; বর্তমান roles `admin`, `manager`, `accountant`, `auditor`, `staff`।
- Login success/failure audit ও temporary lockout এখনো সম্পূর্ণ নয়; Supabase Auth rate limit/CAPTCHA dashboard-এ চালু করতে হবে।
- RLS, Storage ও cross-company automated integration tests নেই। Existing 59 tests এগুলো প্রমাণ করে না।
- Migration 1610/1700/1800 live project-এ প্রয়োগ ও PostgreSQL-এ execute করে যাচাই করা হয়নি।

এই সীমাবদ্ধতাগুলো সমাধান ও security test pass না হওয়া পর্যন্ত সিস্টেমকে enterprise-secure হিসেবে ঘোষণা করবেন না।
