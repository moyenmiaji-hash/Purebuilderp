import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const src = readFileSync(path.resolve(__dirname, "../../public/app/progress-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const c = box["PBProgressCalc"];

describe("site progress formulas", () => {
  it("weights overall progress by BOQ value, not simple average", () => {
    const items = [{ qty: 100, rate: 10, executedQty: 100 }, { qty: 100, rate: 90, executedQty: 0 }];
    expect(c.weighted(items)).toBeCloseTo(10);
  });
  it("never shows remaining below zero or progress above 100%", () => {
    const r = c.itemCalc({ qty: 50, executedQty: 70 });
    expect(r.remaining).toBe(0);
    expect(r.pct).toBe(100);
  });
  it("planned % is straight-line between project start and end", () => {
    expect(c.planned("2026-01-01", "2026-01-11", "2026-01-06")).toBeCloseTo(50);
    expect(c.planned("", "2026-01-11", "2026-01-06")).toBeNull();
  });
  it("keeps quantities of different units separate", () => {
    const u = c.byUnit([{ unit: "SFT", qty: 10, executedQty: 4 }, { unit: "KG", qty: 5, executedQty: 5 }, { unit: "SFT", qty: 6, executedQty: 0 }]);
    expect(u.find((x: any) => x.unit === "SFT")).toMatchObject({ qty: 16, done: 4, remaining: 12 });
    expect(u.find((x: any) => x.unit === "KG")).toMatchObject({ qty: 5, done: 5, remaining: 0 });
  });
  it("groups weeks from Monday", () => {
    expect(c.periodKey("2026-10-30", "week")).toBe("2026-10-26");
    expect(c.periodKey("2026-10-30", "month")).toBe("2026-10");
  });
});

describe("schedule & manpower", () => {
  const C = c;
  it("delay: finished 3 days after plan", () => expect(C.delayDays("2026-10-10", "2026-10-13", 100, "2026-10-30")).toBe(3));
  it("delay: not finished, past plan end", () => expect(C.delayDays("2026-10-20", "", 50, "2026-10-30")).toBe(10));
  it("delay: finished early is 0", () => expect(C.delayDays("2026-10-20", "2026-10-15", 100, "2026-10-30")).toBe(0));
  it("labour cost and absent not counted", () => {
    const s = C.labourSummary([
      { workerId: "a", status: "Present", role: "Mason", rate: 100, overtime: 2, otRate: 10, hours: 8 },
      { workerId: "b", status: "Absent", role: "Helper", rate: 80 },
      { status: "Present", role: "General Labour", units: 3, rate: 50, hours: 8 },
    ]);
    expect(s.present).toBe(4); expect(s.absent).toBe(1); expect(s.skilled).toBe(1); expect(s.unskilled).toBe(3); expect(s.cost).toBe(270);
  });
});
