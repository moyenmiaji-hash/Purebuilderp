import { createFileRoute } from "@tanstack/react-router";
import { isStrongPassword, isUuid } from "@/lib/security";
import {
  authenticateActiveRequest,
  isAdmin,
  writeSecurityAudit,
} from "@/integrations/supabase/request-auth.server";

export const Route = createFileRoute("/api/staff-accounts")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const authResult = await authenticateActiveRequest(request);
        if (!authResult.ok) return authResult.response;
        const adminResult = await isAdmin(authResult.auth);
        if (adminResult === null) {
          return Response.json(
            { error: "Authorization is temporarily unavailable." },
            { status: 503 },
          );
        }
        if (!adminResult) {
          return Response.json({ error: "Only an Admin can see accounts." }, { status: 403 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: profiles, error: profileError } = await supabaseAdmin
          .from("profiles")
          .select("id, display_name, role, status")
          .eq("organization_id", authResult.auth.organizationId)
          .neq("role", "admin");
        if (profileError) {
          console.error("[Staff accounts] Could not load profiles.", profileError);
          return Response.json({ error: "Could not load accounts." }, { status: 500 });
        }
        const profileById = new Map((profiles || []).map((profile) => [profile.id, profile]));
        const { data: list, error: listError } = await supabaseAdmin.auth.admin.listUsers({
          page: 1,
          perPage: 1000,
        });
        if (listError) {
          console.error("[Staff accounts] Could not load Auth users.", listError);
          return Response.json({ error: "Could not load accounts." }, { status: 500 });
        }

        const users = list.users.flatMap((user) => {
          const profile = profileById.get(user.id);
          if (!profile) return [];
          const bannedUntil = (user as { banned_until?: string }).banned_until;
          const blockedByAuth = !!bannedUntil && new Date(bannedUntil) > new Date();
          return [
            {
              id: user.id,
              email: user.email,
              name: profile.display_name || "",
              role: profile.role,
              status: blockedByAuth || profile.status !== "active" ? "blocked" : "active",
              last_sign_in_at: user.last_sign_in_at,
              self: user.id === authResult.auth.userId,
            },
          ];
        });
        return Response.json({ data: users });
      },
      POST: async ({ request }) => {
        const authResult = await authenticateActiveRequest(request);
        if (!authResult.ok) return authResult.response;
        const adminResult = await isAdmin(authResult.auth);
        if (adminResult === null) {
          return Response.json(
            { error: "Authorization is temporarily unavailable." },
            { status: 503 },
          );
        }
        if (!adminResult) {
          return Response.json({ error: "Only an Admin can change accounts." }, { status: 403 });
        }
        if (Number(request.headers.get("content-length") || 0) > 16_384) {
          return Response.json({ error: "Request is too large." }, { status: 413 });
        }

        let value: unknown;
        try {
          value = await request.json();
        } catch {
          return Response.json({ error: "Bad request." }, { status: 400 });
        }
        if (typeof value !== "object" || value === null || Array.isArray(value)) {
          return Response.json({ error: "Bad request." }, { status: 400 });
        }
        const body = value as { user_id?: unknown; action?: unknown; password?: unknown };
        const userId = typeof body.user_id === "string" ? body.user_id : "";
        const action = body.action;
        if (!isUuid(userId)) {
          return Response.json({ error: "Bad user." }, { status: 400 });
        }
        if (action !== "block" && action !== "allow" && action !== "reset_password") {
          return Response.json({ error: "Choose a valid account action." }, { status: 400 });
        }
        if (userId === authResult.auth.userId && action !== "reset_password") {
          return Response.json({ error: "You cannot block your own account." }, { status: 400 });
        }
        if (
          action === "reset_password" &&
          (typeof body.password !== "string" || !isStrongPassword(body.password))
        ) {
          return Response.json(
            {
              error:
                "Password must be at least 12 characters and include upper/lowercase letters, a number, and a symbol.",
            },
            { status: 400 },
          );
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: target, error: targetError } = await supabaseAdmin
          .from("profiles")
          .select("id, organization_id, role, status")
          .eq("id", userId)
          .eq("organization_id", authResult.auth.organizationId)
          .maybeSingle();
        if (targetError) {
          console.error("[Staff accounts] Could not verify the target account.", targetError);
          return Response.json({ error: "Could not verify the target account." }, { status: 500 });
        }
        if (!target || target.role === "admin") {
          return Response.json(
            { error: "Only employee accounts in your company can be changed here." },
            { status: 404 },
          );
        }

        if (action === "block" || action === "reset_password") {
          const { error: profileError } = await supabaseAdmin
            .from("profiles")
            .update({ status: "inactive" })
            .eq("id", userId)
            .eq("organization_id", authResult.auth.organizationId);
          if (profileError) {
            console.error("[Staff accounts] Could not disable the target profile.", profileError);
            return Response.json({ error: "Could not disable the account." }, { status: 500 });
          }

          const update =
            action === "reset_password"
              ? await supabaseAdmin.auth.admin.updateUserById(userId, {
                  password: body.password as string,
                  ban_duration: "876000h",
                })
              : await supabaseAdmin.auth.admin.updateUserById(userId, { ban_duration: "876000h" });
          if (update.error) {
            console.error(
              "[Staff accounts] Supabase could not disable or reset the account.",
              update.error,
            );
            const { error: rollbackError } = await supabaseAdmin
              .from("profiles")
              .update({ status: target.status })
              .eq("id", userId)
              .eq("organization_id", authResult.auth.organizationId);
            if (rollbackError) {
              console.error(
                "[Staff accounts] Could not restore the profile after a failed account update.",
                rollbackError,
              );
            }
            return Response.json({ error: "Could not change the account." }, { status: 500 });
          }
        } else {
          const { error: authError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
            ban_duration: "none",
          });
          if (authError) {
            console.error("[Staff accounts] Supabase could not reactivate the account.", authError);
            return Response.json({ error: "Could not reactivate the account." }, { status: 500 });
          }
          const { error: profileError } = await supabaseAdmin
            .from("profiles")
            .update({ status: "active" })
            .eq("id", userId)
            .eq("organization_id", authResult.auth.organizationId);
          if (profileError) {
            console.error(
              "[Staff accounts] Could not reactivate the target profile.",
              profileError,
            );
            return Response.json(
              { error: "The login is unblocked, but the profile remains inactive." },
              { status: 500 },
            );
          }
        }

        const auditAction =
          action === "reset_password"
            ? "password_reset"
            : action === "block"
              ? "user_disabled"
              : "user_reactivated";
        const auditWarning = await writeSecurityAudit(
          authResult.auth.userId,
          authResult.auth.organizationId,
          auditAction,
          userId,
        );
        return Response.json({
          data: { ok: true, status: action === "allow" ? "active" : "blocked" },
          ...(auditWarning ? { warning: auditWarning } : {}),
        });
      },
    },
  },
});
