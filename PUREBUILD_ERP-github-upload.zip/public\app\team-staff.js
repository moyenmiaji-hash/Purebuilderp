import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const config = window.PURE_BUILD_CLOUD_CONFIG || {};
const form = document.getElementById("report-form");
const authCard = document.getElementById("auth-card");
const setupCard = document.getElementById("setup-card");
const inactiveCard = document.getElementById("inactive-card");
const attendanceForm = document.getElementById("attendance-form");
const userbar = document.getElementById("userbar");
const notice = document.getElementById("notice");
const authNotice = document.getElementById("auth-notice");
const submitButton = document.getElementById("submit-report");
const client = config.supabaseUrl && config.supabaseAnonKey
  ? createClient(config.supabaseUrl, config.supabaseAnonKey, { auth: { storageKey: "pb_foreman_auth" } })
  : null;
window.PB_STAFF_CLIENT = client;

let currentUser = null;
let currentProfile = null;
let projects = [];
let attendanceProjects = [];
let attendanceWorkers = [];
let attendanceRequestKey = "";
let attendanceRequestSignature = "";
let attendanceAlreadySubmitted = false;
let attendanceLoadId = 0;
let materialRequestKey = "";
let materialRequestSignature = "";
let equipmentLogKey = "";
let equipmentLogSignature = "";
let diaryEntryKey = "";
let diaryEntrySignature = "";
let boqById = new Map();
let activeDraft = null;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]);
}

function showNotice(message, type = "info") {
  const target = form.hidden ? authNotice : notice;
  target.textContent = message;
  target.className = message ? `notice show ${type}` : "notice";
}

function showAttendanceNotice(message, type = "info") {
  const target = document.getElementById("attendance-notice");
  target.textContent = message;
  target.className = message ? `notice show ${type}` : "notice";
}

function showFailure(message, error) {
  console.error(message, error);
  showNotice(message, "error");
}

function setBusy(busy) {
  submitButton.disabled = busy;
  submitButton.textContent = busy ? "Submitting securely…" : "Submit daily report";
}

function clearWorkerRows() {
  document.getElementById("worker-list").replaceChildren();
  updateLabourTotal();
}

function updateLabourTotal() {
  const n = (id) => Math.max(0, Math.floor(Number(document.getElementById(id).value) || 0));
  const total = n("labour-mason") + n("labour-helper") + n("labour-other");
  document.getElementById("labour-total").textContent = String(total);
  document.getElementById("worker-count").textContent = String(document.getElementById("worker-list").children.length);
}

function addWorkerRow() {
  const container = document.getElementById("worker-list");
  const row = document.createElement("div");
  row.className = "report-item";
  row.innerHTML = `<div class="report-item-head"><span>Worker</span><button class="remove" type="button">Remove</button></div>
    <div class="grid">
      <div class="field full"><label>Name *</label><input data-worker="name" required></div>
      <div class="field"><label>Trade</label><select data-worker="trade"><option>Mason</option><option>Helper</option><option>Other</option></select></div>
      <div class="field"><label>Hours</label><input data-worker="hours" type="number" min="0" step="0.25" value="8"></div>
    </div>`;
  row.querySelector(".remove").addEventListener("click", () => { row.remove(); updateLabourTotal(); });
  container.append(row);
  updateLabourTotal();
}

function workerValues() {
  return [...document.querySelectorAll("#worker-list .report-item")].map((row) => {
    const value = (key) => row.querySelector(`[data-worker="${key}"]`).value.trim();
    return { name: value("name"), trade: value("trade"), hours: Number(value("hours")) || 0 };
  }).filter((entry) => entry.name);
}
function fillProjectSelect() {
  const select = document.getElementById("project");
  select.innerHTML = '<option value="">Choose your site</option>';
  for (const project of projects) {
    const option = document.createElement("option");
    option.value = project.id;
    option.textContent = project.name;
    select.append(option);
  }
}

function projectLocationEntries(project, boqItems = []) {
  const locations = [];
  const tree = project?.metadata?.locations;
  if (Array.isArray(tree)) {
    for (const building of tree) {
      const floors = Array.isArray(building.floors) ? building.floors : [];
      if (!floors.length && building.name) locations.push({ building: building.name, floor: "", area: "" });
      for (const floor of floors) {
        const rooms = Array.isArray(floor.rooms) ? floor.rooms : [];
        if (!rooms.length && building.name && floor.name) {
          locations.push({ building: building.name, floor: floor.name, area: "" });
        }
        for (const room of rooms) {
          if (building.name && floor.name && room) {
            locations.push({ building: building.name, floor: floor.name, area: String(room) });
          }
        }
      }
    }
  }
  if (!locations.length) {
    for (const item of boqItems) {
      const metadata = item.metadata || {};
      const location = {
        building: String(metadata.building || ""),
        floor: String(metadata.floor || ""),
        area: String(metadata.area || ""),
      };
      if (Object.values(location).some(Boolean) &&
          !locations.some((entry) => entry.building === location.building &&
            entry.floor === location.floor && entry.area === location.area)) {
        locations.push(location);
      }
    }
  }
  return locations;
}

function fillReportLocationSelect(projectId, boqItems = []) {
  const select = document.getElementById("location-picker");
  const project = projects.find((entry) => entry.id === projectId);
  const entries = projectLocationEntries(project, boqItems);
  select.replaceChildren(new Option(entries.length ? "Choose a project location" : "No structured locations available", ""));
  for (const location of entries) {
    const value = encodeURIComponent(JSON.stringify(location));
    const label = [location.building, location.floor, location.area].filter(Boolean).join(" / ");
    select.add(new Option(label, value));
  }
}

function selectedReportLocation() {
  const value = document.getElementById("location-picker").value;
  if (!value) return null;
  try {
    return JSON.parse(decodeURIComponent(value));
  } catch (error) {
    console.error("Selected project location is invalid", error);
    return null;
  }
}

function locationMatchesBoqItem(item, location) {
  if (!location) return true;
  const metadata = item.metadata || {};
  // An empty level (e.g. a building chosen without floor/room) includes everything under it.
  const norm = (v) => String(v || "").replace(/\s+/g, " ").trim().toLowerCase();
  const same = (a, b) => !norm(b) || norm(a) === norm(b);
  return same(metadata.building, location.building) &&
    same(metadata.floor, location.floor) &&
    same(metadata.area, location.area);
}

function fillAttendanceProjectSelect() {
  const select = document.getElementById("attendance-project");
  select.innerHTML = '<option value="">Choose your site</option>';
  for (const project of attendanceProjects) {
    const option = document.createElement("option");
    option.value = project.id;
    option.textContent = project.name;
    select.append(option);
  }
  if (attendanceProjects.length === 1) {
    select.value = attendanceProjects[0].id;
    void loadAttendanceWorkers(select.value);
  }
}

async function loadAssignedProjects() {
  const { data: memberships, error: membershipError } = await client
    .from("team_project_members")
    .select("project_id, permissions")
    .eq("user_id", currentUser.id)
    .eq("status", "active");
  if (membershipError) throw membershipError;

  const activeMemberships = memberships || [];
  const projectIds = activeMemberships
    .filter((membership) => membership.permissions?.submit_progress !== false)
    .map((membership) => membership.project_id);
  const attendanceProjectIds = activeMemberships.map((membership) => membership.project_id);
  const allProjectIds = [...new Set([...projectIds, ...attendanceProjectIds])];
  if (!allProjectIds.length) {
    projects = [];
    attendanceProjects = [];
    fillProjectSelect();
    fillAttendanceProjectSelect();
    return;
  }

  const { data: projectRows, error: projectError } = await client
    .from("team_projects")
    .select("id, local_project_id, name, project_code, metadata")
    .in("id", allProjectIds)
    .eq("status", "active")
    .order("name");
  if (projectError) throw projectError;
  const activeRows = projectRows || [];
  const progressIds = new Set(projectIds);
  const attendanceIds = new Set(attendanceProjectIds);
  projects = activeRows.filter((project) => progressIds.has(project.id));
  attendanceProjects = activeRows.filter((project) => attendanceIds.has(project.id));
  fillProjectSelect();
  fillAttendanceProjectSelect();
}

function renderAttendanceWorkers() {
  const container = document.getElementById("attendance-workers");
  const empty = document.getElementById("attendance-empty");
  const submit = document.getElementById("submit-attendance");
  if (!container || !empty || !submit) return;
  if (!attendanceWorkers.length) {
    container.replaceChildren();
    empty.hidden = false;
    submit.disabled = true;
    return;
  }

  empty.hidden = true;
  container.innerHTML = `${attendanceWorkers.map((worker, index) => `
    <div class="attendance-worker" data-attendance-worker="${index}">
      <div class="attendance-worker-name">
        <b>${escapeHtml(worker.name)}</b>
        <small>${escapeHtml(worker.worker_code || worker.worker_legacy_id)} · ${escapeHtml(worker.role || "Worker")}</small>
      </div>
      <div class="field"><label for="attendance-status-${index}">Status *</label>
        <select id="attendance-status-${index}" data-attendance="status" required>
          <option value="">Choose status</option>
          <option>Present</option><option>Absent</option><option>Half-day</option><option>Leave</option>
        </select>
      </div>
      <div class="field"><label for="attendance-hours-${index}">Hours</label>
        <input id="attendance-hours-${index}" data-attendance="hours" type="number" inputmode="decimal" min="0" max="24" step="0.25" value="8">
      </div>
      <div class="field"><label for="attendance-overtime-${index}">Overtime</label>
        <input id="attendance-overtime-${index}" data-attendance="overtime" type="number" inputmode="decimal" min="0" max="24" step="0.25" value="0">
      </div>
      <div class="field full"><label for="attendance-remarks-${index}">Remarks (optional)</label>
        <input id="attendance-remarks-${index}" data-attendance="remarks" maxlength="2000" placeholder="Optional note">
      </div>
    </div>`).join("")}
    <div class="attendance-summary" id="attendance-summary"></div>`;
  container.querySelectorAll("[data-attendance='status']").forEach((select) => {
    select.addEventListener("change", () => {
      const row = select.closest(".attendance-worker");
      const hours = row.querySelector("[data-attendance='hours']");
      const overtime = row.querySelector("[data-attendance='overtime']");
      const isOff = select.value === "Absent" || select.value === "Leave";
      if (select.value === "Half-day" && hours.value === "8") hours.value = "4";
      if (isOff) {
        hours.value = "0";
        overtime.value = "0";
      }
      hours.disabled = isOff;
      overtime.disabled = isOff;
      updateAttendanceSummary();
      attendanceRequestKey = "";
      attendanceRequestSignature = "";
    });
  });
  container.querySelectorAll("input").forEach((input) => input.addEventListener("input", () => {
    attendanceRequestKey = "";
    attendanceRequestSignature = "";
  }));
  updateAttendanceSummary();
  submit.disabled = attendanceAlreadySubmitted;
}

function updateAttendanceSummary() {
  const summary = document.getElementById("attendance-summary");
  if (!summary) return;
  const statuses = [...document.querySelectorAll("[data-attendance='status']")].map((input) => input.value);
  const count = (status) => statuses.filter((value) => value === status).length;
  summary.textContent = `Workers: ${statuses.length} · Present: ${count("Present")} · Absent: ${count("Absent")} · Half-day: ${count("Half-day")} · Leave: ${count("Leave")}`;
}

async function loadAttendanceWorkers(projectId) {
  const loadId = ++attendanceLoadId;
  attendanceWorkers = [];
  attendanceAlreadySubmitted = false;
  attendanceRequestKey = "";
  attendanceRequestSignature = "";
  showAttendanceNotice("");
  renderAttendanceWorkers();
  const submit = document.getElementById("submit-attendance");
  const date = document.getElementById("attendance-date").value;
  if (!projectId || !date) return;
  submit.disabled = true;
  showAttendanceNotice("Loading assigned workers…");
  try {
    const [{ data: workers, error: workerError }, { data: existing, error: existingError }] = await Promise.all([
      client.rpc("get_assigned_attendance_workers", { p_project_id: projectId }),
      client.from("erp_site_attendance").select("id").eq("project_id", projectId)
        .eq("attendance_date", date).limit(1),
    ]);
    if (workerError) throw workerError;
    if (existingError) throw existingError;
    if (loadId !== attendanceLoadId) return;
    attendanceWorkers = workers || [];
    renderAttendanceWorkers();
    if (existing?.length) {
      attendanceAlreadySubmitted = true;
      submit.disabled = true;
      showAttendanceNotice("Attendance has already been recorded for this site and date. Contact a manager if a correction is needed.", "info");
    } else {
      showAttendanceNotice(attendanceWorkers.length ? "" : "No active assigned workers were found.", "info");
    }
  } catch (error) {
    if (loadId !== attendanceLoadId) return;
    submit.disabled = true;
    showAttendanceNotice(`Could not load assigned attendance workers: ${error.message || "Check your cloud access and migration setup."}`, "error");
  }
}

async function loadAttendanceHistory() {
  const container = document.getElementById("attendance-history");
  if (!container || !currentUser) return;
  container.textContent = "Loading your recent attendance submissions…";
  try {
    const { data: submissions, error: submissionError } = await client.from("erp_attendance_submissions")
      .select("id, project_id, project_legacy_id, attendance_date, created_at")
      .eq("submitted_by", currentUser.id)
      .order("attendance_date", { ascending: false })
      .limit(20);
    if (submissionError) throw submissionError;
    if (!submissions?.length) {
      container.textContent = "No attendance submissions yet.";
      return;
    }
    const { data: entries, error: entriesError } = await client.from("erp_site_attendance")
      .select("submission_id, worker_name, status, hours, overtime")
      .in("submission_id", submissions.map((submission) => submission.id));
    if (entriesError) throw entriesError;
    const entriesBySubmission = new Map();
    for (const entry of entries || []) {
      const rows = entriesBySubmission.get(entry.submission_id) || [];
      rows.push(entry);
      entriesBySubmission.set(entry.submission_id, rows);
    }
    container.innerHTML = submissions.map((submission) => {
      const rows = entriesBySubmission.get(submission.id) || [];
      const project = attendanceProjects.find((item) => item.id === submission.project_id);
      const totals = ["Present", "Absent", "Half-day", "Leave"].map((status) =>
        `${status}: ${rows.filter((row) => row.status === status).length}`
      ).join(" · ");
      return `<div class="attendance-history-row">
        <b>${escapeHtml(project?.name || submission.project_legacy_id)} · ${escapeHtml(submission.attendance_date)}</b>
        <div>${escapeHtml(rows.length)} worker(s) · ${escapeHtml(totals)}</div>
      </div>`;
    }).join("");
  } catch (error) {
    console.error("Attendance submission history could not be loaded", error);
    container.textContent = `Could not load attendance history: ${error.message || "Check your cloud access."}`;
  }
}

function collectAttendanceEntries() {
  return attendanceWorkers.map((worker, index) => ({
    worker_id: worker.worker_legacy_id,
    status: document.getElementById(`attendance-status-${index}`).value,
    hours: Number(document.getElementById(`attendance-hours-${index}`).value),
    overtime: Number(document.getElementById(`attendance-overtime-${index}`).value),
    remarks: document.getElementById(`attendance-remarks-${index}`).value.trim(),
  }));
}

async function submitAttendance(event) {
  event.preventDefault();
  if (!attendanceForm.reportValidity()) return;
  const projectId = document.getElementById("attendance-project").value;
  const project = attendanceProjects.find((item) => item.id === projectId);
  const attendanceDate = document.getElementById("attendance-date").value;
  const entries = collectAttendanceEntries();
  if (!project || !entries.length || entries.some((entry) =>
    !entry.status || !Number.isFinite(entry.hours) || entry.hours < 0 || entry.hours > 24 ||
    !Number.isFinite(entry.overtime) || entry.overtime < 0 || entry.overtime > 24
  )) {
    showAttendanceNotice("Choose an assigned site and valid attendance details for every worker.", "error");
    return;
  }

  const signature = JSON.stringify({ projectId, attendanceDate, entries });
  if (!attendanceRequestKey || attendanceRequestSignature !== signature) {
    attendanceRequestKey = crypto.randomUUID();
    attendanceRequestSignature = signature;
  }
  const button = document.getElementById("submit-attendance");
  button.disabled = true;
  button.textContent = "Submitting attendance…";
  try {
    const { data, error } = await client.rpc("submit_site_attendance", {
      p_project_id: projectId,
      p_attendance_date: attendanceDate,
      p_idempotency_key: attendanceRequestKey,
      p_entries: entries,
    });
    if (error) throw error;
    if (data?.saved !== true || !data.submissionId) {
      throw new Error("The server did not confirm that attendance was saved.");
    }
    attendanceAlreadySubmitted = true;
    button.disabled = true;
    await loadAttendanceHistory();
    showAttendanceNotice(`Attendance submitted for ${data.entryCount} worker(s). Reference: ${data.submissionId}`, "success");
  } catch (error) {
    showAttendanceNotice(`Attendance was not confirmed: ${error.message || "Check your connection and retry."}`, "error");
  } finally {
    button.textContent = "Submit daily attendance";
    button.disabled = attendanceAlreadySubmitted || !attendanceWorkers.length;
  }
}

function operationNotice(id, message, type = "info") {
  const target = document.getElementById(id);
  target.textContent = message;
  target.className = message ? `notice show ${type}` : "notice";
}

function fillOperationProjectSelects() {
  for (const id of ["material-project", "equipment-project", "diary-project"]) {
    const select = document.getElementById(id);
    select.innerHTML = '<option value="">Choose your site</option>';
    for (const project of projects) {
      const option = document.createElement("option");
      option.value = project.id;
      option.textContent = project.name;
      select.append(option);
    }
    if (projects.length === 1) select.value = projects[0].id;
  }
}

function addMaterialLine() {
  const container = document.getElementById("material-request-lines");
  if (container.children.length >= 100) {
    operationNotice("material-notice", "A request can contain no more than 100 material lines.", "error");
    return;
  }
  const row = document.createElement("div");
  row.className = "report-item";
  row.innerHTML = `<div class="report-item-head"><span>Requested material</span><button class="remove" type="button">Remove</button></div>
    <div class="grid">
      <div class="field full"><label>Material name *</label><input data-material="name" maxlength="200" required placeholder="Cement, rebar, aggregate"></div>
      <div class="field"><label>Item code (optional)</label><input data-material="code" maxlength="100"></div>
      <div class="field"><label>Unit *</label><input data-material="unit" maxlength="40" required placeholder="bags, kg, m³"></div>
      <div class="field"><label>Requested quantity *</label><input data-material="quantity" type="number" inputmode="decimal" min="0.0001" step="0.0001" required></div>
      <div class="field"><label>Line note</label><input data-material="note" maxlength="500"></div>
    </div>`;
  row.querySelector(".remove").addEventListener("click", () => {
    row.remove();
    materialRequestKey = "";
    materialRequestSignature = "";
  });
  row.querySelectorAll("input").forEach((input) => input.addEventListener("input", () => {
    materialRequestKey = "";
    materialRequestSignature = "";
  }));
  container.append(row);
}

function collectMaterialLines() {
  return [...document.querySelectorAll("#material-request-lines .report-item")].map((row) => ({
    item_name: row.querySelector('[data-material="name"]').value.trim(),
    item_code: row.querySelector('[data-material="code"]').value.trim(),
    unit: row.querySelector('[data-material="unit"]').value.trim(),
    requested_qty: Number(row.querySelector('[data-material="quantity"]').value),
    note: row.querySelector('[data-material="note"]').value.trim(),
  }));
}

function submissionKey(signature, currentKey, currentSignature) {
  return currentKey && currentSignature === signature
    ? currentKey
    : crypto.randomUUID();
}

async function loadOperationsHistory() {
  const [requestsResult, equipmentResult, diaryResult] = await Promise.all([
    client.from("site_material_requests")
      .select("id, project_id, request_date, review_status, review_note, remarks, created_at")
      .eq("requested_by", currentUser.id)
      .order("created_at", { ascending: false })
      .limit(10),
    client.from("site_equipment_logs")
      .select("project_id, entry_date, equipment_name, operating_hours, condition")
      .eq("submitted_by", currentUser.id)
      .order("entry_date", { ascending: false })
      .limit(10),
    client.from("site_diary_entries")
      .select("project_id, entry_date, work_summary")
      .eq("submitted_by", currentUser.id)
      .order("entry_date", { ascending: false })
      .limit(10),
  ]);
  if (requestsResult.error) throw requestsResult.error;
  if (equipmentResult.error) throw equipmentResult.error;
  if (diaryResult.error) throw diaryResult.error;

  const requests = requestsResult.data || [];
  const linesByRequest = new Map();
  if (requests.length) {
    const { data: lines, error } = await client.from("site_material_request_lines")
      .select("request_id, item_name, unit, requested_qty")
      .in("request_id", requests.map((request) => request.id));
    if (error) throw error;
    for (const line of lines || []) {
      const rows = linesByRequest.get(line.request_id) || [];
      rows.push(line);
      linesByRequest.set(line.request_id, rows);
    }
  }
  const projectName = (id) => projects.find((project) => project.id === id)?.name || "Assigned site";
  document.getElementById("material-history").innerHTML = requests.length
    ? requests.map((request) => {
      const lines = linesByRequest.get(request.id) || [];
      return `<div class="attendance-history-row"><b>${escapeHtml(projectName(request.project_id))} · ${escapeHtml(request.request_date)}</b>
        <div>${escapeHtml(lines.map((line) => `${line.item_name}: ${line.requested_qty} ${line.unit}`).join(" · "))}</div>
        <div>Status: ${escapeHtml(request.review_status)}${request.review_note ? ` · ${escapeHtml(request.review_note)}` : ""}</div></div>`;
    }).join("")
    : "No material requests yet.";
  document.getElementById("equipment-history").innerHTML = equipmentResult.data?.length
    ? equipmentResult.data.map((entry) => `<div class="attendance-history-row"><b>${escapeHtml(projectName(entry.project_id))} · ${escapeHtml(entry.entry_date)}</b>
        <div>${escapeHtml(entry.equipment_name)} · ${escapeHtml(entry.operating_hours)}h · ${escapeHtml(entry.condition)}</div></div>`).join("")
    : "No equipment logs yet.";
  document.getElementById("diary-history").innerHTML = diaryResult.data?.length
    ? diaryResult.data.map((entry) => `<div class="attendance-history-row"><b>${escapeHtml(projectName(entry.project_id))} · ${escapeHtml(entry.entry_date)}</b>
        <div>${escapeHtml(entry.work_summary)}</div></div>`).join("")
    : "No diary entries yet.";
}

async function submitMaterialRequest(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  if (!formElement.reportValidity()) return;
  const projectId = document.getElementById("material-project").value;
  const date = document.getElementById("material-date").value;
  const items = collectMaterialLines();
  if (!projects.some((project) => project.id === projectId) ||
      !items.length || items.length > 100 ||
      items.some((item) => !item.item_name || !item.unit || !Number.isFinite(item.requested_qty) || item.requested_qty <= 0)) {
    operationNotice("material-notice", "Choose an assigned site and enter valid material lines.", "error");
    return;
  }
  const remarks = document.getElementById("material-remarks").value.trim();
  const signature = JSON.stringify({ projectId, date, items, remarks });
  if (!materialRequestKey || materialRequestSignature !== signature) {
    materialRequestKey = submissionKey(signature, "", "");
    materialRequestSignature = signature;
  }
  const button = document.getElementById("submit-material-request");
  button.disabled = true;
  button.textContent = "Submitting request…";
  try {
    const { data, error } = await client.rpc("submit_site_material_request", {
      p_project_id: projectId,
      p_request_date: date,
      p_idempotency_key: materialRequestKey,
      p_items: items,
      p_remarks: remarks,
    });
    if (error) throw error;
    if (data?.saved !== true || !data.requestId) throw new Error("The server did not confirm the request was saved.");
    operationNotice("material-notice", `Material request submitted for review. Reference: ${data.requestId}`, "success");
    materialRequestKey = "";
    materialRequestSignature = "";
    formElement.reset();
    document.getElementById("material-request-lines").replaceChildren();
    addMaterialLine();
    document.getElementById("material-date").value = new Date().toISOString().slice(0, 10);
    if (projects.length === 1) document.getElementById("material-project").value = projects[0].id;
    await loadOperationsHistory();
  } catch (error) {
    console.error("Material request submission failed", error);
    operationNotice("material-notice", `Material request was not confirmed: ${error.message || "Check access and retry."}`, "error");
  } finally {
    button.disabled = false;
    button.textContent = "Submit material request";
  }
}

async function submitEquipmentLog(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  if (!formElement.reportValidity()) return;
  const projectId = document.getElementById("equipment-project").value;
  const project = projects.find((entry) => entry.id === projectId);
  const entry = {
    projectId,
    date: document.getElementById("equipment-date").value,
    name: document.getElementById("equipment-name").value.trim(),
    code: document.getElementById("equipment-code").value.trim(),
    hours: Number(document.getElementById("equipment-hours").value),
    condition: document.getElementById("equipment-condition").value,
    location: document.getElementById("equipment-location").value.trim(),
    remarks: document.getElementById("equipment-remarks").value.trim(),
  };
  if (!project || !Number.isFinite(entry.hours) || entry.hours < 0 || entry.hours > 24) {
    operationNotice("equipment-notice", "Choose an assigned site and operating hours from 0 to 24.", "error");
    return;
  }
  const signature = JSON.stringify(entry);
  if (!equipmentLogKey || equipmentLogSignature !== signature) {
    equipmentLogKey = submissionKey(signature, "", "");
    equipmentLogSignature = signature;
  }
  const button = document.getElementById("submit-equipment");
  button.disabled = true;
  try {
    const result = await client.from("site_equipment_logs").insert({
      organization_id: currentProfile.organization_id,
      project_id: project.id,
      local_project_id: project.local_project_id,
      submitted_by: currentUser.id,
      entry_date: entry.date,
      equipment_name: entry.name,
      equipment_code: entry.code || null,
      operating_hours: entry.hours,
      condition: entry.condition,
      location: entry.location,
      remarks: entry.remarks,
      idempotency_key: equipmentLogKey,
    }).select("id").single();
    let savedId = result.data?.id;
    if (result.error?.code === "23505") {
      const { data, error } = await client.from("site_equipment_logs").select("id")
        .eq("idempotency_key", equipmentLogKey).eq("submitted_by", currentUser.id).maybeSingle();
      if (error) throw error;
      savedId = data?.id;
    } else if (result.error) throw result.error;
    if (!savedId) throw new Error("The server did not confirm the equipment log was saved.");
    operationNotice("equipment-notice", `Equipment log saved. Reference: ${savedId}`, "success");
    equipmentLogKey = "";
    equipmentLogSignature = "";
    formElement.reset();
    document.getElementById("equipment-date").value = new Date().toISOString().slice(0, 10);
    if (projects.length === 1) document.getElementById("equipment-project").value = projects[0].id;
    await loadOperationsHistory();
  } catch (error) {
    console.error("Equipment log submission failed", error);
    operationNotice("equipment-notice", `Equipment log was not confirmed: ${error.message || "Check access and retry."}`, "error");
  } finally {
    button.disabled = false;
  }
}

async function submitDiaryEntry(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  if (!formElement.reportValidity()) return;
  const projectId = document.getElementById("diary-project").value;
  const project = projects.find((entry) => entry.id === projectId);
  const entry = {
    projectId,
    date: document.getElementById("diary-date").value,
    weather: document.getElementById("diary-weather").value.trim(),
    work: document.getElementById("diary-work").value.trim(),
    manpower: Number(document.getElementById("diary-manpower").value),
    delays: document.getElementById("diary-delays").value.trim(),
    safety: document.getElementById("diary-safety").value.trim(),
    visitors: document.getElementById("diary-visitors").value.trim(),
    remarks: document.getElementById("diary-remarks").value.trim(),
  };
  if (!project || !Number.isInteger(entry.manpower) || entry.manpower < 0 || entry.manpower > 10000 || !entry.work) {
    operationNotice("diary-notice", "Choose an assigned site, enter work performed, and provide a valid manpower count.", "error");
    return;
  }
  const signature = JSON.stringify(entry);
  if (!diaryEntryKey || diaryEntrySignature !== signature) {
    diaryEntryKey = submissionKey(signature, "", "");
    diaryEntrySignature = signature;
  }
  const button = document.getElementById("submit-diary");
  button.disabled = true;
  try {
    const result = await client.from("site_diary_entries").insert({
      organization_id: currentProfile.organization_id,
      project_id: project.id,
      local_project_id: project.local_project_id,
      submitted_by: currentUser.id,
      entry_date: entry.date,
      weather: entry.weather,
      work_summary: entry.work,
      manpower_count: entry.manpower,
      delays: entry.delays,
      safety_notes: entry.safety,
      visitors: entry.visitors,
      remarks: entry.remarks,
      idempotency_key: diaryEntryKey,
    }).select("id").single();
    let savedId = result.data?.id;
    if (result.error?.code === "23505") {
      const { data, error } = await client.from("site_diary_entries").select("id")
        .eq("idempotency_key", diaryEntryKey).eq("submitted_by", currentUser.id).maybeSingle();
      if (error) throw error;
      savedId = data?.id;
    } else if (result.error) throw result.error;
    if (!savedId) throw new Error("A diary entry for this site and date may already exist; check your recent entries.");
    operationNotice("diary-notice", `Daily diary saved. Reference: ${savedId}`, "success");
    diaryEntryKey = "";
    diaryEntrySignature = "";
    formElement.reset();
    document.getElementById("diary-date").value = new Date().toISOString().slice(0, 10);
    if (projects.length === 1) document.getElementById("diary-project").value = projects[0].id;
    await loadOperationsHistory();
  } catch (error) {
    console.error("Site diary submission failed", error);
    operationNotice("diary-notice", `Daily diary was not confirmed: ${error.message || "Check access and retry."}`, "error");
  } finally {
    button.disabled = false;
  }
}

async function loadBoq(projectId) {
  const container = document.getElementById("boq-progress-lines");
  container.replaceChildren();
  boqById = new Map();
  const addButton = document.getElementById("add-boq-progress");
  addButton.disabled = true;
  if (!projectId) {
    addBoqProgressRow();
    return;
  }

  const { data, error } = await client
    .from("team_boq_items")
    .select("id, local_boq_id, item_code, description, unit, quantity, completed_qty, remaining_qty, approved_completed_qty, metadata")
    .eq("project_id", projectId)
    .eq("is_active", true)
    .order("sort_order")
    .order("item_code");
  if (error) throw error;
  if (document.getElementById("project").value !== projectId) return;
  for (const item of data || []) {
    if (Number(item.remaining_qty) > 0) boqById.set(item.id, item);
  }
  fillReportLocationSelect(projectId, data || []);
  addButton.disabled = boqById.size === 0;
  addBoqProgressRow();
}

function addBoqProgressRow() {
  const container = document.getElementById("boq-progress-lines");
  const row = document.createElement("article");
  row.className = "report-item";
  row.innerHTML = `<div class="report-item-head"><span>BOQ work item</span><button class="remove" type="button" data-remove-progress>Remove</button></div>
    <div class="field"><label>Assigned BOQ item *</label><select data-boq-item required></select></div>
    <div class="grid">
      <div class="field"><label>Building / floor / room</label><input data-location readonly></div>
      <div class="field"><label>Category</label><input data-category readonly></div>
      <div class="field"><label>BOQ quantity</label><input data-total readonly></div>
      <div class="field"><label>Reported quantity (includes pending)</label><input data-reported readonly></div>
      <div class="field"><label>Engineer-approved quantity</label><input data-approved readonly></div>
      <div class="field"><label>Completed today *</label><input data-today type="number" min="0.0001" step="0.0001" required></div>
      <div class="field"><label>Remaining after today</label><input data-remaining readonly></div>
    </div>`;
  row.querySelector("[data-remove-progress]").addEventListener("click", () => {
    if (container.children.length === 1) {
      row.querySelector("[data-boq-item]").value = "";
      row.querySelector("[data-today]").value = "";
    } else {
      row.remove();
    }
    refreshBoqProgressRows();
  });
  container.append(row);
  refreshBoqProgressRows();
}

function refreshBoqProgressRows() {
  const rows = [...document.querySelectorAll("#boq-progress-lines .report-item")];
  const location = selectedReportLocation();
  const availableItems = [...boqById.values()].filter((item) => locationMatchesBoqItem(item, location));
  const availableIds = new Set(availableItems.map((item) => item.id));
  const selections = rows.map((row) => {
    const select = row.querySelector("[data-boq-item]");
    if (select.value && !availableIds.has(select.value)) {
      row.querySelector("[data-today]").value = "";
      return "";
    }
    return select.value;
  });
  rows.forEach((row, index) => {
    const select = row.querySelector("[data-boq-item]");
    const selectedId = selections[index];
    select.replaceChildren(new Option(
      availableItems.length ? "Choose a BOQ work item" : "No BOQ items at this location with remaining quantity",
      "",
    ));
    for (const item of availableItems) {
      const option = new Option(boqOptionLabel(item), item.id);
      option.disabled = selections.some((otherId, otherIndex) => otherIndex !== index && otherId === item.id);
      select.add(option);
    }
    select.value = selectedId;
    select.disabled = availableItems.length === 0;
    updateBoqProgressRow(row);
  });
}

function boqOptionLabel(item) {
  const metadata = item.metadata || {};
  const hierarchy = [metadata.building, metadata.floor, metadata.area].filter(Boolean).join(" / ");
  return `${item.item_code} — ${hierarchy ? `${hierarchy} · ` : ""}${metadata.category ? `${metadata.category} · ` : ""}${item.description}`;
}

function updateBoqProgressRow(row) {
  const select = row.querySelector("[data-boq-item]");
  const item = boqById.get(select.value);
  const metadata = item?.metadata || {};
  const quantity = row.querySelector("[data-today]");
  const today = Number(quantity.value) || 0;
  row.querySelector("[data-location]").value = [metadata.building, metadata.floor, metadata.area].filter(Boolean).join(" / ");
  row.querySelector("[data-category]").value = metadata.category || "";
  row.querySelector("[data-total]").value = item ? `${item.quantity ?? "—"} ${item.unit || ""}`.trim() : "";
  row.querySelector("[data-reported]").value = item ? `${item.completed_qty ?? 0} ${item.unit || ""}`.trim() : "";
  row.querySelector("[data-approved]").value = item ? `${item.approved_completed_qty ?? 0} ${item.unit || ""}`.trim() : "";
  row.querySelector("[data-remaining]").value = item
    ? `${Math.max(0, Number(item.remaining_qty) - today)} ${item.unit || ""}`.trim()
    : "";
  quantity.max = item ? String(item.remaining_qty) : "";
  if (item && today > Number(item.remaining_qty)) quantity.value = "";
  window.PBStages?.decorateRow(row, item);
}

function addReportMaterialRow() {
  const container = document.getElementById("report-material-lines");
  const row = document.createElement("article");
  row.className = "report-item";
  row.innerHTML = `<div class="report-item-head"><span>📦 Material</span><button class="remove" type="button">Remove</button></div>
    <div class="mat-dir"><label><input type="radio" name="dir-${Date.now()}${Math.random()}" value="In"> ⬇ In (came to site)</label><label><input type="radio" name="dir-x" value="Out" checked> ⬆ Out / Used</label><input type="hidden" data-material="direction" value="Out"></div>
    <div class="grid">
      <div class="field"><label>Material *</label><input data-material="item" maxlength="200" required list="pb-stock-items" placeholder="Choose from stock or type"></div>
      <div class="field"><label>Quantity *</label><input data-material="qty" type="number" min="0.0001" step="0.0001" required></div>
      <div class="field"><label>Unit *</label><input data-material="unit" maxlength="40" required placeholder="bag, kg, cft"></div>
      <div class="field"><label>Used for / location</label><input data-material="used-for" maxlength="200"></div>
    </div>`;
  const radios = row.querySelectorAll('.mat-dir input[type=radio]');
  const groupName = `dir-${crypto.randomUUID()}`;
  radios.forEach((r) => { r.name = groupName; r.addEventListener("change", () => { row.querySelector('[data-material="direction"]').value = r.value; row.dataset.dir = r.value; updateMatStock(row); }); });
  row.dataset.dir = "Out";
  const itemInput = row.querySelector('[data-material="item"]');
  itemInput.addEventListener("input", () => {
    const hit = currentStockItems().find((x) => x.name.toLowerCase() === itemInput.value.trim().toLowerCase());
    if (hit && !row.querySelector('[data-material="unit"]').value) row.querySelector('[data-material="unit"]').value = hit.unit || "";
    updateMatStock(row);
  });
  row.querySelector('[data-material="qty"]').addEventListener("input", () => updateMatStock(row));
  const info = document.createElement("div"); info.className = "mat-stock hint"; row.append(info);
  row.querySelector(".remove").addEventListener("click", () => row.remove());
  container.append(row);
}

function currentStockItems() {
  const project = projects.find((entry) => entry.id === document.getElementById("project")?.value);
  return Array.isArray(project?.metadata?.stock_items) ? project.metadata.stock_items : [];
}
function refreshStockDatalist() {
  let list = document.getElementById("pb-stock-items");
  if (!list) { list = document.createElement("datalist"); list.id = "pb-stock-items"; document.body.append(list); }
  list.innerHTML = currentStockItems().map((x) => `<option value="${escapeHtml(x.name)}">${escapeHtml(`${x.balance ?? 0} ${x.unit || ""} in stock`)}</option>`).join("");
}
function updateMatStock(row) {
  const info = row.querySelector(".mat-stock"); if (!info) return;
  const name = row.querySelector('[data-material="item"]').value.trim().toLowerCase();
  const hit = currentStockItems().find((x) => x.name.toLowerCase() === name);
  const qty = Number(row.querySelector('[data-material="qty"]').value) || 0;
  if (!hit) { info.textContent = name ? "New item (not in site stock list)." : ""; info.classList.remove("warn"); return; }
  const before = Number(hit.balance) || 0;
  const after = row.dataset.dir === "In" ? before + qty : before - qty;
  info.textContent = `Stock now ${before} ${hit.unit || ""} → after this ${after} ${hit.unit || ""}`;
  info.classList.toggle("warn", after < 0);
  if (after < 0) info.textContent += " ⚠ more than available";
}
window.PB_STOCK_INFO = (name) => currentStockItems().find((x) => x.name.toLowerCase() === String(name || "").trim().toLowerCase()) || null;

// ---------- Worker attendance inside the daily report ----------
let reportWorkers = [];
let reportWorkersLoad = 0;
async function loadReportWorkers(projectId) {
  const box = document.getElementById("rpt-att");
  refreshStockDatalist();
  if (!box) return;
  const load = ++reportWorkersLoad;
  reportWorkers = [];
  if (!projectId) { box.innerHTML = '<p class="hint">Choose your site first.</p>'; return; }
  box.innerHTML = '<p class="hint">Loading workers…</p>';
  try {
    const { data, error } = await client.rpc("get_assigned_attendance_workers", { p_project_id: projectId });
    if (error) throw error;
    if (load !== reportWorkersLoad) return;
    reportWorkers = data || [];
    renderReportWorkers();
  } catch (error) {
    console.error(error);
    box.innerHTML = '<p class="hint">Could not load the worker list. You can still use the counts above.</p>';
  }
}
function renderReportWorkers() {
  const box = document.getElementById("rpt-att");
  if (!reportWorkers.length) { box.innerHTML = '<p class="hint">No workers are listed for this site yet. Office adds them in Labour &amp; HR.</p>'; return; }
  const opt = (v) => `<option value="${v}">${v}</option>`;
  box.innerHTML = `<div class="att-bulk">
      <b>All workers at once</b>
      <div class="att-bulk-btns"><button type="button" data-bulk="Present" class="g">✓ All Present</button><button type="button" data-bulk="Absent" class="r">✗ All Absent</button><button type="button" data-bulk="Leave" class="a">🌴 All Leave</button><button type="button" data-bulk="Half Day" class="b">◐ All Half Day</button></div>
      <div class="att-bulk-row"><label>Hours<input id="att-all-hours" type="number" min="0" max="24" step="0.25" value="8"></label><label>Overtime<input id="att-all-ot" type="number" min="0" max="24" step="0.25" value="0"></label><button type="button" id="att-apply-hours" class="btn">Apply to all</button></div>
    </div>
    <div class="att-sum" id="att-sum"></div>
    ${reportWorkers.map((w, i) => `<div class="att-row" data-i="${i}" data-st="">
      <div class="att-av">${escapeHtml((w.name || "?").trim().charAt(0).toUpperCase())}</div>
      <div class="att-name"><b>${escapeHtml(w.name)}</b><small>${escapeHtml(w.worker_code || "")} · ${escapeHtml(w.role || "Worker")}</small></div>
      <span class="att-badge" data-badge>Not marked</span>
      <button type="button" class="att-upd" data-upd>✎ Update</button>
      <div class="att-edit" hidden>
        <input type="hidden" data-a="status" value="">
        <div class="att-sts">${["Present", "Absent", "Leave", "Half Day"].map((s) => `<button type="button" data-s="${s}">${s === "Half Day" ? "Half" : s}</button>`).join("")}</div>
        <label>Work hours<input data-a="hours" type="number" min="0" max="24" step="0.25" value="8"></label>
        <label>Overtime<input data-a="ot" type="number" min="0" max="24" step="0.25" value="0"></label>
        <button type="button" class="att-done" data-done>✓ Done</button>
        <button type="button" class="att-rm" data-rm style="margin-top:6px;background:transparent;border:1px solid #b91c1c;color:#fca5a5;border-radius:10px;padding:8px">🗑 Ask office to remove from site</button>
      </div>
    </div>`).join("")}`;
  box.addEventListener("click", (e) => {
    const r = e.target.closest(".att-row"); if (!r) return;
    if (e.target.closest("[data-upd]")) { const ed = r.querySelector(".att-edit"); ed.hidden = !ed.hidden; }
    else if (e.target.closest("[data-done]")) r.querySelector(".att-edit").hidden = true;
    else if (e.target.closest("[data-rm]")) {
      const on = r.dataset.rm !== "1";
      if (on && !confirm("Ask the office to remove this worker from the site? The office must approve.")) return;
      r.dataset.rm = on ? "1" : "";
      e.target.closest("[data-rm]").textContent = on ? "↩ Cancel remove request" : "🗑 Ask office to remove from site";
      const bd = r.querySelector("[data-badge]"); if (bd && on) bd.textContent = "Remove requested";
    }
    else if (e.target.closest("[data-s]")) { r.querySelector('[data-a="status"]').value = e.target.closest("[data-s]").dataset.s; fixRowHours(r); updateAttSum(); }
  });
  box.querySelectorAll("[data-bulk]").forEach((b) => b.onclick = () => {
    box.querySelectorAll('.att-row [data-a="status"]').forEach((s) => { s.value = b.dataset.bulk; });
    box.querySelectorAll(".att-row").forEach(fixRowHours); updateAttSum();
  });
  box.querySelector("#att-apply-hours").onclick = () => {
    const h = box.querySelector("#att-all-hours").value, o = box.querySelector("#att-all-ot").value;
    box.querySelectorAll('.att-row [data-a="hours"]').forEach((x) => { x.value = h; });
    box.querySelectorAll('.att-row [data-a="ot"]').forEach((x) => { x.value = o; });
    box.querySelectorAll(".att-row").forEach(fixRowHours); updateAttSum();
  };
  box.addEventListener("change", (e) => { const r = e.target.closest(".att-row"); if (r && e.target.dataset.a === "status") fixRowHours(r); updateAttSum(); });
  box.addEventListener("input", updateAttSum);
  updateAttSum();
}
function fixRowHours(row) {
  const st = row.querySelector('[data-a="status"]').value;
  row.dataset.st = st;
  const bd = row.querySelector("[data-badge]"); if (bd) bd.textContent = st || "Not marked";
  row.querySelectorAll("[data-s]").forEach((b) => b.classList.toggle("on", b.dataset.s === st));
  if (st === "Absent" || st === "Leave") { row.querySelector('[data-a="hours"]').value = 0; row.querySelector('[data-a="ot"]').value = 0; }
  if (st === "Half Day" && Number(row.querySelector('[data-a="hours"]').value) > 4) row.querySelector('[data-a="hours"]').value = 4;
}
function reportAttendanceValues() {
  return [...document.querySelectorAll("#rpt-att .att-row")].map((row) => {
    const w = reportWorkers[Number(row.dataset.i)];
    return {
      worker_id: w?.worker_legacy_id, name: w?.name || "", code: w?.worker_code || "", role: w?.role || "",
      status: row.querySelector('[data-a="status"]').value,
      hours: Number(row.querySelector('[data-a="hours"]').value) || 0,
      overtime: Number(row.querySelector('[data-a="ot"]').value) || 0,
    };
  }).filter((x) => x.worker_id && x.status);
}
window.PB_REPORT_ATTENDANCE = () => reportAttendanceValues();
function reportWorkerRemovals() {
  return [...document.querySelectorAll('#rpt-att .att-row[data-rm="1"]')].map((row) => {
    const w = reportWorkers[Number(row.dataset.i)];
    return w ? { worker_id: w.worker_legacy_id, name: w.name || "", code: w.worker_code || "" } : null;
  }).filter(Boolean);
}
function updateAttSum() {
  const el = document.getElementById("att-sum"); if (!el) return;
  const v = reportAttendanceValues(), c = (s) => v.filter((x) => x.status === s).length;
  const ot = v.reduce((a, x) => a + x.overtime, 0);
  const lt = document.getElementById("labour-total"); if (lt) lt.textContent = String(c("Present") + c("Half Day"));
  el.innerHTML = `<span class="g">Present <b>${c("Present")}</b></span><span class="b">Half <b>${c("Half Day")}</b></span><span class="r">Absent <b>${c("Absent")}</b></span><span class="a">Leave <b>${c("Leave")}</b></span><span>OT <b>${ot}h</b></span><span>Not marked <b>${reportWorkers.length - v.length}</b></span>`;
}

function reportMaterialValues() {
  return [...document.querySelectorAll("#report-material-lines .report-item")].map((row) => ({
    item: row.querySelector('[data-material="item"]').value.trim(),
    qty: Number(row.querySelector('[data-material="qty"]').value),
    unit: row.querySelector('[data-material="unit"]').value.trim(),
    usedFor: row.querySelector('[data-material="used-for"]').value.trim(),
    direction: row.querySelector('[data-material="direction"]')?.value === "In" ? "In" : "Out",
    location: document.getElementById("location").value.trim(),
  }));
}

function collectReportPayload(progressLines) {
  const count = (id) => Math.max(0, Math.floor(Number(document.getElementById(id).value) || 0));
  const att = reportAttendanceValues().filter((x) => x.status === "Present" || x.status === "Half Day");
  const byRole = (re) => att.filter((x) => re.test(x.role || "")).length;
  const useAtt = !(count("labour-mason") + count("labour-helper") + count("labour-other")) && att.length;
  const mason = useAtt ? byRole(/mason/i) : count("labour-mason");
  const helper = useAtt ? byRole(/helper/i) : count("labour-helper");
  const other = useAtt ? att.length - mason - helper : count("labour-other");
  const total = mason + helper + other;
  const category = [mason && `Mason ${mason}`, helper && `Helper ${helper}`, other && `Other ${other}`].filter(Boolean).join(", ");
  const boqLocations = [...new Set(progressLines.map(({ item }) => {
    const metadata = item.metadata || {};
    return [metadata.building, metadata.floor, metadata.area].filter(Boolean).join(" / ");
  }).filter(Boolean))];
  const enteredLocation = document.getElementById("location").value.trim();
  return {
    foreman: currentProfile.display_name,
    description: document.getElementById("description").value.trim(),
    location: enteredLocation || boqLocations.join("; "),
    notes: document.getElementById("remarks").value.trim(),
    boq_progress: progressLines.map(({ item, todayQty, stages }) => ({
      boq_item_id: item.id,
      local_boq_id: item.local_boq_id,
      today_qty: todayQty,
      ...(stages ? { stages } : {}),
    })),
    labour: {
      total,
      workers: total,
      mason,
      helper,
      other,
      category,
      hours: useAtt ? Math.max(...att.map((x) => x.hours)) : (Number(document.getElementById("labour-hours").value) || 0),
      overtime: useAtt ? att.reduce((a, x) => a + x.overtime, 0) : (Number(document.getElementById("labour-overtime").value) || 0),
      list: workerValues(),
    },
    materials: {
      received: reportMaterialValues().filter((m) => m.direction === "In"),
      used: reportMaterialValues().filter((m) => m.direction !== "In"),
    },
    attendance: reportAttendanceValues(),
    worker_remove: reportWorkerRemovals(),
    inspection: {
      quality_ok: document.getElementById("inspection-quality").checked,
      safety_issue: document.getElementById("inspection-safety").checked,
      remarks: document.getElementById("inspection-remarks").value.trim(),
    },
    photos: [],
  };
}

function safeFilename(name) {
  const extension = name.match(/\.(jpe?g|png|webp)$/i)?.[0]?.toLowerCase() || ".jpg";
  return `${crypto.randomUUID()}${extension}`;
}

// Phone photos are often >3 MB: resize to max 1600px JPEG before the size check.
async function shrinkPhoto(file) {
  try {
    if (!file.type.startsWith("image/") || file.size <= 1.5 * 1024 * 1024) return file;
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.8));
    if (!blob) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch { return file; }
}

async function uploadPhotos(report, files, payload) {
  const photos = [];
  for (const file of files) {
    const path = `${currentProfile.organization_id}/${report.project_id}/${report.id}/${safeFilename(file.name)}`;
    const { error } = await client.storage
      .from("site-progress-photos")
      .upload(path, file, { contentType: file.type, upsert: false });
    if (error) throw error;
    photos.push({
      path,
      content_type: file.type,
      size: file.size,
      original_name: file.name,
      taken_at: new Date().toISOString(),
    });
  }
  payload.photos = photos;
}

async function submitReport(event) {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const project = projects.find((entry) => entry.id === document.getElementById("project").value);
  const progressLines = [...document.querySelectorAll("#boq-progress-lines .report-item")].map((row) => {
    const item = boqById.get(row.querySelector("[data-boq-item]").value);
    const todayQty = Number(row.querySelector("[data-today]").value);
    return { item, todayQty, stages: window.PBStages?.rowStages(row) };
  });
  const photoFiles = await Promise.all([...document.getElementById("photos").files].map(shrinkPhoto));
  if (!project || !progressLines.length || progressLines.some(({ item, todayQty }) =>
    !item || todayQty <= 0 || todayQty > Number(item.remaining_qty)
  )) {
    showNotice("Choose an assigned site and BOQ work item(s), then enter each quantity within its remaining balance.", "error");
    return;
  }
  if (new Set(progressLines.map(({ item }) => item.id)).size !== progressLines.length) {
    showNotice("Each BOQ work item can only be included once in a daily report.", "error");
    return;
  }
  if (photoFiles.length > 8 || photoFiles.some((file) => file.size > 3 * 1024 * 1024)) {
    showNotice("Choose no more than 8 photos, with each photo at most 3 MB.", "error");
    return;
  }

  setBusy(true);
  try {
    const payload = collectReportPayload(progressLines);
    const date = document.getElementById("date").value;
    let report = activeDraft;
    if (!report) {
      const { data, error } = await client.from("site_progress_reports").insert({
        organization_id: currentProfile.organization_id,
        project_id: project.id,
        local_project_id: project.local_project_id,
        local_id: crypto.randomUUID(),
        report_date: date,
        created_by: currentUser.id,
        updated_by: currentUser.id,
        report_payload: payload,
      }).select("id, project_id").single();
      if (error) throw error;
      report = activeDraft = data;
    }

    await uploadPhotos(report, photoFiles, payload);
    const { error } = await client.from("site_progress_reports").update({
      report_date: date,
      updated_by: currentUser.id,
      report_payload: payload,
      review_status: "submitted",
    }).eq("id", report.id);
    if (error) throw error;

    activeDraft = null;
    form.reset();
    clearWorkerRows();
    document.getElementById("report-material-lines").replaceChildren();
    if (reportWorkers.length) renderReportWorkers();
    document.getElementById("date").value = new Date().toISOString().slice(0, 10);
    document.getElementById("project").value = project.id;
    document.getElementById("foreman").value = currentProfile.display_name;
    await loadBoq(project.id);
    showNotice("Report submitted. Your manager can now review it in Site Progress.", "success");
    await loadProgressReportHistory();
  } catch (error) {
    showFailure("The report could not be submitted. Check your connection and try again; if a draft was created, it remains private.", error);
  } finally {
    setBusy(false);
  }
}

async function loadProgressReportHistory() {
  const container = document.getElementById("progress-report-history");
  if (!currentUser || !container) return;
  container.textContent = "Loading your recent reports…";
  try {
    const { data, error } = await client.from("site_progress_reports")
      .select("id, local_project_id, report_date, report_payload, review_status, review_note")
      .eq("created_by", currentUser.id)
      .order("created_at", { ascending: false })
      .limit(20);
    if (error) throw error;
    if (!data?.length) {
      container.textContent = "No daily reports submitted yet.";
      return;
    }
    const projectNames = new Map(projects.map((project) => [project.local_project_id, project.name]));
    container.innerHTML = data.map((report) => {
      const payload = report.report_payload || {};
      const items = Array.isArray(payload.boq_progress) ? payload.boq_progress : [];
      const status = ["draft", "submitted", "approved", "rejected"].includes(report.review_status)
        ? report.review_status
        : "unknown";
      const workSummary = items.map((item) =>
        `${item.local_boq_id || item.boq_item_id}: ${item.today_qty || 0}`
      ).join(" · ");
      return `<article class="attendance-history-row">
        <div class="report-item-head"><b>${escapeHtml(projectNames.get(report.local_project_id) || "Assigned site")} · ${escapeHtml(report.report_date)}</b>
          <span class="pill ${status === "approved" ? "green" : status === "rejected" ? "red" : "amber"}">${escapeHtml(status === "rejected" ? "returned" : status === "submitted" ? "waiting" : status)}</span></div>
        <div class="hint">${escapeHtml(payload.description || workSummary || "Daily site progress")}</div>
        ${report.review_note ? `<div class="hint" style="color:${status === "rejected" ? "#fca5a5" : "#bbf7d0"};font-weight:700">Office note: ${escapeHtml(report.review_note)}</div>` : ""}
      </article>`;
    }).join("");
  } catch (error) {
    console.error("Foreman report history could not be loaded", error);
    container.textContent = `Could not load your reports: ${error.message || "Check your Cloud Team access."}`;
  }
}

async function showSignedIn(user) {
  currentUser = user;
  const { data: profile, error } = await client.from("profiles")
    .select("id, organization_id, display_name, role, status, permissions")
    .eq("id", user.id)
    .maybeSingle();
  if (error) throw error;
  if (!profile || profile.status !== "active") {
    authCard.hidden = true;
    form.hidden = true;
    attendanceForm.hidden = true;
    userbar.hidden = true;
    inactiveCard.hidden = false;
    return;
  }

  currentProfile = profile; window.PB_STAFF_PROFILE = profile; window.dispatchEvent(new Event("pb:staff-ready"));
  document.getElementById("foreman").value = profile.display_name;
  document.getElementById("user-name").textContent = `${profile.display_name} · ${profile.role}`;
  document.getElementById("date").value = new Date().toISOString().slice(0, 10);
  document.getElementById("attendance-date").value = new Date().toISOString().slice(0, 10);
  await loadAssignedProjects();
  fillOperationProjectSelects();
  for (const id of ["material-date", "equipment-date", "diary-date"]) {
    document.getElementById(id).value = new Date().toISOString().slice(0, 10);
  }
  await loadAttendanceHistory();
  try {
    await loadOperationsHistory();
  } catch (error) {
    console.error("Site operations history could not be loaded", error);
    for (const id of ["material-history", "equipment-history", "diary-history"]) {
      document.getElementById(id).textContent = `Could not load history: ${error.message || "Apply the site operations migration and check project access."}`;
    }
  }
  await loadProgressReportHistory();
  authCard.hidden = true;
  if (!projects.length && !attendanceProjects.length) {
    inactiveCard.querySelector("p").textContent = "This account has no active site assignment yet. Ask your administrator to assign a project before submitting reports.";
    inactiveCard.hidden = false;
    form.hidden = true;
    attendanceForm.hidden = true;
    document.getElementById("operations-forms").hidden = true;
  } else {
    inactiveCard.hidden = true;
    form.hidden = projects.length === 0;
    attendanceForm.hidden = attendanceProjects.length === 0;
    document.getElementById("operations-forms").hidden = projects.length === 0;
  }
  document.getElementById("progress-history").hidden = projects.length === 0;
  userbar.hidden = false;
}

async function start() {
  if (!client) {
    setupCard.hidden = false;
    return;
  }
  document.getElementById("add-worker").addEventListener("click", addWorkerRow);
  document.getElementById("add-boq-progress").addEventListener("click", addBoqProgressRow);
  document.getElementById("boq-progress-lines").addEventListener("change", (event) => {
    if (event.target.matches("[data-boq-item]")) refreshBoqProgressRows();
  });
  document.getElementById("boq-progress-lines").addEventListener("input", (event) => {
    const row = event.target.closest(".report-item");
    if (row && event.target.matches("[data-today]")) updateBoqProgressRow(row);
  });
  document.getElementById("add-report-material").addEventListener("click", addReportMaterialRow);
  document.getElementById("refresh-progress-history").addEventListener("click", () => {
    void loadProgressReportHistory();
  });
  document.getElementById("attendance-project").addEventListener("change", (event) => {
    void loadAttendanceWorkers(event.target.value);
  });
  document.getElementById("attendance-date").addEventListener("change", () => {
    void loadAttendanceWorkers(document.getElementById("attendance-project").value);
  });
  attendanceForm.addEventListener("submit", submitAttendance);
  document.getElementById("add-material-line").addEventListener("click", addMaterialLine);
  addMaterialLine();
  document.getElementById("material-request-form").addEventListener("submit", submitMaterialRequest);
  document.getElementById("equipment-form").addEventListener("submit", submitEquipmentLog);
  document.getElementById("diary-form").addEventListener("submit", submitDiaryEntry);
  ["labour-mason", "labour-helper", "labour-other"].forEach((id) => document.getElementById(id).addEventListener("input", updateLabourTotal));
  document.getElementById("project").addEventListener("change", async (event) => {
    activeDraft = null;
    document.getElementById("location-picker").replaceChildren(new Option("Choose a project location", ""));
    document.getElementById("location").value = "";
    try {
      await loadBoq(event.target.value);
    } catch (error) {
      showFailure("Could not load BOQ items for this site.", error);
    }
    void loadReportWorkers(event.target.value);
  });
  document.getElementById("location-picker").addEventListener("change", (event) => {
    const location = selectedReportLocation();
    document.getElementById("location").value = location
      ? [location.building, location.floor, location.area].filter(Boolean).join(" / ")
      : "";
    refreshBoqProgressRows();
  });
  form.addEventListener("submit", submitReport);
  document.getElementById("sign-in-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.currentTarget.querySelector("button[type=submit]");
    button.disabled = true;
    try {
      const captchaToken = window.PB_TURNSTILE
        ? await window.PB_TURNSTILE.getToken(document.getElementById("staff-captcha"))
        : undefined;
      const { data, error } = await client.auth.signInWithPassword({
        email: document.getElementById("email").value.trim(),
        password: document.getElementById("password").value,
        options: captchaToken ? { captchaToken } : undefined,
      });
      if (error) throw error;
      await showSignedIn(data.user);
    } catch (error) {
      const m = String(error?.message || "").toLowerCase();
      const why = m.includes("not confirmed") ? "This email is not confirmed yet. Click the link in your email or ask the Admin."
        : m.includes("invalid login") ? "Email or password is incorrect, or no staff account exists. The Admin must create it from the Access page."
        : m.includes("fetch") || m.includes("network") ? "No internet connection. Please try again."
        : (error?.message || "");
      showFailure(`Sign-in failed. ${why}`, error);
    } finally {
      button.disabled = false;
    }
  });
  document.getElementById("sign-out").addEventListener("click", async () => {
    const { error } = await client.auth.signOut();
    if (error) {
      showFailure("Could not sign out. Please try again.", error);
      return;
    }
    currentUser = null;
    currentProfile = null; window.PB_STAFF_PROFILE = null;
    projects = [];
    attendanceProjects = [];
    attendanceWorkers = [];
    attendanceAlreadySubmitted = false;
    attendanceLoadId += 1;
    activeDraft = null;
    form.reset();
    attendanceForm.reset();
    clearWorkerRows();
    document.getElementById("attendance-history").textContent = "Sign in to view your recent submissions.";
    for (const id of ["material-history", "equipment-history", "diary-history"]) {
      document.getElementById(id).textContent = "Sign in to view recent submissions.";
    }
    form.hidden = true;
    attendanceForm.hidden = true;
    document.getElementById("operations-forms").hidden = true;
    userbar.hidden = true;
    inactiveCard.hidden = true;
    authCard.hidden = false;
    showNotice("", "info");
  });

  const { data, error } = await client.auth.getSession();
  if (error) throw error;
  if (data.session?.user) await showSignedIn(data.session.user);
  else authCard.hidden = false;
  client.auth.onAuthStateChange((event, session) => {
    if (event === "SIGNED_OUT" && !session) {
      currentUser = null;
      currentProfile = null; window.PB_STAFF_PROFILE = null;
      projects = [];
      attendanceProjects = [];
      attendanceWorkers = [];
      attendanceAlreadySubmitted = false;
      attendanceLoadId += 1;
      activeDraft = null;
      form.hidden = true;
      attendanceForm.hidden = true;
      document.getElementById("operations-forms").hidden = true;
      userbar.hidden = true;
      inactiveCard.hidden = true;
      authCard.hidden = false;
    }
  });
}

start().catch((error) => {
  console.error("Staff portal initialization failed", error);
  setupCard.hidden = false;
  setupCard.querySelector(".hint").textContent = "The team workspace could not connect. Check the cloud configuration and connection, then reload this page.";
});
