import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const config = window.PURE_BUILD_CLOUD_CONFIG || {};
const api = window.PB_APP_API || {
  getData: () => (window.db || {}),
  getPage: () => window.page || "",
  getSelectedProject: () => window.selectedProject || "",
  setSelectedProject: (value) => { window.selectedProject = value; },
  openProjectDetail: (pid, tab) => window.projectDetail && window.projectDetail(pid, tab),
  getOpenProjectDetails: () => (document.querySelector('.project-dashboard') ? window.projectDetailsProjectId || '' : ''),
  getOpenProjectDetailsTab: () => window.projectDetailsTab || "",
};
const sharedAuthStorageKey = "pb_shared_auth";
const client = config.supabaseUrl && config.supabaseAnonKey
  ? createClient(config.supabaseUrl, config.supabaseAnonKey, { auth: { storageKey: sharedAuthStorageKey } })
  : null;
const entryClient = client;
window.PB_CLOUD_CLIENT = client;
window.PB_ENTRY_CLIENT = entryClient;

let session = null;
let profile = null;
let cloudProjects = [];
let cachedReports = [];
let reportLines = new Map();
let siteOperationData = { requests: [], requestLines: new Map(), equipment: [], diary: [] };
let siteOperationMessage = "";
let siteOperationProject = "";
let siteOperationLoadedAt = 0;
let siteOperationReviewer = false;
let boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
let boqAssignmentMessage = "";
let boqAssignmentProject = "";
let boqAssignmentLoadedAt = 0;
let lastLoadedProject = "";
let lastLoadedCloudProject = "";
let lastLoadedAt = 0;
let lastCloudBoqSyncAt = 0;
let cloudBoqSyncInFlight = false;
let cloudAttendanceRows = [];
window.PB_CLOUD_ATTENDANCE_ROWS = [];
let attendanceMessage = "";
let lastAttendanceKey = "";
let lastAttendanceAt = 0;
let attendanceFetchInFlight = false;
let progressMessage = "";
let panelMessage = "";
let panelError = false;
let projectReportRefreshTimer = 0;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]);
}

function appData() {
  return api.getData();
}

function toast(message) {
  const element = document.getElementById("toast");
  if (!element) return;
  element.textContent = message;
  element.classList.add("show");
  setTimeout(() => element.classList.remove("show"), 2600);
}

function showPanelMessage(message, error = false) {
  panelMessage = message;
  panelError = error;
  updateAccessPanel();
  if (typeof window.accessFit === "function") { window.accessFit(); setTimeout(() => window.accessFit(), 300); }
}

async function loadProfile(user) {
  const { data, error } = await client.from("profiles")
    .select("id, organization_id, display_name, role, status, permissions")
    .eq("id", user.id)
    .maybeSingle();
  if (error) throw error;
  if (!data || data.status !== "active") {
    throw new Error("This account has no active PURE_BUILD cloud profile. Complete the admin bootstrap or ask an administrator to confirm the invite.");
  }
  session = user;
  profile = data;
  window.PB_CLOUD_ROLE = data.role; window.PB_CLOUD_NAME = data.display_name || user.email || "";
  if (["admin", "manager"].includes(profile.role)) setTimeout(() => scheduleAutoSync(), 1000);
  const { data: projects, error: projectError } = await client.from("team_projects")
    .select("id, local_project_id, project_code, name, status")
    .eq("organization_id", profile.organization_id)
    .order("name");
  if (projectError) throw projectError;
  cloudProjects = projects || [];
}

function authMarkup() {
  if (!client) {
    return `<div class="panel" style="margin:0 0 12px;border-left:4px solid #d79b22">
      <b>Cloud team is not configured</b>
      <p class="muted" style="margin:6px 0">Set the Supabase project URL and public anon key in <code>team-cloud-config.js</code>, deploy the database migration and invite function, then bootstrap the first organization admin. Existing browser data stays local until you sync it.</p>
      <small>Setup guide: supabase/README.md</small>
    </div>`;
  }
  if (!session || !profile) {
    return `<div class="panel" style="margin:0 0 12px">
      <b>PURE_BUILD Cloud Team</b>
      <p class="muted" style="margin:6px 0">This is separate from the main ERP login. Sign in with the organization Admin or Manager cloud account to synchronize project references, invite staff, and review mobile reports. Admins must verify their authenticator code.</p>
      <form id="pb-cloud-login" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;align-items:end">
        <label class="field">Cloud email<input id="pb-cloud-email" type="email" autocomplete="username" required></label>
        <label class="field">Password<input id="pb-cloud-password" type="password" autocomplete="current-password" required></label>
        <div class="captcha"></div>
        <button class="btn primary" type="submit">Sign in to Cloud Team</button>
      </form>
      <div class="muted" style="margin-top:7px">An organization admin must first be bootstrapped using the steps in <code>supabase/README.md</code>.</div>
      <div class="muted" data-cloud-message style="margin-top:7px;color:${panelError ? "#b43a40" : "inherit"}">${escapeHtml(panelMessage)}</div>
    </div>`;
  }
  const permissionText = [
    profile.permissions?.manage_projects ? "manage projects" : "",
    profile.permissions?.manage_boq ? "manage BOQ" : "",
    profile.permissions?.invite_staff ? "invite staff" : "",
    profile.permissions?.review_progress ? "review progress" : "",
    profile.permissions?.manage_materials ? "manage materials" : "",
  ].filter(Boolean).join(" · ") || "assigned project access";
  return `<div class="panel" style="margin:0 0 12px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
      <div><b>Cloud team connected</b><div class="muted">${escapeHtml(profile.display_name)} · ${escapeHtml(profile.role)} · ${escapeHtml(permissionText)}</div></div>
      <button class="btn small" id="pb-cloud-signout" type="button">Sign out</button>
    </div>
    <div class="muted" data-cloud-message style="margin-top:7px;color:${panelError ? "#b43a40" : "inherit"}">${escapeHtml(panelMessage)}</div>
  </div>`;
}

function updateAccessPanel() {
  const panel = document.getElementById("pb-cloud-access");
  if (!panel) return;
  panel.innerHTML = authMarkup();
  panel.querySelector("#pb-cloud-login")?.addEventListener("submit", signIn);
  panel.querySelector("#pb-cloud-signout")?.addEventListener("click", signOut);
  if (!session || !profile || !client) return;
  panel.insertAdjacentHTML("beforeend", `<div class="panel" style="margin:0 0 12px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
      <div><b>Publish ERP project &amp; BOQ references</b><div class="muted">Only project and BOQ reference data is synchronized. Existing cloud completion totals are preserved.</div></div>
      <button class="btn primary" type="button" id="pb-cloud-sync">Sync projects &amp; BOQ</button>
    </div>
    <div class="muted" id="pb-sync-message" style="margin-top:7px"></div>
  </div>
  <div class="panel" style="margin:0 0 12px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
      <div><b>Publish assigned workforce</b><div class="muted">Sync worker IDs, names, trade, active status and site only. Payroll and contact details are excluded.</div></div>
      <button class="btn" type="button" id="pb-attendance-workers-sync">Sync HR workforce</button>
    </div>
    <div class="muted" id="pb-attendance-workers-message" style="margin-top:7px"></div>
  </div>
  <div class="panel" style="margin:0 0 12px">
    <b>Create staff account</b>
    <div class="muted" style="margin:5px 0 9px">This creates the Supabase login immediately and assigns the selected project. Staff can sign in to the mobile app with this email and password.</div>
    <form id="pb-cloud-invite" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;align-items:end">
      <label class="field">Name<input id="pb-invite-name" required maxlength="200"></label>
      <label class="field">Work email<input id="pb-invite-email" type="email" required></label>
      <label class="field">Password (12+ characters, upper/lowercase, number and symbol)<input id="pb-invite-password" type="password" minlength="12" maxlength="72" autocomplete="new-password" required></label>
      <label class="field">Account role<select id="pb-invite-role"><option value="staff">Employee / Foreman (project-limited)</option><option value="manager">Manager</option></select></label>
      <label class="field">Assigned project<select id="pb-invite-project" required><option value="">Select project</option>${cloudProjects.filter((p) => p.status === "active").map((p) => `<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)}</option>`).join("")}</select></label>
      <button class="btn primary" type="submit">Create staff account in Supabase</button>
    </form>
    <div class="muted" id="pb-invite-message" style="margin-top:7px"></div>
  </div>
  ${profile.role === "admin" ? `<div class="panel" style="margin:0 0 12px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
      <div><b>Logged-in accounts</b><div class="muted">Everyone who can sign in. Block = signed out and cannot log in until you allow again.</div></div>
      <button class="btn small" type="button" id="pb-staff-accounts-refresh">Refresh</button>
    </div>
    <div id="pb-staff-accounts" style="margin-top:8px;overflow:auto"></div>
  </div>` : ""}`);
  panel.querySelector("#pb-cloud-sync")?.addEventListener("click", syncReferences);
  panel.querySelector("#pb-attendance-workers-sync")?.addEventListener("click", syncAttendanceWorkers);
  panel.querySelector("#pb-cloud-invite")?.addEventListener("submit", inviteStaff);
  panel.querySelector("#pb-staff-accounts-refresh")?.addEventListener("click", loadStaffAccounts);
  loadStaffAccounts();
  window.accessFit?.();
}

async function signIn(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  try {
    const captchaToken = window.PB_TURNSTILE
      ? await window.PB_TURNSTILE.getToken(form.querySelector(".captcha"))
      : undefined;
    const { data, error } = await client.auth.signInWithPassword({
      email: form.querySelector("#pb-cloud-email").value.trim(),
      password: form.querySelector("#pb-cloud-password").value,
      options: captchaToken ? { captchaToken } : undefined,
    });
    if (error) throw error;
    const { data: account, error: accountError } = await client.from("profiles")
      .select("role,status").eq("id", data.user.id).maybeSingle();
    if (accountError || !account || account.status !== "active" || !["admin", "manager"].includes(account.role)) {
      await client.auth.signOut();
      throw new Error("Use an active organization Admin or Manager cloud account.");
    }
    await loadProfile(data.user);
    showPanelMessage("Cloud team sign-in successful.");
  } catch (error) {
    console.error("Cloud team sign-in failed", error);
    const message = document.querySelector("#pb-cloud-access [data-cloud-message]");
    if (message) message.textContent = error.message || "Sign-in failed. Verify your cloud account and password.";
  } finally {
    button.disabled = false;
    button.textContent = "Sign in to Cloud Team";
  }
}

async function signOut() {
  const { error } = await client.auth.signOut();
  if (error) {
    console.error("Cloud team sign-out failed", error);
    showPanelMessage("Sign out failed. Please try again.", true);
    return;
  }
  session = null;
  profile = null;
  cloudProjects = [];
  cachedReports = [];
  lastLoadedProject = "";
  lastLoadedCloudProject = "";
  cloudAttendanceRows = [];
  window.PB_CLOUD_ATTENDANCE_ROWS = [];
  lastAttendanceKey = "";
  lastAttendanceAt = 0;
  siteOperationData = { requests: [], requestLines: new Map(), equipment: [], diary: [] };
  siteOperationProject = "";
  siteOperationLoadedAt = 0;
  siteOperationReviewer = false;
  boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
  boqAssignmentProject = "";
  boqAssignmentLoadedAt = 0;
  showPanelMessage("Signed out of Cloud Team.");
  window.location.reload();
}

function localProjects() {
  return (appData().projects || []).filter((project) => project.id && project.name);
}

function localBoq() {
  return (appData().boq || []).filter((item) => item.id && item.projectId);
}

// Site stock list (name, unit, balance) so foremen can pick materials and see balance.
function projectStockItems(pid) {
  const data = appData();
  const map = new Map();
  const key = (n, u) => `${String(n || "").trim().toLowerCase()}|${String(u || "")}`;
  for (const m of data.materials || []) {
    if (!m?.name) continue;
    map.set(key(m.name, m.unit), { name: String(m.name).trim(), unit: String(m.unit || ""), balance: 0 });
  }
  for (const x of data.stock || []) {
    if (String(x.projectId) !== String(pid) || !x.item) continue;
    const k = key(x.item, x.unit);
    if (!map.has(k)) map.set(k, { name: String(x.item).trim(), unit: String(x.unit || ""), balance: 0 });
    map.get(k).balance += (x.direction === "In" ? 1 : -1) * (Number(x.qty) || 0);
  }
  return [...map.values()].map((x) => ({ ...x, balance: Math.round(x.balance * 1000) / 1000 })).slice(0, 500);
}

function attendanceWorkerRows() {
  const activeProjectIds = new Set(localProjects()
    .filter((project) => project.status === "Active")
    .map((project) => String(project.id)));
  return (appData().workers || [])
    .filter((worker) => worker.id && worker.projectId && activeProjectIds.has(String(worker.projectId)))
    .map((worker) => ({
      legacy_id: String(worker.id),
      project_legacy_id: String(worker.projectId),
      name: String(worker.name || "").trim(),
      worker_code: String(worker.workerId || worker.id),
      status: worker.status === "Inactive" ? "Inactive" : "Active",
      role: String(worker.role || "General Labour"),
      employment_category: String(worker.employmentCategory || ""),
    }));
}

async function syncAttendanceWorkers(event) {
  const button = event.currentTarget;
  const message = document.getElementById("pb-attendance-workers-message");
  button.disabled = true;
  message.textContent = "Synchronizing assigned workers…";
  try {
    const activeProjectIds = new Set(localProjects()
      .filter((project) => project.status === "Active")
      .map((project) => String(project.id)));
    const workers = (appData().workers || [])
      .filter((worker) => worker.id && worker.projectId && activeProjectIds.has(String(worker.projectId)))
      .map((worker) => ({
        legacy_id: String(worker.id),
        project_legacy_id: String(worker.projectId),
        name: String(worker.name || "").trim(),
        worker_code: String(worker.workerId || worker.id),
        status: worker.status === "Inactive" ? "Inactive" : "Active",
        role: String(worker.role || "General Labour"),
        employment_category: String(worker.employmentCategory || ""),
      }));
    const { data, error } = await client.rpc("sync_attendance_workers", { p_workers: workers });
    if (error) throw error;
    message.textContent = `${data} worker record(s) synchronized. Foremen can now mark active workers on their assigned sites.`;
  } catch (error) {
    console.error("Assigned workforce synchronization failed", error);
    message.textContent = `Workforce synchronization failed: ${error.message || "Check Labour & HR permissions and the attendance migration."}`;
  } finally {
    button.disabled = false;
  }
}

async function syncCloudBoqProgress(force = false) {
  if (!client || !session || !profile || cloudBoqSyncInFlight || (!force && Date.now() - lastCloudBoqSyncAt < 30_000)) return;
  const remoteProjects = cloudProjects.filter((project) => project.status === "active" && project.local_project_id);
  if (!remoteProjects.length) return;

  cloudBoqSyncInFlight = true;
  lastCloudBoqSyncAt = Date.now();
  try {
    const projectIds = remoteProjects.map((project) => project.id);
    const cloudItems = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await client.from("team_boq_items")
        .select("project_id, local_boq_id, quantity, approved_completed_qty")
        .in("project_id", projectIds)
        .eq("is_active", true)
        .order("project_id")
        .order("sort_order")
        .range(offset, offset + pageSize - 1);
      if (error) throw error;
      cloudItems.push(...(data || []));
      if (!data || data.length < pageSize) break;
    }

    const localProjectByRemoteId = new Map(remoteProjects.map((project) => [
      project.id,
      String(project.local_project_id),
    ]));
    const localByKey = new Map(localBoq().map((item) => [
      `${String(item.projectId)}|${String(item.id)}`,
      item,
    ]));
    const updates = [];
    for (const cloudItem of cloudItems) {
      const localProjectId = localProjectByRemoteId.get(cloudItem.project_id);
      const localItem = localByKey.get(`${localProjectId}|${cloudItem.local_boq_id}`);
      if (!localItem) continue;

      // Office-entered dated progress (room panel) is added on top of approved foreman progress.
      const officeQty = (Array.isArray(localItem.progressLog) ? localItem.progressLog : []).filter((p) => p && p.source === 'office').reduce((n, p) => n + (Number(p.qty) || 0), 0);
      const completedQty = Math.min(Number(localItem.qty) || 0, Number(cloudItem.approved_completed_qty) + officeQty);
      const localTotal = Number(localItem.qty);
      if (!Number.isFinite(completedQty) || completedQty < 0 || !Number.isFinite(localTotal) || completedQty > localTotal + 0.0001) {
        throw new Error(`Cloud progress for BOQ ${localItem.boqId || localItem.id} does not match its local quantity. Reconcile this BOQ before syncing.`);
      }
      if (Math.abs((Number(localItem.executedQty) || 0) - completedQty) > 0.0001) {
        updates.push({ item: localItem, previousQty: localItem.executedQty, completedQty });
      }
    }
    if (!updates.length) return;

    for (const update of updates) update.item.executedQty = update.completedQty;
    try {
      api.save();
    } catch (error) {
      for (const update of updates) update.item.executedQty = update.previousQty;
      throw error;
    }
    const openProjectId = api.getOpenProjectDetails?.();
    if (openProjectId) api.openProjectDetail(openProjectId, api.getOpenProjectDetailsTab?.() || "overview");
    else api.render();
  } finally {
    cloudBoqSyncInFlight = false;
  }
}

// Auto sync: whenever the ERP saves, quietly send projects & BOQ to the Cloud (office users only).
let autoSyncTimer = null;
let autoSyncBusy = false;
function scheduleAutoSync() {
  clearTimeout(autoSyncTimer);
  autoSyncTimer = setTimeout(async () => {
    if (autoSyncBusy || !session || !profile || !client) return;
    if (profile.permissions?.manage_projects !== true || profile.permissions?.manage_boq !== true) return;
    autoSyncBusy = true;
    try {
      await syncReferences({ currentTarget: null, auto: true });
      const rows = attendanceWorkerRows();
      if (rows.length) { const { error } = await client.rpc("sync_attendance_workers", { p_workers: rows }); if (error) console.warn("Worker auto-sync failed", error.message); }
    } catch (error) { console.warn("Auto-sync failed", error); } finally { autoSyncBusy = false; }
  }, 4000);
}
(function hookAutoSync() {
  let tries = 0;
  const t = setInterval(() => {
    tries += 1;
    if (typeof window.save === "function" && !window.save.__pbAutoSync) {
      const original = window.save;
      const wrapped = function (...args) { const r = original.apply(this, args); scheduleAutoSync(); return r; };
      wrapped.__pbAutoSync = true;
      window.save = wrapped;
      if (window.PB_APP_API) window.PB_APP_API.save = wrapped;
    }
    if (tries > 40) clearInterval(t);
  }, 500);
  // Also sync once right after an office user signs in, so staff always see the latest projects/BOQ/workers.
  let firstDone = false;
  const first = setInterval(() => {
    if (firstDone) return clearInterval(first);
    if (session && profile && client) { firstDone = true; clearInterval(first); scheduleAutoSync(); }
  }, 3000);
})();

async function syncReferences(event) {
  const auto = !!event?.auto;
  const button = event?.currentTarget || { disabled: false };
  const message = document.getElementById("pb-sync-message") || { textContent: "" };
  button.disabled = true;
  message.textContent = auto ? "Auto-syncing projects & BOQ…" : "Synchronizing project and BOQ references…";
  try {
    if (profile.permissions?.manage_projects !== true || profile.permissions?.manage_boq !== true) {
      throw new Error("Your cloud profile needs both manage_projects and manage_boq permissions to publish ERP references.");
    }
    const projects = localProjects();
    if (!projects.length) throw new Error("Create at least one local ERP project before synchronizing.");
    const projectRows = projects.map((project) => ({
      organization_id: profile.organization_id,
      local_project_id: String(project.id),
      project_code: String(project.projectCode || project.code || `PB-${project.id}`).slice(0, 80),
      name: String(project.name).trim().slice(0, 200),
      status: project.status === "Active" ? "active" : "archived",
      metadata: {
        client: String(project.client || "").slice(0, 200),
        description: String(project.description || "").slice(0, 2000),
        locations: Array.isArray(appData().projectLocations?.[String(project.id)])
          ? appData().projectLocations[String(project.id)]
          : [],
        stock_items: projectStockItems(project.id),
      },
    }));
    const { error: projectError } = await client.from("team_projects")
      .upsert(projectRows, { onConflict: "organization_id,local_project_id" });
    if (projectError) throw projectError;

    const { data: syncedProjects, error: lookupError } = await client.from("team_projects")
      .select("id, local_project_id")
      .eq("organization_id", profile.organization_id);
    if (lookupError) throw lookupError;
    const remoteByLocalId = new Map((syncedProjects || []).map((project) => [project.local_project_id, project.id]));
    const allLocalBoq = localBoq();
    const invalidBoq = allLocalBoq.find((item) =>
      !String(item.description || "").trim() ||
      !Number.isFinite(Number(item.qty)) ||
      Number(item.qty) < 0 ||
      (Number(item.executedQty) || 0) < 0 ||
      (Number(item.executedQty) || 0) > Number(item.qty)
    );
    if (invalidBoq) {
      throw new Error(`BOQ item ${invalidBoq.boqId || invalidBoq.id} has an invalid description, quantity, or completed quantity.`);
    }
    const activeLocalProjectIds = new Set(projects.filter((project) => project.status === "Active").map((project) => String(project.id)));
    const boqRows = allLocalBoq.flatMap((item) => {
      if (!activeLocalProjectIds.has(String(item.projectId))) return [];
      const projectId = remoteByLocalId.get(String(item.projectId));
      if (!projectId) return [];
      return [{
        organization_id: profile.organization_id,
        project_id: projectId,
        local_boq_id: String(item.id),
        item_code: String(item.boqId || item.itemCode || item.id).slice(0, 100),
        description: String(item.description).trim().slice(0, 2000),
        unit: item.unit ? String(item.unit).slice(0, 80) : null,
        quantity: Number(item.qty),
        sort_order: Number(item.sortOrder) || 0,
        // Staff only see BOQ that is approved (old items without status count as Approved).
        is_active: ["Approved", "Revised", ""].includes(String(item.status || "")),
        metadata: {
          status: String(item.status || "Approved").replace("Submitted", "Under Review"),
          category: String(item.category || "").slice(0, 120),
          building: String(item.building || "").slice(0, 160),
          floor: String(item.floor || "").slice(0, 160),
          area: String(item.area || "").slice(0, 200),
          ...(window.PBStages?.metaFor(item, appData()) || {}),
        },
      }];
    });
    if (boqRows.length) {
      const { data: existingBoq, error: existingBoqError } = await client.from("team_boq_items")
        .select("project_id, local_boq_id, completed_qty")
        .in("project_id", [...new Set(boqRows.map((item) => item.project_id))]);
      if (existingBoqError) throw existingBoqError;
      const existingKeys = new Set((existingBoq || []).map((item) => `${item.project_id}|${item.local_boq_id}`));
      const insertRows = boqRows.filter((item) => !existingKeys.has(`${item.project_id}|${item.local_boq_id}`))
        .map((item) => {
          const local = allLocalBoq.find((entry) => String(entry.id) === item.local_boq_id && remoteByLocalId.get(String(entry.projectId)) === item.project_id);
          const approved = Number(local?.executedQty) || 0;
          return { ...item, completed_qty: approved };
        });
      const updateRows = boqRows.filter((item) => existingKeys.has(`${item.project_id}|${item.local_boq_id}`));
      if (insertRows.length) {
        const { error: insertError } = await client.from("team_boq_items").insert(insertRows);
        if (insertError) throw insertError;
      }
      if (updateRows.length) {
        const { error: updateError } = await client.from("team_boq_items")
          .upsert(updateRows, { onConflict: "project_id,local_boq_id" });
        if (updateError) throw updateError;
      }
      // BOQ items deleted in the office app must disappear from the staff app too (cloud history kept, only hidden).
      const localKeys = new Set(boqRows.map((item) => `${item.project_id}|${item.local_boq_id}`));
      const stale = (existingBoq || []).filter((item) => !localKeys.has(`${item.project_id}|${item.local_boq_id}`));
      for (const pid of new Set(stale.map((item) => item.project_id))) {
        const ids = stale.filter((item) => item.project_id === pid).map((item) => item.local_boq_id);
        const { error: hideError } = await client.from("team_boq_items").update({ is_active: false }).eq("project_id", pid).in("local_boq_id", ids);
        if (hideError) console.warn("Could not hide deleted BOQ items", hideError.message);
      }
    }
    const { data: refreshedProjects, error: refreshError } = await client.from("team_projects")
      .select("id, local_project_id, project_code, name, status")
      .eq("organization_id", profile.organization_id)
      .order("name");
    if (refreshError) throw refreshError;
    cloudProjects = refreshedProjects || [];
    const projectSelect = document.getElementById("pb-invite-project");
    if (projectSelect) {
      projectSelect.innerHTML = `<option value="">Select project</option>${cloudProjects.filter((project) => project.status === "active").map((project) => `<option value="${escapeHtml(project.id)}">${escapeHtml(project.name)}</option>`).join("")}`;
    }
    message.textContent = `Synchronized ${projectRows.length} project(s) and ${boqRows.length} BOQ item(s). Existing remote reported and approved completion totals were not overwritten.`;
    if (!auto) { lastLoadedProject = ""; attachProgressPanel(); }
  } catch (error) {
    console.error("ERP project/BOQ synchronization failed", error);
    message.textContent = `Synchronization failed: ${error.message || "Check your cloud permissions and data."}`;
  } finally {
    button.disabled = false;
  }
}

// Logged-in cloud accounts list: Admin can block (sign out) or allow again.
async function staffAccountsCall(method, body) {
  const { data: sess } = await client.auth.getSession();
  const res = await fetch("/api/staff-accounts", {
    method,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${sess.session?.access_token || ""}` },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({ error: "Server did not answer." }));
  if (json?.error) throw new Error(json.error);
  if (json?.warning) alert(json.warning);
  return json.data;
}

async function loadStaffAccounts() {
  const box = document.getElementById("pb-staff-accounts");
  if (!box || profile?.role !== "admin") return;
  box.innerHTML = `<div class="muted">Loading accounts…</div>`;
  try {
    const users = await staffAccountsCall("GET");
    const when = (t) => (t ? new Date(t).toLocaleString() : "Never");
    box.innerHTML = `<table class="table" style="width:100%;font-size:13px"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Last login</th><th>Status</th><th></th></tr></thead><tbody>${users.map((u) => `<tr>
      <td>${escapeHtml(u.name || "—")}</td><td>${escapeHtml(u.email || "")}</td><td>${escapeHtml(u.role)}</td><td>${escapeHtml(when(u.last_sign_in_at))}</td>
      <td><span class="pill ${u.status === "active" ? "green" : "amber"}">${u.status === "active" ? "Active" : "Blocked"}</span></td>
      <td>${u.self ? `<span class="muted">You</span>` : u.status === "active"
        ? `<button type="button" class="btn small danger" data-acc-block="${escapeHtml(u.id)}">Sign out &amp; block</button>
          <button type="button" class="btn small" data-acc-reset="${escapeHtml(u.id)}">Reset password</button>
          <input type="password" data-reset-password="${escapeHtml(u.id)}" minlength="12" maxlength="72" autocomplete="new-password" placeholder="New strong password" hidden>
          <button type="button" class="btn small primary" data-acc-reset-confirm="${escapeHtml(u.id)}" hidden>Set password &amp; block</button>`
        : `<button type="button" class="btn small primary" data-acc-allow="${escapeHtml(u.id)}">Allow again</button>`}</td></tr>`).join("")}</tbody></table>`;
    box.querySelectorAll("[data-acc-block],[data-acc-allow],[data-acc-reset]").forEach((btn) => btn.addEventListener("click", async () => {
      const block = !!btn.dataset.accBlock;
      if (btn.dataset.accReset) {
        const password = box.querySelector(`[data-reset-password="${CSS.escape(btn.dataset.accReset)}"]`);
        const confirm = box.querySelector(`[data-acc-reset-confirm="${CSS.escape(btn.dataset.accReset)}"]`);
        password.hidden = false;
        confirm.hidden = false;
        password.focus();
        return;
      }
      if (block && !confirm("Sign out and block this account? You can Allow it again later.")) return;
      btn.disabled = true;
      try { await staffAccountsCall("POST", { user_id: btn.dataset.accBlock || btn.dataset.accAllow, action: block ? "block" : "allow" }); }
      catch (error) { alert(error.message); }
      loadStaffAccounts();
    }));
    box.querySelectorAll("[data-acc-reset-confirm]").forEach((btn) => btn.addEventListener("click", async () => {
      const userId = btn.dataset.accResetConfirm;
      const password = box.querySelector(`[data-reset-password="${CSS.escape(userId)}"]`);
      if (password.value.length < 12) { alert("Use a strong password of at least 12 characters."); return; }
      btn.disabled = true;
      try {
        await staffAccountsCall("POST", { user_id: userId, action: "reset_password", password: password.value });
      } catch (error) {
        alert(error.message);
        password.value = "";
      }
      loadStaffAccounts();
    }));
  } catch (error) {
    box.innerHTML = `<div class="muted">${escapeHtml(error.message)}</div>`;
  }
  window.accessFit?.();
}

async function inviteStaff(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector("button[type=submit]");
  const message = document.getElementById("pb-invite-message");
  const projectId = form.querySelector("#pb-invite-project").value;
  button.disabled = true;
  message.textContent = "Creating Supabase account and assigning project…";
  try {
    if (!profile.permissions?.invite_staff) throw new Error("Your cloud profile does not have invite_staff permission.");
    if (!projectId) throw new Error("Choose an assigned project for this staff member.");
    const { data: sess } = await client.auth.getSession();
    const inviteRes = await fetch("/api/invite-staff", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${sess.session?.access_token || ""}` },
      body: JSON.stringify({
        email: form.querySelector("#pb-invite-email").value.trim(),
        display_name: form.querySelector("#pb-invite-name").value.trim(),
        password: form.querySelector("#pb-invite-password").value,
        role: form.querySelector("#pb-invite-role").value,
        project_ids: [projectId],
      }),
    });
    const data = await inviteRes.json().catch(() => ({ error: "Server did not answer." }));
    if (data?.error) throw new Error(data.error);
    message.textContent = `Account created for ${data.data.email}. The administrator must share the initial password through a secure channel.`;
    if (data?.warning) message.textContent += ` ${data.warning}`;
    form.reset();
  } catch (error) {
    console.error("Staff invitation failed", error);
    message.textContent = `Invitation failed: ${error.message || "Check invite permissions and the deployed Edge Function."}`;
  } finally {
    button.disabled = false;
  }
}

function reportPayload(report) {
  return report.report_payload || {};
}

function canReview(projectId) {
  if (!profile) return false;
  if (profile.permissions?.review_progress === true) return true;
  return Boolean(cloudProjects.find((project) => project.id === projectId)?.can_review);
}

async function fetchReports(projectId, localProjectIdOverride = api.getSelectedProject(), containerId = "pb-cloud-reports") {
  if (!session || !profile) return;
  cachedReports = [];
  reportLines = new Map();
  const localProjectId = String(localProjectIdOverride || "");
  lastLoadedProject = localProjectId;
  lastLoadedAt = Date.now();
  const cloudProjectId = projectId || document.getElementById(containerId)?.dataset.cloudProjectId;
  const remoteProject = cloudProjects.find((project) => project.local_project_id === String(localProjectId))
    || cloudProjects.find((project) => project.id === String(cloudProjectId || ""));
  lastLoadedCloudProject = remoteProject?.id || "";
  if (!remoteProject) {
    progressMessage = "This site has not been synchronized to Cloud Team yet. Use Access → Sync projects & BOQ first.";
    renderCloudReports(containerId, localProjectId);
    return;
  }
  const message = document.getElementById(containerId === "pb-cloud-reports" ? "pb-progress-status" : `${containerId}-status`);
  progressMessage = "Loading authorized cloud reports…";
  if (message) message.textContent = progressMessage;
  try {
    const { data: membership, error: membershipError } = await client.from("team_project_members")
      .select("permissions")
      .eq("project_id", remoteProject.id)
      .eq("user_id", session.id)
      .eq("status", "active")
      .maybeSingle();
    if (membershipError) throw membershipError;
    remoteProject.can_review = membership?.permissions?.review_progress === true;

    const { data: reports, error: reportError } = await client.from("site_progress_reports")
      .select("id, project_id, local_project_id, local_id, report_date, created_by, report_payload, review_status, review_note, created_at")
      .eq("project_id", remoteProject.id)
      .order("report_date", { ascending: false })
      .limit(100);
    if (reportError) throw reportError;
    cachedReports = reports || [];
    reportLines = new Map();
    if (cachedReports.length) {
      const { data: lines, error: linesError } = await client.from("site_progress_report_boq_lines")
        .select("report_id, boq_item_id, local_boq_id, today_qty, previous_qty, total_qty, remaining_qty, percent")
        .in("report_id", cachedReports.map((report) => report.id));
      if (linesError) throw linesError;
      for (const line of lines || []) {
        const current = reportLines.get(line.report_id) || [];
        current.push(line);
        reportLines.set(line.report_id, current);
      }
      for (const report of cachedReports) {
        const payload = reportPayload(report);
        const photos = payload.photos || [];
        for (const photo of photos) {
          const { data: signed, error: signError } = await client.storage
            .from("site-progress-photos").createSignedUrl(photo.path, 600);
          if (signError) {
            console.error("Could not create a signed site photo URL", signError);
            photo.signed_url = "";
          } else {
            photo.signed_url = signed.signedUrl;
          }
        }
      }
    }
    lastLoadedProject = localProjectId;
    lastLoadedAt = Date.now();
    progressMessage = `${cachedReports.length} cloud report(s) for ${remoteProject.name}.`;
    const autoImported = importApprovedProjectReports(localProjectId);
    if (autoImported) progressMessage += ` ${autoImported} approved report(s) automatically added to the project activity.`;
    if (message) message.textContent = progressMessage;
    renderCloudReports(containerId, localProjectId);
  } catch (error) {
    console.error("Cloud site reports could not be loaded", error);
    progressMessage = `Could not load reports: ${error.message || "Check your cloud access."}`;
    if (message) message.textContent = progressMessage;
    renderCloudReports(containerId, localProjectId);
  }
}

function importedReportIds() {
  const data = appData();
  if (!Array.isArray(data.cloudImportedReportIds)) data.cloudImportedReportIds = [];
  return data.cloudImportedReportIds;
}

function importApprovedProjectReports(localProjectId) {
  const data = appData();
  const imported = importedReportIds();
  const eligible = cachedReports.filter((report) =>
    report.review_status === "approved" &&
    report.local_project_id === String(localProjectId) &&
    !imported.includes(report.id) &&
    (reportLines.get(report.id) || []).length > 0
  );
  let importedCount = 0;
  const snapshot = JSON.stringify(data);
  try {
    for (const report of eligible) {
      const allLines = reportLines.get(report.id) || [];
      // Import what can be matched; a BOQ item deleted in the office app no longer blocks the whole report.
      const lines = allLines.filter((line) => (data.boq || []).some((item) =>
        item.id === line.local_boq_id && item.projectId === localProjectId
      ));
      if (lines.length < allLines.length) console.warn(`Report ${report.id}: ${allLines.length - lines.length} BOQ line(s) skipped (item no longer in the office app).`);
      importReportRows(report, lines, localProjectId);
      imported.push(report.id);
      importedCount += 1;
    }
    if (!importedCount) return 0;
    api.save();
  } catch (error) {
    const restored = JSON.parse(snapshot);
    for (const key of Object.keys(data)) delete data[key];
    Object.assign(data, restored);
    throw error;
  }
  void syncCloudBoqProgress(true).catch((error) => {
    console.error("Approved foreman progress could not be synchronized to the project BOQ", error);
    toast(`Report details were saved, but BOQ progress sync failed: ${error.message || "Check the Cloud Team connection."}`);
  });
  if (api.getOpenProjectDetails?.() === localProjectId) api.openProjectDetail(localProjectId, "daily");
  return importedCount;
}

function renderCloudReports(containerId = "pb-cloud-reports", localProjectId = api.getSelectedProject()) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.dataset.projectId = String(localProjectId || "");
  if (!session || !profile) {
    container.innerHTML = `<div class="panel" style="margin:0"><b>Foreman mobile reports</b><p class="muted" style="margin:6px 0">Sign in to Cloud Team on the Access page to securely receive and review foreman submissions for this project.</p></div>`;
    return;
  }
  if (!cachedReports.length) {
    container.innerHTML = `<div class="panel" style="margin:0"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><b>Foreman mobile reports</b><button type="button" class="btn small" data-refresh-project-reports>Refresh reports</button></div><p class="muted" style="margin:6px 0">${escapeHtml(progressMessage || "No cloud reports are available for this project yet.")}</p></div>`;
    container.querySelector("[data-refresh-project-reports]")?.addEventListener("click", () => fetchReports("", localProjectId, containerId));
    return;
  }
  const imported = new Set(importedReportIds());
  container.innerHTML = `<div class="panel" style="margin:0">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
      <div><b>Foreman mobile reports</b><div class="muted">Submitted reports appear here. After approval, the report, labour and materials are automatically added to project activity and BOQ progress is synchronized.</div></div>
      <button type="button" class="btn small" id="pb-refresh-reports">Refresh reports</button>
    </div>
    <div id="${containerId === "pb-cloud-reports" ? "pb-progress-status" : `${containerId}-status`}" class="muted" style="margin:6px 0 10px"></div>
    <div style="display:grid;gap:9px">${cachedReports.map((report) => {
      const payload = reportPayload(report);
      const lines = reportLines.get(report.id) || [];
      const isImported = imported.has(report.id);
      const review = canReview(report.project_id);
      const materialIn = payload.materials?.received || payload.materialIn || [];
      const materialOut = payload.materials?.used || payload.materialOut || [];
      const labour = payload.labour || {};
      const photos = payload.photos || [];
      const inspection = payload.inspection || {};
      const stockNow = (item) => (appData().stock || []).filter((x) => String(x.projectId) === String(localProjectId) && String(x.item || "").trim().toLowerCase() === String(item.item || "").trim().toLowerCase() && String(x.unit || "") === String(item.unit || "")).reduce((a, x) => a + (x.direction === "In" ? 1 : -1) * (Number(x.qty) || 0), 0);
      const materialSummary = (items, dir) => items.map((item) => {
        const before = stockNow(item);
        const after = report.review_status === "approved" ? before : before + (dir === "In" ? 1 : -1) * (Number(item.qty) || 0);
        return `${item.item || "Material"}: ${item.qty || 0} ${item.unit || ""}` + (report.review_status === "approved" ? ` (stock now ${before})` : ` (stock ${before} → ${after}${after < 0 ? " ⚠" : ""})`);
      }).join(" · ");
      const att = Array.isArray(payload.attendance) ? payload.attendance : [];
      const attCount = (st) => att.filter((a) => a.status === st).length;
      const attLine = att.length ? `<div class="muted" style="margin-top:5px">Attendance: Present ${attCount("Present")} · Half Day ${attCount("Half Day")} · Absent ${attCount("Absent")} · Leave ${attCount("Leave")} · OT ${att.reduce((a, x) => a + (Number(x.overtime) || 0), 0)}h</div>` : "";
      const localBoq = (line) => (appData().boq || []).find((item) =>
        item.id === line.local_boq_id && item.projectId === localProjectId
      );
      const localItems = lines.map((line) => (appData().boq || []).find((item) =>
        item.id === line.local_boq_id && item.projectId === localProjectId
      ));
      const canImportDetails = lines.length > 0 && localItems.some(Boolean);
      return `<article data-report-card="${escapeHtml(report.id)}" style="border:1px solid #dfe7ef;border-radius:12px;padding:12px;background:var(--panel,#fff)">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap">
          <div><b>${escapeHtml(payload.description || "Daily Site Progress")}</b><div class="muted">${escapeHtml(report.report_date)} · ${escapeHtml(payload.foreman || "Staff member")} · Ref ${escapeHtml(report.id)}</div></div>
          <span class="pill ${report.review_status === "approved" ? "green" : report.review_status === "rejected" ? "amber" : ""}">${escapeHtml(report.review_status)}</span>
        </div>
        ${lines.map((line) => {
          const item = localBoq(line);
          const reportedTotal = Number(line.previous_qty || 0) + Number(line.today_qty || 0);
          const approvedTotal = Number(item?.executedQty || 0);
          return `<div class="muted" style="margin-top:7px"><b>${escapeHtml(item?.boqId || line.local_boq_id)} · ${escapeHtml(item?.description || "BOQ item")}</b> · Reported today ${escapeHtml(line.today_qty)} ${escapeHtml(item?.unit || "")} · Reported cumulative ${escapeHtml(reportedTotal)} / ${escapeHtml(line.total_qty)} (${escapeHtml(Number(line.percent || 0).toFixed(1))}%) · Approved overall ${escapeHtml(approvedTotal)} / ${escapeHtml(line.total_qty)} ${escapeHtml(item?.unit || "")}</div>`;
        }).join("")}
        ${payload.location ? `<div class="muted" style="margin-top:5px">Location: ${escapeHtml(payload.location)}</div>` : ""}
        ${labour.workers || labour.category ? `<div class="muted" style="margin-top:5px">Labour: ${escapeHtml(labour.category || "Crew")} · ${escapeHtml(labour.workers || 0)} workers · ${escapeHtml(labour.hours || 0)} hours</div>` : ""}
        ${attLine}
        ${materialIn.length ? `<div class="muted" style="margin-top:5px">Materials received: ${escapeHtml(materialSummary(materialIn, "In"))}</div>` : ""}
        ${materialOut.length ? `<div class="muted" style="margin-top:5px">Materials used: ${escapeHtml(materialSummary(materialOut))}</div>` : ""}
        ${inspection.quality_ok || inspection.safety_issue || inspection.remarks ? `<div class="muted" style="margin-top:5px">Inspection: ${inspection.quality_ok ? "Work quality checked" : "Quality not marked"} · ${inspection.safety_issue ? "Safety issue flagged" : "No safety issue flagged"}${inspection.remarks ? ` · ${escapeHtml(inspection.remarks)}` : ""}</div>` : ""}
        ${payload.notes ? `<div style="margin-top:7px">${escapeHtml(payload.notes)}</div>` : ""}
        ${report.review_note ? `<div class="muted" style="margin-top:6px">Review note: ${escapeHtml(report.review_note)}</div>` : ""}
        ${photos.length ? `<div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:8px">${photos.map((photo) => photo.signed_url
          ? `<a href="${escapeHtml(photo.signed_url)}" target="_blank" rel="noopener" class="btn small">${escapeHtml(photo.original_name || "View site photo")}</a>`
          : `<span class="muted">Photo unavailable</span>`).join("")}</div>` : ""}
        <div class="pb-rv-actions" style="display:flex;gap:7px;flex-wrap:wrap;margin-top:9px">
          ${review && report.review_status === "submitted" ? `<button type="button" class="btn small primary" data-review="approved" data-report="${escapeHtml(report.id)}">Approve</button><button type="button" class="btn small danger" data-review="rejected" data-report="${escapeHtml(report.id)}">Reject</button>` : ""}
          ${report.review_status === "approved" && !isImported ? `<span class="muted">${canImportDetails ? "Adding approved report to project activity…" : "Sync or restore the matching local BOQ item to finish automatic import."}</span>` : ""}
          ${isImported ? `<span class="pill green">Automatically added to project</span>` : ""}
        </div>
      </article>`;
    }).join("")}</div>
  </div>`;
  container.querySelector("[data-refresh-project-reports]")?.addEventListener("click", () => fetchReports("", localProjectId, containerId));
  container.querySelectorAll("[data-review]").forEach((button) => {
    button.addEventListener("click", () => reviewReport(button.dataset.report, button.dataset.review, localProjectId, containerId));
  });
  container.querySelectorAll("[data-import-report]").forEach((button) => {
    button.addEventListener("click", () => importReport(button.dataset.importReport, localProjectId, containerId));
  });
  const status = container.querySelector(containerId === "pb-cloud-reports" ? "#pb-progress-status" : `#${containerId}-status`);
  if (status && lastLoadedProject === String(localProjectId)) {
    status.textContent = `${cachedReports.length} cloud report(s). Submitted quantities are reserved; only approved quantities sync to the local ERP. Approved labour, materials and activity are added automatically when their BOQ links are available.`;
  }
  pbFocusReportCard(container);
}

// Dashboard "Check & Approve" -> open Site Progress on the waiting report and highlight it.
function pbFocusReportCard(container) {
  const id = window.pbFocusReport;
  if (!id || !container) return;
  const card = container.querySelector(`[data-report-card="${CSS.escape(id)}"]`);
  if (!card) return;
  window.pbFocusReport = "";
  pbReviewStyles();
  setTimeout(() => {
    card.scrollIntoView({ behavior: "smooth", block: "center" });
    card.classList.add("pb-rv-focus");
    setTimeout(() => card.classList.remove("pb-rv-focus"), 4200);
  }, 150);
}
window.PB_GO_APPROVE = (localProjectId, reportId) => {
  window.pbFocusReport = reportId || "";
  if (localProjectId) api.setSelectedProject(String(localProjectId));
  lastLoadedAt = 0;
  if (typeof window.setPage === "function") window.setPage("progress");
  api.render();
};

function pbReviewStyles() {
  if (document.getElementById("pb-rv-css")) return;
  const st = document.createElement("style");
  st.id = "pb-rv-css";
  st.textContent = `
.pb-rv-focus{animation:pbRvGlow 1.4s ease-in-out 3;border-color:#2f80ed!important}
@keyframes pbRvGlow{50%{box-shadow:0 0 0 5px #2f80ed44,0 10px 30px -10px #2f80ed88}}
.pb-rv-ov{position:fixed;inset:0;z-index:9000;background:#0b1626aa;backdrop-filter:blur(3px);display:grid;place-items:center;padding:16px;animation:pbRvFade .2s ease}
@keyframes pbRvFade{from{opacity:0}}
.pb-rv-box{width:min(720px,100%);max-height:calc(100vh - 32px);display:flex;flex-direction:column;background:var(--panel,#fff);color:var(--text,#17283d);border-radius:18px;box-shadow:0 30px 80px -20px #000a;overflow:hidden;animation:pbRvUp .28s cubic-bezier(.2,.9,.3,1.2)}
@keyframes pbRvUp{from{transform:translateY(24px) scale(.97);opacity:0}}
.pb-rv-head{padding:16px 20px;background:linear-gradient(110deg,#1677d6,#0aa597);color:#fff}
.pb-rv-head.rej{background:linear-gradient(110deg,#c2414a,#e0794a)}
.pb-rv-head h3{margin:0;font-size:18px;color:#fff}.pb-rv-head small{opacity:.9}
.pb-rv-body{padding:14px 20px;overflow:auto;display:grid;gap:10px}
.pb-rv-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.pb-rv-grid div{background:#f4f8fc;border:1px solid #e3ebf4;border-radius:10px;padding:8px}
.pb-rv-grid small{display:block;font-size:10px;color:#6b7c92;text-transform:uppercase;font-weight:800}
.pb-rv-grid b{font-size:13px;word-break:break-word}
.pb-rv-sec{border:1px solid #e3ebf4;border-radius:12px;padding:10px 12px}
.pb-rv-sec h4{margin:0 0 6px;font-size:13px}
.pb-rv-sec .muted{margin-top:4px!important}
.pb-rv-photos{display:flex;gap:8px;flex-wrap:wrap}
.pb-rv-photos img{width:92px;height:92px;object-fit:cover;border-radius:10px;border:1px solid #dfe7ef}
.pb-rv-body textarea{width:100%;box-sizing:border-box;min-height:64px;border:1px solid #cfdbe8;border-radius:10px;padding:8px;font:inherit}
.pb-rv-foot{display:flex;justify-content:flex-end;gap:8px;padding:12px 20px;border-top:1px solid #e3ebf4;flex-wrap:wrap}
.pb-rv-foot .btn{min-height:40px;padding:8px 16px}
.pb-rv-done{position:fixed;inset:0;z-index:9100;display:grid;place-items:center;background:#0b1626aa;animation:pbRvFade .2s ease;pointer-events:none}
.pb-rv-done .ring{width:150px;height:150px;border-radius:50%;display:grid;place-items:center;background:#fff;box-shadow:0 0 0 0 #16a34a66;animation:pbRvPop .5s cubic-bezier(.2,.9,.3,1.4) both,pbRvPulse 1.2s .4s ease-out 2}
.pb-rv-done.rej .ring{animation:pbRvPop .5s cubic-bezier(.2,.9,.3,1.4) both}
.pb-rv-done svg{width:86px;height:86px}
.pb-rv-done path{stroke-dasharray:80;stroke-dashoffset:80;animation:pbRvDraw .55s .35s ease forwards}
.pb-rv-done p{margin:14px 0 0;color:#fff;font-weight:800;font-size:20px;text-align:center;animation:pbRvUp .4s .5s both}
.pb-rv-done i{position:absolute;width:10px;height:14px;border-radius:3px;top:50%;left:50%;opacity:0;animation:pbRvConf 1.3s .35s ease-out forwards}
@keyframes pbRvPop{from{transform:scale(.2);opacity:0}}
@keyframes pbRvPulse{to{box-shadow:0 0 0 40px #16a34a00}}
@keyframes pbRvDraw{to{stroke-dashoffset:0}}
@keyframes pbRvConf{0%{opacity:1;transform:translate(-50%,-50%)}100%{opacity:0;transform:translate(var(--x),var(--y)) rotate(var(--r))}}
@media(max-width:640px){.pb-rv-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
body.dark-theme .pb-rv-grid div,body.dark-theme .pb-rv-sec{background:#13243a;border-color:#24405f}`;
  document.head.appendChild(st);
}

// Summary popup before Approve / Reject. Resolves to { decision, note } or null.
function pbReviewDialog(report, decision, localProjectId) {
  pbReviewStyles();
  const payload = reportPayload(report);
  const card = document.querySelector(`[data-report-card="${CSS.escape(report.id)}"]`);
  let detail = "";
  if (card) {
    const clone = card.cloneNode(true);
    clone.querySelector(".pb-rv-actions")?.remove();
    clone.querySelectorAll("a[href]").forEach((a) => {
      const img = document.createElement("a");
      img.href = a.href; img.target = "_blank"; img.rel = "noopener";
      img.innerHTML = `<img src="${escapeHtml(a.href)}" alt="${escapeHtml(a.textContent || "Site photo")}">`;
      a.replaceWith(img);
    });
    const photoRow = clone.querySelector("a[href]")?.parentElement;
    if (photoRow) photoRow.className = "pb-rv-photos";
    const first = clone.firstElementChild; first?.remove();
    detail = clone.innerHTML;
  }
  const lines = reportLines.get(report.id) || [];
  const att = Array.isArray(payload.attendance) ? payload.attendance : [];
  const mi = payload.materials?.received || payload.materialIn || [];
  const mo = payload.materials?.used || payload.materialOut || [];
  const pname = ((appData().projects || []).find((p) => String(p.id) === String(localProjectId))?.name) || "—";
  const isRej = decision === "rejected";
  return new Promise((resolve) => {
    const w = document.createElement("div");
    w.className = "pb-rv-ov";
    w.innerHTML = `<div class="pb-rv-box" role="dialog" aria-modal="true">
      <div class="pb-rv-head ${isRej ? "rej" : ""}"><h3>${isRej ? "✕ Reject this report?" : "✓ Check & Approve report"}</h3><small>${escapeHtml(payload.description || "Daily Site Progress")} · Ref ${escapeHtml(String(report.id).slice(0, 8))}</small></div>
      <div class="pb-rv-body">
        <div class="pb-rv-grid">
          <div><small>Project / Site</small><b>${escapeHtml(pname)}</b></div>
          <div><small>Date</small><b>${escapeHtml(report.report_date || "—")}</b></div>
          <div><small>Submitted by</small><b>${escapeHtml(payload.foreman || "Staff member")}</b></div>
          <div><small>Location</small><b>${escapeHtml(payload.location || "—")}</b></div>
          <div><small>BOQ items</small><b>${lines.length}</b></div>
          <div><small>Workers present</small><b>${att.filter((a) => a.status === "Present" || a.status === "Half Day").length || payload.labour?.workers || 0}</b></div>
          <div><small>Material In / Out</small><b>${mi.length} / ${mo.length}</b></div>
          <div><small>Photos</small><b>${(payload.photos || []).length}</b></div>
        </div>
        <div class="pb-rv-sec"><h4>Full details</h4>${detail || '<span class="muted">No extra details.</span>'}</div>
        <div><label style="font-size:12px;font-weight:800">${isRej ? "Reason for rejecting (required)" : "Approval note (optional)"}</label><textarea maxlength="4000" placeholder="${isRej ? "Why is this report rejected?" : "Note for the foreman (optional)"}"></textarea><div class="pb-rv-err" style="color:#c2414a;font-size:12px;min-height:16px"></div></div>
      </div>
      <div class="pb-rv-foot">
        <button type="button" class="btn" data-a="back">← Back</button>
        ${isRej ? `<button type="button" class="btn" data-a="approved">Approve instead</button><button type="button" class="btn danger" data-a="rejected">✕ Reject report</button>`
          : `<button type="button" class="btn danger" data-a="rejected">✕ Reject</button><button type="button" class="btn primary" data-a="approved">✓ Approve report</button>`}
      </div></div>`;
    const ta = w.querySelector("textarea"), err = w.querySelector(".pb-rv-err");
    const close = (v) => { w.remove(); document.removeEventListener("keydown", onKey); resolve(v); };
    const onKey = (e) => { if (e.key === "Escape") close(null); };
    document.addEventListener("keydown", onKey);
    w.addEventListener("click", (e) => {
      if (e.target === w) return close(null);
      const b = e.target.closest("[data-a]");
      if (!b) return;
      const a = b.dataset.a;
      if (a === "back") return close(null);
      const note = ta.value.trim();
      if (a === "rejected" && !note) {
        err.textContent = "Rejecting needs a reason.";
        w.querySelector(".pb-rv-head").classList.add("rej");
        ta.focus();
        return;
      }
      close({ decision: a, note });
    });
    document.body.appendChild(w);
    setTimeout(() => (isRej ? ta : w.querySelector('[data-a="approved"]'))?.focus(), 50);
  });
}

function pbReviewDone(decision) {
  pbReviewStyles();
  const ok = decision === "approved";
  const d = document.createElement("div");
  d.className = `pb-rv-done ${ok ? "" : "rej"}`;
  const colors = ["#16a34a", "#2f80ed", "#f59e0b", "#0aa597", "#e11d48", "#8b5cf6"];
  const conf = ok ? Array.from({ length: 28 }, (_, i) => {
    const ang = (i / 28) * Math.PI * 2, dist = 140 + Math.random() * 120;
    return `<i style="background:${colors[i % colors.length]};--x:calc(-50% + ${Math.round(Math.cos(ang) * dist)}px);--y:calc(-50% + ${Math.round(Math.sin(ang) * dist)}px);--r:${Math.round(Math.random() * 720)}deg"></i>`;
  }).join("") : "";
  d.innerHTML = `<div style="position:relative;display:grid;justify-items:center">${conf}<div class="ring">${ok
    ? '<svg viewBox="0 0 52 52"><path d="M14 27 l8 8 l16 -18" fill="none" stroke="#16a34a" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    : '<svg viewBox="0 0 52 52"><path d="M16 16 L36 36 M36 16 L16 36" fill="none" stroke="#c2414a" stroke-width="5" stroke-linecap="round"/></svg>'}</div><p>${ok ? "Approved! Added to Site Progress" : "Report rejected"}</p></div>`;
  document.body.appendChild(d);
  setTimeout(() => { d.style.transition = "opacity .4s"; d.style.opacity = "0"; }, 2000);
  setTimeout(() => d.remove(), 2450);
}

async function reviewReport(reportId, decision, localProjectId = api.getSelectedProject(), containerId = "pb-cloud-reports") {
  const report = cachedReports.find((item) => item.id === reportId);
  if (!report || !["approved", "rejected"].includes(decision)) return;
  const choice = await pbReviewDialog(report, decision, localProjectId);
  if (!choice) return;
  decision = choice.decision;
  const note = choice.note;
  if (decision === "rejected" && !note.trim()) {
    toast("Add a reason before rejecting this report.");
    return;
  }
  if (note.length > 4000) {
    toast("Review notes must be no more than 4,000 characters.");
    return;
  }
  try {
    const { error } = await client.from("site_progress_reports").update({
      review_status: decision,
      reviewed_by: session.id,
      reviewed_at: new Date().toISOString(),
      review_note: note.trim() || null,
    }).eq("id", reportId);
    if (error) throw error;
    pbReviewDone(decision);
    toast(`Report ${decision}.`);
    pbPending.at = 0;
    await syncCloudBoqProgress(true);
    await fetchReports("", localProjectId, containerId);
  } catch (error) {
    console.error("Cloud site report review failed", error);
    toast(`Review failed: ${error.message || "Check review permissions."}`);
  }
}

window.PB_LOAD_PROJECT_PROGRESS_REPORTS = async (localProjectId, containerId = "pb-project-cloud-reports") => {
  const container = document.getElementById(containerId);
  if (!container) return;
  const requestedProjectId = String(localProjectId || "");
  const remote = cloudProjects.find((project) => project.local_project_id === requestedProjectId)
    || cloudProjects.find((project) => project.id === requestedProjectId);
  const resolvedLocalProjectId = remote?.local_project_id || (remote ? "" : requestedProjectId);
  container.dataset.projectId = resolvedLocalProjectId;
  container.dataset.cloudProjectId = remote?.id || "";
  if (!client || !session || !profile) {
    renderCloudReports(containerId, resolvedLocalProjectId);
    return;
  }
  if (!remote) {
    progressMessage = "This project is not synchronized to Cloud Team. Use Access → Sync projects & BOQ first.";
    renderCloudReports(containerId, resolvedLocalProjectId);
    return;
  }
  if (projectReportRefreshTimer) clearInterval(projectReportRefreshTimer);
  projectReportRefreshTimer = window.setInterval(() => {
    const current = document.getElementById(containerId);
    if (!current || current.dataset.projectId !== resolvedLocalProjectId) {
      clearInterval(projectReportRefreshTimer);
      projectReportRefreshTimer = 0;
      return;
    }
    lastLoadedAt = 0;
    void fetchReports(remote.id, resolvedLocalProjectId, containerId);
  }, 30_000);
  if (lastLoadedProject === resolvedLocalProjectId && lastLoadedCloudProject === remote.id && Date.now() - lastLoadedAt < 30_000) {
    renderCloudReports(containerId, resolvedLocalProjectId);
    return;
  }
  await fetchReports(remote.id, resolvedLocalProjectId, containerId);
};

function importReportRows(report, lines, localProjectId) {
  const data = appData();
  try { window.PBStages?.applyReport(report, data); } catch (error) { console.error("Work stage update skipped", error); }
  const payload = reportPayload(report);
  const date = report.report_date;
  const labour = payload.labour || {};
  const materials = payload.materials || {};
  const materialIn = materials.received || payload.materialIn || [];
  const materialOut = materials.used || payload.materialOut || [];
  const localItems = lines.map((line) => (data.boq || []).find((item) => item.id === line.local_boq_id && item.projectId === localProjectId) || null);
  const attendanceList = Array.isArray(payload.attendance) ? payload.attendance : [];
  // When named attendance exists, the crew total is already counted there; avoid a double labour row.
  if (!attendanceList.length && (Number(labour.workers) > 0 || Number(labour.hours) > 0 || labour.category)) {
    data.labour.push({
      id: `cloud-${report.id}-labour`,
      date,
      projectId: localProjectId,
      worker: labour.category || "Site Crew",
      role: labour.category || "General Labour",
      units: Number(labour.workers) || 0,
      rate: 0,
      note: labour.remarks || "",
      hours: Number(labour.hours) || 0,
      overtime: Number(labour.overtime) || 0,
      sourceReportId: report.id,
    });
  }
  // Worker attendance from the foreman report -> Labour & HR (never overwrite a day already marked).
  for (const a of attendanceList) {
    if (!a.status) continue;
    const worker = (data.workers || []).find((w) => String(w.id) === String(a.worker_id))
      || (data.removedWorkers || []).find((w) => String(w.id) === String(a.worker_id))
      || { id: String(a.worker_id || a.code || a.name), name: a.name, role: a.role };
    if ((data.labour || []).some((x) => String(x.workerId) === String(worker.id) && x.date === date)) continue;
    const half = a.status === "Half Day";
    data.labour.push({
      id: `cloud-${report.id}-att-${worker.id}`,
      workerId: worker.id, worker: worker.name || a.name || "", projectId: localProjectId, date,
      status: half ? "Present" : a.status, halfDay: half || undefined,
      hours: Number(a.hours) || 0, overtime: Number(a.overtime) || 0,
      rate: Number(worker.rate) || 0, otRate: Number(worker.otRate) || 0,
      role: worker.role || a.role || "Labour", sourceReportId: report.id,
    });
  }
  // Foreman asked to remove workers from the site: office must confirm each one. Salary/ledger stay untouched.
  for (const r of Array.isArray(payload.worker_remove) ? payload.worker_remove : []) {
    const w = (data.workers || []).find((x) => String(x.id) === String(r.worker_id));
    if (!w) continue;
    if (!confirm(`Foreman asked to remove ${w.name || r.name} from this site. Remove? (Salary and ledger entries are kept.)`)) continue;
    data.removedWorkers = data.removedWorkers || [];
    data.removedWorkers.push({ ...w, removedAt: new Date().toISOString(), removedReason: "Foreman request (approved)", sourceReportId: report.id });
    data.workers = data.workers.filter((x) => x.id !== w.id);
  }
  for (const material of materialIn) {
    data.stock.push({
      id: `cloud-${report.id}-in-${data.stock.length}`,
      date, projectId: localProjectId, item: material.item, unit: material.unit || "",
      direction: "In", qty: Number(material.qty) || 0,
      note: `Supplier: ${material.supplier || "—"} | Challan: ${material.challan || "—"} | Vehicle: ${material.vehicle || "—"}`,
      sourceReportId: report.id,
    });
  }
  for (const material of materialOut) {
    data.stock.push({
      id: `cloud-${report.id}-out-${data.stock.length}`,
      date, projectId: localProjectId, item: material.item, unit: material.unit || "",
      direction: "Out", qty: Number(material.qty) || 0,
      note: `Used For: ${material.usedFor || "—"} | Location: ${material.location || "—"}`,
      sourceReportId: report.id,
    });
  }
  for (const [index, line] of lines.entries()) {
    const boq = localItems[index];
    data.progress.push({
      id: `cloud-${report.id}-${lines.indexOf(line)}`,
      date,
      projectId: localProjectId,
      title: payload.description || boq?.description || "Daily Site Progress",
      description: payload.description || "",
      percent: Number(line.percent) || 0,
      foreman: payload.foreman || "Staff member",
      photos: (payload.photos || []).length,
      note: payload.notes || "",
      boqId: line.local_boq_id,
      boqCode: boq?.boqId || line.local_boq_id,
      todayQty: Number(line.today_qty),
      previousQty: Number(line.previous_qty),
      totalCompleted: Number(line.previous_qty) + Number(line.today_qty),
      remainingQty: Number(line.remaining_qty),
      unit: boq?.unit || "",
      rate: Number(boq?.rate) || 0,
      location: payload.location || "",
      labourWorkers: Number(labour.workers) || 0,
      labourEntries: labour.workers || labour.hours || labour.category ? [{
        category: labour.category || "",
        workers: Number(labour.workers) || 0,
        hours: Number(labour.hours) || 0,
        overtime: Number(labour.overtime) || 0,
        remarks: labour.remarks || "",
      }] : [],
      materialIn,
      materialOut,
      photoData: [],
      sourceReportId: report.id,
    });
  }
}

async function importReport(reportId, localProjectId = api.getSelectedProject(), containerId = "pb-cloud-reports") {
  const report = cachedReports.find((item) => item.id === reportId);
  const lines = reportLines.get(reportId) || [];
  if (!report || report.review_status !== "approved" || !lines.length || report.local_project_id !== String(localProjectId)) {
    toast("Only approved reports with valid BOQ progress can be imported.");
    return;
  }
  const data = appData();
  const imported = importedReportIds();
  if (imported.includes(reportId)) {
    toast("This cloud report was already imported.");
    return;
  }
  try {
    importReportRows(report, lines, localProjectId);
    imported.push(reportId);
    api.save();
    toast("Approved cloud report added to project activity, labour and stock.");
    await syncCloudBoqProgress(true);
    if (containerId === "pb-cloud-reports") {
      api.render();
    } else {
      api.openProjectDetail(localProjectId, "daily");
      void fetchReports("", localProjectId, containerId);
    }
  } catch (error) {
    console.error("Cloud site report import failed", error);
    toast(`Import failed: ${error.message}`);
  }
}

function attachAccessPanel() {
  if (api.getPage() !== "access") return;
  const view = document.getElementById("view");
  if (!view) return;
  let panel = document.getElementById("pb-cloud-access");
  if (!panel) {
    panel = document.createElement("section");
    panel.id = "pb-cloud-access";
    view.prepend(panel);
    const note = document.createElement("div");
    note.className = "notice";
    note.style.margin = "0 0 12px";
    note.innerHTML = "<b>Local access records are not login accounts.</b> Use Cloud Team below for real staff invitations and server-enforced project permissions.";
    panel.after(note);
  }
  updateAccessPanel();
}

function attachProgressPanel() {
  if (api.getPage() !== "progress") return;
  const view = document.getElementById("view");
  if (!view) return;
  let container = document.getElementById("pb-cloud-reports");
  if (!container) {
    container = document.createElement("section");
    container.id = "pb-cloud-reports";
    const siteBar = view.querySelector(".progress-sitebar");
    if (siteBar) siteBar.after(container);
    else view.prepend(container);
  }
  renderCloudReports();
  const projectId = String(api.getSelectedProject() || "");
  if (client && session && projectId && (lastLoadedProject !== projectId || Date.now() - lastLoadedAt > 60_000)) {
    void fetchReports(projectId);
  }
}

async function fetchBoqAssignments(remoteProject, localProjectId) {
  if (!client || !session || !profile || !remoteProject) return;
  boqAssignmentProject = localProjectId;
  boqAssignmentLoadedAt = Date.now();
  boqAssignmentMessage = "Loading BOQ assignments…";
  renderBoqAssignments();
  try {
    const [membersResult, itemsResult, assignmentsResult] = await Promise.all([
      client.rpc("get_project_boq_assignable_staff", { p_project_id: remoteProject.id }),
      client.from("team_boq_items")
        .select("id, local_boq_id, item_code, description, metadata, sort_order")
        .eq("project_id", remoteProject.id).eq("is_active", true)
        .order("sort_order").order("item_code"),
      client.from("site_boq_assignments")
        .select("boq_item_id, assigned_to")
        .eq("project_id", remoteProject.id),
    ]);
    if (String(api.getSelectedProject() || "") !== localProjectId) return;
    if (membersResult.error) {
      if (/not authorized/i.test(membersResult.error.message || "")) {
        boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
        boqAssignmentProject = localProjectId;
        boqAssignmentLoadedAt = Date.now();
        boqAssignmentMessage = "BOQ assignment management requires explicit manage_boq permission for this site.";
        renderBoqAssignments();
        return;
      }
      throw membersResult.error;
    }
    if (itemsResult.error) throw itemsResult.error;
    if (assignmentsResult.error) throw assignmentsResult.error;
    boqAssignmentData = {
      items: itemsResult.data || [],
      members: membersResult.data || [],
      assignments: assignmentsResult.data || [],
      canManage: true,
    };
    boqAssignmentProject = localProjectId;
    boqAssignmentLoadedAt = Date.now();
    boqAssignmentMessage = `Manage foreman assignments for ${boqAssignmentData.items.length} active BOQ item(s).`;
  } catch (error) {
    if (String(api.getSelectedProject() || "") !== localProjectId) return;
    console.error("BOQ foreman assignments could not be loaded", error);
    boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
    boqAssignmentMessage = `Could not load BOQ assignments: ${error.message || "Check manage_boq access and apply the site operations migration."}`;
    boqAssignmentProject = localProjectId;
    boqAssignmentLoadedAt = Date.now();
  }
  renderBoqAssignments();
}

function renderBoqAssignments() {
  const container = document.getElementById("pb-boq-assignments");
  if (!container) return;
  if (!session || !profile) {
    container.innerHTML = '<div class="panel" style="margin:0"><b>BOQ foreman assignments</b><p class="muted">Sign in to Cloud Team to manage authorized work assignments.</p></div>';
    return;
  }
  const members = boqAssignmentData.members || [];
  const assignments = boqAssignmentData.assignments || [];
  const selectedProject = String(api.getSelectedProject() || "");
  const localItems = new Map(localBoq().map((item) => [
    `${String(item.projectId)}|${String(item.id)}`,
    item,
  ]));
  container.innerHTML = `<div class="panel" style="margin:0">
    <div class="toolbar" style="justify-content:space-between"><div><b>BOQ foreman assignments</b>
      <div class="muted">Assign existing project staff to existing BOQ work items. Unassigned items remain visible to all authorized site members.</div></div>
      <button type="button" class="btn small" id="pb-refresh-boq-assignments">Refresh</button></div>
    <div class="muted" style="margin:6px 0 10px">${escapeHtml(boqAssignmentMessage || "BOQ assignment data is not loaded.")}</div>
    ${!boqAssignmentData.canManage ? "" : boqAssignmentData.items.length ? `<div style="display:grid;gap:8px">${boqAssignmentData.items.map((item) => {
      const assignedIds = assignments.filter((assignment) => assignment.boq_item_id === item.id).map((assignment) => assignment.assigned_to);
      const local = localItems.get(`${selectedProject}|${String(item.local_boq_id)}`);
      const metadata = item.metadata || {};
      const hierarchy = [metadata.building, metadata.floor, metadata.area].filter(Boolean).join(" / ");
      const chips = assignedIds.map((userId) => {
        const person = members.find((member) => member.user_id === userId);
        return `<span class="pill">${escapeHtml(person?.display_name || "Assigned foreman")} <button type="button" class="btn small" data-remove-boq-assignment="${escapeHtml(item.id)}" data-user="${escapeHtml(userId)}" aria-label="Remove assignment">×</button></span>`;
      }).join(" ");
      const options = members.filter((member) => !assignedIds.includes(member.user_id))
        .map((member) => `<option value="${escapeHtml(member.user_id)}">${escapeHtml(member.display_name)}</option>`).join("");
      return `<article style="border:1px solid #dfe7ef;border-radius:10px;padding:10px">
        <b>${escapeHtml(item.item_code)} · ${escapeHtml(item.description)}</b>
        <div class="muted">${escapeHtml([hierarchy, metadata.category, local?.unit].filter(Boolean).join(" · "))} · BOQ ${escapeHtml(local?.qty ?? "—")} ${escapeHtml(local?.unit || "")}</div>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:7px">${chips || '<span class="muted">No specific foreman assigned</span>'}</div>
        ${members.length ? `<div style="display:flex;gap:7px;align-items:end;flex-wrap:wrap;margin-top:8px"><label class="field" style="min-width:220px;flex:1">Assign staff<select class="select" data-assignee-for="${escapeHtml(item.id)}"><option value="">Choose an assigned foreman</option>${options}</select></label><button type="button" class="btn small primary" data-add-boq-assignment="${escapeHtml(item.id)}">Add assignment</button></div>` : '<div class="muted" style="margin-top:7px">No active staff members are assigned to this site.</div>'}
      </article>`;
    }).join("")}</div>` : '<div class="muted">No active BOQ items are synchronized for this site.</div>'}
  </div>`;
  container.querySelector("#pb-refresh-boq-assignments")?.addEventListener("click", () => {
    const remote = cloudProjects.find((project) => project.local_project_id === selectedProject);
    if (remote) void fetchBoqAssignments(remote, selectedProject);
  });
  container.querySelectorAll("[data-add-boq-assignment]").forEach((button) => {
    button.addEventListener("click", () => void addBoqAssignment(button.dataset.addBoqAssignment));
  });
  container.querySelectorAll("[data-remove-boq-assignment]").forEach((button) => {
    button.addEventListener("click", () => void removeBoqAssignment(button.dataset.removeBoqAssignment, button.dataset.user));
  });
}

async function addBoqAssignment(boqItemId) {
  const select = [...document.querySelectorAll("[data-assignee-for]")].find((node) => node.dataset.assigneeFor === boqItemId);
  const assignedTo = select?.value;
  const remote = cloudProjects.find((project) => project.local_project_id === String(api.getSelectedProject()));
  if (!remote || !assignedTo || !boqAssignmentData.canManage) return;
  try {
    const { error } = await client.from("site_boq_assignments").insert({
      organization_id: profile.organization_id,
      project_id: remote.id,
      boq_item_id: boqItemId,
      assigned_to: assignedTo,
      assigned_by: session.id,
    });
    if (error) throw error;
    await fetchBoqAssignments(remote, String(api.getSelectedProject()));
    toast("BOQ work item assigned to the foreman.");
  } catch (error) {
    console.error("BOQ foreman assignment failed", error);
    toast(`Could not assign BOQ item: ${error.message || "Check manage_boq access and project membership."}`);
  }
}

async function removeBoqAssignment(boqItemId, assignedTo) {
  const remote = cloudProjects.find((project) => project.local_project_id === String(api.getSelectedProject()));
  if (!remote || !assignedTo || !boqAssignmentData.canManage) return;
  try {
    const { error } = await client.from("site_boq_assignments").delete()
      .eq("project_id", remote.id).eq("boq_item_id", boqItemId).eq("assigned_to", assignedTo);
    if (error) throw error;
    await fetchBoqAssignments(remote, String(api.getSelectedProject()));
    toast("BOQ assignment removed.");
  } catch (error) {
    console.error("BOQ foreman assignment removal failed", error);
    toast(`Could not remove BOQ assignment: ${error.message || "Check manage_boq access."}`);
  }
}

function attachBoqAssignmentPanel() {
  if (api.getPage() !== "progress") return;
  const reports = document.getElementById("pb-cloud-reports");
  if (!reports) return;
  let container = document.getElementById("pb-boq-assignments");
  if (!container) {
    container = document.createElement("section");
    container.id = "pb-boq-assignments";
    reports.after(container);
  }
  if (!session || !profile) {
    renderBoqAssignments();
    return;
  }
  const localProjectId = String(api.getSelectedProject() || "");
  const remote = cloudProjects.find((project) => project.local_project_id === localProjectId);
  if (boqAssignmentProject !== localProjectId) {
    boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
    boqAssignmentMessage = remote
      ? "Loading BOQ assignments…"
      : "This project site is not synchronized to Cloud Team yet.";
  }
  renderBoqAssignments();
  if (remote && (boqAssignmentProject !== localProjectId || Date.now() - boqAssignmentLoadedAt > 60_000)) {
    void fetchBoqAssignments(remote, localProjectId);
  }
}

function canManageSiteMaterials(projectId) {
  if (!profile || !["admin", "manager"].includes(profile.role)) return false;
  const membership = siteOperationData.membership;
  return profile.permissions?.manage_materials === true ||
    (membership?.project_id === projectId && membership.permissions?.manage_materials === true);
}

async function fetchSiteOperations(projectId, localProjectIdOverride = null) {
  if (!client || !session || !profile || !projectId) return;
  const localProjectId = String(localProjectIdOverride ?? api.getSelectedProject() ?? "");
  const remoteProject = cloudProjects.find((project) =>
    project.id === projectId && project.local_project_id === localProjectId
  );
  if (!remoteProject) return;
  siteOperationMessage = "Loading project operations…";
  renderSiteOperations();
  try {
    const [membershipResult, requestsResult, equipmentResult, diaryResult] = await Promise.all([
      client.from("team_project_members").select("project_id, permissions")
        .eq("project_id", projectId).eq("user_id", session.id).eq("status", "active").maybeSingle(),
      client.from("site_material_requests")
        .select("id, project_id, requested_by, request_date, remarks, review_status, reviewed_by, reviewed_at, review_note, created_at")
        .eq("project_id", projectId).order("request_date", { ascending: false }).limit(50),
      client.from("site_equipment_logs")
        .select("id, submitted_by, entry_date, equipment_name, equipment_code, operating_hours, condition, location, remarks, created_at")
        .eq("project_id", projectId).order("entry_date", { ascending: false }).limit(50),
      client.from("site_diary_entries")
        .select("id, submitted_by, entry_date, weather, work_summary, manpower_count, delays, safety_notes, visitors, remarks, created_at")
        .eq("project_id", projectId).order("entry_date", { ascending: false }).limit(50),
    ]);
    if (membershipResult.error) throw membershipResult.error;
    if (requestsResult.error) throw requestsResult.error;
    if (equipmentResult.error) throw equipmentResult.error;
    if (diaryResult.error) throw diaryResult.error;
    const requests = requestsResult.data || [];
    const requestLines = new Map();
    if (requests.length) {
      const { data: lines, error } = await client.from("site_material_request_lines")
        .select("request_id, item_name, item_code, unit, requested_qty, note")
        .in("request_id", requests.map((request) => request.id));
      if (error) throw error;
      for (const line of lines || []) {
        const current = requestLines.get(line.request_id) || [];
        current.push(line);
        requestLines.set(line.request_id, current);
      }
    }
    siteOperationData = {
      requests,
      requestLines,
      equipment: equipmentResult.data || [],
      diary: diaryResult.data || [],
      membership: membershipResult.data,
    };
    siteOperationReviewer = canManageSiteMaterials(projectId);
    siteOperationProject = localProjectId;
    siteOperationLoadedAt = Date.now();
    siteOperationMessage = `${requests.length} material request(s), ${siteOperationData.equipment.length} equipment log(s), and ${siteOperationData.diary.length} diary entr(y/ies).`;
  } catch (error) {
    console.error("Project site operations could not be loaded", error);
    siteOperationData = { requests: [], requestLines: new Map(), equipment: [], diary: [] };
    siteOperationMessage = `Could not load site operations: ${error.message || "Check project access and apply the site operations migration."}`;
  }
  renderSiteOperations();
}

function renderSiteOperations() {
  const container = document.getElementById("pb-site-operations");
  if (!container) return;
  const requests = siteOperationData.requests || [];
  const equipment = siteOperationData.equipment || [];
  const diary = siteOperationData.diary || [];
  const projectName = (id) => cloudProjects.find((project) => project.id === id)?.name || "Project site";
  container.innerHTML = `<div class="panel" style="margin:0">
    <div class="toolbar" style="justify-content:space-between">
      <div><b>Project site operations</b><div class="muted">Project-scoped material requests, equipment usage and site diary.</div></div>
      <button type="button" class="btn small" id="pb-refresh-site-operations">Refresh operations</button>
    </div>
    <div class="muted" style="margin:6px 0 10px">${escapeHtml(siteOperationMessage || "Site operations will appear here when staff submit entries.")}</div>
    <div class="hr-summary-row"><b>Site totals</b><span>Pending requests ${requests.filter((row) => row.review_status === "submitted").length}</span><span>Approved ${requests.filter((row) => row.review_status === "approved").length}</span><span>Equipment logs ${equipment.length}</span><span>Diary entries ${diary.length}</span></div>
    <h4 style="margin:12px 0 6px">Material requests</h4>
    <div style="display:grid;gap:8px">${requests.map((request) => {
      const lines = siteOperationData.requestLines.get(request.id) || [];
      return `<article style="border:1px solid #dfe7ef;border-radius:10px;padding:10px">
        <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><b>${escapeHtml(request.request_date)} · ${escapeHtml(projectName(request.project_id))}</b>
          <span class="pill ${request.review_status === "approved" ? "green" : request.review_status === "rejected" ? "amber" : ""}">${escapeHtml(request.review_status)}</span></div>
        <div class="muted" style="margin-top:5px">${lines.map((line) => `${escapeHtml(line.item_name)}${line.item_code ? ` (${escapeHtml(line.item_code)})` : ""}: ${escapeHtml(line.requested_qty)} ${escapeHtml(line.unit)}${line.note ? ` — ${escapeHtml(line.note)}` : ""}`).join("<br>") || "No line items"}</div>
        ${request.remarks ? `<div style="margin-top:5px">${escapeHtml(request.remarks)}</div>` : ""}
        ${request.review_note ? `<div class="muted" style="margin-top:5px">Review note: ${escapeHtml(request.review_note)}</div>` : ""}
        ${siteOperationReviewer && request.review_status === "submitted" ? `<div style="display:flex;gap:6px;margin-top:8px"><button class="btn small primary" data-material-review="approved" data-request="${escapeHtml(request.id)}">Approve request</button><button class="btn small danger" data-material-review="rejected" data-request="${escapeHtml(request.id)}">Reject</button></div>` : ""}
      </article>`;
    }).join("") || '<div class="muted">No material requests for this site.</div>'}</div>
    <h4 style="margin:14px 0 6px">Equipment use</h4>
    <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Equipment</th><th>Hours</th><th>Condition</th><th>Location / remarks</th></tr></thead><tbody>${equipment.map((row) => `<tr><td>${escapeHtml(row.entry_date)}</td><td>${escapeHtml(row.equipment_name)}${row.equipment_code ? `<br><small>${escapeHtml(row.equipment_code)}</small>` : ""}</td><td>${escapeHtml(row.operating_hours)}</td><td>${escapeHtml(row.condition)}</td><td>${escapeHtml([row.location, row.remarks].filter(Boolean).join(" · ") || "—")}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">No equipment logs for this site.</td></tr>'}</tbody></table></div>
    <h4 style="margin:14px 0 6px">Daily site diary</h4>
    <div style="display:grid;gap:8px">${diary.map((row) => `<article style="border:1px solid #dfe7ef;border-radius:10px;padding:10px">
      <b>${escapeHtml(row.entry_date)} · ${escapeHtml(row.manpower_count)} people${row.weather ? ` · ${escapeHtml(row.weather)}` : ""}</b>
      <div style="margin-top:5px;white-space:pre-wrap">${escapeHtml(row.work_summary)}</div>
      ${row.delays ? `<div class="muted" style="margin-top:5px">Delays: ${escapeHtml(row.delays)}</div>` : ""}
      ${row.safety_notes ? `<div class="muted" style="margin-top:5px">Safety: ${escapeHtml(row.safety_notes)}</div>` : ""}
      ${row.visitors ? `<div class="muted" style="margin-top:5px">Visitors: ${escapeHtml(row.visitors)}</div>` : ""}
      ${row.remarks ? `<div class="muted" style="margin-top:5px">${escapeHtml(row.remarks)}</div>` : ""}
    </article>`).join("") || '<div class="muted">No diary entries for this site.</div>'}</div>
    <div class="muted" style="margin-top:8px">Material request approval does not reserve or issue inventory. Storekeeper/admin records any later stock issue separately.</div>
  </div>`;
  container.querySelector("#pb-refresh-site-operations")?.addEventListener("click", () => {
    const remote = cloudProjects.find((project) => project.local_project_id === String(api.getSelectedProject()));
    if (remote) void fetchSiteOperations(remote.id);
  });
  container.querySelectorAll("[data-material-review]").forEach((button) => {
    button.addEventListener("click", () => {
      void reviewMaterialRequest(button.dataset.request, button.dataset.materialReview);
    });
  });
}

async function reviewMaterialRequest(requestId, decision) {
  const request = siteOperationData.requests.find((row) => row.id === requestId);
  if (!request || !siteOperationReviewer || !["approved", "rejected"].includes(decision)) return;
  const note = window.prompt(decision === "rejected" ? "Reason for rejecting this material request (required):" : "Approval note (optional):", "");
  if (note === null) return;
  if (decision === "rejected" && !note.trim()) {
    toast("Add a reason before rejecting a material request.");
    return;
  }
  if (note.length > 2000) {
    toast("Material request review notes must be no more than 2,000 characters.");
    return;
  }
  try {
    const { data, error } = await client.rpc("review_site_material_request", {
      p_request_id: requestId,
      p_decision: decision,
      p_review_note: note.trim(),
    });
    if (error) throw error;
    if (data?.saved !== true || data.status !== decision) throw new Error("The server did not confirm the review.");
    toast(`Material request ${decision}. Stock was not issued or deducted.`);
    const remote = cloudProjects.find((project) => project.local_project_id === String(api.getSelectedProject()));
    if (remote) await fetchSiteOperations(remote.id);
  } catch (error) {
    console.error("Material request review failed", error);
    toast(`Material request review failed: ${error.message || "Check manage_materials access."}`);
  }
}

function attachSiteOperationsPanel() {
  if (api.getPage() !== "progress") return;
  const view = document.getElementById("view");
  const reports = view?.querySelector("#pb-cloud-reports");
  if (!view || !reports) return;
  let container = view.querySelector("#pb-site-operations");
  if (!container) {
    container = document.createElement("section");
    container.id = "pb-site-operations";
    reports.after(container);
  }
  const remote = cloudProjects.find((project) => project.local_project_id === String(api.getSelectedProject()));
  if (!session || !profile) {
    container.innerHTML = '<div class="panel" style="margin:0"><b>Project site operations</b><p class="muted">Sign in to Cloud Team to view project-scoped operations.</p></div>';
    return;
  }
  if (siteOperationProject !== String(api.getSelectedProject())) {
    siteOperationData = { requests: [], requestLines: new Map(), equipment: [], diary: [] };
    siteOperationReviewer = false;
    siteOperationMessage = "Loading project operations…";
  }
  renderSiteOperations();
  if (remote && (siteOperationProject !== String(api.getSelectedProject()) || Date.now() - siteOperationLoadedAt > 60_000)) {
    void fetchSiteOperations(remote.id);
  }
}

window.PB_LOAD_PROJECT_OPERATIONS = async (localProjectId) => {
  const summary = document.getElementById("pb-project-operations-summary");
  const diaryContainer = document.getElementById("pb-project-daily-operations");
  if (!summary && !diaryContainer) return;
  if (!client || !session || !profile) {
    if (summary) summary.textContent = "Sign in to Cloud Team to view authorized cloud site operations.";
    if (diaryContainer) diaryContainer.textContent = "Sign in to Cloud Team to view authorized cloud site diary entries.";
    return;
  }
  const remote = cloudProjects.find((project) => project.local_project_id === String(localProjectId));
  if (!remote) {
    if (summary) summary.textContent = "This existing project has not been synchronized to Cloud Team. Use Site Progress → Access to sync project references.";
    if (diaryContainer) diaryContainer.textContent = "This project has not been synchronized to Cloud Team.";
    return;
  }
  if (siteOperationProject !== String(localProjectId) || Date.now() - siteOperationLoadedAt > 60_000) {
    await fetchSiteOperations(remote.id, localProjectId);
  }
  if (!document.getElementById("pb-project-operations-summary") && !document.getElementById("pb-project-daily-operations")) return;
  const requests = siteOperationData.requests || [];
  const pending = requests.filter((row) => row.review_status === "submitted").length;
  const equipment = siteOperationData.equipment || [];
  const diary = siteOperationData.diary || [];
  if (summary) {
    summary.innerHTML = `<div class="hr-kpis">
      <div class="hr-kpi"><small>Pending material requests</small><b>${pending}</b></div>
      <div class="hr-kpi"><small>Approved requests</small><b>${requests.filter((row) => row.review_status === "approved").length}</b></div>
      <div class="hr-kpi"><small>Equipment logs</small><b>${equipment.length}</b></div>
      <div class="hr-kpi"><small>Diary entries</small><b>${diary.length}</b></div>
    </div>
    <div class="muted" style="margin-top:8px">${escapeHtml(siteOperationMessage)}</div>
    <div style="margin-top:8px">Latest diary: ${escapeHtml(diary[0]?.entry_date || "No diary entry")}${diary[0] ? ` · ${escapeHtml(diary[0].work_summary)}` : ""}</div>
    <button type="button" class="btn small" style="margin-top:9px" data-open-project-operations="${escapeHtml(localProjectId)}">Open Site Progress &amp; Operations</button>`;
    summary.querySelector("[data-open-project-operations]")?.addEventListener("click", (event) => {
      api.setSelectedProject(event.currentTarget.dataset.openProjectOperations);
      closeModal();
      document.querySelector('button[data-page="progress"]')?.click();
    });
  }
  if (diaryContainer) {
    diaryContainer.innerHTML = `<div class="muted">${escapeHtml(siteOperationMessage)}</div>
      <h4>Cloud daily diary</h4>
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Reporting User ID</th><th>Workers</th><th>Weather</th><th>Work Summary</th><th>Problems / Delays</th><th>Safety / Remarks</th></tr></thead><tbody>${diary.map((row) => `<tr><td>${escapeHtml(row.entry_date)}</td><td>${escapeHtml(row.submitted_by)}</td><td>${escapeHtml(row.manpower_count)}</td><td>${escapeHtml(row.weather || "—")}</td><td>${escapeHtml(row.work_summary)}</td><td>${escapeHtml(row.delays || "—")}</td><td>${escapeHtml([row.safety_notes, row.remarks].filter(Boolean).join(" · ") || "—")}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">No Cloud Team diary entries for this project.</td></tr>'}</tbody></table></div>
      <h4>Cloud equipment logs</h4>
      <div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Equipment</th><th>Hours</th><th>Condition</th><th>Location / Remarks</th></tr></thead><tbody>${equipment.map((row) => `<tr><td>${escapeHtml(row.entry_date)}</td><td>${escapeHtml(row.equipment_name)}${row.equipment_code ? ` · ${escapeHtml(row.equipment_code)}` : ""}</td><td>${escapeHtml(row.operating_hours)}</td><td>${escapeHtml(row.condition)}</td><td>${escapeHtml([row.location, row.remarks].filter(Boolean).join(" · ") || "—")}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">No Cloud Team equipment logs for this project.</td></tr>'}</tbody></table></div>
      <h4>Cloud material requests</h4>
      <div>${requests.map((row) => {
        const lines = siteOperationData.requestLines.get(row.id) || [];
        return `<div class="notice"><b>${escapeHtml(row.request_date)} · ${escapeHtml(row.review_status)}</b><div>${lines.map((line) => `${escapeHtml(line.item_name)}: ${escapeHtml(line.requested_qty)} ${escapeHtml(line.unit)}`).join(" · ") || "No request lines"}</div>${row.remarks ? `<div>${escapeHtml(row.remarks)}</div>` : ""}${row.review_note ? `<div>Review: ${escapeHtml(row.review_note)}</div>` : ""}</div>`;
      }).join("") || '<div class="empty">No Cloud Team material requests for this project.</div>'}</div>
      <p class="muted">The cloud equipment log records hours, condition and usage notes, but no equipment cost rate. Reporting user IDs are shown because display names are not available from this project-scoped query.</p>`;
  }
};

function canCorrectAttendance() {
  const actions = profile?.permissions?.modules?.["Labour & HR"];
  return profile?.role === "admin" || (
    profile?.role === "manager" && Array.isArray(actions) && actions.includes("edit")
  );
}

function attendanceEditMarkup(row) {
  const correct = canCorrectAttendance()
    ? `<button type="button" class="btn small" data-correct-attendance="${escapeHtml(row.id)}">Correct</button>`
    : "";
  return `${correct}<button type="button" class="btn small" data-attendance-history="${escapeHtml(row.id)}">History</button>`;
}

function renderCloudAttendance(container) {
  const rows = cloudAttendanceRows;
  const countStatus = (status) => rows.filter((row) => row.status === status).length;
  container.innerHTML = `
    <div class="toolbar" style="justify-content:space-between">
      <div><b>Foreman attendance submissions</b><div class="muted">Cloud records appear here after staff submit. Corrections are permission-checked and audited.</div></div>
      <button type="button" class="btn small" id="pb-refresh-attendance">Refresh</button>
    </div>
    <div class="muted" id="pb-attendance-status" style="margin:6px 0 10px">${escapeHtml(attendanceMessage)}</div>
    <div class="hr-summary-row"><b>Cloud totals</b><span>Workers ${rows.length}</span><span>Present ${countStatus("Present")}</span><span>Absent ${countStatus("Absent")}</span><span>Half-day ${countStatus("Half-day")}</span><span>Leave ${countStatus("Leave")}</span><span>OT ${escapeHtml(rows.reduce((sum, row) => sum + Number(row.overtime || 0), 0))}h</span></div>
    <div class="tablewrap"><table class="table"><thead><tr>
      <th>Worker</th><th>Project / Site</th><th>Date</th><th>Attendance</th><th>Hours</th><th>OT</th><th>Remarks</th><th>Submitted</th><th>Action</th>
    </tr></thead><tbody>${rows.map((row) => {
      const project = cloudProjects.find((item) => item.id === row.project_id);
      return `<tr>
        <td><b>${escapeHtml(row.worker_name)}</b><br><small>${escapeHtml(row.worker_code || row.worker_legacy_id)} · ${escapeHtml(row.worker_role || "Worker")}</small></td>
        <td>${escapeHtml(project?.name || row.project_legacy_id)}</td>
        <td>${escapeHtml(row.attendance_date)}</td>
        <td>${escapeHtml(row.status)}</td>
        <td>${escapeHtml(row.hours)}</td>
        <td>${escapeHtml(row.overtime)}</td>
        <td>${escapeHtml(row.remarks || "—")}</td>
        <td>${escapeHtml(row.created_at ? new Date(row.created_at).toLocaleString() : "—")}</td>
        <td>${attendanceEditMarkup(row)}</td>
      </tr>`;
    }).join("") || `<tr><td colspan="9" class="empty">No cloud attendance entries for this month and site filter.</td></tr>`}</tbody></table></div>`;
  container.querySelector("#pb-refresh-attendance")?.addEventListener("click", () => {
    void fetchCloudAttendance(true);
  });
  container.querySelectorAll("[data-correct-attendance]").forEach((button) => {
    button.addEventListener("click", () => editCloudAttendance(button.dataset.correctAttendance));
  });
  container.querySelectorAll("[data-attendance-history]").forEach((button) => {
    button.addEventListener("click", () => void viewCloudAttendanceHistory(button.dataset.attendanceHistory));
  });
}

async function fetchCloudAttendance(force = false) {
  const container = document.getElementById("pb-cloud-attendance");
  if (!container || attendanceFetchInFlight) return;
  if (!client || !session || !profile) {
    const hadRows = cloudAttendanceRows.length > 0;
    cloudAttendanceRows = [];
    window.PB_CLOUD_ATTENDANCE_ROWS = [];
    attendanceMessage = "Sign in to Cloud Team on the Access page to view authenticated foreman attendance.";
    renderCloudAttendance(container);
    if (hadRows && api.getPage() === "labour" && window.hrTab === "attendance") api.render();
    return;
  }

  const month = document.getElementById("hrAttMonth")?.value || new Date().toISOString().slice(0, 7);
  const [year, monthNumber] = month.split("-").map(Number);
  const monthStart = `${month}-01`;
  const nextMonth = monthNumber === 12
    ? `${year + 1}-01-01`
    : `${year}-${String(monthNumber + 1).padStart(2, "0")}-01`;
  const localProjectId = document.getElementById("hrAttProject")?.value || api.getSelectedProject() || "";
  const key = `${month}|${localProjectId}`;
  if (!force && key === lastAttendanceKey && Date.now() - lastAttendanceAt < 30_000) {
    renderCloudAttendance(container);
    return;
  }

  const remoteProjects = cloudProjects.filter((project) =>
    project.status === "active" && project.local_project_id &&
    (!localProjectId || project.local_project_id === String(localProjectId))
  );
  if (!remoteProjects.length) {
    const hadRows = cloudAttendanceRows.length > 0;
    cloudAttendanceRows = [];
    window.PB_CLOUD_ATTENDANCE_ROWS = [];
    attendanceMessage = localProjectId
      ? "This selected site has not been synchronized to Cloud Team."
      : "No active synchronized sites are available for this account.";
    lastAttendanceKey = key;
    lastAttendanceAt = Date.now();
    renderCloudAttendance(container);
    if (hadRows && api.getPage() === "labour" && window.hrTab === "attendance") api.render();
    return;
  }

  attendanceFetchInFlight = true;
  attendanceMessage = "Loading authorized cloud attendance…";
  renderCloudAttendance(container);
  try {
    const rows = [];
    for (let offset = 0; ; offset += 500) {
      const { data, error } = await client.from("erp_site_attendance")
        .select("id, project_id, project_legacy_id, attendance_date, worker_legacy_id, worker_name, worker_code, worker_role, status, hours, overtime, remarks, submitted_by, updated_by, created_at, updated_at")
        .in("project_id", remoteProjects.map((project) => project.id))
        .gte("attendance_date", monthStart)
        .lt("attendance_date", nextMonth)
        .order("attendance_date")
        .order("worker_name")
        .order("id")
        .range(offset, offset + 499);
      if (error) throw error;
      rows.push(...(data || []));
      if (!data || data.length < 500) break;
    }
    cloudAttendanceRows = rows;
    window.PB_CLOUD_ATTENDANCE_ROWS = cloudAttendanceRows;
    attendanceMessage = `${cloudAttendanceRows.length} cloud attendance record(s) for ${month}.`;
    lastAttendanceKey = key;
    lastAttendanceAt = Date.now();
  } catch (error) {
    console.error("Cloud attendance could not be loaded", error);
    cloudAttendanceRows = [];
    window.PB_CLOUD_ATTENDANCE_ROWS = [];
    attendanceMessage = `Could not load cloud attendance: ${error.message || "Check Labour & HR access and the attendance migration."}`;
    lastAttendanceKey = key;
    lastAttendanceAt = Date.now();
  } finally {
    attendanceFetchInFlight = false;
    renderCloudAttendance(container);
    const latestMonth = document.getElementById("hrAttMonth")?.value || new Date().toISOString().slice(0, 7);
    const latestProject = document.getElementById("hrAttProject")?.value || api.getSelectedProject() || "";
    if (api.getPage() === "labour" && window.hrTab === "attendance") api.render();
    if (`${latestMonth}|${latestProject}` !== key) void fetchCloudAttendance(true);
  }
}

function editCloudAttendance(attendanceId) {
  if (!canCorrectAttendance()) {
    toast("Only an authorized Labour & HR manager can correct cloud attendance.");
    return;
  }
  const row = cloudAttendanceRows.find((entry) => entry.id === attendanceId);
  if (!row) return;
  const body = `<div class="formgrid">
    <div class="field"><label>Worker</label><input value="${escapeHtml(row.worker_name)} · ${escapeHtml(row.worker_code || row.worker_legacy_id)}" readonly></div>
    <div class="field"><label>Date</label><input value="${escapeHtml(row.attendance_date)}" readonly></div>
    <div class="field"><label>Attendance status</label><select id="pbAttendanceCorrectionStatus" class="select">
      ${["Present", "Absent", "Half-day", "Leave"].map((status) => `<option ${row.status === status ? "selected" : ""}>${status}</option>`).join("")}
    </select></div>
    <div class="field"><label>Working hours</label><input id="pbAttendanceCorrectionHours" type="number" min="0" max="24" step="0.25" value="${escapeHtml(row.hours)}"></div>
    <div class="field"><label>Overtime hours</label><input id="pbAttendanceCorrectionOvertime" type="number" min="0" max="24" step="0.25" value="${escapeHtml(row.overtime)}"></div>
    <div class="field full"><label>Remarks</label><textarea id="pbAttendanceCorrectionRemarks" maxlength="2000">${escapeHtml(row.remarks || "")}</textarea></div>
    <div class="muted full">Changes are saved to the shared attendance record and an audit entry is retained.</div>
  </div>`;
  window.openModal(`Correct Attendance — ${row.worker_name}`, body, async () => {
    const status = document.getElementById("pbAttendanceCorrectionStatus").value;
    const hours = Number(document.getElementById("pbAttendanceCorrectionHours").value);
    const overtime = Number(document.getElementById("pbAttendanceCorrectionOvertime").value);
    const remarks = document.getElementById("pbAttendanceCorrectionRemarks").value.trim();
    if (!Number.isFinite(hours) || hours < 0 || hours > 24 ||
        !Number.isFinite(overtime) || overtime < 0 || overtime > 24 ||
        (["Absent", "Leave"].includes(status) && (hours !== 0 || overtime !== 0))) {
      toast("Hours must be 0–24; Absent and Leave entries require zero hours and overtime.");
      return false;
    }
    const { error } = await client.from("erp_site_attendance").update({
      status, hours, overtime, remarks,
    }).eq("id", row.id);
    if (error) {
      console.error("Cloud attendance correction failed", error);
      toast(`Attendance correction failed: ${error.message || "Check your permissions and retry."}`);
      return false;
    }
    await fetchCloudAttendance(true);
    toast("Attendance corrected; the change was added to its audit history.");
    return true;
  });
}

async function viewCloudAttendanceHistory(attendanceId) {
  const row = cloudAttendanceRows.find((entry) => entry.id === attendanceId);
  if (!row) return;
  try {
    const { data, error } = await client.from("erp_site_attendance_history")
      .select("old_values, new_values, changed_by, changed_at")
      .eq("attendance_id", attendanceId)
      .order("changed_at", { ascending: false })
      .limit(20);
    if (error) throw error;
    const body = data?.length ? `<div class="tablewrap"><table class="table"><thead><tr><th>Changed</th><th>Changed by</th><th>Before</th><th>After</th></tr></thead><tbody>
      ${data.map((change) => `<tr>
        <td>${escapeHtml(new Date(change.changed_at).toLocaleString())}</td>
        <td>${escapeHtml(change.changed_by)}</td>
        <td>${escapeHtml(JSON.stringify(change.old_values))}</td>
        <td>${escapeHtml(JSON.stringify(change.new_values))}</td>
      </tr>`).join("")}
    </tbody></table></div>` : `<p class="muted">No corrections have been recorded for this attendance entry.</p>`;
    window.openModal(`Attendance History — ${row.worker_name}`, body, () => true);
    document.getElementById("modalSave").style.display = "none";
  } catch (error) {
    console.error("Cloud attendance history could not be loaded", error);
    toast(`Could not load attendance history: ${error.message || "Check your Labour & HR permissions."}`);
  }
}

function attachAttendancePanel() {
  if (api.getPage() !== "labour" || window.hrTab !== "attendance") return;
  const view = document.getElementById("view");
  const attendanceTable = view?.querySelector(".hr-table-panel");
  if (!view || !attendanceTable) return;
  let container = document.getElementById("pb-cloud-attendance");
  if (!container) {
    container = document.createElement("section");
    container.id = "pb-cloud-attendance";
    container.className = "panel";
    attendanceTable.after(container);
  }
  renderCloudAttendance(container);
  const dateInput = document.getElementById("hrAttMonth");
  const projectInput = document.getElementById("hrAttProject");
  if (dateInput && !dateInput.dataset.cloudBound) {
    dateInput.dataset.cloudBound = "true";
    dateInput.addEventListener("change", () => void fetchCloudAttendance(true));
  }
  if (projectInput && !projectInput.dataset.cloudBound) {
    projectInput.dataset.cloudBound = "true";
    projectInput.addEventListener("change", () => void fetchCloudAttendance(true));
  }
  void fetchCloudAttendance();
}

function onRender() {
  attachAccessPanel();
  attachProgressPanel();
  attachSiteOperationsPanel();
  attachBoqAssignmentPanel();
  attachAttendancePanel();
  void syncCloudBoqProgress().catch((error) => {
    console.error("Cloud BOQ progress could not be synchronized to the local ERP", error);
    progressMessage = `Automatic BOQ progress sync failed: ${error.message || "Check the cloud connection and local BOQ quantities."}`;
    const status = document.getElementById("pb-progress-status");
    if (status) status.textContent = progressMessage;
  });
}

async function initialize() {
  if (client) {
    const { data, error } = await client.auth.getSession();
    if (error) throw error;
    if (data.session?.user) {
      try {
        const { data: storedProfile, error: profileError } = await client.from("profiles")
          .select("role,status").eq("id", data.session.user.id).maybeSingle();
        if (profileError) throw profileError;
        if (!storedProfile || storedProfile.status !== "active" || !["admin", "manager"].includes(storedProfile.role)) {
          await client.auth.signOut();
          throw new Error("Stored Cloud session is not an active Admin or Manager account.");
        }
        await loadProfile(data.session.user);
      } catch (profileError) {
        console.error("Stored cloud session profile could not be loaded", profileError);
        // Keep the saved login; a slow network must not sign the user out.
      }
    }
  }
  const originalRender = window.render;
  if (typeof originalRender === "function") {
    window.render = function (...args) {
      const result = originalRender.apply(this, args);
      requestAnimationFrame(onRender);
      return result;
    };
    api.render = window.render;
  }
  onRender();
  setInterval(() => {
    void syncCloudBoqProgress().catch((error) => {
      console.error("Cloud BOQ progress could not be synchronized to the local ERP", error);
      progressMessage = `Automatic BOQ progress sync failed: ${error.message || "Check the cloud connection and local BOQ quantities."}`;
      const status = document.getElementById("pb-progress-status");
      if (status) status.textContent = progressMessage;
    });
  }, 30_000);
  setInterval(() => {
    if (api.getPage() === "labour" && window.hrTab === "attendance") {
      void fetchCloudAttendance(true);
    }
  }, 30_000);
  if (client) {
    client.auth.onAuthStateChange((_event, nextSession) => {
      if (!nextSession) {
        session = null;
        profile = null;
        cloudProjects = [];
        cachedReports = [];
        lastLoadedProject = "";
        cloudAttendanceRows = [];
        window.PB_CLOUD_ATTENDANCE_ROWS = [];
        lastAttendanceKey = "";
        lastAttendanceAt = 0;
        siteOperationData = { requests: [], requestLines: new Map(), equipment: [], diary: [] };
        siteOperationProject = "";
        siteOperationLoadedAt = 0;
        siteOperationReviewer = false;
        boqAssignmentData = { items: [], members: [], assignments: [], canManage: false };
        boqAssignmentProject = "";
        boqAssignmentLoadedAt = 0;
      }
      requestAnimationFrame(onRender);
    });
  }
  window.PB_EDIT_CLOUD_ATTENDANCE = editCloudAttendance;
}

initialize().catch((error) => {
  console.error("PURE_BUILD cloud integration could not start", error);
  panelMessage = `Cloud initialization failed: ${error.message || "Verify the Supabase configuration."}`;
  panelError = true;
});


// Pending staff reports summary -> Dashboard "Site Progress" box and Warehouse/Stock page.
let pbPending = { reports: [], at: 0 };
// Approved reports not yet in the office app are added automatically (no need to open Site Progress per project).
async function pbAutoImportApproved(reports) {
  if (!profile || !["admin", "manager", "accountant"].includes(profile.role)) return;
  const imported = importedReportIds();
  const todo = reports.filter((r) => r.review_status === "approved" && r.local_project_id && !imported.includes(r.id));
  if (!todo.length) return;
  const { data: lines, error } = await client.from("site_progress_report_boq_lines")
    .select("report_id, boq_item_id, local_boq_id, today_qty, previous_qty, total_qty, remaining_qty, percent")
    .in("report_id", todo.map((r) => r.id));
  if (error) { console.error("Approved report lines could not load", error); return; }
  const data = appData(), snapshot = JSON.stringify(data);
  let n = 0;
  try {
    for (const r of todo) {
      const pid = String(r.local_project_id);
      if (!(data.projects || []).some((p) => String(p.id) === pid)) continue;
      const ls = (lines || []).filter((l) => l.report_id === r.id && (data.boq || []).some((b) => b.id === l.local_boq_id && b.projectId === pid));
      importReportRows(r, ls, pid);
      imported.push(r.id); n += 1;
    }
    if (!n) return;
    api.save();
    toast(`${n} approved staff report(s) added to Site Progress.`);
    api.render();
  } catch (e) {
    const restored = JSON.parse(snapshot);
    for (const k of Object.keys(data)) delete data[k];
    Object.assign(data, restored);
    console.error("Auto import failed", e);
  }
}
async function pbLoadPending() {
  if (!client) return;
  try {
    const { data: s } = await client.auth.getSession();
    if (!s.session) return;
    const { data, error } = await client.from("site_progress_reports")
      .select("id, report_date, review_status, report_payload, local_project_id, created_at")
      .in("review_status", ["submitted", "approved"]).order("created_at", { ascending: false }).limit(60);
    if (error) throw error;
    pbPending = { reports: data || [], at: Date.now() };
    await pbAutoImportApproved(data || []);
    pbPaintPending();
  } catch (e) { console.error("Pending reports could not load", e); }
}
function pbPaintPending() {
  const page = api.getPage?.();
  const rs = pbPending.reports, sub = rs.filter((r) => r.review_status === "submitted");
  const today = new Date().toISOString().slice(0, 10);
  const pname = (pid) => ((appData().projects || []).find((p) => String(p.id) === String(pid))?.name) || pid || "—";
  const first = sub[0];
  const go = first ? `onclick="PB_GO_APPROVE('${escapeHtml(String(first.local_project_id || ""))}','${escapeHtml(String(first.id))}')"` : `onclick="setPage('progress');render()"`;
  if (page === "dashboard") {
    const head = [...document.querySelectorAll(".dashboard-panel h3")].find((h) => h.textContent.trim().endsWith("Site Progress"));
    const panel = head?.closest(".dashboard-panel");
    if (panel && !panel.querySelector(".pb-pend")) {
      const appr = rs.filter((r) => r.review_status === "approved").length, td = rs.filter((r) => r.report_date === today).length;
      const box = document.createElement("div"); box.className = "pb-pend";
      box.style.cssText = "display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:4px 0 6px;font-size:11px";
      box.innerHTML = `<span class="pill" style="background:#fef3c7;color:#92400e">Waiting ${sub.length}</span><span class="pill" style="background:#dcfce7;color:#166534">Approved ${appr}</span><span class="pill">Today ${td}</span>${sub.length ? `<button class="btn small" ${go}>Check & Approve →</button>` : ""}`;
      panel.querySelector(".panel-head")?.after(box);
    }
  }
  if (page === "stock") {
    const main = document.getElementById("view");
    if (!main || main.querySelector(".pb-pend-stock")) return;
    const moves = [];
    for (const r of sub) {
      const p = r.report_payload || {}, m = p.materials || {};
      for (const x of [...(m.received || p.materialIn || []).map((x) => ({ ...x, d: "In" })), ...(m.used || p.materialOut || []).map((x) => ({ ...x, d: "Out" }))])
        moves.push({ ...x, date: r.report_date, pid: r.local_project_id, by: p.foreman || "Staff" });
    }
    const stock = appData().stock || [];
    const bal = (pid, item) => stock.filter((s) => String(s.projectId) === String(pid) && String(s.item).toLowerCase() === String(item).toLowerCase())
      .reduce((a, s) => a + (s.direction === "In" || /in$/i.test(s.direction || "") ? 1 : -1) * (Number(s.qty) || 0), 0);
    const box = document.createElement("div"); box.className = "card pb-pend-stock";
    box.style.cssText = "margin:0 0 12px;padding:12px";
    box.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><b>📦 Materials from site (waiting for approval): ${moves.length}</b>${moves.length ? `<button class="btn small" ${go}>Approve in Site Progress →</button>` : ""}</div>
      ${moves.length ? `<div class="table-wrap" style="margin-top:8px"><table><thead><tr><th>Date</th><th>Project</th><th>Item</th><th>In/Out</th><th>Qty</th><th>Stock now</th><th>After approval</th><th>By</th></tr></thead><tbody>${moves.slice(0, 12).map((x) => { const now = bal(x.pid, x.item), q = Number(x.qty) || 0, after = now + (x.d === "In" ? q : -q); return `<tr><td>${escapeHtml(x.date)}</td><td>${escapeHtml(pname(x.pid))}</td><td>${escapeHtml(x.item)}</td><td>${x.d}</td><td>${q} ${escapeHtml(x.unit || "")}</td><td>${now}</td><td style="color:${after < 0 ? "#b91c1c" : "inherit"}">${after}${after < 0 ? " ⚠" : ""}</td><td>${escapeHtml(x.by)}</td></tr>`; }).join("")}</tbody></table></div>` : `<div class="muted" style="margin-top:4px">No material updates waiting. Approved items are added to stock automatically.</div>`}`;
    main.prepend(box);
  }
}
window.addEventListener("pb:rendered", () => { if (Date.now() - pbPending.at > 60000) void pbLoadPending(); else pbPaintPending(); });
setInterval(pbLoadPending, 60000);
