/* Eye comfort: display-only layer for the light theme. Replaces glaring pure-white surfaces with soft tinted tones.
   Never changes sizes, layout, IDs, data or logic. Print stays white. */
(function(){
  var BG='#E9E8F0',PANEL='#F2F1F6',INPUT='#ECEBF2',LINE='#DCD9E7',HEAD='#E3E0EF',HOVER='#E8E5F4';
  var S='html body.light-theme:not(.cx1):not(.cx2):not(.cx3):not(.cx4)';
  var css=`${S}{--bg:${BG};--panel:${PANEL};--line:${LINE};--ink:#2B2A3A;--clay-hi:-6px -6px 14px rgba(255,255,255,.55);background:${BG}!important;color:#2B2A3A}
${S} .app,${S} .main,${S} .content{background:${BG}!important}
${S} .card.kpi,${S} .quick-btn{background-color:${PANEL}!important}
${S} .panel,${S} .card,${S} .dashboard-panel,${S} .small-card,${S} .hr-kpi,${S} .quote-panel,${S} .quote-kpi,${S} .metricrow>*,${S} .sidebar,${S} .tablewrap,${S} .modalbox,${S} .btn:not(.primary):not(.success):not(.green):not(.danger):not(.red){background-color:${PANEL}!important;border-color:${LINE}!important}
${S} .topbar{background:rgba(242,241,246,.94)!important;border-color:${LINE}!important}
${S} input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]),${S} select,${S} textarea{background:${INPUT}!important;border-color:${LINE}!important;box-shadow:inset 2px 2px 5px rgba(118,106,170,.12),inset -2px -2px 5px rgba(255,255,255,.5)!important}
${S} table th{background:${HEAD}!important;border-color:${LINE}!important}
${S} table td{border-color:${LINE}!important}
${S} table tbody tr:hover td{background:${HOVER}!important}
${S} [style*="background:#fff;"],${S} [style$="background:#fff"],${S} [style*="background: #fff;"],${S} [style*="background:#ffffff"],${S} [style*="background:white"],${S} [style*="background: white"],${S} [style*="background-color: rgb(255, 255, 255)"],${S} [style*="background: rgb(255, 255, 255)"]{background:${PANEL}!important}
${S} .sidebar .nav button:not(.active):hover,${S} .sidebar .nav a:not(.active):hover{background:#E4E0F5!important}
${S} .sidebar .nav .active.active.active,${S} .sidebar .nav .active.active.active:hover{background:linear-gradient(135deg,#8875DC,#A99AEF)!important;color:#fff!important;border-color:#8875DC!important}
${S} .sidebar .nav .active.active.active *{color:#fff!important}
${S} ::selection{background:#D5CDF5}
@media print{${S},${S} .app,${S} .main,${S} .content,${S} .panel,${S} .card,${S} .tablewrap,${S} .modalbox,${S} table th,${S} table td,${S} [style]{background:#fff!important}}`;
  var st=document.createElement('style');st.id='eye-comfort';st.textContent=css;
  (document.head||document.documentElement).appendChild(st);

  /* Soften pure-white backgrounds declared by other display stylesheets (screen rules only, light theme only). */
  function light(){return document.body&&document.body.classList.contains('light-theme')}
  function rgbOf(v){v=(v||'').trim().toLowerCase();if(v==='white')return[255,255,255,1];var m;
    if((m=v.match(/^#([0-9a-f]{3})$/)))return[parseInt(m[1][0]+m[1][0],16),parseInt(m[1][1]+m[1][1],16),parseInt(m[1][2]+m[1][2],16),1];
    if((m=v.match(/^#([0-9a-f]{6})$/)))return[parseInt(m[1].slice(0,2),16),parseInt(m[1].slice(2,4),16),parseInt(m[1].slice(4,6),16),1];
    if((m=v.match(/^rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/))){var a=m[4]==null?1:(/%$/.test(m[4])?parseFloat(m[4])/100:parseFloat(m[4]));return[+m[1],+m[2],+m[3],a]}
    return null}
  function glare(v){var c=rgbOf(v);return !!(c&&c[3]>=.9&&Math.min(c[0],c[1],c[2])>=243)}
  var TOK=/#[0-9a-f]{6}\b|#[0-9a-f]{3}\b|rgba?\([^)]*\)|\bwhite\b/gi;
  function softImg(img){if(!img||!/gradient/i.test(img))return null;var hit=0;var out=img.replace(TOK,function(t){if(glare(t)){hit=1;return PANEL}return t});return hit?out:null}
  function walk(rules){
    for(var i=0;i<rules.length;i++){var r=rules[i];
      if(r.type===4){var m=(r.media&&r.media.mediaText)||'';if(/print/i.test(m)&&!/screen/i.test(m))continue;walk(r.cssRules);continue}
      if(r.type!==1||!r.style||r.__pbEye)continue;
      var sel=r.selectorText||'';if(/#pbGate|print|\.dark|cx[1-4]|sidebar-visual/i.test(sel))continue;
      var st=r.style,pri=st.getPropertyPriority('background-color')||st.getPropertyPriority('background')||st.getPropertyPriority('background-image');
      var full=st.getPropertyValue('background');
      if(full){
        if(glare(full)){st.setProperty('background',PANEL,pri);r.__pbEye=1;continue}
        var nf=softImg(full);if(nf){st.setProperty('background',nf,pri);r.__pbEye=1;continue}
      }
      if(glare(st.getPropertyValue('background-color'))){st.setProperty('background-color',PANEL,pri);r.__pbEye=1}
      var ni=softImg(st.getPropertyValue('background-image'));
      if(ni){st.setProperty('background-image',ni,pri);r.__pbEye=1}
    }
  }
  function run(){
    if(!light())return;
    document.documentElement.style.setProperty('--pb-eye-panel',PANEL);
    for(var i=0;i<document.styleSheets.length;i++){var sh=document.styleSheets[i];
      if(sh.ownerNode&&sh.ownerNode.id==='eye-comfort')continue;
      try{if(sh.__pbEyeN===sh.cssRules.length)continue;walk(sh.cssRules);sh.__pbEyeN=sh.cssRules.length}catch(e){}
    }
  }
  var t;function later(){clearTimeout(t);t=setTimeout(run,120)}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',later);else later();
  window.addEventListener('load',later);
  try{new MutationObserver(function(ms){for(var i=0;i<ms.length;i++){var m=ms[i];if(m.target.nodeName==='STYLE'){later();return}
    for(var j=0;j<m.addedNodes.length;j++){var n=m.addedNodes[j];if(n.nodeName==='STYLE'||n.nodeName==='LINK'){later();return}}}}).observe(document.documentElement,{childList:true,subtree:true})}catch(e){}
  try{new MutationObserver(later).observe(document.body||document.documentElement,{attributes:true,attributeFilter:['class']})}catch(e){}
})();
