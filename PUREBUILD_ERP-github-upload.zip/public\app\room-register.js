// Site Progress → "Room Work Register": a separate, tidy view of what work is done in each Building → Floor → Room.
// Read from BOQ automatically. Office can add "work done" (adds qty to the BOQ once, capped at BOQ qty) as a db.progress
// record with source 'room-entry'. Staff phone reports arrive through the existing Cloud approval flow and appear here too.
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const today = () => new Date().toISOString().slice(0, 10);
  const nc = (a, b) => String(a || "\uffff").localeCompare(String(b || "\uffff"), undefined, { numeric: true, sensitivity: "base" });
  let sel = { b: "", f: "", r: "" }, q = "";

  const css = `.rr-wrap{display:grid;grid-template-columns:260px minmax(0,1fr);gap:12px;min-height:60vh}
.rr-tree{border:1px solid var(--line);border-radius:12px;padding:8px;overflow:auto;max-height:76vh;background:#f8fafd}
.rr-bld{font-weight:900;font-size:12px;color:#0f2f57;margin:8px 4px 4px;text-transform:uppercase;letter-spacing:.04em}
.rr-floor{font-weight:800;font-size:11px;color:#5b6f8c;margin:6px 6px 3px}
.rr-room{display:flex;justify-content:space-between;align-items:center;width:100%;border:1px solid transparent;background:#fff;border-radius:9px;padding:6px 8px;margin:2px 0;cursor:pointer;font-size:12px;text-align:left}
.rr-room:hover{border-color:#bcd3ee}.rr-room.on{border-color:#0f5fae;background:#eaf3fd;font-weight:800}
.rr-room small{font-weight:800;color:#0f5fae}
.rr-main{min-width:0;overflow:auto;max-height:76vh}
.rr-head{display:flex;justify-content:space-between;align-items:flex-end;gap:10px;flex-wrap:wrap;margin-bottom:8px}
.rr-head h3{margin:0;font-size:17px}.rr-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:10px}
.rr-kpi{border:1px solid var(--line);border-radius:10px;padding:8px 10px;background:#fff}.rr-kpi small{display:block;font-size:10px;font-weight:800;color:#6a7c95;text-transform:uppercase}.rr-kpi b{font-size:17px}
.rr-tbl{width:100%;border-collapse:collapse;font-size:12px}.rr-tbl th{background:#0f2f57;color:#fff;text-align:left;padding:7px;font-size:10px;text-transform:uppercase}
.rr-tbl td{padding:7px;border-top:1px solid var(--line);vertical-align:middle}.rr-tbl .progress{min-width:70px}
.rr-sec{font-size:12px;font-weight:900;color:#36507a;text-transform:uppercase;margin:14px 0 6px}
.rr-form{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;border:1px solid #bcd3ee;background:#f3f8fe;border-radius:10px;padding:10px;margin:8px 0}
.rr-form label{font-size:10px;font-weight:800;color:#5b6f8c;display:block;margin-bottom:3px}.rr-form input,.rr-form select{width:100%}.rr-form .full{grid-column:1/-1}
.rr-src{font-size:10px;font-weight:800;border-radius:20px;padding:2px 8px}.rr-src.o{background:#e6f0fb;color:#0f5fae}.rr-src.s{background:#e7f7ee;color:#137a43}
@media(max-width:900px){.rr-wrap{grid-template-columns:1fr}.rr-kpis,.rr-form{grid-template-columns:1fr 1fr}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  const items = () => (db.boq || []).filter((b) => b.projectId === selectedProject);
  const key = (b) => [b.building || "General", b.floor || "—", b.area || b.room || "—"];
  const done = (b) => n(b.executedQty);
  const pct = (list) => { const t = list.reduce((a, b) => a + n(b.amount || n(b.qty) * n(b.rate)), 0), d = list.reduce((a, b) => a + done(b) * n(b.rate), 0); return t ? Math.min(100, (d / t) * 100) : 0; };
  const entriesFor = (list) => {
    const ids = new Set(); list.forEach((b) => { ids.add(b.id); if (b.boqId) ids.add(b.boqId); });
    return (db.progress || []).filter((x) => x.projectId === selectedProject && ids.has(x.boqId)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
  };

  function tree() {
    const map = {};
    items().forEach((b) => { const [B, F, R] = key(b); ((map[B] = map[B] || {})[F] = map[B][F] || {})[R] = (map[B][F][R] || []).concat(b); });
    return map;
  }

  function draw() {
    const body = document.getElementById("modalBody"); if (!body) return;
    const t = tree(), blds = Object.keys(t).sort(nc);
    if (!blds.length) { body.innerHTML = '<div class="empty">No BOQ items for this project yet. Add BOQ items first.</div>'; return; }
    if (!sel.b || !t[sel.b]) { sel.b = blds[0]; const f = Object.keys(t[sel.b]).sort(nc)[0]; sel.f = f; sel.r = Object.keys(t[sel.b][f]).sort(nc)[0]; }
    if (!t[sel.b][sel.f] || !t[sel.b][sel.f][sel.r]) { sel.f = Object.keys(t[sel.b]).sort(nc)[0]; sel.r = Object.keys(t[sel.b][sel.f]).sort(nc)[0]; }
    const ql = q.toLowerCase();
    const treeHtml = `<input class="input" id="rrQ" placeholder="Search room…" value="${esc(q)}" style="width:100%;margin-bottom:4px">` + blds.map((B) => {
      const floors = Object.keys(t[B]).sort(nc);
      const inner = floors.map((F) => {
        const rooms = Object.keys(t[B][F]).sort(nc).filter((R) => !ql || (B + " " + F + " " + R).toLowerCase().includes(ql));
        if (!rooms.length) return "";
        return `<div class="rr-floor">${esc(F)}</div>` + rooms.map((R) => `<button type="button" class="rr-room${B === sel.b && F === sel.f && R === sel.r ? " on" : ""}" data-b="${esc(B)}" data-f="${esc(F)}" data-r="${esc(R)}"><span>${esc(R)} <span class="muted">(${t[B][F][R].length})</span></span><small>${pct(t[B][F][R]).toFixed(0)}%</small></button>`).join("");
      }).join("");
      return inner ? `<div class="rr-bld">${esc(B)} · ${pct(Object.values(t[B]).flatMap((f) => Object.values(f).flat())).toFixed(0)}%</div>${inner}` : "";
    }).join("");

    const list = t[sel.b][sel.f][sel.r].slice().sort((a, b) => nc(a.boqId, b.boqId));
    const tot = list.reduce((a, b) => a + n(b.amount || n(b.qty) * n(b.rate)), 0), exe = list.reduce((a, b) => a + done(b) * n(b.rate), 0);
    const finished = list.filter((b) => n(b.qty) > 0 && done(b) >= n(b.qty)).length;
    const rows = list.map((b) => {
      const qy = n(b.qty), d = done(b), p = qy ? Math.min(100, (d / qy) * 100) : 0;
      return `<tr><td><b>${esc(b.boqId || "—")}</b></td><td>${esc(b.category || "Other")}</td><td>${esc(b.description || "")}</td><td>${fmt(qy)} ${esc(b.unit || "")}</td><td><b>${fmt(d)}</b></td><td>${fmt(Math.max(0, qy - d))}</td><td><div class="progress"><i style="width:${p}%"></i></div><small>${p.toFixed(1)}%</small></td><td><span class="pill ${p >= 100 ? "green" : p > 0 ? "" : "amber"}">${p >= 100 ? "Completed" : p > 0 ? "In Progress" : "Not Started"}</span></td><td>${p >= 100 ? "" : `<button class="btn small" data-add="${esc(b.id)}">＋ Add</button>`}</td></tr>`;
    }).join("");
    const ents = entriesFor(list).slice(0, 30);
    const bName = (bid) => { const b = list.find((x) => x.id === bid || x.boqId === bid); return b ? (b.boqId || "") + " " + (b.description || "") : bid; };
    const entRows = ents.map((x) => { const staff = String(x.id).startsWith("cloud-") || (x.source !== "room-entry" && x.source !== "stage-update" && !x.submittedBy); return `<tr><td>${esc(x.date)}</td><td>${esc(bName(x.boqId))}</td><td><b>+${fmt(x.todayQty || 0)}</b> ${esc(x.unit || "")}</td><td><span class="rr-src ${staff ? "s" : "o"}">${staff ? "Staff" : "Office"}</span> ${esc(x.foreman || x.submittedBy || "")}</td><td>${esc(x.note || x.description || "")}</td></tr>`; }).join("");

    body.innerHTML = `<div class="rr-wrap"><div class="rr-tree">${treeHtml}</div><div class="rr-main">
<div class="rr-head"><div><div class="muted" style="font-size:11px;font-weight:800">${esc(sel.b)} › ${esc(sel.f)}</div><h3>${esc(sel.r)}</h3></div><span class="muted" style="font-size:11px">Staff work comes in from the phone app after you approve it.</span></div>
<div class="rr-kpis"><div class="rr-kpi"><small>Works in room</small><b>${list.length}</b></div><div class="rr-kpi"><small>Completed works</small><b>${finished}</b></div><div class="rr-kpi"><small>Done value</small><b>${money(exe)}</b></div><div class="rr-kpi"><small>Room progress</small><b>${(tot ? Math.min(100, (exe / tot) * 100) : 0).toFixed(1)}%</b></div></div>
<div id="rrForm"></div>
<table class="rr-tbl"><thead><tr><th>BOQ</th><th>Trade</th><th>Work</th><th>BOQ Qty</th><th>Done</th><th>Remaining</th><th>Progress</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>
<div class="rr-sec">Work done history — this room</div>
<table class="rr-tbl"><thead><tr><th>Date</th><th>Work</th><th>Qty</th><th>Added by</th><th>Note</th></tr></thead><tbody>${entRows || '<tr><td colspan="5" class="empty">No work recorded in this room yet.</td></tr>'}</tbody></table>
</div></div>`;
    body.querySelectorAll(".rr-room").forEach((el) => el.onclick = () => { sel = { b: el.dataset.b, f: el.dataset.f, r: el.dataset.r }; draw(); });
    const qi = document.getElementById("rrQ"); if (qi) qi.oninput = () => { q = qi.value; const pos = qi.selectionStart; draw(); const z = document.getElementById("rrQ"); z.focus(); z.setSelectionRange(pos, pos); };
    body.querySelectorAll("[data-add]").forEach((el) => el.onclick = () => form(el.dataset.add));
  }

  function form(bid) {
    const b = (db.boq || []).find((x) => x.id === bid); if (!b) return;
    const rem = Math.max(0, n(b.qty) - done(b));
    document.getElementById("rrForm").innerHTML = `<div class="rr-form"><div class="full"><b>${esc(b.boqId || "")} — ${esc(b.description || "")}</b> <span class="muted">· Remaining ${fmt(rem)} ${esc(b.unit || "")}</span></div>
<div><label>Date</label><input type="date" class="input" id="rrDate" value="${today()}" max="${today()}"></div>
<div><label>Work done (${esc(b.unit || "qty")})</label><input type="number" class="input" id="rrQty" min="0" step="any" max="${rem}"></div>
<div><label>Done by</label><input class="input" id="rrBy" placeholder="Supervisor / team"></div>
<div><label>Note</label><input class="input" id="rrNote" placeholder="Optional"></div>
<div class="full" style="display:flex;gap:8px"><button class="btn primary" id="rrSave">Save work done</button><button class="btn" id="rrCancel">Cancel</button></div></div>`;
    document.getElementById("rrCancel").onclick = () => { document.getElementById("rrForm").innerHTML = ""; };
    document.getElementById("rrSave").onclick = () => saveEntry(b);
    document.getElementById("rrQty").focus();
  }

  function saveEntry(b) {
    const date = document.getElementById("rrDate").value, qty = n(document.getElementById("rrQty").value);
    const by = document.getElementById("rrBy").value.trim(), note = document.getElementById("rrNote").value.trim();
    const rem = Math.max(0, n(b.qty) - done(b));
    if (!date || date > today()) return toast("Choose a valid date (not in the future)");
    if (qty <= 0) return toast("Enter the work done quantity");
    if (qty > rem + 1e-9) return toast(`Only ${fmt(rem)} ${b.unit || ""} is remaining in the BOQ`);
    if ((db.progress || []).some((x) => x.source === "room-entry" && x.boqId === b.id && x.date === date)) return toast("Work for this item is already added on this date");
    const prev = done(b), next = prev + qty, user = window.PB_CURRENT_USER_EMAIL || document.querySelector(".pb-account-email")?.textContent || "Office user";
    b.executedQty = next;
    db.progress = db.progress || [];
    db.progress.push({ id: id(), date, projectId: selectedProject, ...(b.building ? { building: b.building } : {}), floor: b.floor || "", room: b.area || b.room || "",
      title: b.description || "Room work", description: note, percent: n(b.qty) ? Math.min(100, (next / n(b.qty)) * 100) : 0, foreman: by || user,
      boqId: b.id, boqCode: b.boqId, todayQty: qty, previousQty: prev, totalCompleted: next, remainingQty: Math.max(0, n(b.qty) - next), unit: b.unit, rate: n(b.rate),
      location: [b.building, b.floor, b.area || b.room].filter(Boolean).join(" / "), labourWorkers: 0, labourEntries: [], materialIn: [], materialOut: [], photoData: [], photos: 0,
      note, source: "room-entry", submittedBy: user, submittedAt: new Date().toISOString(), approvalStatus: "Approved" });
    try { projectHistoryAdd(selectedProject, "Room work added", `${date} · ${b.boqId} · +${fmt(qty)} ${b.unit || ""}`); } catch (e) {}
    save(); toast("Work done saved — BOQ updated"); draw();
  }

  function open() {
    if (!selectedProject) return toast("Select a project first");
    const p = (db.projects || []).find((x) => x.id === selectedProject);
    openModal(`Room Work Register — ${p?.name || ""}`, "", null);
    document.getElementById("modalSave").style.display = "none";
    const box = document.querySelector("#modal .modalbox"); if (box) { box.style.width = "min(1280px,100%)"; box.style.maxHeight = "94vh"; }
    draw();
    const close = document.querySelector("#modal .modalclose, #modal [onclick*='closeModal']");
    if (close && !close.dataset.rr) { close.dataset.rr = 1; close.addEventListener("click", () => { if (page === "progress") setTimeout(render, 0); }); }
  }
  window.PB_ROOM_REGISTER = { open };

  const orig = window.progress;
  window.progress = function () {
    const r = orig.apply(this, arguments);
    try {
      const bar = document.querySelector(".work-detail-panel .toolbar");
      if (bar && !bar.querySelector(".rr-open")) {
        const btn = document.createElement("button"); btn.className = "btn primary rr-open"; btn.textContent = "▦ Room Work Register";
        btn.onclick = open; const v = bar.querySelector("button"); bar.insertBefore(btn, v);
        if (v) { const g = document.createElement("div"); g.style.cssText = "display:flex;gap:6px"; bar.insertBefore(g, btn); g.appendChild(btn); g.appendChild(v); }
      }
    } catch (e) {}
    return r;
  };
})();
