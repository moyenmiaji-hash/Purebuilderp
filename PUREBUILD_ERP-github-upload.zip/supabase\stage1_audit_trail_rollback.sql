-- Undo Stage 1. ERP data is not touched.
drop trigger if exists erp_state_audit on public.erp_cloud_state;
drop trigger if exists profiles_audit on public.profiles;
drop function if exists public.audit_erp_state();
drop function if exists public.audit_profiles();
drop function if exists public.audit_clean(jsonb);
drop policy if exists "Admins and auditors read audit log" on public.audit_log;
drop function if exists public.audit_can_read();
-- Keep history by default. Uncomment only if you really want to delete it:
-- drop table if exists public.audit_log;
