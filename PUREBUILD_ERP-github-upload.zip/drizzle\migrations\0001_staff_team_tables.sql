CREATE OR REPLACE FUNCTION public.pb_is_member(_project uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT false $$;

-- Projects
CREATE TABLE public.team_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  local_project_id text NOT NULL,
  project_code text,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, local_project_id)
);
GRANT SELECT, INSERT, UPDATE ON public.team_projects TO authenticated;
GRANT ALL ON public.team_projects TO service_role;
ALTER TABLE public.team_projects ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.team_project_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'active',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, user_id)
);
GRANT SELECT ON public.team_project_members TO authenticated;
GRANT ALL ON public.team_project_members TO service_role;
ALTER TABLE public.team_project_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.pb_is_member(_project uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.team_project_members WHERE project_id=_project AND user_id=_user AND status='active') $$;

CREATE POLICY "read projects" ON public.team_projects FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(id, auth.uid()));
CREATE POLICY "office add projects" ON public.team_projects FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office edit projects" ON public.team_projects FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "read memberships" ON public.team_project_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_office_user(auth.uid()));

-- BOQ
CREATE TABLE public.team_boq_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  local_boq_id text NOT NULL,
  item_code text,
  description text NOT NULL,
  unit text,
  quantity numeric NOT NULL DEFAULT 0,
  completed_qty numeric NOT NULL DEFAULT 0,
  approved_completed_qty numeric NOT NULL DEFAULT 0,
  remaining_qty numeric GENERATED ALWAYS AS (greatest(quantity - completed_qty, 0)) STORED,
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (project_id, local_boq_id)
);
GRANT SELECT, INSERT, UPDATE ON public.team_boq_items TO authenticated;
GRANT ALL ON public.team_boq_items TO service_role;
ALTER TABLE public.team_boq_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read boq" ON public.team_boq_items FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(project_id, auth.uid()));
CREATE POLICY "office add boq" ON public.team_boq_items FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office edit boq" ON public.team_boq_items FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.site_boq_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  boq_item_id uuid NOT NULL REFERENCES public.team_boq_items(id) ON DELETE CASCADE,
  assigned_to uuid NOT NULL,
  assigned_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (boq_item_id, assigned_to)
);
GRANT SELECT, INSERT, DELETE ON public.site_boq_assignments TO authenticated;
GRANT ALL ON public.site_boq_assignments TO service_role;
ALTER TABLE public.site_boq_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read assignments" ON public.site_boq_assignments FOR SELECT TO authenticated
  USING (assigned_to = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "office add assignments" ON public.site_boq_assignments FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office remove assignments" ON public.site_boq_assignments FOR DELETE TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.get_project_boq_assignable_staff(p_project_id uuid)
RETURNS TABLE(user_id uuid, display_name text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT m.user_id, coalesce(p.display_name, 'Staff') FROM public.team_project_members m
    LEFT JOIN public.profiles p ON p.id = m.user_id WHERE m.project_id = p_project_id AND m.status = 'active';
END $$;

-- Progress reports
CREATE TABLE public.site_progress_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  local_id text,
  report_date date NOT NULL DEFAULT current_date,
  created_by uuid NOT NULL,
  updated_by uuid,
  report_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  review_status text NOT NULL DEFAULT 'draft',
  review_note text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.site_progress_reports TO authenticated;
GRANT ALL ON public.site_progress_reports TO service_role;
ALTER TABLE public.site_progress_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read reports" ON public.site_progress_reports FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add reports" ON public.site_progress_reports FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()) AND review_status = 'draft');
CREATE POLICY "own draft submit" ON public.site_progress_reports FOR UPDATE TO authenticated
  USING (created_by = auth.uid() AND review_status = 'draft')
  WITH CHECK (created_by = auth.uid() AND review_status IN ('draft','submitted'));
CREATE POLICY "office review" ON public.site_progress_reports FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.site_progress_report_boq_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES public.site_progress_reports(id) ON DELETE CASCADE,
  boq_item_id uuid NOT NULL,
  local_boq_id text,
  today_qty numeric NOT NULL,
  previous_qty numeric NOT NULL DEFAULT 0,
  total_qty numeric NOT NULL DEFAULT 0,
  remaining_qty numeric NOT NULL DEFAULT 0,
  percent numeric NOT NULL DEFAULT 0
);
GRANT SELECT ON public.site_progress_report_boq_lines TO authenticated;
GRANT ALL ON public.site_progress_report_boq_lines TO service_role;
ALTER TABLE public.site_progress_report_boq_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read lines" ON public.site_progress_report_boq_lines FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.site_progress_reports r WHERE r.id = report_id
    AND (r.created_by = auth.uid() OR public.is_office_user(auth.uid()))));

CREATE OR REPLACE FUNCTION public.pb_report_status_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE line jsonb; b public.team_boq_items; q numeric;
BEGIN
  IF NEW.review_status = OLD.review_status THEN RETURN NEW; END IF;
  IF OLD.review_status = 'draft' AND NEW.review_status = 'submitted' THEN
    FOR line IN SELECT * FROM jsonb_array_elements(coalesce(NEW.report_payload->'boq_progress','[]'::jsonb)) LOOP
      SELECT * INTO b FROM public.team_boq_items WHERE id = (line->>'boq_item_id')::uuid AND project_id = NEW.project_id FOR UPDATE;
      IF NOT FOUND THEN RAISE EXCEPTION 'BOQ item not found for this site'; END IF;
      q := (line->>'today_qty')::numeric;
      IF q <= 0 OR q > b.quantity - b.completed_qty THEN RAISE EXCEPTION 'Quantity is more than the remaining work'; END IF;
      INSERT INTO public.site_progress_report_boq_lines(report_id,boq_item_id,local_boq_id,today_qty,previous_qty,total_qty,remaining_qty,percent)
        VALUES (NEW.id, b.id, b.local_boq_id, q, b.completed_qty, b.completed_qty+q, b.quantity-b.completed_qty-q,
          CASE WHEN b.quantity > 0 THEN round((b.completed_qty+q)/b.quantity*100,2) ELSE 0 END);
      UPDATE public.team_boq_items SET completed_qty = completed_qty + q WHERE id = b.id;
    END LOOP;
  ELSIF OLD.review_status = 'submitted' AND NEW.review_status = 'approved' THEN
    UPDATE public.team_boq_items t SET approved_completed_qty = least(t.quantity, t.approved_completed_qty + l.today_qty)
      FROM public.site_progress_report_boq_lines l WHERE l.report_id = NEW.id AND l.boq_item_id = t.id;
  ELSIF OLD.review_status = 'submitted' AND NEW.review_status = 'rejected' THEN
    UPDATE public.team_boq_items t SET completed_qty = greatest(0, t.completed_qty - l.today_qty)
      FROM public.site_progress_report_boq_lines l WHERE l.report_id = NEW.id AND l.boq_item_id = t.id;
  ELSE
    RAISE EXCEPTION 'This review change is not allowed';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER pb_report_status BEFORE UPDATE ON public.site_progress_reports
  FOR EACH ROW EXECUTE FUNCTION public.pb_report_status_change();

-- Workers and attendance
CREATE TABLE public.erp_attendance_workers (
  legacy_id text PRIMARY KEY,
  project_legacy_id text NOT NULL,
  name text NOT NULL,
  worker_code text,
  status text NOT NULL DEFAULT 'Active',
  role text,
  employment_category text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.erp_attendance_workers TO service_role;
ALTER TABLE public.erp_attendance_workers ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.sync_attendance_workers(p_workers jsonb)
RETURNS int LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  INSERT INTO public.erp_attendance_workers(legacy_id,project_legacy_id,name,worker_code,status,role,employment_category,updated_at)
  SELECT w->>'legacy_id', w->>'project_legacy_id', w->>'name', w->>'worker_code', coalesce(w->>'status','Active'), w->>'role', w->>'employment_category', now()
  FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','') <> ''
  ON CONFLICT (legacy_id) DO UPDATE SET project_legacy_id=EXCLUDED.project_legacy_id, name=EXCLUDED.name,
    worker_code=EXCLUDED.worker_code, status=EXCLUDED.status, role=EXCLUDED.role, employment_category=EXCLUDED.employment_category, updated_at=now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;

CREATE OR REPLACE FUNCTION public.get_assigned_attendance_workers(p_project_id uuid)
RETURNS TABLE(worker_legacy_id text, name text, worker_code text, role text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT w.legacy_id, w.name, w.worker_code, w.role FROM public.erp_attendance_workers w
    JOIN public.team_projects p ON p.local_project_id = w.project_legacy_id
    WHERE p.id = p_project_id AND w.status = 'Active' ORDER BY w.name;
END $$;

CREATE TABLE public.erp_attendance_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  project_legacy_id text,
  attendance_date date NOT NULL,
  submitted_by uuid NOT NULL,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, attendance_date)
);
GRANT SELECT ON public.erp_attendance_submissions TO authenticated;
GRANT ALL ON public.erp_attendance_submissions TO service_role;
ALTER TABLE public.erp_attendance_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read submissions" ON public.erp_attendance_submissions FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE TABLE public.erp_site_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES public.erp_attendance_submissions(id),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  project_legacy_id text,
  attendance_date date NOT NULL,
  worker_legacy_id text NOT NULL,
  worker_name text,
  worker_code text,
  worker_role text,
  status text NOT NULL,
  hours numeric NOT NULL DEFAULT 0,
  overtime numeric NOT NULL DEFAULT 0,
  remarks text,
  submitted_by uuid,
  updated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, attendance_date, worker_legacy_id)
);
GRANT SELECT, UPDATE ON public.erp_site_attendance TO authenticated;
GRANT ALL ON public.erp_site_attendance TO service_role;
ALTER TABLE public.erp_site_attendance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read attendance" ON public.erp_site_attendance FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(project_id, auth.uid()));
CREATE POLICY "office correct attendance" ON public.erp_site_attendance FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.erp_site_attendance_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  attendance_id uuid NOT NULL,
  old_values jsonb, new_values jsonb,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.erp_site_attendance_history TO authenticated;
GRANT ALL ON public.erp_site_attendance_history TO service_role;
ALTER TABLE public.erp_site_attendance_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "office read history" ON public.erp_site_attendance_history FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.pb_attendance_history()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.updated_by := auth.uid(); NEW.updated_at := now();
  INSERT INTO public.erp_site_attendance_history(attendance_id, old_values, new_values, changed_by)
  VALUES (OLD.id, jsonb_build_object('status',OLD.status,'hours',OLD.hours,'overtime',OLD.overtime,'remarks',OLD.remarks),
          jsonb_build_object('status',NEW.status,'hours',NEW.hours,'overtime',NEW.overtime,'remarks',NEW.remarks), auth.uid());
  RETURN NEW;
END $$;
CREATE TRIGGER pb_attendance_hist BEFORE UPDATE ON public.erp_site_attendance
  FOR EACH ROW EXECUTE FUNCTION public.pb_attendance_history();

CREATE OR REPLACE FUNCTION public.submit_site_attendance(p_project_id uuid, p_attendance_date date, p_idempotency_key text, p_entries jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE sid uuid; legacy text; n int;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'not authorized for this site'; END IF;
  SELECT id INTO sid FROM public.erp_attendance_submissions WHERE idempotency_key = p_idempotency_key;
  IF sid IS NOT NULL THEN
    RETURN jsonb_build_object('saved',true,'submissionId',sid,'entryCount',(SELECT count(*) FROM public.erp_site_attendance WHERE submission_id=sid));
  END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  INSERT INTO public.erp_attendance_submissions(project_id,project_legacy_id,attendance_date,submitted_by,idempotency_key)
    VALUES (p_project_id, legacy, p_attendance_date, auth.uid(), p_idempotency_key) RETURNING id INTO sid;
  INSERT INTO public.erp_site_attendance(submission_id,project_id,project_legacy_id,attendance_date,worker_legacy_id,worker_name,worker_code,worker_role,status,hours,overtime,remarks,submitted_by)
  SELECT sid, p_project_id, legacy, p_attendance_date, w.legacy_id, w.name, w.worker_code, w.role,
    e->>'status', coalesce((e->>'hours')::numeric,0), coalesce((e->>'overtime')::numeric,0), nullif(e->>'remarks',''), auth.uid()
  FROM jsonb_array_elements(p_entries) e
  JOIN public.erp_attendance_workers w ON w.legacy_id = e->>'worker_id' AND w.project_legacy_id = legacy;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN jsonb_build_object('saved',true,'submissionId',sid,'entryCount',n);
END $$;

-- Materials, equipment, diary
CREATE TABLE public.site_material_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  requested_by uuid NOT NULL,
  request_date date NOT NULL,
  remarks text,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid, reviewed_at timestamptz, review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_material_requests TO authenticated;
GRANT ALL ON public.site_material_requests TO service_role;
ALTER TABLE public.site_material_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read material requests" ON public.site_material_requests FOR SELECT TO authenticated
  USING (requested_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE TABLE public.site_material_request_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.site_material_requests(id) ON DELETE CASCADE,
  item_name text NOT NULL, item_code text, unit text, requested_qty numeric NOT NULL, note text
);
GRANT SELECT ON public.site_material_request_lines TO authenticated;
GRANT ALL ON public.site_material_request_lines TO service_role;
ALTER TABLE public.site_material_request_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read material lines" ON public.site_material_request_lines FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.site_material_requests r WHERE r.id = request_id
    AND (r.requested_by = auth.uid() OR public.is_office_user(auth.uid()))));

CREATE OR REPLACE FUNCTION public.submit_site_material_request(p_project_id uuid, p_request_date date, p_idempotency_key text, p_items jsonb, p_remarks text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE rid uuid;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'not authorized for this site'; END IF;
  SELECT id INTO rid FROM public.site_material_requests WHERE idempotency_key = p_idempotency_key;
  IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'requestId',rid); END IF;
  INSERT INTO public.site_material_requests(project_id,requested_by,request_date,remarks,idempotency_key)
    VALUES (p_project_id, auth.uid(), p_request_date, nullif(p_remarks,''), p_idempotency_key) RETURNING id INTO rid;
  INSERT INTO public.site_material_request_lines(request_id,item_name,item_code,unit,requested_qty,note)
  SELECT rid, i->>'item_name', nullif(i->>'item_code',''), i->>'unit', (i->>'requested_qty')::numeric, nullif(i->>'note','')
  FROM jsonb_array_elements(p_items) i;
  RETURN jsonb_build_object('saved',true,'requestId',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_material_request(p_request_id uuid, p_decision text, p_review_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  UPDATE public.site_material_requests SET review_status=p_decision, reviewed_by=auth.uid(), reviewed_at=now(), review_note=nullif(p_review_note,'')
    WHERE id = p_request_id AND review_status = 'pending';
  IF NOT FOUND THEN RAISE EXCEPTION 'Request already reviewed or not found'; END IF;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE TABLE public.site_equipment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  submitted_by uuid NOT NULL,
  entry_date date NOT NULL,
  equipment_name text NOT NULL, equipment_code text,
  operating_hours numeric, condition text, location text, remarks text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.site_equipment_logs TO authenticated;
GRANT ALL ON public.site_equipment_logs TO service_role;
ALTER TABLE public.site_equipment_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read equipment" ON public.site_equipment_logs FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add equipment" ON public.site_equipment_logs FOR INSERT TO authenticated
  WITH CHECK (submitted_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()));

CREATE TABLE public.site_diary_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  submitted_by uuid NOT NULL,
  entry_date date NOT NULL,
  weather text, work_summary text, manpower_count int, delays text, safety_notes text, visitors text, remarks text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, entry_date, submitted_by)
);
GRANT SELECT, INSERT ON public.site_diary_entries TO authenticated;
GRANT ALL ON public.site_diary_entries TO service_role;
ALTER TABLE public.site_diary_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read diary" ON public.site_diary_entries FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add diary" ON public.site_diary_entries FOR INSERT TO authenticated
  WITH CHECK (submitted_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()));

-- Profile for each new login
CREATE OR REPLACE FUNCTION public.pb_handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles(id, display_name) VALUES (NEW.id, coalesce(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER pb_on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.pb_handle_new_user();

-- Photos (bucket created separately)
CREATE POLICY "members upload photos" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'site-progress-photos' AND public.pb_is_member(((storage.foldername(name))[2])::uuid, auth.uid()));
CREATE POLICY "read photos" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'site-progress-photos' AND (owner = auth.uid() OR public.is_office_user(auth.uid())));