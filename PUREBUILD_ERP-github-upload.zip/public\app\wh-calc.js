/* PURE_BUILD Central Warehouse formulas (pure, no DOM). Tested in src/test/wh-calc.test.ts */
(function (root) {
  const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };

  /* ---------- Units ---------- */
  const ALIAS = { "m3": "cum", "m³": "cum", "cu.m": "cum", "cbm": "cum", "cum": "cum", "cft": "cft", "cu.ft": "cft",
    "m2": "sqm", "m²": "sqm", "sqm": "sqm", "sft": "sft", "sqft": "sft", "m": "m", "rm": "m", "rmt": "m", "ft": "ft",
    "kg": "kg", "kgs": "kg", "ton": "ton", "tons": "ton", "mt": "ton", "tonne": "ton", "l": "litre", "ltr": "litre", "litre": "litre", "liter": "litre",
    "pcs": "pcs", "pc": "pcs", "nos": "pcs", "no": "pcs", "no.": "pcs", "bag": "bag", "bags": "bag" };
  const unitKey = (u) => { const k = String(u || "").trim().toLowerCase(); return ALIAS[k] || k; };
  const BUILTIN = [["ton", "kg", 1000], ["cum", "cft", 35.3147], ["sqm", "sft", 10.7639], ["m", "ft", 3.28084]];

  /** Convert qty from one unit to another. rules: [{from,to,factor}] meaning 1 from = factor to. Returns null if units cannot be mixed. */
  function convert(qty, from, to, rules) {
    const a = unitKey(from), b = unitKey(to), q = num(qty);
    if (a === b) return q;
    const all = BUILTIN.concat((rules || []).map((r) => [unitKey(r.from), unitKey(r.to), num(r.factor)])).filter((r) => r[2] > 0);
    for (const [f, t, k] of all) {
      if (f === a && t === b) return q * k;
      if (f === b && t === a) return q / k;
    }
    return null;
  }

  /* ---------- Central warehouse ---------- */
  const sign = (x) => (x.direction === "In" ? 1 : -1);
  /** Statement per key for central ledger rows. movement: Opening | GRN | Issue | Return | Damage | AdjIn | AdjOut (reversal rows flip). */
  function centralStatement(rows, keyFn) {
    const map = new Map();
    (rows || []).forEach((x) => {
      const k = keyFn(x);
      if (!map.has(k)) map.set(k, { key: k, item: x.item, unit: x.unit, opening: 0, received: 0, issued: 0, returned: 0, damaged: 0, adjIn: 0, adjOut: 0, inQty: 0, inValue: 0 });
      const r = map.get(k), q = num(x.qty), s = x.reversal ? -1 : 1;
      const f = { Opening: "opening", GRN: "received", Issue: "issued", Return: "returned", Damage: "damaged", AdjIn: "adjIn", AdjOut: "adjOut" }[x.movement] || (x.direction === "In" ? "adjIn" : "adjOut");
      if (x.reversal) {
        // a reversal row undoes its original bucket
        const orig = x.direction === "In" ? (x.movement === "Issue" ? "issued" : x.movement === "Damage" ? "damaged" : "adjOut") : (x.movement === "GRN" ? "received" : x.movement === "Return" ? "returned" : x.movement === "Opening" ? "opening" : "adjIn");
        r[orig] -= q;
      } else r[f] += q;
      if (!x.reversal && x.direction === "In" && num(x.rate) > 0) { r.inQty += q; r.inValue += q * num(x.rate); }
      void s; void sign;
    });
    return [...map.values()].map((r) => ({ ...r, available: r.opening + r.received + r.returned + r.adjIn - r.issued - r.damaged - r.adjOut, avgRate: r.inQty ? r.inValue / r.inQty : 0 }));
  }

  /** Plain balance (In − Out) of rows for one key. */
  function balance(rows, keyFn, key) {
    return (rows || []).filter((x) => keyFn(x) === key).reduce((a, x) => a + sign(x) * num(x.qty), 0);
  }

  /** Foreman site formula. Closing = Opening + Received + ReturnsFromWarehouse − Used − Damaged − TransferredOut */
  function siteClosing(o) {
    return num(o.opening) + num(o.received) + num(o.returnsFromWh) - num(o.used) - num(o.damaged) - num(o.transferredOut);
  }
  /** Validate a foreman line: returns "" or an error text. */
  function checkSiteLine(o) {
    for (const k of ["received", "used", "damaged", "transferredOut", "returnsFromWh"]) if (num(o[k]) < 0) return "Quantities cannot be negative";
    if (siteClosing(o) < -1e-9) return "Used + damaged + returned is more than the stock on site";
    return "";
  }

  /** Purchase receiving: how much is still open. received = posted qty, pending = qty in pending vouchers. */
  function purchaseOpen(ordered, received, pending) {
    return Math.max(0, num(ordered) - num(received) - num(pending));
  }

  /** Is a voucher already posted? rows = all ledger rows (central + site). */
  function isPosted(voucherId, rows) {
    return (rows || []).some((x) => x.whVoucherId === voucherId && !x.reversal);
  }

  /** Site receiving: what to post on approval.
      source 'supplier' = material not yet in site stock → add accepted only.
      source 'central' / 'site_purchase' = expected qty was ALREADY added to site stock by the issue voucher / purchase
      → post only the difference: damaged and shortage go out, any excess comes in. Damaged is never usable stock. */
  function receivingPost(source, expected, accepted, damaged) {
    const a = Math.max(0, num(accepted)), d = Math.max(0, num(damaged));
    if (source === "supplier") return { inQty: a, damageOut: 0, shortOut: 0 };
    const delta = a - Math.max(0, num(expected)), miss = Math.max(0, -delta), dOut = Math.min(d, miss);
    return { inQty: Math.max(0, delta), damageOut: dOut, shortOut: miss - dOut };
  }
  /** Shortage for a receiving line = expected − received (never negative). */
  function receivingShortage(expected, received) { return Math.max(0, num(expected) - num(received)); }

  const api = { receivingPost, receivingShortage, unitKey, convert, centralStatement, balance, siteClosing, checkSiteLine, purchaseOpen, isPosted };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PBWhCalc = api;
})(typeof window !== "undefined" ? window : globalThis);
