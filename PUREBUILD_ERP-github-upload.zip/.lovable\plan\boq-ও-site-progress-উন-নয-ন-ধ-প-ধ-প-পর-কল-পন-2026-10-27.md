# BOQ ও Site Progress উন্নয়ন: ধাপে ধাপে পরিকল্পনা

আপনার অ্যাপের ভেতরটা খুঁটিয়ে দেখে ছবির ৮টি ধাপের সাথে মিলিয়েছি। নিচে লেখা আছে কোনটা আগে থেকেই আছে, কোনটা অর্ধেক হয়ে আছে, আর কোনটা একেবারে নেই।
নিয়ম তিনটা:
- নতুন মেনু বা নতুন অ্যাপ হবে না।
- পুরনো কোনো তথ্য মুছবে না।
- কাজগুলো ৩টা ভাগে হবে। একেকটা ভাগ শেষ হলে আপনি দেখে "ঠিক আছে" বললে তারপর পরেরটা ধরব।

## আগে থেকেই আছে, ঠিকমতো চলছে (ছোঁয়া হবে না)
| ছবির ধাপ | অ্যাপে এখন যা আছে |
|---|---|
| ১. প্রজেক্ট সেটআপ | Projects পাতা, প্রজেক্টের ভেতরে Site যোগ |
| ২. সাইট সেটআপ | Building → Floor → Room → Zone (Locations & Allocation) |
| ৩. ড্রয়িং থেকে BOQ | মাপ L×W×H দিলে পরিমাণ ও টাকা নিজে থেকে হিসাব, ড্রয়িং সংযুক্ত করা, CSV import, Copy বোতাম |
| ৬. মোবাইল প্রগ্রেস | ৫ ধাপের ফোরম্যান অ্যাপ: লোকেশন, BOQ, শ্রমিক, মালামাল, ছবি; বাকি কাজের চেয়ে বেশি পরিমাণ দেওয়া যায় না |
| ৭. Approve | Dashboard থেকে Check & Approve, সারাংশ দেখে Approve বা Reject; Reject হলে পরিমাণ ফেরত যায় |

## অর্ধেক আছে, সম্পূর্ণ করতে হবে
- **BOQ অবস্থা:** এখন Draft, Submitted আর Approved আছে। ছবিতে চাওয়া হয়েছে Draft → Under Review → Approved → Revised।
- **সমস্যা:** ফোরম্যান এখন Draft BOQ-ও দেখতে পায়। অনুমোদন হয়নি এমন কাজে প্রগ্রেস দেওয়া যাচ্ছে।
- **Revision ইতিহাস:** পরিবর্তনের ইতিহাস সংরক্ষণ হয়, কিন্তু কে বদলালেন আর কেন বদলালেন, সেটা লেখা থাকে না।

## একেবারে নেই
- Common Area-র ধরন (Corridor, Staircase, Roof, Lift)।
- Room Template, আর এক ক্লিকে কয়েকটা রুমে BOQ কপি।
- Dashboard-এ Building-ভিত্তিক অগ্রগতি।
- Location-ভিত্তিক অগ্রগতির রিপোর্ট।

---

## ভাগ ১: BOQ অনুমোদন ঠিক করা (সবচেয়ে জরুরি)
1. অবস্থাগুলো হবে: **Draft → Under Review → Approved → Revised**। আগের "Submitted" নিজে থেকেই "Under Review" নামে দেখাবে, পুরনো তথ্য বদলাবে না।
2. যেসব পুরনো BOQ-তে কোনো অবস্থা দেওয়া নেই, সেগুলো আগের মতোই **Approved** থাকবে। তাই এখন যে কাজ চলছে, সেটা থামবে না।
3. Approved BOQ-এর পরিমাণ, রেট বা লোকেশন বদলালে:
   - কারণ লেখা বাধ্যতামূলক হবে।
   - অবস্থা নিজে থেকে **Revised** হবে।
   - ইতিহাসে লেখা থাকবে: তারিখ, কে বদলালেন, 100 → 120, আর কারণ।
4. অবস্থা বদলাতে পারবেন শুধু Admin আর Manager। Accountant দেখতে পারবেন, বদলাতে পারবেন না।
5. **ফোরম্যানের ফোনে শুধু Approved আর Revised BOQ আসবে।** Draft বা Under Review এলে সেটা ফোন থেকে লুকিয়ে যাবে। এটা আগের "লুকানো" ব্যবস্থা দিয়েই হবে, ডাটাবেসে কিছু মুছবে না। আগে জমা পড়া রিপোর্টও ঠিক থাকবে।
6. BOQ-এর বিস্তারিত দেখার বাক্সে একটা "Revision History" অংশ থাকবে, ছবির মতো।

## ভাগ ২: সাইট সেটআপ ও Room Template
1. **Room-এর ধরন:** Room যোগ বা Edit করার সময় বেছে নেওয়া যাবে: Room, Corridor, Staircase, Roof, Lift বা অন্য। লোকেশন তালিকায় ধরন অনুযায়ী ছোট চিহ্ন দেখাবে। পুরনো রুম "Room" হিসেবেই থাকবে।
2. **Room Template:** BOQ পাতায় নতুন বোতাম আসবে **"Room Template"**।
   - কোনো রুমের সব BOQ আইটেম, অথবা বেছে নেওয়া কয়েকটা আইটেম, নাম দিয়ে template হিসেবে রাখা যাবে, যেমন "Bedroom Type A"।
   - template বেছে নিয়ে, Building আর Floor ধরে রুমের তালিকায় টিক দিয়ে **"Copy BOQ"** চাপা যাবে।
   - কপি করার আগে একটা আগাম তালিকা দেখাবে: কোন রুমে কয়টা আইটেম যাবে, আর কয়টা বাদ যাবে কারণ আগে থেকেই আছে।
   - প্রতিটা রুমে আলাদা নতুন BOQ তৈরি হবে, নতুন ID (BOQ-0xx) আর **Draft** অবস্থা নিয়ে। পরে প্রতিটা রুমের পরিমাণ আলাদা করে বদলানো যাবে।
   - আগের কোনো BOQ, Approved আইটেম বা প্রগ্রেস বদলাবে না, মুছবেও না।

## ভাগ ৩: Dashboard ও Report
1. **Dashboard-এর এখনকার Site Progress বক্সে** ছোট করে যোগ হবে: মোট Building, মোট Room, সামগ্রিক অগ্রগতির % আর Pending রিপোর্ট। সাথে থাকবে Building-ভিত্তিক অগ্রগতির দাগ আর সাম্প্রতিক কাজ। Dashboard আগের মতো এক স্ক্রিনেই থাকবে। কোনো টাকার বক্স বদলাবে না।
2. **Reports পাতায় একটা নতুন ট্যাব আসবে: "Site Progress"**
   - Project → Building → Floor → Room ধরে প্রতিটা কাজের পরিকল্পিত, সম্পন্ন ও বাকি পরিমাণ আর %।
   - Pending, Approved আর Rejected রিপোর্টের সংখ্যা।
   - **পিছিয়ে থাকা কাজ:** ১৪ দিন কোনো প্রগ্রেস আসেনি অথচ কাজ শেষ হয়নি, এমন আইটেম।
   - BOQ-এর পরিবর্তনের ইতিহাস।
   - ফিল্টার করা যাবে, আর CSV ডাউনলোড করা যাবে।
   - **শুধু Approve হওয়া প্রগ্রেস গোনা হবে।** Pending আর Rejected গোনা হবে না।

## যা ছোঁয়া হবে না
Transaction Entry, Sales & Invoiced, Ledger, Accounts Payable, Stock, Labour & HR, Quotation, Settings, টাকার সব হিসাব, লগইন আর ব্যবহারকারীর অনুমতি।

## পরীক্ষা ও নিরাপত্তা
- প্রতিটা ভাগ আলাদা একটা পরীক্ষার ব্রাউজারে নকল তথ্য দিয়ে চালিয়ে দেখব। আপনার আসল তথ্যে হাত দেওয়া হবে না।
- আপডেটের আগে আপনার তথ্যের একটা নিরাপত্তা কপি নিজে থেকে রাখা হবে।
- Publish আমি নিজে করব না, আপনি দেখে নিজে Publish করবেন।
- ডাটাবেসে কোনো পরিবর্তন (migration) লাগবে না।

## Technical details
- Files: `public/app/index.html` (boqStatus/boqSetStatus, addBOQ revision reason + role gate, boqDetail history, location type in locationMeta, template modal, reports tab), `public/app/team-erp.js` (sync: `is_active` = status in Approved/Revised; status in `metadata`; dashboard box in `pbPaintPending`), `public/app/team-staff.js` (no change expected; already filters `is_active`).
- New optional data only: `boq.status` values, `boq.statusHistory[{at,by,from,to,reason}]`, `boq.revisions[].by/reason`, `boq.templateId`, `db.boqTemplates[]`, `db.locationMeta[pid][key].type`. Existing "Submitted" displayed as "Under Review" (value mapping, not rewritten).
- Role check uses the existing signed-in cloud profile role (admin/manager); falls back to the existing Access role locally.
- Hiding non-approved BOQ from staff uses the existing `is_active=false` update path (rows kept). The DB trigger already blocks quantity over remaining.
- Bump `PB_SAFETY_VERSION` and cache version per phase.
- Rollback: restore the previous version from project history; data untouched.
