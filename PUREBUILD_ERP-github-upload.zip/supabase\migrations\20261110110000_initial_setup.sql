-- PURE_BUILD initial schema for a new Supabase project. Run once in Supabase SQL Editor.
-- Migrations 0002-0004 are intentionally excluded: they hard-code an unrelated admin email.
BEGIN;
INSERT INTO storage.buckets (id, name, public) VALUES ('site-progress-photos', 'site-progress-photos', false), ('project-documents', 'project-documents', false) ON CONFLICT (id) DO NOTHING;

-- Source: drizzle\migrations\0000_core_erp_foundation.sql
CREATE TYPE public.app_role AS ENUM ('admin','manager','accountant','auditor','staff');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  display_name text,
  role text NOT NULL DEFAULT 'staff',
  status text NOT NULL DEFAULT 'active',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.profiles (id, display_name)
SELECT id, coalesce(raw_user_meta_data->>'display_name', split_part(email, '@', 1))
FROM auth.users
ON CONFLICT (id) DO NOTHING;
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_office_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','manager','accountant'))
$$;

CREATE POLICY "Users read own profile" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update profiles" ON public.profiles FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.erp_cloud_state (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  data jsonb NOT NULL,
  revision int NOT NULL DEFAULT 1,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.erp_cloud_state TO authenticated;
GRANT ALL ON public.erp_cloud_state TO service_role;
ALTER TABLE public.erp_cloud_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office users read ERP data" ON public.erp_cloud_state FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE TABLE public.erp_state_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  revision int NOT NULL,
  data jsonb NOT NULL,
  saved_by uuid,
  saved_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.erp_state_history TO service_role;
ALTER TABLE public.erp_state_history ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.erp_state_save(p_expected int, p_data jsonb)
RETURNS int LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE cur public.erp_cloud_state; nrev int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'NOT_ALLOWED'; END IF;
  IF p_data IS NULL OR coalesce(jsonb_array_length(p_data->'projects'),0) = 0
     AND coalesce(jsonb_array_length(p_data->'transactions'),0) = 0 THEN
    RAISE EXCEPTION 'EMPTY_OVERWRITE_BLOCKED';
  END IF;
  SELECT * INTO cur FROM public.erp_cloud_state WHERE id = 1 FOR UPDATE;
  IF NOT FOUND THEN
    IF coalesce(p_expected,0) <> 0 THEN RAISE EXCEPTION 'REVISION_CONFLICT'; END IF;
    INSERT INTO public.erp_cloud_state(id,data,revision,updated_by) VALUES (1,p_data,1,auth.uid());
    RETURN 1;
  END IF;
  IF cur.revision <> p_expected THEN RAISE EXCEPTION 'REVISION_CONFLICT'; END IF;
  INSERT INTO public.erp_state_history(revision,data,saved_by) VALUES (cur.revision,cur.data,cur.updated_by);
  nrev := cur.revision + 1;
  UPDATE public.erp_cloud_state SET data=p_data, revision=nrev, updated_by=auth.uid(), updated_at=now() WHERE id=1;
  RETURN nrev;
END $$;
REVOKE EXECUTE ON FUNCTION public.erp_state_save(int,jsonb) FROM anon;
GRANT EXECUTE ON FUNCTION public.erp_state_save(int,jsonb) TO authenticated;

-- Source: drizzle\migrations\0001_staff_team_tables.sql
CREATE OR REPLACE FUNCTION public.pb_is_member(_project uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT false $$;

-- Projects
CREATE TABLE public.team_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  local_project_id text NOT NULL,
  project_code text,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organization_id, local_project_id)
);
GRANT SELECT, INSERT, UPDATE ON public.team_projects TO authenticated;
GRANT ALL ON public.team_projects TO service_role;
ALTER TABLE public.team_projects ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.team_project_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'active',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, user_id)
);
GRANT SELECT ON public.team_project_members TO authenticated;
GRANT ALL ON public.team_project_members TO service_role;
ALTER TABLE public.team_project_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.pb_is_member(_project uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.team_project_members WHERE project_id=_project AND user_id=_user AND status='active') $$;

CREATE POLICY "read projects" ON public.team_projects FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(id, auth.uid()));
CREATE POLICY "office add projects" ON public.team_projects FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office edit projects" ON public.team_projects FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "read memberships" ON public.team_project_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_office_user(auth.uid()));

-- BOQ
CREATE TABLE public.team_boq_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  local_boq_id text NOT NULL,
  item_code text,
  description text NOT NULL,
  unit text,
  quantity numeric NOT NULL DEFAULT 0,
  completed_qty numeric NOT NULL DEFAULT 0,
  approved_completed_qty numeric NOT NULL DEFAULT 0,
  remaining_qty numeric GENERATED ALWAYS AS (greatest(quantity - completed_qty, 0)) STORED,
  sort_order int NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (project_id, local_boq_id)
);
GRANT SELECT, INSERT, UPDATE ON public.team_boq_items TO authenticated;
GRANT ALL ON public.team_boq_items TO service_role;
ALTER TABLE public.team_boq_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read boq" ON public.team_boq_items FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(project_id, auth.uid()));
CREATE POLICY "office add boq" ON public.team_boq_items FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office edit boq" ON public.team_boq_items FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.site_boq_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id) ON DELETE CASCADE,
  boq_item_id uuid NOT NULL REFERENCES public.team_boq_items(id) ON DELETE CASCADE,
  assigned_to uuid NOT NULL,
  assigned_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (boq_item_id, assigned_to)
);
GRANT SELECT, INSERT, DELETE ON public.site_boq_assignments TO authenticated;
GRANT ALL ON public.site_boq_assignments TO service_role;
ALTER TABLE public.site_boq_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read assignments" ON public.site_boq_assignments FOR SELECT TO authenticated
  USING (assigned_to = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "office add assignments" ON public.site_boq_assignments FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()));
CREATE POLICY "office remove assignments" ON public.site_boq_assignments FOR DELETE TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.get_project_boq_assignable_staff(p_project_id uuid)
RETURNS TABLE(user_id uuid, display_name text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT m.user_id, coalesce(p.display_name, 'Staff') FROM public.team_project_members m
    LEFT JOIN public.profiles p ON p.id = m.user_id WHERE m.project_id = p_project_id AND m.status = 'active';
END $$;

-- Progress reports
CREATE TABLE public.site_progress_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  local_id text,
  report_date date NOT NULL DEFAULT current_date,
  created_by uuid NOT NULL,
  updated_by uuid,
  report_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  review_status text NOT NULL DEFAULT 'draft',
  review_note text,
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.site_progress_reports TO authenticated;
GRANT ALL ON public.site_progress_reports TO service_role;
ALTER TABLE public.site_progress_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read reports" ON public.site_progress_reports FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add reports" ON public.site_progress_reports FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()) AND review_status = 'draft');
CREATE POLICY "own draft submit" ON public.site_progress_reports FOR UPDATE TO authenticated
  USING (created_by = auth.uid() AND review_status = 'draft')
  WITH CHECK (created_by = auth.uid() AND review_status IN ('draft','submitted'));
CREATE POLICY "office review" ON public.site_progress_reports FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.site_progress_report_boq_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES public.site_progress_reports(id) ON DELETE CASCADE,
  boq_item_id uuid NOT NULL,
  local_boq_id text,
  today_qty numeric NOT NULL,
  previous_qty numeric NOT NULL DEFAULT 0,
  total_qty numeric NOT NULL DEFAULT 0,
  remaining_qty numeric NOT NULL DEFAULT 0,
  percent numeric NOT NULL DEFAULT 0
);
GRANT SELECT ON public.site_progress_report_boq_lines TO authenticated;
GRANT ALL ON public.site_progress_report_boq_lines TO service_role;
ALTER TABLE public.site_progress_report_boq_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read lines" ON public.site_progress_report_boq_lines FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.site_progress_reports r WHERE r.id = report_id
    AND (r.created_by = auth.uid() OR public.is_office_user(auth.uid()))));

CREATE OR REPLACE FUNCTION public.pb_report_status_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE line jsonb; b public.team_boq_items; q numeric;
BEGIN
  IF NEW.review_status = OLD.review_status THEN RETURN NEW; END IF;
  IF OLD.review_status = 'draft' AND NEW.review_status = 'submitted' THEN
    FOR line IN SELECT * FROM jsonb_array_elements(coalesce(NEW.report_payload->'boq_progress','[]'::jsonb)) LOOP
      SELECT * INTO b FROM public.team_boq_items WHERE id = (line->>'boq_item_id')::uuid AND project_id = NEW.project_id FOR UPDATE;
      IF NOT FOUND THEN RAISE EXCEPTION 'BOQ item not found for this site'; END IF;
      q := (line->>'today_qty')::numeric;
      IF q <= 0 OR q > b.quantity - b.completed_qty THEN RAISE EXCEPTION 'Quantity is more than the remaining work'; END IF;
      INSERT INTO public.site_progress_report_boq_lines(report_id,boq_item_id,local_boq_id,today_qty,previous_qty,total_qty,remaining_qty,percent)
        VALUES (NEW.id, b.id, b.local_boq_id, q, b.completed_qty, b.completed_qty+q, b.quantity-b.completed_qty-q,
          CASE WHEN b.quantity > 0 THEN round((b.completed_qty+q)/b.quantity*100,2) ELSE 0 END);
      UPDATE public.team_boq_items SET completed_qty = completed_qty + q WHERE id = b.id;
    END LOOP;
  ELSIF OLD.review_status = 'submitted' AND NEW.review_status = 'approved' THEN
    UPDATE public.team_boq_items t SET approved_completed_qty = least(t.quantity, t.approved_completed_qty + l.today_qty)
      FROM public.site_progress_report_boq_lines l WHERE l.report_id = NEW.id AND l.boq_item_id = t.id;
  ELSIF OLD.review_status = 'submitted' AND NEW.review_status = 'rejected' THEN
    UPDATE public.team_boq_items t SET completed_qty = greatest(0, t.completed_qty - l.today_qty)
      FROM public.site_progress_report_boq_lines l WHERE l.report_id = NEW.id AND l.boq_item_id = t.id;
  ELSE
    RAISE EXCEPTION 'This review change is not allowed';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER pb_report_status BEFORE UPDATE ON public.site_progress_reports
  FOR EACH ROW EXECUTE FUNCTION public.pb_report_status_change();

-- Workers and attendance
CREATE TABLE public.erp_attendance_workers (
  legacy_id text PRIMARY KEY,
  project_legacy_id text NOT NULL,
  name text NOT NULL,
  worker_code text,
  status text NOT NULL DEFAULT 'Active',
  role text,
  employment_category text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.erp_attendance_workers TO service_role;
ALTER TABLE public.erp_attendance_workers ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.sync_attendance_workers(p_workers jsonb)
RETURNS int LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  INSERT INTO public.erp_attendance_workers(legacy_id,project_legacy_id,name,worker_code,status,role,employment_category,updated_at)
  SELECT w->>'legacy_id', w->>'project_legacy_id', w->>'name', w->>'worker_code', coalesce(w->>'status','Active'), w->>'role', w->>'employment_category', now()
  FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','') <> ''
  ON CONFLICT (legacy_id) DO UPDATE SET project_legacy_id=EXCLUDED.project_legacy_id, name=EXCLUDED.name,
    worker_code=EXCLUDED.worker_code, status=EXCLUDED.status, role=EXCLUDED.role, employment_category=EXCLUDED.employment_category, updated_at=now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;

CREATE OR REPLACE FUNCTION public.get_assigned_attendance_workers(p_project_id uuid)
RETURNS TABLE(worker_legacy_id text, name text, worker_code text, role text) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT w.legacy_id, w.name, w.worker_code, w.role FROM public.erp_attendance_workers w
    JOIN public.team_projects p ON p.local_project_id = w.project_legacy_id
    WHERE p.id = p_project_id AND w.status = 'Active' ORDER BY w.name;
END $$;

CREATE TABLE public.erp_attendance_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  project_legacy_id text,
  attendance_date date NOT NULL,
  submitted_by uuid NOT NULL,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, attendance_date)
);
GRANT SELECT ON public.erp_attendance_submissions TO authenticated;
GRANT ALL ON public.erp_attendance_submissions TO service_role;
ALTER TABLE public.erp_attendance_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read submissions" ON public.erp_attendance_submissions FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE TABLE public.erp_site_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES public.erp_attendance_submissions(id),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  project_legacy_id text,
  attendance_date date NOT NULL,
  worker_legacy_id text NOT NULL,
  worker_name text,
  worker_code text,
  worker_role text,
  status text NOT NULL,
  hours numeric NOT NULL DEFAULT 0,
  overtime numeric NOT NULL DEFAULT 0,
  remarks text,
  submitted_by uuid,
  updated_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, attendance_date, worker_legacy_id)
);
GRANT SELECT, UPDATE ON public.erp_site_attendance TO authenticated;
GRANT ALL ON public.erp_site_attendance TO service_role;
ALTER TABLE public.erp_site_attendance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read attendance" ON public.erp_site_attendance FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR public.pb_is_member(project_id, auth.uid()));
CREATE POLICY "office correct attendance" ON public.erp_site_attendance FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE TABLE public.erp_site_attendance_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  attendance_id uuid NOT NULL,
  old_values jsonb, new_values jsonb,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.erp_site_attendance_history TO authenticated;
GRANT ALL ON public.erp_site_attendance_history TO service_role;
ALTER TABLE public.erp_site_attendance_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "office read history" ON public.erp_site_attendance_history FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.pb_attendance_history()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.updated_by := auth.uid(); NEW.updated_at := now();
  INSERT INTO public.erp_site_attendance_history(attendance_id, old_values, new_values, changed_by)
  VALUES (OLD.id, jsonb_build_object('status',OLD.status,'hours',OLD.hours,'overtime',OLD.overtime,'remarks',OLD.remarks),
          jsonb_build_object('status',NEW.status,'hours',NEW.hours,'overtime',NEW.overtime,'remarks',NEW.remarks), auth.uid());
  RETURN NEW;
END $$;
CREATE TRIGGER pb_attendance_hist BEFORE UPDATE ON public.erp_site_attendance
  FOR EACH ROW EXECUTE FUNCTION public.pb_attendance_history();

CREATE OR REPLACE FUNCTION public.submit_site_attendance(p_project_id uuid, p_attendance_date date, p_idempotency_key text, p_entries jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE sid uuid; legacy text; n int;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'not authorized for this site'; END IF;
  SELECT id INTO sid FROM public.erp_attendance_submissions WHERE idempotency_key = p_idempotency_key;
  IF sid IS NOT NULL THEN
    RETURN jsonb_build_object('saved',true,'submissionId',sid,'entryCount',(SELECT count(*) FROM public.erp_site_attendance WHERE submission_id=sid));
  END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  INSERT INTO public.erp_attendance_submissions(project_id,project_legacy_id,attendance_date,submitted_by,idempotency_key)
    VALUES (p_project_id, legacy, p_attendance_date, auth.uid(), p_idempotency_key) RETURNING id INTO sid;
  INSERT INTO public.erp_site_attendance(submission_id,project_id,project_legacy_id,attendance_date,worker_legacy_id,worker_name,worker_code,worker_role,status,hours,overtime,remarks,submitted_by)
  SELECT sid, p_project_id, legacy, p_attendance_date, w.legacy_id, w.name, w.worker_code, w.role,
    e->>'status', coalesce((e->>'hours')::numeric,0), coalesce((e->>'overtime')::numeric,0), nullif(e->>'remarks',''), auth.uid()
  FROM jsonb_array_elements(p_entries) e
  JOIN public.erp_attendance_workers w ON w.legacy_id = e->>'worker_id' AND w.project_legacy_id = legacy;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN jsonb_build_object('saved',true,'submissionId',sid,'entryCount',n);
END $$;

-- Materials, equipment, diary
CREATE TABLE public.site_material_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  requested_by uuid NOT NULL,
  request_date date NOT NULL,
  remarks text,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid, reviewed_at timestamptz, review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_material_requests TO authenticated;
GRANT ALL ON public.site_material_requests TO service_role;
ALTER TABLE public.site_material_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read material requests" ON public.site_material_requests FOR SELECT TO authenticated
  USING (requested_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE TABLE public.site_material_request_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.site_material_requests(id) ON DELETE CASCADE,
  item_name text NOT NULL, item_code text, unit text, requested_qty numeric NOT NULL, note text
);
GRANT SELECT ON public.site_material_request_lines TO authenticated;
GRANT ALL ON public.site_material_request_lines TO service_role;
ALTER TABLE public.site_material_request_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read material lines" ON public.site_material_request_lines FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.site_material_requests r WHERE r.id = request_id
    AND (r.requested_by = auth.uid() OR public.is_office_user(auth.uid()))));

CREATE OR REPLACE FUNCTION public.submit_site_material_request(p_project_id uuid, p_request_date date, p_idempotency_key text, p_items jsonb, p_remarks text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE rid uuid;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'not authorized for this site'; END IF;
  SELECT id INTO rid FROM public.site_material_requests WHERE idempotency_key = p_idempotency_key;
  IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'requestId',rid); END IF;
  INSERT INTO public.site_material_requests(project_id,requested_by,request_date,remarks,idempotency_key)
    VALUES (p_project_id, auth.uid(), p_request_date, nullif(p_remarks,''), p_idempotency_key) RETURNING id INTO rid;
  INSERT INTO public.site_material_request_lines(request_id,item_name,item_code,unit,requested_qty,note)
  SELECT rid, i->>'item_name', nullif(i->>'item_code',''), i->>'unit', (i->>'requested_qty')::numeric, nullif(i->>'note','')
  FROM jsonb_array_elements(p_items) i;
  RETURN jsonb_build_object('saved',true,'requestId',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_material_request(p_request_id uuid, p_decision text, p_review_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  UPDATE public.site_material_requests SET review_status=p_decision, reviewed_by=auth.uid(), reviewed_at=now(), review_note=nullif(p_review_note,'')
    WHERE id = p_request_id AND review_status = 'pending';
  IF NOT FOUND THEN RAISE EXCEPTION 'Request already reviewed or not found'; END IF;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE TABLE public.site_equipment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  submitted_by uuid NOT NULL,
  entry_date date NOT NULL,
  equipment_name text NOT NULL, equipment_code text,
  operating_hours numeric, condition text, location text, remarks text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.site_equipment_logs TO authenticated;
GRANT ALL ON public.site_equipment_logs TO service_role;
ALTER TABLE public.site_equipment_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read equipment" ON public.site_equipment_logs FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add equipment" ON public.site_equipment_logs FOR INSERT TO authenticated
  WITH CHECK (submitted_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()));

CREATE TABLE public.site_diary_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  submitted_by uuid NOT NULL,
  entry_date date NOT NULL,
  weather text, work_summary text, manpower_count int, delays text, safety_notes text, visitors text, remarks text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (project_id, entry_date, submitted_by)
);
GRANT SELECT, INSERT ON public.site_diary_entries TO authenticated;
GRANT ALL ON public.site_diary_entries TO service_role;
ALTER TABLE public.site_diary_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read diary" ON public.site_diary_entries FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE POLICY "members add diary" ON public.site_diary_entries FOR INSERT TO authenticated
  WITH CHECK (submitted_by = auth.uid() AND public.pb_is_member(project_id, auth.uid()));

-- Profile for each new login
CREATE OR REPLACE FUNCTION public.pb_handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles(id, display_name) VALUES (NEW.id, coalesce(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END $$;
CREATE TRIGGER pb_on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.pb_handle_new_user();

-- Photos (bucket created separately)
CREATE POLICY "members upload photos" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'site-progress-photos' AND public.pb_is_member(((storage.foldername(name))[2])::uuid, auth.uid()));
CREATE POLICY "read photos" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'site-progress-photos' AND (owner = auth.uid() OR public.is_office_user(auth.uid())));

-- Source: drizzle\migrations\0005_sync_workers_hide_removed.sql
CREATE OR REPLACE FUNCTION public.sync_attendance_workers(p_workers jsonb)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  INSERT INTO public.erp_attendance_workers(legacy_id,project_legacy_id,name,worker_code,status,role,employment_category,updated_at)
  SELECT w->>'legacy_id', w->>'project_legacy_id', w->>'name', w->>'worker_code', coalesce(w->>'status','Active'), w->>'role', w->>'employment_category', now()
  FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','') <> ''
  ON CONFLICT (legacy_id) DO UPDATE SET project_legacy_id=EXCLUDED.project_legacy_id, name=EXCLUDED.name,
    worker_code=EXCLUDED.worker_code, status=EXCLUDED.status, role=EXCLUDED.role, employment_category=EXCLUDED.employment_category, updated_at=now();
  GET DIAGNOSTICS n = ROW_COUNT;
  -- Workers no longer in the office list are marked Inactive (row kept, only hidden from staff).
  UPDATE public.erp_attendance_workers SET status='Inactive', updated_at=now()
  WHERE status <> 'Inactive'
    AND legacy_id NOT IN (SELECT w->>'legacy_id' FROM jsonb_array_elements(coalesce(p_workers,'[]'::jsonb)) w WHERE coalesce(w->>'legacy_id','')<>'');
  RETURN n;
END $$;

-- Source: drizzle\migrations\0006_foreman_task_management.sql
CREATE TABLE public.foreman_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_no bigint GENERATED ALWAYS AS IDENTITY,
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid,
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  local_project_id text,
  building text, floor text, location text,
  title text NOT NULL,
  description text,
  category text,
  boq_item_id uuid REFERENCES public.team_boq_items(id),
  assigned_to uuid NOT NULL,
  assigned_by uuid,
  start_date date NOT NULL,
  due_date date NOT NULL,
  priority text NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High','Urgent')),
  target_qty numeric NOT NULL CHECK (target_qty > 0),
  unit text NOT NULL,
  period text NOT NULL DEFAULT 'daily' CHECK (period IN ('daily','weekly','total')),
  period_target numeric CHECK (period_target IS NULL OR period_target >= 0),
  working_days integer CHECK (working_days IS NULL OR working_days >= 0),
  required_labour integer CHECK (required_labour IS NULL OR required_labour >= 0),
  required_materials text,
  acceptance_criteria text,
  attachments jsonb NOT NULL DEFAULT '[]'::jsonb,
  notes text,
  status text NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned','in_progress','submitted','rejected','completed','cancelled')),
  original_target_qty numeric,
  original_due_date date,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_tasks_assigned_idx ON public.foreman_tasks(assigned_to);
CREATE INDEX foreman_tasks_project_idx ON public.foreman_tasks(project_id);

CREATE TABLE public.foreman_task_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.foreman_tasks(id),
  submitted_by uuid NOT NULL,
  report_date date NOT NULL,
  reported_qty numeric NOT NULL CHECK (reported_qty >= 0),
  approved_qty numeric CHECK (approved_qty IS NULL OR approved_qty >= 0),
  note text,
  delay_reason text,
  delay_external boolean NOT NULL DEFAULT false,
  blockers jsonb NOT NULL DEFAULT '[]'::jsonb,
  photos jsonb NOT NULL DEFAULT '[]'::jsonb,
  ask_complete boolean NOT NULL DEFAULT false,
  review_status text NOT NULL DEFAULT 'submitted' CHECK (review_status IN ('submitted','approved','rejected')),
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_task_updates_task_idx ON public.foreman_task_updates(task_id);
CREATE UNIQUE INDEX foreman_task_updates_one_per_day ON public.foreman_task_updates(task_id, report_date) WHERE review_status <> 'rejected';

CREATE TABLE public.foreman_task_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  task_id uuid NOT NULL REFERENCES public.foreman_tasks(id),
  event_type text NOT NULL,
  old_values jsonb,
  new_values jsonb,
  reason text,
  actor uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX foreman_task_events_task_idx ON public.foreman_task_events(task_id);

GRANT SELECT ON public.foreman_tasks TO authenticated;
GRANT SELECT ON public.foreman_task_updates TO authenticated;
GRANT SELECT ON public.foreman_task_events TO authenticated;
GRANT ALL ON public.foreman_tasks TO service_role;
GRANT ALL ON public.foreman_task_updates TO service_role;
GRANT ALL ON public.foreman_task_events TO service_role;

ALTER TABLE public.foreman_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.foreman_task_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.foreman_task_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "office or assigned foreman reads tasks" ON public.foreman_tasks FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR assigned_to = auth.uid());
CREATE POLICY "office or own foreman reads task updates" ON public.foreman_task_updates FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR submitted_by = auth.uid()
    OR EXISTS (SELECT 1 FROM public.foreman_tasks t WHERE t.id = task_id AND t.assigned_to = auth.uid()));
CREATE POLICY "office reads task history" ON public.foreman_task_events FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

-- Only Admin / Manager may assign, change and approve tasks.
CREATE OR REPLACE FUNCTION public.pb_can_manage_tasks(_user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user,'admin') OR public.has_role(_user,'manager')
$$;

CREATE OR REPLACE FUNCTION public.create_foreman_task(p jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE tid uuid; pid uuid := (p->>'project_id')::uuid; who uuid := (p->>'assigned_to')::uuid; tq numeric := (p->>'target_qty')::numeric;
  sd date := (p->>'start_date')::date; dd date := (p->>'due_date')::date; legacy text;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can assign tasks'; END IF;
  IF coalesce(trim(p->>'title'),'') = '' THEN RAISE EXCEPTION 'Task title is required'; END IF;
  IF coalesce(trim(p->>'unit'),'') = '' THEN RAISE EXCEPTION 'Unit is required'; END IF;
  IF tq IS NULL OR tq <= 0 THEN RAISE EXCEPTION 'Target quantity must be more than 0'; END IF;
  IF sd IS NULL OR dd IS NULL OR dd < sd THEN RAISE EXCEPTION 'Due date must be on or after start date'; END IF;
  IF NOT public.pb_is_member(pid, who) THEN RAISE EXCEPTION 'This foreman is not assigned to this site'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = pid;
  INSERT INTO public.foreman_tasks(project_id, local_project_id, building, floor, location, title, description, category, boq_item_id,
    assigned_to, assigned_by, start_date, due_date, priority, target_qty, unit, period, period_target, working_days, required_labour,
    required_materials, acceptance_criteria, attachments, notes, original_target_qty, original_due_date)
  VALUES (pid, legacy, nullif(p->>'building',''), nullif(p->>'floor',''), nullif(p->>'location',''), trim(p->>'title'), nullif(p->>'description',''),
    nullif(p->>'category',''), nullif(p->>'boq_item_id','')::uuid, who, auth.uid(), sd, dd, coalesce(nullif(p->>'priority',''),'Medium'), tq,
    trim(p->>'unit'), coalesce(nullif(p->>'period',''),'daily'), nullif(p->>'period_target','')::numeric, nullif(p->>'working_days','')::int,
    nullif(p->>'required_labour','')::int, nullif(p->>'required_materials',''), nullif(p->>'acceptance_criteria',''),
    coalesce(p->'attachments','[]'::jsonb), nullif(p->>'notes',''), tq, dd)
  RETURNING id INTO tid;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, actor)
    VALUES (tid, 'assigned', jsonb_build_object('assigned_to', who, 'target_qty', tq, 'unit', p->>'unit', 'due_date', dd), auth.uid());
  RETURN tid;
END $$;

CREATE OR REPLACE FUNCTION public.update_foreman_task(p_task uuid, p jsonb, p_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks; nt numeric; nd date; nw uuid; key text; oldv jsonb := '{}'::jsonb; newv jsonb := '{}'::jsonb;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change tasks'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF t.status IN ('completed','cancelled') THEN RAISE EXCEPTION 'Completed or cancelled tasks cannot be changed'; END IF;
  nt := coalesce(nullif(p->>'target_qty','')::numeric, t.target_qty);
  nd := coalesce(nullif(p->>'due_date','')::date, t.due_date);
  nw := coalesce(nullif(p->>'assigned_to','')::uuid, t.assigned_to);
  IF nt <= 0 THEN RAISE EXCEPTION 'Target quantity must be more than 0'; END IF;
  IF nd < t.start_date THEN RAISE EXCEPTION 'Due date must be on or after start date'; END IF;
  IF (nt <> t.target_qty OR nd <> t.due_date OR nw <> t.assigned_to) AND coalesce(trim(p_reason),'') = '' THEN
    RAISE EXCEPTION 'Please write a reason for changing target, due date or foreman';
  END IF;
  IF nw <> t.assigned_to AND NOT public.pb_is_member(t.project_id, nw) THEN RAISE EXCEPTION 'This foreman is not assigned to this site'; END IF;
  FOREACH key IN ARRAY ARRAY['title','description','category','building','floor','location','priority','period','period_target','working_days','required_labour','required_materials','acceptance_criteria','notes'] LOOP
    IF p ? key AND coalesce(p->>key,'') IS DISTINCT FROM coalesce(to_jsonb(t)->>key,'') THEN
      oldv := oldv || jsonb_build_object(key, to_jsonb(t)->key); newv := newv || jsonb_build_object(key, p->key);
    END IF;
  END LOOP;
  IF nt <> t.target_qty THEN oldv := oldv || jsonb_build_object('target_qty', t.target_qty); newv := newv || jsonb_build_object('target_qty', nt); END IF;
  IF nd <> t.due_date THEN oldv := oldv || jsonb_build_object('due_date', t.due_date); newv := newv || jsonb_build_object('due_date', nd); END IF;
  IF nw <> t.assigned_to THEN oldv := oldv || jsonb_build_object('assigned_to', t.assigned_to); newv := newv || jsonb_build_object('assigned_to', nw); END IF;
  IF newv = '{}'::jsonb THEN RETURN jsonb_build_object('saved', false); END IF;
  UPDATE public.foreman_tasks SET
    title = CASE WHEN p ? 'title' AND trim(p->>'title') <> '' THEN trim(p->>'title') ELSE title END,
    description = CASE WHEN p ? 'description' THEN nullif(p->>'description','') ELSE description END,
    category = CASE WHEN p ? 'category' THEN nullif(p->>'category','') ELSE category END,
    building = CASE WHEN p ? 'building' THEN nullif(p->>'building','') ELSE building END,
    floor = CASE WHEN p ? 'floor' THEN nullif(p->>'floor','') ELSE floor END,
    location = CASE WHEN p ? 'location' THEN nullif(p->>'location','') ELSE location END,
    priority = CASE WHEN p->>'priority' IN ('Low','Medium','High','Urgent') THEN p->>'priority' ELSE priority END,
    period = CASE WHEN p->>'period' IN ('daily','weekly','total') THEN p->>'period' ELSE period END,
    period_target = CASE WHEN p ? 'period_target' THEN nullif(p->>'period_target','')::numeric ELSE period_target END,
    working_days = CASE WHEN p ? 'working_days' THEN nullif(p->>'working_days','')::int ELSE working_days END,
    required_labour = CASE WHEN p ? 'required_labour' THEN nullif(p->>'required_labour','')::int ELSE required_labour END,
    required_materials = CASE WHEN p ? 'required_materials' THEN nullif(p->>'required_materials','') ELSE required_materials END,
    acceptance_criteria = CASE WHEN p ? 'acceptance_criteria' THEN nullif(p->>'acceptance_criteria','') ELSE acceptance_criteria END,
    notes = CASE WHEN p ? 'notes' THEN nullif(p->>'notes','') ELSE notes END,
    target_qty = nt, due_date = nd, assigned_to = nw, updated_at = now()
  WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (p_task, CASE WHEN nw <> t.assigned_to THEN 'reassigned' WHEN nt <> t.target_qty OR nd <> t.due_date THEN 'target_revised' ELSE 'edited' END,
      oldv, newv, nullif(trim(p_reason),''), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;

CREATE OR REPLACE FUNCTION public.set_foreman_task_status(p_task uuid, p_status text, p_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change task status'; END IF;
  IF p_status NOT IN ('completed','cancelled','in_progress') THEN RAISE EXCEPTION 'Status not allowed'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF p_status = 'cancelled' AND coalesce(trim(p_reason),'') = '' THEN RAISE EXCEPTION 'Please write why the task is cancelled'; END IF;
  IF p_status = 'in_progress' AND t.status NOT IN ('completed','cancelled') THEN RAISE EXCEPTION 'Only completed or cancelled tasks can be reopened'; END IF;
  IF p_status = 'in_progress' AND coalesce(trim(p_reason),'') = '' THEN RAISE EXCEPTION 'Please write why the task is reopened'; END IF;
  IF EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = p_task AND review_status = 'submitted') AND p_status = 'completed' THEN
    RAISE EXCEPTION 'Review the waiting submissions first';
  END IF;
  UPDATE public.foreman_tasks SET status = p_status, completed_at = CASE WHEN p_status = 'completed' THEN now() ELSE NULL END, updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (p_task, p_status, jsonb_build_object('status', t.status), jsonb_build_object('status', p_status), nullif(trim(p_reason),''), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;

CREATE OR REPLACE FUNCTION public.start_foreman_task(p_task uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks;
BEGIN
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND OR t.assigned_to <> auth.uid() THEN RAISE EXCEPTION 'This task is not assigned to you'; END IF;
  IF t.status <> 'assigned' THEN RETURN jsonb_build_object('saved', false, 'status', t.status); END IF;
  UPDATE public.foreman_tasks SET status = 'in_progress', updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, actor)
    VALUES (p_task, 'started', jsonb_build_object('status', t.status), jsonb_build_object('status','in_progress'), auth.uid());
  RETURN jsonb_build_object('saved', true, 'status', 'in_progress');
END $$;

CREATE OR REPLACE FUNCTION public.submit_foreman_task_update(p_task uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE t public.foreman_tasks; uid uuid; q numeric := (p->>'reported_qty')::numeric; d date := coalesce(nullif(p->>'report_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  k text := nullif(p->>'idempotency_key','');
BEGIN
  IF k IS NOT NULL THEN
    SELECT id INTO uid FROM public.foreman_task_updates WHERE idempotency_key = k;
    IF uid IS NOT NULL THEN RETURN jsonb_build_object('saved', true, 'updateId', uid, 'duplicate', true); END IF;
  END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND OR t.assigned_to <> auth.uid() THEN RAISE EXCEPTION 'This task is not assigned to you'; END IF;
  IF NOT public.pb_is_member(t.project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF t.status IN ('completed','cancelled') THEN RAISE EXCEPTION 'This task is already closed'; END IF;
  IF q IS NULL OR q < 0 THEN RAISE EXCEPTION 'Quantity cannot be negative'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF d < t.start_date THEN RAISE EXCEPTION 'Date is before the task start date'; END IF;
  IF nullif(p->>'unit','') IS NOT NULL AND lower(trim(p->>'unit')) <> lower(t.unit) THEN RAISE EXCEPTION 'Unit must be %', t.unit; END IF;
  IF EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = p_task AND report_date = d AND review_status <> 'rejected') THEN
    RAISE EXCEPTION 'An update for this date was already sent';
  END IF;
  INSERT INTO public.foreman_task_updates(task_id, submitted_by, report_date, reported_qty, note, delay_reason, delay_external, blockers, photos, ask_complete, idempotency_key)
    VALUES (p_task, auth.uid(), d, q, nullif(p->>'note',''), nullif(p->>'delay_reason',''), coalesce((p->>'delay_external')::boolean, false),
      coalesce(p->'blockers','[]'::jsonb), coalesce(p->'photos','[]'::jsonb), coalesce((p->>'ask_complete')::boolean,false), k)
    RETURNING id INTO uid;
  UPDATE public.foreman_tasks SET status = 'submitted', updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, reason, actor)
    VALUES (p_task, 'submitted', jsonb_build_object('update_id', uid, 'report_date', d, 'reported_qty', q, 'delay_reason', p->>'delay_reason', 'photos', jsonb_array_length(coalesce(p->'photos','[]'::jsonb))), nullif(p->>'note',''), auth.uid());
  RETURN jsonb_build_object('saved', true, 'updateId', uid);
END $$;

CREATE OR REPLACE FUNCTION public.review_foreman_task_update(p_update uuid, p_decision text, p_approved_qty numeric, p_note text, p_complete boolean)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; aq numeric; nstatus text;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'Invalid decision'; END IF;
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF u.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own work'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id FOR UPDATE;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    aq := coalesce(p_approved_qty, u.reported_qty);
    IF aq < 0 OR aq > u.reported_qty THEN RAISE EXCEPTION 'Approved quantity must be between 0 and the reported quantity'; END IF;
  END IF;
  UPDATE public.foreman_task_updates SET review_status = p_decision, approved_qty = CASE WHEN p_decision='approved' THEN aq ELSE NULL END,
    reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_update;
  IF t.status NOT IN ('completed','cancelled') THEN
    nstatus := CASE WHEN p_decision = 'rejected' THEN 'rejected' WHEN coalesce(p_complete,false) THEN 'completed' ELSE 'in_progress' END;
    IF nstatus <> 'completed' AND EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = t.id AND review_status = 'submitted') THEN nstatus := 'submitted'; END IF;
    UPDATE public.foreman_tasks SET status = nstatus, completed_at = CASE WHEN nstatus='completed' THEN now() ELSE completed_at END, updated_at = now() WHERE id = t.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, p_decision, jsonb_build_object('update_id', u.id, 'reported_qty', u.reported_qty),
      jsonb_build_object('approved_qty', aq, 'completed', coalesce(p_complete,false) AND p_decision='approved'), nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved', true, 'status', p_decision);
END $$;

-- List of assigned foremen for the office task form (names only).
CREATE OR REPLACE FUNCTION public.get_task_foremen()
RETURNS TABLE(user_id uuid, display_name text, project_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  RETURN QUERY SELECT m.user_id, coalesce(p.display_name,'Staff'), m.project_id FROM public.team_project_members m
    LEFT JOIN public.profiles p ON p.id = m.user_id WHERE m.status = 'active';
END $$;

REVOKE EXECUTE ON FUNCTION public.create_foreman_task(jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.update_foreman_task(uuid, jsonb, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.set_foreman_task_status(uuid, text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.start_foreman_task(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.submit_foreman_task_update(uuid, jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.review_foreman_task_update(uuid, text, numeric, text, boolean) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.get_task_foremen() FROM anon, public;
GRANT EXECUTE ON FUNCTION public.create_foreman_task(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_foreman_task(uuid, jsonb, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_foreman_task_status(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.start_foreman_task(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.submit_foreman_task_update(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.review_foreman_task_update(uuid, text, numeric, text, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_task_foremen() TO authenticated;

-- Source: drizzle\migrations\0007_foreman_task_files.sql
CREATE POLICY "office upload task files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'site-progress-photos' AND public.is_office_user(auth.uid()) AND (storage.foldername(name))[3] LIKE 'task-%');
CREATE POLICY "foreman reads own task files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'site-progress-photos' AND EXISTS (
    SELECT 1 FROM public.foreman_tasks t WHERE 'task-' || t.id::text = (storage.foldername(name))[3] AND t.assigned_to = auth.uid()));

CREATE OR REPLACE FUNCTION public.add_foreman_task_attachments(p_task uuid, p_files jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can add task files'; END IF;
  IF jsonb_typeof(p_files) <> 'array' THEN RAISE EXCEPTION 'Invalid files'; END IF;
  UPDATE public.foreman_tasks SET attachments = attachments || p_files, updated_at = now() WHERE id = p_task;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, actor)
    VALUES (p_task, 'files_added', jsonb_build_object('files', jsonb_array_length(p_files)), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE EXECUTE ON FUNCTION public.add_foreman_task_attachments(uuid, jsonb) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.add_foreman_task_attachments(uuid, jsonb) TO authenticated;

-- Source: drizzle\migrations\0008_task_approval_to_boq_progress.sql
ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS boq_applied_qty numeric;
COMMENT ON COLUMN public.foreman_task_updates.boq_applied_qty IS 'Quantity of this approved update added to linked BOQ progress (after double-count check). NULL = not applied.';

CREATE OR REPLACE FUNCTION public.pb_apply_task_update_to_boq(p_update uuid)
RETURNS numeric LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; b public.team_boq_items; already numeric; q numeric;
BEGIN
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND OR u.review_status <> 'approved' OR u.boq_applied_qty IS NOT NULL THEN RETURN 0; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id;
  IF t.boq_item_id IS NULL THEN RETURN 0; END IF;
  SELECT * INTO b FROM public.team_boq_items WHERE id = t.boq_item_id FOR UPDATE;
  IF NOT FOUND THEN RETURN 0; END IF;
  -- Double-count check: same foreman, same BOQ item, same date already reported through a site progress report
  SELECT coalesce(sum(l.today_qty),0) INTO already FROM public.site_progress_report_boq_lines l
    JOIN public.site_progress_reports r ON r.id = l.report_id
   WHERE l.boq_item_id = b.id AND r.created_by = u.submitted_by AND r.report_date = u.report_date AND r.review_status IN ('submitted','approved');
  q := greatest(0, coalesce(u.approved_qty,0) - already);
  q := least(q, greatest(0, b.quantity - b.approved_completed_qty), greatest(0, b.quantity - b.completed_qty));
  UPDATE public.foreman_task_updates SET boq_applied_qty = q WHERE id = u.id;
  IF q > 0 THEN
    UPDATE public.team_boq_items SET completed_qty = completed_qty + q, approved_completed_qty = approved_completed_qty + q WHERE id = b.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, 'boq_progress', jsonb_build_object('update_id', u.id, 'approved_qty', u.approved_qty, 'already_reported', already),
      jsonb_build_object('added_to_site_progress', q), CASE WHEN already > 0 THEN 'Part already reported in a site progress report — not counted twice' END, auth.uid());
  RETURN q;
END $$;
REVOKE ALL ON FUNCTION public.pb_apply_task_update_to_boq(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.review_foreman_task_update(p_update uuid, p_decision text, p_approved_qty numeric, p_note text, p_complete boolean)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; aq numeric; nstatus text; added numeric := 0;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'Invalid decision'; END IF;
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF u.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own work'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id FOR UPDATE;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    aq := coalesce(p_approved_qty, u.reported_qty);
    IF aq < 0 OR aq > u.reported_qty THEN RAISE EXCEPTION 'Approved quantity must be between 0 and the reported quantity'; END IF;
  END IF;
  UPDATE public.foreman_task_updates SET review_status = p_decision, approved_qty = CASE WHEN p_decision='approved' THEN aq ELSE NULL END,
    reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_update;
  IF t.status NOT IN ('completed','cancelled') THEN
    nstatus := CASE WHEN p_decision = 'rejected' THEN 'rejected' WHEN coalesce(p_complete,false) THEN 'completed' ELSE 'in_progress' END;
    IF nstatus <> 'completed' AND EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = t.id AND review_status = 'submitted') THEN nstatus := 'submitted'; END IF;
    UPDATE public.foreman_tasks SET status = nstatus, completed_at = CASE WHEN nstatus='completed' THEN now() ELSE completed_at END, updated_at = now() WHERE id = t.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, p_decision, jsonb_build_object('update_id', u.id, 'reported_qty', u.reported_qty),
      jsonb_build_object('approved_qty', aq, 'completed', coalesce(p_complete,false) AND p_decision='approved'), nullif(trim(p_note),''), auth.uid());
  IF p_decision = 'approved' THEN added := public.pb_apply_task_update_to_boq(u.id); END IF;
  RETURN jsonb_build_object('saved', true, 'status', p_decision, 'added_to_site_progress', added);
END $function$;

-- Backfill: updates approved before this change are added once
DO $$ DECLARE r record; BEGIN
  FOR r IN SELECT id FROM public.foreman_task_updates WHERE review_status = 'approved' AND boq_applied_qty IS NULL ORDER BY reviewed_at LOOP
    PERFORM public.pb_apply_task_update_to_boq(r.id);
  END LOOP;
END $$;

-- Source: drizzle\migrations\0009_task_team_workers_hours.sql
ALTER TABLE public.foreman_tasks ADD COLUMN IF NOT EXISTS assigned_team text;
ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS workers integer;
ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS work_hours numeric;

CREATE OR REPLACE FUNCTION public.pb_task_extras_on_create() RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public' AS $$
BEGIN RETURN NEW; END $$;
DROP FUNCTION public.pb_task_extras_on_create();

CREATE OR REPLACE FUNCTION public.set_foreman_task_team(p_task uuid, p_team text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE t public.foreman_tasks;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change tasks'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF coalesce(t.assigned_team,'') IS NOT DISTINCT FROM coalesce(trim(p_team),'') THEN RETURN jsonb_build_object('saved', false); END IF;
  UPDATE public.foreman_tasks SET assigned_team = nullif(trim(p_team),''), updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, actor)
    VALUES (p_task, 'edited', jsonb_build_object('assigned_team', t.assigned_team), jsonb_build_object('assigned_team', nullif(trim(p_team),'')), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE ALL ON FUNCTION public.set_foreman_task_team(uuid, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_foreman_task_team(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.set_task_update_labour(p_update uuid, p_workers integer, p_hours numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE u public.foreman_task_updates;
BEGIN
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.submitted_by <> auth.uid() THEN RAISE EXCEPTION 'This update is not yours'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF coalesce(p_workers,0) < 0 OR coalesce(p_hours,0) < 0 OR coalesce(p_hours,0) > 24 THEN RAISE EXCEPTION 'Workers or hours are not valid'; END IF;
  UPDATE public.foreman_task_updates SET workers = p_workers, work_hours = p_hours WHERE id = p_update;
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE ALL ON FUNCTION public.set_task_update_labour(uuid, integer, numeric) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_task_update_labour(uuid, integer, numeric) TO authenticated;

-- Source: drizzle\migrations\0010_staff_expense_requests_and_documents.sql
CREATE TABLE public.site_expense_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  requested_by uuid NOT NULL,
  request_date date NOT NULL,
  category text NOT NULL,
  amount numeric NOT NULL,
  payee text,
  description text,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_expense_requests TO authenticated;
GRANT ALL ON public.site_expense_requests TO service_role;
ALTER TABLE public.site_expense_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or office read expense requests" ON public.site_expense_requests FOR SELECT TO authenticated
  USING (requested_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.submit_site_expense_request(p_project_id uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); a numeric := (p->>'amount')::numeric;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_expense_requests WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'requestId',rid,'duplicate',true); END IF; END IF;
  IF a IS NULL OR a <= 0 THEN RAISE EXCEPTION 'Amount must be more than 0'; END IF;
  IF coalesce(trim(p->>'category'),'') = '' THEN RAISE EXCEPTION 'Category is required'; END IF;
  INSERT INTO public.site_expense_requests(project_id, requested_by, request_date, category, amount, payee, description, idempotency_key)
  VALUES (p_project_id, auth.uid(), coalesce(nullif(p->>'request_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date),
    trim(p->>'category'), a, nullif(p->>'payee',''), nullif(p->>'description',''), k) RETURNING id INTO rid;
  RETURN jsonb_build_object('saved',true,'requestId',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_expense_request(p_id uuid, p_decision text, p_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE r public.site_expense_requests;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_expense_requests WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Request already reviewed or not found'; END IF;
  IF r.requested_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own request'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_expense_requests SET review_status=p_decision, reviewed_by=auth.uid(), reviewed_at=now(), review_note=nullif(trim(p_note),'') WHERE id=p_id;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE TABLE public.project_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  title text NOT NULL,
  doc_type text NOT NULL DEFAULT 'Drawing',
  file_path text NOT NULL,
  file_name text,
  is_active boolean NOT NULL DEFAULT true,
  uploaded_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.project_documents TO authenticated;
GRANT ALL ON public.project_documents TO service_role;
ALTER TABLE public.project_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members and office read docs" ON public.project_documents FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR (is_active AND public.pb_is_member(project_id, auth.uid())));
CREATE POLICY "office add docs" ON public.project_documents FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()) AND uploaded_by = auth.uid());
CREATE POLICY "office update docs" ON public.project_documents FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE POLICY "office upload project docs" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'project-documents' AND public.is_office_user(auth.uid()));
CREATE POLICY "read project docs" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'project-documents' AND (public.is_office_user(auth.uid())
    OR public.pb_is_member(((storage.foldername(name))[1])::uuid, auth.uid())));

-- Source: drizzle\migrations\0011_site_stock_submissions.sql
CREATE TABLE public.site_stock_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  submitted_by uuid NOT NULL,
  submitted_name text,
  work_date date NOT NULL,
  kind text NOT NULL DEFAULT 'daily',
  lines jsonb NOT NULL DEFAULT '[]'::jsonb,
  supplier text,
  invoice_no text,
  remarks text,
  photos jsonb NOT NULL DEFAULT '[]'::jsonb,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  posted_to_stock boolean NOT NULL DEFAULT false,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_stock_submissions TO authenticated;
GRANT ALL ON public.site_stock_submissions TO service_role;
ALTER TABLE public.site_stock_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or office read stock submissions" ON public.site_stock_submissions FOR SELECT TO authenticated
  USING (submitted_by = auth.uid() OR public.is_office_user(auth.uid()));
CREATE INDEX site_stock_submissions_project_idx ON public.site_stock_submissions(project_id, work_date);

CREATE OR REPLACE FUNCTION public.get_site_stock_balance(p_project_id uuid)
RETURNS TABLE(item text, unit text, balance numeric)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE legacy text;
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  RETURN QUERY
    SELECT trim(s->>'item'), coalesce(s->>'unit',''),
      sum(CASE WHEN s->>'direction' = 'In' THEN 1 ELSE -1 END * coalesce(nullif(s->>'qty','')::numeric,0))
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'stock','[]'::jsonb)) s
    WHERE c.id = 1 AND s->>'projectId' = legacy AND coalesce(trim(s->>'item'),'') <> ''
    GROUP BY 1,2 ORDER BY 1;
END $$;

CREATE OR REPLACE FUNCTION public.submit_site_stock_update(p_project_id uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); d date := coalesce(nullif(p->>'work_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  kd text := coalesce(nullif(p->>'kind',''),'daily'); ln jsonb; nm text;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_stock_submissions WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'id',rid,'duplicate',true); END IF; END IF;
  IF kd NOT IN ('daily','site_purchase') THEN RAISE EXCEPTION 'Invalid update type'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF jsonb_typeof(p->'lines') <> 'array' OR jsonb_array_length(p->'lines') = 0 THEN RAISE EXCEPTION 'Add at least one material'; END IF;
  FOR ln IN SELECT * FROM jsonb_array_elements(p->'lines') LOOP
    IF coalesce(trim(ln->>'item'),'') = '' THEN RAISE EXCEPTION 'Material name is required'; END IF;
    IF coalesce((ln->>'received')::numeric,0) < 0 OR coalesce((ln->>'used')::numeric,0) < 0 OR coalesce((ln->>'damaged')::numeric,0) < 0
       OR coalesce((ln->>'returned')::numeric,0) < 0 OR coalesce((ln->>'qty')::numeric,0) < 0 THEN RAISE EXCEPTION 'Quantities cannot be negative'; END IF;
  END LOOP;
  SELECT display_name INTO nm FROM public.profiles WHERE id = auth.uid();
  INSERT INTO public.site_stock_submissions(project_id, submitted_by, submitted_name, work_date, kind, lines, supplier, invoice_no, remarks, photos, idempotency_key)
  VALUES (p_project_id, auth.uid(), nm, d, kd, p->'lines', nullif(p->>'supplier',''), nullif(p->>'invoice_no',''), nullif(p->>'remarks',''), coalesce(p->'photos','[]'::jsonb), k)
  RETURNING id INTO rid;
  RETURN jsonb_build_object('saved',true,'id',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_stock_update(p_id uuid, p_decision text, p_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE r public.site_stock_submissions;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed or not found'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own update'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_id;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE OR REPLACE FUNCTION public.mark_site_stock_posted(p_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  UPDATE public.site_stock_submissions SET posted_to_stock = true WHERE id = p_id AND review_status = 'approved';
  RETURN jsonb_build_object('saved', FOUND);
END $$;

REVOKE EXECUTE ON FUNCTION public.get_site_stock_balance(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.submit_site_stock_update(uuid, jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.review_site_stock_update(uuid, text, text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.mark_site_stock_posted(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_site_stock_balance(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.submit_site_stock_update(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.review_site_stock_update(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mark_site_stock_posted(uuid) TO authenticated;

-- Source: drizzle\migrations\0012_site_material_receiving.sql
ALTER TABLE public.site_stock_submissions
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS ref_id text,
  ADD COLUMN IF NOT EXISTS ref_label text,
  ADD COLUMN IF NOT EXISTS approved_lines jsonb;

CREATE TABLE IF NOT EXISTS public.site_stock_events (
  id bigserial PRIMARY KEY,
  submission_id uuid NOT NULL REFERENCES public.site_stock_submissions(id),
  event_type text NOT NULL,
  detail jsonb,
  note text,
  actor uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_stock_events TO authenticated;
GRANT ALL ON public.site_stock_events TO service_role;
ALTER TABLE public.site_stock_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office or submitter can read stock events" ON public.site_stock_events FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR EXISTS (SELECT 1 FROM public.site_stock_submissions s WHERE s.id = submission_id AND s.submitted_by = auth.uid()));

CREATE OR REPLACE FUNCTION public.submit_site_stock_update(p_project_id uuid, p jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); d date := coalesce(nullif(p->>'work_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  kd text := coalesce(nullif(p->>'kind',''),'daily'); ln jsonb; nm text; src text := nullif(p->>'source',''); ref text := nullif(p->>'ref_id','');
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_stock_submissions WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'id',rid,'duplicate',true); END IF; END IF;
  IF kd NOT IN ('daily','site_purchase','receiving') THEN RAISE EXCEPTION 'Invalid update type'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF jsonb_typeof(p->'lines') <> 'array' OR jsonb_array_length(p->'lines') = 0 THEN RAISE EXCEPTION 'Add at least one material'; END IF;
  FOR ln IN SELECT * FROM jsonb_array_elements(p->'lines') LOOP
    IF coalesce(trim(ln->>'item'),'') = '' THEN RAISE EXCEPTION 'Material name is required'; END IF;
    IF coalesce((ln->>'received')::numeric,0) < 0 OR coalesce((ln->>'used')::numeric,0) < 0 OR coalesce((ln->>'damaged')::numeric,0) < 0
       OR coalesce((ln->>'returned')::numeric,0) < 0 OR coalesce((ln->>'qty')::numeric,0) < 0
       OR coalesce((ln->>'accepted')::numeric,0) < 0 OR coalesce((ln->>'shortage')::numeric,0) < 0 OR coalesce((ln->>'expected')::numeric,0) < 0 THEN RAISE EXCEPTION 'Quantities cannot be negative'; END IF;
    IF kd = 'receiving' AND coalesce((ln->>'accepted')::numeric,0) + coalesce((ln->>'damaged')::numeric,0) > coalesce((ln->>'received')::numeric,0) + 0.000001 THEN
      RAISE EXCEPTION 'Accepted + damaged cannot be more than received for %', ln->>'item'; END IF;
  END LOOP;
  IF kd = 'receiving' THEN
    IF src NOT IN ('central','supplier','site_purchase') THEN RAISE EXCEPTION 'Choose the material source'; END IF;
    IF src IN ('central','site_purchase') AND ref IS NULL THEN RAISE EXCEPTION 'Choose the delivery you are receiving'; END IF;
    IF src IN ('central','site_purchase') AND EXISTS (SELECT 1 FROM public.site_stock_submissions WHERE project_id = p_project_id AND kind = 'receiving' AND source = src AND ref_id = ref AND review_status <> 'rejected') THEN
      RAISE EXCEPTION 'This delivery was already received'; END IF;
    IF src = 'supplier' AND nullif(trim(p->>'invoice_no'),'') IS NOT NULL AND EXISTS (SELECT 1 FROM public.site_stock_submissions WHERE project_id = p_project_id AND kind = 'receiving' AND source = 'supplier'
       AND lower(trim(invoice_no)) = lower(trim(p->>'invoice_no')) AND lower(coalesce(supplier,'')) = lower(coalesce(trim(p->>'supplier'),'')) AND review_status <> 'rejected') THEN
      RAISE EXCEPTION 'This supplier invoice / challan was already received'; END IF;
  END IF;
  SELECT display_name INTO nm FROM public.profiles WHERE id = auth.uid();
  INSERT INTO public.site_stock_submissions(project_id, submitted_by, submitted_name, work_date, kind, lines, supplier, invoice_no, remarks, photos, idempotency_key, source, ref_id, ref_label)
  VALUES (p_project_id, auth.uid(), nm, d, kd, p->'lines', nullif(p->>'supplier',''), nullif(p->>'invoice_no',''), nullif(p->>'remarks',''), coalesce(p->'photos','[]'::jsonb), k,
    CASE WHEN kd='receiving' THEN src END, CASE WHEN kd='receiving' THEN ref END, CASE WHEN kd='receiving' THEN nullif(p->>'ref_label','') END)
  RETURNING id INTO rid;
  INSERT INTO public.site_stock_events(submission_id, event_type, detail, actor) VALUES (rid, 'submitted', jsonb_build_object('kind', kd, 'source', src, 'lines', jsonb_array_length(p->'lines')), auth.uid());
  RETURN jsonb_build_object('saved',true,'id',rid);
END $function$;

CREATE OR REPLACE FUNCTION public.review_site_stock_update(p_id uuid, p_decision text, p_note text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE r public.site_stock_submissions;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed or not found'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own update'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_id;
  INSERT INTO public.site_stock_events(submission_id, event_type, note, actor) VALUES (p_id, p_decision, nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $function$;

CREATE OR REPLACE FUNCTION public.review_site_receiving(p_id uuid, p_decision text, p_note text, p_lines jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE r public.site_stock_submissions; ln jsonb; i int := 0; orig jsonb;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.kind <> 'receiving' THEN RAISE EXCEPTION 'Receiving entry not found'; END IF;
  IF r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own receiving'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    IF jsonb_typeof(p_lines) <> 'array' OR jsonb_array_length(p_lines) <> jsonb_array_length(r.lines) THEN RAISE EXCEPTION 'Approved lines do not match'; END IF;
    FOR ln IN SELECT * FROM jsonb_array_elements(p_lines) LOOP
      orig := r.lines->i;
      IF coalesce((ln->>'accepted')::numeric,-1) < 0 OR (ln->>'accepted')::numeric > coalesce((orig->>'received')::numeric,0) + 0.000001 THEN
        RAISE EXCEPTION 'Approved quantity for % must be between 0 and the received quantity', orig->>'item'; END IF;
      i := i + 1;
    END LOOP;
  END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),''),
    approved_lines = CASE WHEN p_decision = 'approved' THEN p_lines END WHERE id = p_id;
  INSERT INTO public.site_stock_events(submission_id, event_type, detail, note, actor) VALUES (p_id, p_decision, CASE WHEN p_decision='approved' THEN jsonb_build_object('lines', p_lines) END, nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $function$;

CREATE OR REPLACE FUNCTION public.get_site_incoming(p_project_id uuid)
 RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE legacy text; cen jsonb; pur jsonb; sp jsonb;
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', v->>'id', 'no', v->>'no', 'date', v->>'date', 'lines', v->'lines') ORDER BY v->>'date' DESC), '[]'::jsonb) INTO cen
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'whVouchers','[]'::jsonb)) v
   WHERE c.id = 1 AND v->>'kind' = 'CISS' AND v->>'status' = 'Approved' AND v->>'projectId' = legacy
     AND NOT EXISTS (SELECT 1 FROM public.site_stock_submissions s WHERE s.project_id = p_project_id AND s.kind='receiving' AND s.source='central' AND s.ref_id = v->>'id' AND s.review_status <> 'rejected');
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', t->>'id', 'date', t->>'date', 'item', t->>'material', 'unit', t->>'unit', 'qty', t->'qty', 'supplier', t->>'supplier', 'invoice', coalesce(t->>'invoiceNo', t->>'reference')) ORDER BY t->>'date' DESC), '[]'::jsonb) INTO pur
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'transactions','[]'::jsonb)) t
   WHERE c.id = 1 AND t->>'type' = 'Purchase' AND coalesce(t->>'category','') ~* '^material' AND coalesce(trim(t->>'material'),'') <> '' AND t->>'projectId' = legacy;
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'date', s.work_date, 'supplier', s.supplier, 'invoice', s.invoice_no, 'lines', s.lines) ORDER BY s.work_date DESC), '[]'::jsonb) INTO sp
    FROM public.site_stock_submissions s
   WHERE s.project_id = p_project_id AND s.kind = 'site_purchase' AND s.review_status = 'approved'
     AND NOT EXISTS (SELECT 1 FROM public.site_stock_submissions x WHERE x.project_id = p_project_id AND x.kind='receiving' AND x.source='site_purchase' AND x.ref_id = s.id::text AND x.review_status <> 'rejected');
  RETURN jsonb_build_object('central', cen, 'purchases', pur, 'site_purchases', sp);
END $function$;

-- Source: supabase\stage1_audit_trail.sql
-- PURE BUILD — Stage 1: Audit Trail (safe: does NOT change or delete any existing data)
-- Run in the Cloud SQL editor only after taking a backup. Rollback: supabase/stage1_audit_trail_rollback.sql

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  actor_id uuid,
  actor_role text,
  project_id text,
  module text not null,
  record_id text,
  action text not null,            -- create | update | delete | void | approve | reject | permission_change
  old_values jsonb,
  new_values jsonb,
  reason text,
  status text not null default 'success'
);
create index if not exists audit_log_created_idx on public.audit_log (created_at desc);
create index if not exists audit_log_project_idx on public.audit_log (project_id);
create index if not exists audit_log_record_idx on public.audit_log (record_id);

-- Read-only for signed-in users; nobody can edit/delete from the app.
grant select on public.audit_log to authenticated;
grant all on public.audit_log to service_role;
alter table public.audit_log enable row level security;

create or replace function public.audit_can_read()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p
    where p.id = auth.uid() and p.status = 'active' and p.role in ('admin','auditor'))
$$;

drop policy if exists "Admins and auditors read audit log" on public.audit_log;
create policy "Admins and auditors read audit log" on public.audit_log
  for select to authenticated using (public.audit_can_read());

-- Strip secrets from any stored record.
create or replace function public.audit_clean(v jsonb)
returns jsonb language sql immutable as $$
  select case when v is null then null
    else v - 'password' - 'pass' - 'token' - 'access_token' - 'secret' - 'apiKey' end
$$;

-- Compares old vs new ERP data list by id and writes one audit row per change.
create or replace function public.audit_erp_state()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  k text;
  modules text[] := array['projects','transactions','boq','invoices','quotations','payables',
    'stock','employees','progress','dailyReports','runningBills','projectLocations'];
  o jsonb; n jsonb; rid text; role_now text;
begin
  select role into role_now from public.profiles where id = auth.uid();
  foreach k in array modules loop
    if jsonb_typeof(coalesce(new.data->k, '[]')) <> 'array' or jsonb_typeof(coalesce(old.data->k,'[]')) <> 'array' then
      if (old.data->k) is distinct from (new.data->k) then
        insert into audit_log(actor_id, actor_role, module, action, old_values, new_values)
        values (auth.uid(), role_now, k, 'update', null, jsonb_build_object('changed', true));
      end if;
      continue;
    end if;
    -- created + updated
    for n in select * from jsonb_array_elements(coalesce(new.data->k, '[]')) loop
      rid := n->>'id';
      if rid is null then continue; end if;
      select e into o from jsonb_array_elements(coalesce(old.data->k, '[]')) e where e->>'id' = rid limit 1;
      if o is null then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, new_values)
        values (auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'), k, rid, 'create', audit_clean(n));
      elsif o is distinct from n then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, old_values, new_values, reason)
        values (auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'), k, rid,
          case when lower(coalesce(n->>'status','')) in ('void','approved','rejected') and (o->>'status') is distinct from (n->>'status')
               then lower(case when lower(n->>'status')='approved' then 'approve' when lower(n->>'status')='rejected' then 'reject' else 'void' end)
               else 'update' end,
          audit_clean(o), audit_clean(n), n->>'reason');
      end if;
      o := null;
    end loop;
    -- deleted
    for o in select * from jsonb_array_elements(coalesce(old.data->k, '[]')) loop
      rid := o->>'id';
      if rid is null then continue; end if;
      if not exists (select 1 from jsonb_array_elements(coalesce(new.data->k, '[]')) e where e->>'id' = rid) then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, old_values)
        values (auth.uid(), role_now, coalesce(o->>'projectId', o->>'project', o->>'pid'), k, rid, 'delete', audit_clean(o));
      end if;
    end loop;
  end loop;
  return new;
end $$;

drop trigger if exists erp_state_audit on public.erp_cloud_state;
create trigger erp_state_audit after update on public.erp_cloud_state
  for each row execute function public.audit_erp_state();

-- Log role / permission changes on profiles.
create or replace function public.audit_profiles()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (old.role, old.status, old.permissions) is distinct from (new.role, new.status, new.permissions) then
    insert into audit_log(actor_id, actor_role, module, record_id, action, old_values, new_values)
    values (auth.uid(), (select role from profiles where id = auth.uid()), 'user_management', new.id::text,
      'permission_change',
      jsonb_build_object('role', old.role, 'status', old.status, 'permissions', old.permissions),
      jsonb_build_object('role', new.role, 'status', new.status, 'permissions', new.permissions));
  end if;
  return new;
end $$;

drop trigger if exists profiles_audit on public.profiles;
create trigger profiles_audit after update on public.profiles
  for each row execute function public.audit_profiles();

COMMIT;
