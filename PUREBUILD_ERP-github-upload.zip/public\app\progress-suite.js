/* Site Progress suite: all-project dashboard, progress history with details, period reports.
   Read-only over db.projects / db.boq / db.progress; never writes saved data. Physical progress only. */
(function () {
  const C = () => window.PBProgressCalc;
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : n(v).toFixed(2));
  const F = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));
  const today = () => new Date().toISOString().slice(0, 10);
  const pend = (x) => /submit|pending/i.test(String(x.approvalStatus || ""));
  const ui = { from: "", to: "", hq: "", hst: "", hfrom: "", hto: "", hpg: 1, rmode: "week", rfrom: "", rto: "", rall: false };

  const css = document.createElement("style");
  css.textContent = `
.ps-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}.ps-host>.panel,.ps-host>div>.panel{margin:0}
.ps-p{padding:12px 14px!important}
.ps-h{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}
.ps-h h3{margin:0;font-size:16px;color:#12233d}.ps-h small{display:block;color:#64748b;font-size:12px;margin-top:2px}
.ps-f{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.ps-f select,.ps-f input{height:32px;border:1px solid #cfdcec;border-radius:8px;padding:0 8px;font-size:12px;background:#fff}
.ps-k{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-bottom:10px}
.ps-k div{background:#f6f9fd;border:1px solid #e3e9f1;border-radius:10px;padding:8px 10px;min-width:0}
.ps-k small{display:block;font-size:10.5px;font-weight:800;color:#5b6b7f;text-transform:uppercase;letter-spacing:.02em}
.ps-k b{display:block;font-size:17px;color:#12233d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ps-k i{font-style:normal;font-size:11px;color:#64748b}
.ps-k .r b{color:#b91c1c}.ps-k .a b{color:#b45309}.ps-k .g b{color:#15803d}
.ps-t{overflow-x:auto;border:1px solid #e3e9f1;border-radius:10px}
.ps-t table{width:100%;border-collapse:collapse;font-size:12.5px}
.ps-t th{background:#14213d;color:#fff;text-align:left;padding:8px;font-size:11.5px;white-space:nowrap}
.ps-t td{padding:7px 8px;border-bottom:1px solid #eef2f7;color:#1e293b;vertical-align:middle}
.ps-t .r{text-align:right;white-space:nowrap}
.ps-pv{min-width:150px}.ps-pv div{display:flex;align-items:center;gap:6px;font-size:10.5px;color:#64748b}
.ps-pv i{flex:1;height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden;display:block}.ps-pv em{display:block;height:100%}
.ps-b{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10.5px;font-weight:800;white-space:nowrap}
.ps-b.g{background:#e6f6ec;color:#15803d}.ps-b.a{background:#fff6dd;color:#a16207}.ps-b.r{background:#fde8e8;color:#b91c1c}.ps-b.s{background:#eef2f7;color:#475569}
.ps-chart{display:flex;align-items:flex-end;gap:10px;height:130px;padding:8px 4px 0;border-bottom:1px solid #e3e9f1}
.ps-chart div{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;font-size:10.5px;color:#64748b}
.ps-chart span{width:70%;max-width:46px;background:linear-gradient(180deg,#2182df,#0f5fae);border-radius:4px 4px 0 0;min-height:2px}
.ps-chart b{font-size:10px;color:#12233d;margin-bottom:2px}
.ps-2{display:grid;grid-template-columns:2fr 1fr;gap:12px}
.ps-pg{display:flex;justify-content:space-between;align-items:center;padding:6px 2px;font-size:12px;color:#5b6b7f}.ps-pg div{display:flex;gap:6px;align-items:center}
.ps-d{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;font-size:13px}.ps-d div{background:#f6f9fd;border:1px solid #e3e9f1;border-radius:8px;padding:6px 9px}.ps-d small{display:block;color:#64748b;font-size:11px}
.ps-ph{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.ps-ph img{width:110px;height:80px;object-fit:cover;border-radius:8px;border:1px solid #e3e9f1}
#view.pt-on .ps-2[data-pt].pt-show{display:grid!important}
@media(max-width:1100px){.ps-k{grid-template-columns:repeat(2,minmax(0,1fr))}.ps-2{grid-template-columns:1fr}.ps-d{grid-template-columns:1fr 1fr}}
body.dark-theme .ps-k div,body.dark-theme .ps-d div{background:#17283c;border-color:#344960}body.dark-theme .ps-k b,body.dark-theme .ps-h h3,body.dark-theme .ps-t td{color:#e2ecf8}
`;
  document.head.appendChild(css);

  const projItems = (pid) => (db.boq || []).filter((b) => b.projectId === pid && C().approvedish(b));
  const inRange = (d, f, t) => (!f || d >= f) && (!t || d <= t);
  const val = (x) => n(x.todayQty) * n(x.rate || (boqOf(x) || {}).rate);
  function boqOf(x) { return (db.boq || []).find((b) => b.id === x.boqId || (x.boqCode && b.boqId === x.boqCode && b.projectId === x.projectId)); }

  // ---------- 1. All-projects dashboard ----------
  function dashHtml() {
    const t = today(), mon = t.slice(0, 7), projects = db.projects || [], prog = db.progress || [];
    const all = projects.flatMap((p) => projItems(p.id));
    const inR = prog.filter((x) => inRange(String(x.date || ""), ui.from, ui.to));
    const rows = projects.map((p) => {
      const it = projItems(p.id), act = C().weighted(it), plan = C().planned(p.start, p.end, t);
      const late = p.end && t > p.end && act < 100, gap = plan == null ? null : act - plan;
      const st = act >= 100 ? ["g", "Completed"] : late ? ["r", "Delayed"] : gap != null && gap < -10 ? ["r", "Behind plan"] : gap != null && gap < 0 ? ["a", "Slightly behind"] : it.length ? ["g", "On track"] : ["s", "No BOQ"];
      const pr = inR.filter((x) => x.projectId === p.id);
      return { p, it, act, plan, st, todayV: prog.filter((x) => x.projectId === p.id && x.date === t).reduce((s, x) => s + val(x), 0),
        rangeV: pr.reduce((s, x) => s + val(x), 0), pending: prog.filter((x) => x.projectId === p.id && pend(x)).length,
        delayed: it.filter((b) => n(b.executedQty) > 0 && n(b.executedQty) < n(b.qty) && !prog.some((x) => (x.boqId === b.id) && String(x.date) >= new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10))).length };
    }).filter((r) => r.it.length || r.pending);
    const units = C().byUnit(all), u3 = units.slice(0, 3).map((u) => `${F(u.qty)} ${E(u.unit)}`).join(" · ") || "—";
    const done3 = units.slice(0, 3).map((u) => `${F(u.done)} ${E(u.unit)}`).join(" · ") || "—", rem3 = units.slice(0, 3).map((u) => `${F(u.remaining)} ${E(u.unit)}`).join(" · ") || "—";
    const todayV = prog.filter((x) => x.date === t).reduce((s, x) => s + val(x), 0), monV = prog.filter((x) => String(x.date).slice(0, 7) === mon).reduce((s, x) => s + val(x), 0);
    const k = (c, l, v, s, tt) => `<div class="${c}" title="${E(tt || "")}"><small>${l}</small><b>${v}</b><i>${s || ""}</i></div>`;
    const months = []; for (let i = 5; i >= 0; i--) { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); months.push(d.toISOString().slice(0, 7)); }
    const mv = months.map((m) => prog.filter((x) => String(x.date).slice(0, 7) === m).reduce((s, x) => s + val(x), 0)), mx = Math.max(1, ...mv);
    return `<div class="panel ps-p" data-pt="overview"><div class="ps-h"><div><h3>🌐 All Projects — Physical Progress</h3><small>From saved BOQ and progress records. Weighted by BOQ value. Separate from billing and accounts.</small></div>
<div class="ps-f"><span style="font-size:12px;color:#64748b">Work done between</span><input type="date" id="psFrom" value="${E(ui.from)}"><input type="date" id="psTo" value="${E(ui.to)}"><button class="btn small" id="psClr">All dates</button></div></div>
<div class="ps-k">${k("", "Total Projects", rows.length, "with BOQ work")}${k("", "Total BOQ Items", all.length, "approved items")}${k("g", "Overall Progress", C().weighted(all).toFixed(1) + "%", "weighted by value")}${k("", "Total BOQ Qty", units.length > 1 ? units.length + " units" : u3, units.length > 1 ? u3 : "", units.map((u) => F(u.qty) + " " + u.unit).join(", "))}${k("g", "Completed Qty", done3, "", units.map((u) => F(u.done) + " " + u.unit).join(", "))}
${k("a", "Remaining Qty", rem3, "", units.map((u) => F(u.remaining) + " " + u.unit).join(", "))}${k("", "Today's Work", M(todayV), t)}${k("", "This Month", M(monV), mon)}${k(rows.some((r) => r.pending) ? "a" : "", "Pending Approvals", rows.reduce((s, r) => s + r.pending, 0), "reports waiting")}${k(rows.some((r) => r.delayed) ? "r" : "", "Delayed Activities", rows.reduce((s, r) => s + r.delayed, 0), "running, no update 7+ days")}</div>
<div class="ps-2" style="display:grid"><div class="ps-t"><table><thead><tr><th>Project</th><th class="r">Items</th><th>Planned vs Actual</th><th class="r">Today</th><th class="r">${ui.from || ui.to ? "In range" : "All time"}</th><th class="r">Pending</th><th>Status</th></tr></thead><tbody>
${rows.map((r) => `<tr style="cursor:pointer" onclick="PB_PROGRESS_SUITE.openProject('${E(r.p.id)}')"><td><b>${E(r.p.name)}</b><br><small style="color:#64748b">${E(r.p.start || "?")} → ${E(r.p.end || "?")}</small></td><td class="r">${r.it.length}</td>
<td class="ps-pv"><div>Plan<i><em style="width:${r.plan ?? 0}%;background:#94a3b8"></em></i>${r.plan == null ? "—" : r.plan.toFixed(0) + "%"}</div><div>Actual<i><em style="width:${r.act}%;background:#16a34a"></em></i>${r.act.toFixed(1)}%</div></td>
<td class="r">${M(r.todayV)}</td><td class="r">${M(r.rangeV)}</td><td class="r">${r.pending || "—"}</td><td><span class="ps-b ${r.st[0]}">${r.st[1]}</span>${r.delayed ? `<br><small style="color:#b91c1c">${r.delayed} stalled</small>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" style="text-align:center;color:#64748b;padding:18px">No projects with BOQ yet.</td></tr>'}
</tbody></table></div>
<div><div style="font-size:13px;font-weight:800;color:#12233d;margin-bottom:4px">📈 Monthly Progress Trend</div><small style="color:#64748b">Value of work done per month (all projects)</small><div class="ps-chart">${months.map((m, i) => `<div><b>${mv[i] ? M(mv[i]).replace(/\.00$/, "") : ""}</b><span style="height:${(mv[i] / mx) * 85}%"></span>${m.slice(5)}/${m.slice(2, 4)}</div>`).join("")}</div>
<small style="display:block;color:#64748b;margin-top:6px">Plan line uses each project's start and end date (straight line).</small></div></div></div>`;
  }

  // ---------- 2. Progress history ----------
  function histRows() {
    const q = ui.hq.trim().toLowerCase();
    return (db.progress || []).filter((x) => x.projectId === selectedProject).map((x) => {
      const b = boqOf(x) || {}, st = x.approvalStatus || "Approved";
      return { x, b, date: String(x.date || ""), loc: [x.building || b.building || "General", x.floor || b.floor, x.room || b.area || b.room].filter(Boolean).join(" / "),
        item: `${x.boqCode || b.boqId || ""} ${x.title || b.description || ""}`.trim(), prev: n(x.previousQty), sub: n(x.todayQty),
        appr: /reject|return/i.test(st) ? 0 : n(x.approvedQty ?? x.todayQty), total: n(x.totalCompleted), by: x.submittedBy || x.foreman || "—",
        aby: x.approvedBy || x.reviewedBy || (pend(x) ? "—" : String(x.id || "").startsWith("cloud-") ? "Office (approved)" : "Direct office entry"), st: pend(x) ? "Pending" : st, rem: x.note || x.description || "" };
    }).filter((r) => inRange(r.date, ui.hfrom, ui.hto) && (!ui.hst || r.st === ui.hst) && (!q || [r.item, r.loc, r.by, r.rem].join(" ").toLowerCase().includes(q)))
      .sort((a, b) => b.date.localeCompare(a.date));
  }
  const stB = (s) => `<span class="ps-b ${/pend/i.test(s) ? "a" : /reject|return/i.test(s) ? "r" : "g"}">${E(s)}</span>`;
  function histHtml() {
    const all = histRows(), per = 15, pages = Math.max(1, Math.ceil(all.length / per)); if (ui.hpg > pages) ui.hpg = pages;
    const list = all.slice((ui.hpg - 1) * per, ui.hpg * per), sts = [...new Set((db.progress || []).filter((x) => x.projectId === selectedProject).map((x) => (pend(x) ? "Pending" : x.approvalStatus || "Approved")))];
    return `<div class="panel ps-p" data-pt="daily"><div class="ps-h"><div><h3>🧾 Progress History</h3><small>Every entry like a transaction. Approved entries are never overwritten — corrections are new entries.</small></div>
<div class="ps-f"><input type="date" id="psHf" value="${E(ui.hfrom)}"><input type="date" id="psHt" value="${E(ui.hto)}"><select id="psHs"><option value="">All Status</option>${sts.map((s) => `<option ${s === ui.hst ? "selected" : ""}>${E(s)}</option>`).join("")}</select><input id="psHq" placeholder="Search item, location, name…" value="${E(ui.hq)}"></div></div>
<div class="ps-t pbpg-skip"><table><thead><tr><th>Date</th><th>Building / Floor</th><th>BOQ Item</th><th class="r">Previous</th><th class="r">Submitted</th><th class="r">Approved</th><th class="r">Updated Total</th><th>Updated By</th><th>Approved By</th><th>Status</th><th>Remarks</th><th></th></tr></thead><tbody id="psHb">
${list.map((r) => `<tr><td style="white-space:nowrap">${E(r.date)}</td><td>${E(r.loc)}</td><td>${E(r.item)}</td><td class="r">${F(r.prev)}</td><td class="r">${F(r.sub)}</td><td class="r"><b>${F(r.appr)}</b></td><td class="r">${F(r.total)}</td><td>${E(r.by)}</td><td>${E(r.aby)}</td><td>${stB(r.st)}</td><td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${E(r.rem)}">${E(r.rem || "—")}</td><td><button class="btn small" onclick="PB_PROGRESS_SUITE.view('${E(r.x.id)}')">View</button></td></tr>`).join("") || '<tr><td colspan="12" style="text-align:center;color:#64748b;padding:18px">No entries for this filter.</td></tr>'}
</tbody></table></div><div class="ps-pg"><span>${all.length ? `Showing ${(ui.hpg - 1) * per + 1}–${Math.min(ui.hpg * per, all.length)} of ${all.length}` : "0 entries"}</span><div><button class="btn small" id="psHp" ${ui.hpg <= 1 ? "disabled" : ""}>‹ Prev</button><b>${ui.hpg} / ${pages}</b><button class="btn small" id="psHn" ${ui.hpg >= pages ? "disabled" : ""}>Next ›</button></div></div></div>`;
  }
  function view(id) {
    const x = (db.progress || []).find((r) => r.id === id); if (!x) return;
    const b = boqOf(x) || {}, c = C().itemCalc(b);
    const same = (db.progress || []).filter((r) => r.boqId && r.boqId === x.boqId).sort((a, z) => String(a.date).localeCompare(String(z.date)));
    const d = (l, v) => `<div><small>${l}</small><b>${v}</b></div>`;
    const lab = Array.isArray(x.labourEntries) ? x.labourEntries.reduce((s, l) => s + n(l.workers || l.units), 0) : n(x.labourWorkers);
    const html = `<div class="ps-d">${d("Date", E(x.date))}${d("Project", E(typeof projectName === "function" ? projectName(x.projectId) : ""))}${d("Location", E([x.building || b.building, x.floor || b.floor, x.room || b.area].filter(Boolean).join(" / ") || "General"))}
${d("BOQ Item", E((x.boqCode || b.boqId || "") + " " + (x.title || b.description || "")))}${d("BOQ Qty", F(b.qty) + " " + E(b.unit || x.unit || ""))}${d("Previous", F(x.previousQty))}${d("This entry", "<b>" + F(x.todayQty) + "</b> " + E(x.unit || ""))}${d("Total after", F(x.totalCompleted))}${d("Item now", c.pct.toFixed(1) + "% · " + F(c.remaining) + " left")}
${d("Labour", lab || "—")}${d("Submitted by", E(x.submittedBy || x.foreman || "—"))}${d("Status", stB(pend(x) ? "Pending" : x.approvalStatus || "Approved"))}${x.weather ? d("Weather", E(x.weather)) : ""}${x.correction ? d("Correction reason", E(x.correctionReason || "")) : ""}${x.reviewNote ? d("Approval remark", E(x.reviewNote)) : ""}</div>
${x.note || x.description ? `<p style="margin:10px 0 0;font-size:13px"><b>Remarks:</b> ${E(x.description || "")} ${E(x.note || "")}</p>` : ""}
${Array.isArray(x.photoData) && x.photoData.length ? `<div class="ps-ph">${x.photoData.map((s) => `<img src="${s}" alt="site photo">`).join("")}</div>` : ""}
<h4 style="margin:14px 0 6px">History of this BOQ item</h4><div class="ps-t"><table><thead><tr><th>Date</th><th class="r">Qty</th><th class="r">Total after</th><th>By</th><th>Status</th></tr></thead><tbody>${same.map((r) => `<tr${r.id === x.id ? ' style="background:#eef4ff"' : ""}><td>${E(r.date)}</td><td class="r">${F(r.todayQty)}</td><td class="r">${F(r.totalCompleted)}</td><td>${E(r.submittedBy || r.foreman || "—")}</td><td>${stB(pend(r) ? "Pending" : r.approvalStatus || "Approved")}</td></tr>`).join("")}</tbody></table></div>`;
    if (typeof openModal === "function") { openModal("Progress Entry Details", html, () => { if (typeof closeModal === "function") closeModal(); }); const sv = document.getElementById("modalSave"); if (sv) sv.style.display = "none"; } else alert("Details unavailable");
  }

  // ---------- 3. Period reports ----------
  function repData() {
    const pids = ui.rall ? (db.projects || []).map((p) => p.id) : [selectedProject];
    const list = (db.progress || []).filter((x) => pids.includes(x.projectId) && n(x.todayQty) > 0 && inRange(String(x.date || ""), ui.rfrom, ui.rto) && !/reject|return/i.test(String(x.approvalStatus || "")));
    const g = {};
    list.forEach((x) => {
      const k = C().periodKey(x.date, ui.rmode) + "|" + x.projectId, r = (g[k] = g[k] || { period: C().periodKey(x.date, ui.rmode), pid: x.projectId, entries: 0, items: new Set(), value: 0, workers: 0, pending: 0 });
      r.entries++; r.items.add(x.boqId); r.value += val(x); r.pending += pend(x) ? 1 : 0;
      r.workers += Array.isArray(x.labourEntries) && x.labourEntries.length ? x.labourEntries.reduce((s, l) => s + n(l.workers || l.units), 0) : n(x.labourWorkers);
    });
    return Object.values(g).sort((a, b) => b.period.localeCompare(a.period) || String(a.pid).localeCompare(String(b.pid)));
  }
  function repHtml() {
    const d = repData(), tot = d.reduce((s, r) => s + r.value, 0), w = d.reduce((s, r) => s + r.workers, 0);
    const lbl = { day: "Daily", week: "Weekly", month: "Monthly" }[ui.rmode];
    return `<div class="panel ps-p" data-pt="reports"><div class="ps-h"><div><h3>📊 ${lbl} Progress Report & Labour Productivity</h3><small>Physical work done per period. Rejected entries are left out. Productivity = work value ÷ worker-days reported.</small></div>
<div class="ps-f"><select id="psRm">${["day", "week", "month"].map((m) => `<option value="${m}" ${m === ui.rmode ? "selected" : ""}>${{ day: "Daily", week: "Weekly", month: "Monthly" }[m]}</option>`).join("")}</select><input type="date" id="psRf" value="${E(ui.rfrom)}"><input type="date" id="psRt" value="${E(ui.rto)}">
<label style="font-size:12px;display:flex;gap:4px;align-items:center"><input type="checkbox" id="psRa" ${ui.rall ? "checked" : ""}>All projects</label><button class="btn small" onclick="PB_PROGRESS_SUITE.csv()">Excel (CSV)</button><button class="btn small" onclick="PB_PROGRESS_SUITE.print()">PDF / Print</button></div></div>
<div class="ps-k" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div><small>Periods</small><b>${new Set(d.map((r) => r.period)).size}</b></div><div><small>Work value</small><b>${M(tot)}</b></div><div><small>Worker-days</small><b>${F(w)}</b></div><div class="g"><small>Value per worker</small><b>${w ? M(tot / w) : "—"}</b></div></div>
<div class="ps-t"><table><thead><tr><th>${ui.rmode === "week" ? "Week from" : ui.rmode === "month" ? "Month" : "Date"}</th><th>Project</th><th class="r">Entries</th><th class="r">BOQ items</th><th class="r">Work value</th><th class="r">Workers</th><th class="r">Value / worker</th><th class="r">Pending</th></tr></thead><tbody>
${d.map((r) => `<tr><td><b>${E(r.period)}</b></td><td>${E(typeof projectName === "function" ? projectName(r.pid) : r.pid)}</td><td class="r">${r.entries}</td><td class="r">${r.items.size}</td><td class="r">${M(r.value)}</td><td class="r">${F(r.workers) || "—"}</td><td class="r">${r.workers ? M(r.value / r.workers) : "—"}</td><td class="r">${r.pending || "—"}</td></tr>`).join("") || '<tr><td colspan="8" style="text-align:center;color:#64748b;padding:18px">No work in this period.</td></tr>'}
</tbody></table></div></div>`;
  }
  function csv() {
    const d = repData(), q = (s) => `"${String(s).replace(/"/g, '""')}"`;
    const lines = [["Period", "Project", "Entries", "BOQ items", "Work value AED", "Workers", "Value per worker AED", "Pending"].map(q).join(",")].concat(d.map((r) => [r.period, typeof projectName === "function" ? projectName(r.pid) : r.pid, r.entries, r.items.size, r.value.toFixed(2), r.workers, r.workers ? (r.value / r.workers).toFixed(2) : "", r.pending].map(q).join(",")));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv" })); a.download = `progress-${ui.rmode}-report.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function print() {
    const box = document.querySelector('.ps-p[data-pt="reports"]'); if (!box) return;
    const s = db.settings || {}, f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    const c = box.cloneNode(true); c.querySelectorAll(".ps-f").forEach((e) => e.remove());
    f.contentDocument.open(); f.contentDocument.write(`<html><head><title>Progress Report</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Arial;font-size:11px;color:#111}h1{font-size:17px;margin:0 0 8px}table{width:100%;border-collapse:collapse}th{background:#14213d;color:#fff;padding:5px;text-align:left}td{padding:4px 5px;border-bottom:1px solid #ddd}.r{text-align:right}thead{display:table-header-group}.ps-k{display:flex;gap:10px;margin:8px 0}.ps-k div{border:1px solid #ccc;padding:5px 8px;border-radius:6px}.ps-k small{display:block;color:#555}</style></head><body><h1>${E(s.companyName || "PURE_BUILD")}</h1>${c.innerHTML}<p style="margin-top:30px">Prepared by: ____________ &nbsp;&nbsp; Checked by: ____________</p></body></html>`); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  // ---------- mount ----------
  function inject(v) {
    v.querySelectorAll(".ps-host").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum || !C()) return;
    const host = document.createElement("div"); host.className = "ps-host";
    try { host.innerHTML = dashHtml() + (selectedProject ? histHtml() + repHtml() : ""); } catch (e) { console.warn("progress-suite", e); return; }
    sum.insertAdjacentElement("afterend", host);
    const on = (id, ev, fn) => host.querySelector(id)?.addEventListener(ev, fn);
    on("#psFrom", "change", (e) => { ui.from = e.target.value; refresh(); }); on("#psTo", "change", (e) => { ui.to = e.target.value; refresh(); }); on("#psClr", "click", () => { ui.from = ui.to = ""; refresh(); });
    on("#psHf", "change", (e) => { ui.hfrom = e.target.value; ui.hpg = 1; refresh(); }); on("#psHt", "change", (e) => { ui.hto = e.target.value; ui.hpg = 1; refresh(); });
    on("#psHs", "change", (e) => { ui.hst = e.target.value; ui.hpg = 1; refresh(); }); on("#psHp", "click", () => { ui.hpg--; refresh(); }); on("#psHn", "click", () => { ui.hpg++; refresh(); });
    let tm; on("#psHq", "input", (e) => { ui.hq = e.target.value; ui.hpg = 1; clearTimeout(tm); tm = setTimeout(() => { refresh(); const i = document.getElementById("psHq"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); });
    on("#psRm", "change", (e) => { ui.rmode = e.target.value; refresh(); }); on("#psRf", "change", (e) => { ui.rfrom = e.target.value; refresh(); }); on("#psRt", "change", (e) => { ui.rto = e.target.value; refresh(); }); on("#psRa", "change", (e) => { ui.rall = e.target.checked; refresh(); });
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }
  function openProject(pid) {
    try { selectedProject = pid; } catch (e) {}
    if (typeof progressBuilding !== "undefined") try { progressBuilding = ""; } catch (e) {}
    window.PB_PROGRESS_TABS_SET && PB_PROGRESS_TABS_SET("boqwork"); if (typeof render === "function") render();
  }
  window.PB_PROGRESS_SUITE = { inject, view, csv, print, openProject };
})();
