/* Site Progress formulas (physical progress only; never financial). Tested in src/test/progress-calc.test.ts */
(function (root) {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const approvedish = (b) => !["Draft", "Under Review", "Submitted"].includes(b.status);
  // Weighted progress: by BOQ value (qty × rate); falls back to qty share when no rates.
  function weighted(items) {
    let v = 0, d = 0, q = 0, dq = 0;
    items.forEach((b) => { const qty = n(b.qty), ex = Math.min(qty, Math.max(0, n(b.executedQty))), r = n(b.rate); v += qty * r; d += ex * r; q += qty; dq += ex; });
    const pct = v > 0 ? (d / v) * 100 : q > 0 ? (dq / q) * 100 : 0;
    return Math.min(100, Math.max(0, pct));
  }
  function itemCalc(b) {
    const qty = n(b.qty), ex = Math.max(0, n(b.executedQty));
    return { qty, done: Math.min(qty, ex), remaining: Math.max(0, qty - ex), pct: qty > 0 ? Math.min(100, (ex / qty) * 100) : 0 };
  }
  // Planned % straight-line between project start and end dates.
  function planned(start, end, today) {
    if (!start || !end) return null;
    const s = new Date(start).getTime(), e = new Date(end).getTime(), t = new Date(today).getTime();
    if (!(e > s)) return null;
    return Math.max(0, Math.min(100, ((t - s) / (e - s)) * 100));
  }
  // Quantity totals per unit (never mixes units).
  function byUnit(items) {
    const m = {};
    items.forEach((b) => { const u = String(b.unit || "—").trim() || "—", c = itemCalc(b); const x = (m[u] = m[u] || { unit: u, qty: 0, done: 0, remaining: 0 }); x.qty += c.qty; x.done += c.done; x.remaining += c.remaining; });
    return Object.values(m);
  }
  // Group progress entries by period key: day | week (ISO Monday) | month.
  function periodKey(date, mode) {
    const d = String(date || "").slice(0, 10);
    if (mode === "month") return d.slice(0, 7);
    if (mode === "week") { const x = new Date(d + "T00:00:00Z"); const wd = (x.getUTCDay() + 6) % 7; x.setUTCDate(x.getUTCDate() - wd); return x.toISOString().slice(0, 10); }
    return d;
  }
  // Days between two ISO dates (b - a).
  const dayDiff = (a, b) => Math.round((new Date(b + "T00:00:00Z") - new Date(a + "T00:00:00Z")) / 86400000);
  // Delay days for a work item: finished late, or past planned finish and not complete. Never negative.
  function delayDays(planEnd, actualFinish, pct, today) {
    if (!planEnd) return 0;
    if (actualFinish) return Math.max(0, dayDiff(planEnd, actualFinish));
    if (n(pct) >= 100) return 0;
    return Math.max(0, dayDiff(planEnd, today));
  }
  // Labour summary from saved labour rows (read-only). Cost = units×rate + OT hrs×OT rate.
  function labourSummary(rows) {
    const s = { entries: 0, workers: 0, present: 0, absent: 0, skilled: 0, unskilled: 0, hours: 0, overtime: 0, cost: 0 };
    rows.forEach((x) => {
      const st = String(x.status || "Present"), u = x.workerId ? 1 : Math.max(0, n(x.units) || 0);
      s.entries++; s.workers += u;
      if (/absent|leave/i.test(st)) { s.absent += x.workerId ? 1 : 0; return; }
      s.present += u;
      if (/helper|labou?r|unskilled|general/i.test(String(x.role || ""))) s.unskilled += u; else s.skilled += u;
      s.hours += n(x.hours); s.overtime += n(x.overtime);
      s.cost += (x.workerId ? 1 : u) * n(x.rate) + n(x.overtime) * n(x.otRate);
    });
    return s;
  }
  const api = { delayDays, labourSummary, dayDiff, weighted, itemCalc, planned, byUnit, periodKey, approvedish };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PBProgressCalc = api;
})(typeof window !== "undefined" ? window : globalThis);
