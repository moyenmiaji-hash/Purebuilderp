CREATE POLICY "office upload task files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'site-progress-photos' AND public.is_office_user(auth.uid()) AND (storage.foldername(name))[3] LIKE 'task-%');
CREATE POLICY "foreman reads own task files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'site-progress-photos' AND EXISTS (
    SELECT 1 FROM public.foreman_tasks t WHERE 'task-' || t.id::text = (storage.foldername(name))[3] AND t.assigned_to = auth.uid()));

CREATE OR REPLACE FUNCTION public.add_foreman_task_attachments(p_task uuid, p_files jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can add task files'; END IF;
  IF jsonb_typeof(p_files) <> 'array' THEN RAISE EXCEPTION 'Invalid files'; END IF;
  UPDATE public.foreman_tasks SET attachments = attachments || p_files, updated_at = now() WHERE id = p_task;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, new_values, actor)
    VALUES (p_task, 'files_added', jsonb_build_object('files', jsonb_array_length(p_files)), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE EXECUTE ON FUNCTION public.add_foreman_task_attachments(uuid, jsonb) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.add_foreman_task_attachments(uuid, jsonb) TO authenticated;