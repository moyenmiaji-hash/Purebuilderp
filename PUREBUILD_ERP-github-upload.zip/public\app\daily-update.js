// Site Progress: "Daily Progress Update" panel with weighted work stages.
// Additive only: stage lists in db.stageTemplates, per-BOQ stage % in db.stageProgress, drafts in db.progressDrafts.
// Submitted updates are pushed to db.progress (same shape as the existing Daily Site Report) and add qty to the BOQ once.
(function () {
  const C = () => window.PB_STAGE_CALC;
  const today = () => new Date().toISOString().slice(0, 10);
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  function templates() {
    if (!db.stageTemplates || typeof db.stageTemplates !== "object") {
      db.stageTemplates = {};
      Object.entries(C().DEFAULTS).forEach(([k, arr]) => { db.stageTemplates[k] = arr.map(([name, weight]) => ({ name, weight })); });
    }
    return db.stageTemplates;
  }
  function tradeKey(b) {
    const t = templates(), cat = String(b?.category || "").trim(), desc = String(b?.description || "").toLowerCase();
    if (t[cat]) return cat;
    const hit = Object.keys(t).find((k) => k !== "General" && (desc.includes(k.toLowerCase()) || cat.toLowerCase().includes(k.toLowerCase())));
    return hit || (t.General ? "General" : Object.keys(t)[0]);
  }
  const approvedQty = (b) => n(b.qty) + (typeof salesApprovedVariationQty === "function" ? n(salesApprovedVariationQty(b.projectId, b.id)) : 0);
  const prevStages = (b) => ((db.stageProgress || {})[b.id] || {}).stages || {};
  let photos = [], state = { boqId: "", draftId: "" };

  const css = `.du-btn{background:linear-gradient(135deg,#0f5fae,#2182df)!important;color:#fff!important;border:0!important;font-weight:800;white-space:nowrap}
.du-wrap{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(260px,.9fr);gap:12px}.du-sec{border:1px solid var(--line);border-radius:11px;padding:10px 12px;margin-bottom:10px;background:#fff}
.du-sec h4{margin:0 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#36507a}.du-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.du-grid .full{grid-column:1/-1}
.du-grid label{display:block;font-size:10px;font-weight:800;color:#667891;margin-bottom:3px}.du-grid input,.du-grid select,.du-grid textarea{width:100%}
.du-tbl{width:100%;border-collapse:collapse;font-size:12px}.du-tbl th{background:#f2f6fb;text-align:left;padding:6px;font-size:10px;color:#52647d}.du-tbl td{padding:5px 6px;border-top:1px solid var(--line)}.du-tbl input{width:70px}
.du-side{position:sticky;top:0;align-self:start}.du-big{font-size:30px;font-weight:900;color:#0f5fae}.du-kv{display:flex;justify-content:space-between;font-size:12px;padding:5px 0;border-bottom:1px dashed var(--line)}
.du-ph{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.du-ph span{position:relative}.du-ph img{width:62px;height:62px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}.du-ph button{position:absolute;top:-6px;right:-6px;border:0;border-radius:50%;width:18px;height:18px;background:#c0392b;color:#fff;font-size:11px;cursor:pointer}
.du-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.du-warn{background:#fff6e5;border:1px solid #f1c27d;color:#7a4b00;border-radius:8px;padding:7px 9px;font-size:12px;margin-top:8px}
#modal .du-wrap .du-sec{box-shadow:0 1px 2px rgba(15,40,80,.05);border-color:#dfe8f3}
.du-sec h4{display:flex;align-items:center;gap:7px}.du-sec h4 i{font-style:normal;display:inline-grid;place-items:center;width:20px;height:20px;border-radius:6px;background:linear-gradient(135deg,#0f5fae,#2182df);color:#fff;font-size:11px;letter-spacing:0}
.du-chips{display:flex;gap:5px;flex-wrap:wrap;align-self:end}.du-chips button{border:1px solid #cfdcec;background:#f4f8fd;color:#0f5fae;border-radius:999px;padding:5px 10px;font-size:11px;font-weight:800;cursor:pointer}.du-chips button:hover{background:#0f5fae;color:#fff}
.du-info{display:flex;gap:10px;flex-wrap:wrap;align-items:center;background:linear-gradient(135deg,#f4f8fd,#eef6f1);border:1px solid #dbe6f2;border-radius:9px;padding:7px 10px;font-size:11px;color:#40546f}.du-info b{color:#12233d}.du-info .tag{background:#fff;border:1px solid #d8e4f0;border-radius:999px;padding:2px 8px;font-weight:800}
.du-ring{width:104px;height:104px;border-radius:50%;display:grid;place-items:center;margin:2px auto 6px;background:conic-gradient(#0f5fae 0 var(--a),#22a06b var(--a) var(--b),#e7eef7 var(--b) 100%)}.du-ring>div{width:80px;height:80px;border-radius:50%;background:#fff;display:grid;place-items:center;text-align:center}.du-ring b{font-size:20px;color:#0f5fae;line-height:1}.du-ring small{font-size:9px;color:#6b7c93;font-weight:700}
.du-legend{display:flex;justify-content:center;gap:12px;font-size:10px;color:#5a6b82;margin-bottom:6px}.du-legend span:before{content:"";display:inline-block;width:8px;height:8px;border-radius:2px;margin-right:4px;background:var(--c)}
.du-check{margin-top:10px;border-top:1px solid var(--line);padding-top:8px}.du-check div{font-size:11.5px;padding:3px 0;color:#7a879a}.du-check div.ok{color:#16784d;font-weight:700}.du-check div:before{content:"○";display:inline-block;width:16px}.du-check div.ok:before{content:"✓"}
.du-dup{background:#fdecec;border:1px solid #f0b5b5;color:#8a1f1f;border-radius:8px;padding:6px 9px;font-size:11.5px;margin-top:6px}
@media(max-width:900px){.du-wrap{grid-template-columns:1fr}.du-grid{grid-template-columns:1fr 1fr}.du-side{position:static}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  // Add the button to the Site Progress header row.
  const orig = window.progress;
  window.progress = function () {
    const r = orig.apply(this, arguments);
    try {
      const bar = document.querySelector("#view .progress-sitebar");
      if (bar && !document.querySelector("#view .du-bar")) {
        const box = document.createElement("div");
        box.className = "du-bar";
        box.style.cssText = "display:flex;gap:8px;justify-content:flex-end;align-items:center;flex-wrap:wrap;margin:0 0 10px;padding:8px 10px;background:#f4f8fd;border:1px solid #d8e4f0;border-radius:11px";
        box.innerHTML = `<span style="margin-right:auto;font-size:12px;font-weight:800;color:#36507a">Daily Work Progress</span><button class="btn du-btn" type="button" onclick="PB_DAILY_UPDATE.open()">＋ Daily Progress Update</button><button class="btn small" type="button" onclick="PB_DAILY_UPDATE.history()">Previous Updates</button><button class="btn small" type="button" onclick="PB_DAILY_UPDATE.stages()">Work Stages</button>`;
        bar.insertAdjacentElement("afterend", box);
      }
    } catch (e) { console.warn(e); }
    return r;
  };

  function wide() { const b = document.querySelector("#modal .modalbox"); if (b) { b.style.width = "min(1180px,100%)"; b.style.maxHeight = "94vh"; } }

  function open(draftId) {
    if (!selectedProject) { toast("Select a site first"); return; }
    const pid = selectedProject, draft = draftId ? (db.progressDrafts || []).find((d) => d.id === draftId) : null;
    state = { boqId: draft?.boqId || "", draftId: draft?.id || "" }; photos = draft?.photoData ? draft.photoData.slice() : [];
    const items = (db.boq || []).filter((b) => b.projectId === pid && !["Draft", "Under Review", "Submitted"].includes(b.status));
    const blds = typeof projectBuildings === "function" ? projectBuildings(pid) : [];
    const bSel = draft?.building || (progressBuilding && progressBuilding !== "__general" ? progressBuilding : "");
    const v = (k, d = "") => esc(draft?.[k] ?? d);
    openModal("Daily Work Progress Update", `<div class="du-wrap"><div>
<div class="du-sec"><h4><i>1</i>Project &amp; Work Location</h4><div class="du-grid">
<div><label>Project</label><input value="${esc(projectName(pid))}" readonly></div>
<div><label>Building / Site</label><select id="duBld" class="select"><option value="">All / General</option>${blds.map((x) => `<option ${x === bSel ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></div>
<div><label>Date *</label><input id="duDate" type="date" value="${v("date", today())}" max="${today()}"></div>
<div class="full"><label>Work Activity (BOQ item) *</label><select id="duBoq" class="select"><option value="">Select work</option>${items.map((b) => `<option value="${esc(b.id)}" data-b="${esc(b.building || "")}" ${b.id === state.boqId ? "selected" : ""}>${esc(b.boqId || "")} — ${esc(b.description || "")} · ${esc(b.building || "General")}${b.floor ? " / " + esc(b.floor) : ""}${b.area ? " / " + esc(b.area) : ""}</option>`).join("")}</select></div>
<div><label>Completed today (qty) *</label><input id="duQty" type="number" min="0" step="any" value="${v("qty", "")}" placeholder="e.g. 25"></div><div class="du-chips" style="grid-column:span 2"><button type="button" data-f="0.1">10% of remaining</button><button type="button" data-f="0.25">25%</button><button type="button" data-f="0.5">50%</button><button type="button" data-f="1">All remaining</button><button type="button" data-f="0">Clear</button></div><div class="full" id="duQtyHint"></div>
<div><label>Floor</label><input id="duFloor" value="${v("floor")}"></div><div><label>Flat / Room No.</label><input id="duRoom" value="${v("room")}"></div><div><label>Assigned Team</label><input id="duTeam" value="${v("team")}" placeholder="e.g. Painting Team A"></div>
<div><label>Weather</label><select id="duWeather" class="select">${["", "Sunny", "Hot", "Cloudy", "Windy / Dust", "Rain"].map((w) => `<option ${w === (draft?.weather || "") ? "selected" : ""}>${w}</option>`).join("")}</select></div><div><label>Shift</label><select id="duShift" class="select">${["Day", "Night", "Day + Night"].map((w) => `<option ${w === (draft?.shift || "Day") ? "selected" : ""}>${w}</option>`).join("")}</select></div><div><label>Working hours</label><input id="duHours" type="number" min="0" max="24" step="0.5" value="${v("workHours", "")}" placeholder="e.g. 8"></div>
</div></div>
<div class="du-sec" style="display:none"><h4>2 · Work Breakdown &amp; Progress</h4><div id="duStages"><div class="empty">Select a work activity to see its stages.</div></div></div>
<div class="du-sec"><h4><i>2</i>Work Notes, Problems &amp; Photos &amp; Site Updates</h4><div class="du-grid">
<div class="full"><label>Work Description</label><textarea id="duDesc">${v("description")}</textarea></div>
<div><label>Site Issues</label><input id="duIssues" value="${v("problems")}"></div><div><label>Delays</label><input id="duDelay" value="${v("delay")}"></div><div><label>Site Supervisor / Foreman</label><input id="duSup" value="${v("foreman")}"></div>
<div><label>Material Notes</label><input id="duMat" value="${v("materialNote")}"></div><div><label>Manpower Notes</label><input id="duMan" value="${v("manpowerNote")}"></div><div><label>Workers today</label><input id="duWorkers" type="number" min="0" value="${v("labourWorkers", 0)}"></div>
<div class="full"><label>Site Photos (up to 8, max 3 MB each)</label><input id="duPhotos" type="file" accept="image/png,image/jpeg,image/webp" multiple><div class="du-ph" id="duPh"></div></div>
</div></div>
<div class="du-sec"><h4><i>3</i>Materials, Labour &amp; Equipment</h4>
<div class="muted" style="font-size:11px;margin-bottom:6px">Fill only what happened today. Materials go to Warehouse/Stock, labour to Labour &amp; HR — exactly like an approved foreman report.</div>
${PB_DU_ROWS.html(draft)}
</div><div class="du-sec"><h4><i>4</i>Correction</h4><div class="du-grid">
<div class="full"><label><input type="checkbox" id="duCorr" style="width:auto"> Authorized correction (an update already exists for this work and date)</label><input id="duCorrWhy" placeholder="Reason for correction" style="margin-top:4px"></div>
</div></div></div>
<div class="du-side"><div class="du-sec"><h4><i>✓</i>Progress Summary</h4><div id="duSum"><div class="empty">No work selected.</div></div>
<div class="du-check" id="duCheck"></div><div class="du-actions"><button class="btn" type="button" onclick="PB_DAILY_UPDATE.saveDraft()">Save as Draft</button><button class="btn primary" type="button" onclick="PB_DAILY_UPDATE.submit()">Submit Update</button><button class="btn small" type="button" onclick="PB_DAILY_UPDATE.history()">View Previous Updates</button></div></div></div></div>`, () => true);
    document.getElementById("modalSave").style.display = "none"; wide();
    const sel = document.getElementById("duBoq"), bld = document.getElementById("duBld");
    const filt = () => { const b = bld.value; [...sel.options].forEach((o) => { if (o.value) o.hidden = !!b && o.dataset.b !== b; }); };
    bld.addEventListener("change", filt); filt();
    sel.addEventListener("change", () => { state.boqId = sel.value; const b = (db.boq || []).find((x) => x.id === sel.value); if (b) { document.getElementById("duFloor").value = b.floor || ""; document.getElementById("duRoom").value = b.area || b.room || ""; if (b.building) bld.value = b.building; } drawStages(); });
    document.getElementById("duQty").addEventListener("input", () => drawSum());
    document.querySelectorAll(".du-chips button").forEach((bt) => bt.addEventListener("click", () => { const c = current(); if (!c) { toast("Select a work activity first"); return; } const rem = Math.max(0, c.appr - c.exec), f = n(bt.dataset.f); document.getElementById("duQty").value = f ? Math.round(rem * f * 100) / 100 : ""; drawSum(); }));
    ["duDate", "duDesc", "duSup"].forEach((k) => document.getElementById(k)?.addEventListener("input", () => drawSum()));
    document.getElementById("modalBody")?.addEventListener("change", () => drawSum());
    document.getElementById("duPhotos").addEventListener("change", async (e) => {
      for (const f of [...e.target.files]) { if (photos.length >= 8) break; if (f.size > 3 * 1024 * 1024) { toast("A photo is larger than 3 MB"); continue; } photos.push(await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(f); })); }
      e.target.value = ""; drawPhotos(); drawSum();
    });
    drawPhotos(); drawStages(draft?.stageToday); PB_DU_ROWS.bind();
    document.getElementById("modalBody")?.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); submit(); } });
  }
  function drawPhotos() { const el = document.getElementById("duPh"); if (el) el.innerHTML = photos.map((s, i) => `<span><img src="${s}" alt="site photo"><button type="button" onclick="PB_DAILY_UPDATE.rmPhoto(${i})">×</button></span>`).join(""); }

  function current() {
    const b = (db.boq || []).find((x) => x.id === state.boqId); if (!b) return null;
    const key = tradeKey(b), stages = templates()[key] || [], prev = prevStages(b), todayMap = {};
    document.querySelectorAll("#duStages input[data-st]").forEach((i) => { todayMap[i.dataset.st] = n(i.value); });
    const calc = C().compute(stages, prev, todayMap), appr = approvedQty(b), exec = n(b.executedQty);
    return { b, key, stages, prev, todayMap, calc, appr, exec, add: n(document.getElementById("duQty")?.value) > 0 ? Math.min(n(document.getElementById("duQty").value), Math.max(0, appr - exec)) : C().qtyToAdd(calc.overall, appr, exec) };
  }
  function drawStages(preset) {
    const box = document.getElementById("duStages"); const b = (db.boq || []).find((x) => x.id === state.boqId);
    if (!b) { box.innerHTML = '<div class="empty">Select a work activity to see its stages.</div>'; drawSum(); return; }
    const key = tradeKey(b), stages = templates()[key] || [], prev = prevStages(b), bad = C().validStages(stages);
    box.innerHTML = `<div class="muted" style="font-size:11px;margin-bottom:6px">Stage list: <b>${esc(key)}</b> · <a href="#" onclick="PB_DAILY_UPDATE.stages();return false">change stages</a></div>${bad ? `<div class="du-warn">${esc(bad)}. Fix the stage list first.</div>` : ""}
<table class="du-tbl"><thead><tr><th>Work Stage</th><th>Weight %</th><th>Previously %</th><th>Today %</th><th>Updated %</th><th>Remaining %</th><th>Status</th></tr></thead><tbody>${stages.map((s) => { const p = Math.min(100, n(prev[s.name])); return `<tr><td><b>${esc(s.name)}</b></td><td>${n(s.weight)}</td><td>${p.toFixed(0)}</td><td><input type="number" min="0" max="${100 - p}" step="1" data-st="${esc(s.name)}" value="${n(preset?.[s.name]) || 0}" ${p >= 100 || bad ? "disabled" : ""}></td><td data-u></td><td data-r></td><td data-s></td></tr>`; }).join("")}</tbody></table>`;
    box.querySelectorAll("input[data-st]").forEach((i) => i.addEventListener("input", () => { const mx = n(i.max); if (n(i.value) > mx) i.value = mx; if (n(i.value) < 0) i.value = 0; drawSum(); }));
    drawSum();
  }
  function drawSum() {
    const el = document.getElementById("duSum"); if (!el) return; const c = current(); drawCheck(c);
    if (!c) { el.innerHTML = '<div class="empty">No work selected.</div>'; const h0 = document.getElementById("duQtyHint"); if (h0) h0.innerHTML = ""; return; }
    c.calc.rows.forEach((r, i) => { const tr = document.querySelectorAll("#duStages tbody tr")[i]; if (!tr) return; tr.querySelector("[data-u]").textContent = r.updated.toFixed(0) + "%"; tr.querySelector("[data-r]").textContent = r.remaining.toFixed(0) + "%"; tr.querySelector("[data-s]").innerHTML = `<span class="pill ${r.status === "Completed" ? "green" : r.status === "In Progress" ? "" : "amber"}">${r.status}</span>`; });
    const u = esc(c.b.unit || ""), qtyPct = c.appr ? (c.exec / c.appr) * 100 : 0;
    const h = document.getElementById("duQtyHint"); if (h) h.innerHTML = info(c);
    if (n(document.getElementById("duQty")?.value) > 0 || c.calc.today <= 0) { const nx = c.exec + c.add, pc = c.appr ? (nx / c.appr) * 100 : 0, a = c.appr ? Math.min(100, (c.exec / c.appr) * 100) : 0; el.innerHTML = `<div class="du-ring" style="--a:${a}%;--b:${Math.min(100, pc)}%"><div><span><b>${pc.toFixed(1)}%</b><br><small>after this entry</small></span></div></div><div class="du-legend"><span style="--c:#0f5fae">Done before ${a.toFixed(1)}%</span><span style="--c:#22a06b">Today +${Math.max(0, pc - a).toFixed(1)}%</span></div><div class="du-kv"><span>BOQ approved qty</span><b>${fmt(c.appr)} ${u}</b></div><div class="du-kv"><span>Already done</span><b>${fmt(c.exec)} ${u}</b></div><div class="du-kv"><span>Adding today</span><b>${fmt(c.add)} ${u}</b></div><div class="du-kv"><span>Remaining after</span><b>${fmt(Math.max(0, c.appr - nx))} ${u}</b></div><div class="du-kv"><span>Value added</span><b>${money(c.add * n(c.b.rate))}</b></div>`; return; }
    el.innerHTML = `<div class="du-big">${c.calc.overall.toFixed(1)}%</div><div class="muted" style="font-size:11px;margin-bottom:6px">Updated overall completion (weighted)</div><div class="progress"><i style="width:${c.calc.overall}%"></i></div>
<div class="du-kv"><span>Previously completed</span><b>${c.calc.previous.toFixed(1)}%</b></div><div class="du-kv"><span>Today's progress</span><b>${c.calc.today.toFixed(1)}%</b></div><div class="du-kv"><span>Remaining</span><b>${c.calc.remaining.toFixed(1)}%</b></div><div class="du-kv"><span>Status</span><b>${c.calc.status}</b></div>
<div class="du-kv"><span>BOQ approved qty</span><b>${fmt(c.appr)} ${u}</b></div><div class="du-kv"><span>Already done (BOQ)</span><b>${fmt(c.exec)} ${u} · ${qtyPct.toFixed(1)}%</b></div><div class="du-kv"><span>Will add to BOQ</span><b>${fmt(c.add)} ${u}</b></div><div class="du-kv"><span>Value added</span><b>${money(c.add * n(c.b.rate))}</b></div>
${c.calc.today > 0 && c.add <= 0 ? '<div class="du-warn">BOQ already shows this much done (for example from foreman reports), so no extra quantity will be added. Stage % will still be saved.</div>' : ""}`;
  }
  function lastUpdate(b) { return (db.progress || []).filter((x) => x.boqId === b.id && n(x.todayQty) > 0).sort((p, q) => String(q.date).localeCompare(String(p.date)))[0]; }
  function dupFor(b, date) { return (db.progress || []).some((x) => x.source === "stage-update" && x.boqId === b.id && x.date === date && (n(x.stageToday) > 0 || n(x.todayQty) > 0)); }
  function info(c) {
    const u = esc(c.b.unit || ""), rem = Math.max(0, c.appr - c.exec), last = lastUpdate(c.b), date = document.getElementById("duDate")?.value;
    const days = last ? Math.round((new Date(today()) - new Date(last.date)) / 864e5) : null;
    return `<div class="du-info"><span class="tag">${esc(c.b.category || c.key || "Work")}</span><span>BOQ <b>${fmt(c.appr)} ${u}</b></span><span>Done <b>${fmt(c.exec)} ${u}</b></span><span>Remaining <b>${fmt(rem)} ${u}</b></span><span>Rate <b>${money(n(c.b.rate))}</b></span><span>Last update: <b>${last ? `${esc(last.date)} · +${fmt(last.todayQty)} ${u}${days != null ? ` (${days === 0 ? "today" : days + " day" + (days > 1 ? "s" : "") + " ago"})` : ""}` : "none yet"}</b></span></div>${date && dupFor(c.b, date) ? '<div class="du-dup">⚠ An update for this work on this date already exists. Use section 4 "Authorized correction" with a reason to add another.</div>' : ""}${rem <= 0 ? '<div class="du-warn">This BOQ item is already 100% done — no more quantity can be added.</div>' : ""}`;
  }
  function drawCheck(c) {
    const el = document.getElementById("duCheck"); if (!el) return; const f = gather(), ex = window.PB_DU_ROWS ? PB_DU_ROWS.read() : { materialIn: [], materialOut: [], labourEntries: [], equipment: [] };
    const rows = [[!!c, "Work activity selected"], [n(f.qty) > 0, n(f.qty) > 0 ? `Quantity today: ${fmt(n(f.qty))} ${c?.b.unit || ""}` : "Quantity completed today"], [!!f.date && f.date <= today(), "Valid date"], [!!f.description, "Work description written"], [photos.length > 0, `Site photos (${photos.length}/8)`], [ex.materialIn.length + ex.materialOut.length + ex.labourEntries.length + ex.equipment.length > 0, `Materials / labour / equipment rows (${ex.materialIn.length + ex.materialOut.length + ex.labourEntries.length + ex.equipment.length})`]];
    const done = rows.filter((r) => r[0]).length;
    el.innerHTML = `<p style="margin:0 0 3px;font-size:10px;font-weight:800;color:#36507a;text-transform:uppercase">Ready check · ${done}/${rows.length}</p>${rows.map((r) => `<div class="${r[0] ? "ok" : ""}">${esc(r[1])}</div>`).join("")}`;
  }
  function gather() {
    const g = (i) => document.getElementById(i)?.value?.trim() || "";
    return { date: g("duDate"), building: g("duBld"), floor: g("duFloor"), room: g("duRoom"), team: g("duTeam"), description: g("duDesc"), problems: g("duIssues"), delay: g("duDelay"), foreman: g("duSup"), materialNote: g("duMat"), manpowerNote: g("duMan"), labourWorkers: n(g("duWorkers")), qty: g("duQty"), weather: g("duWeather"), shift: g("duShift"), workHours: g("duHours") };
  }
  function saveDraft() {
    const c = current(), f = gather(); db.progressDrafts = db.progressDrafts || [];
    const rec = { ...f, id: state.draftId || id(), projectId: selectedProject, boqId: state.boqId, stageToday: c ? c.todayMap : {}, photoData: photos.slice(), ...PB_DU_ROWS.read(), status: "Draft", savedAt: new Date().toISOString() };
    const i = db.progressDrafts.findIndex((d) => d.id === rec.id); if (i >= 0) db.progressDrafts[i] = rec; else db.progressDrafts.push(rec);
    state.draftId = rec.id; save(); toast("Draft saved — nothing added to BOQ yet");
  }
  function submit() {
    const c = current(), f = gather();
    if (!c) { toast("Select a work activity"); return; }
    const bad = c.calc.today > 0 && C().validStages(c.stages); if (bad) { toast(bad); return; }
    if (n(f.qty) > Math.max(0, c.appr - c.exec) + 1e-6) { toast("Quantity is more than the BOQ remaining (" + fmt(Math.max(0, c.appr - c.exec)) + ")"); return; }
    if (!f.date || f.date > today()) { toast("Choose a valid date (not in the future)"); return; }
    if (!f.foreman) f.foreman = "Office";
    const ex = PB_DU_ROWS.read(), hasEx = ex.materialIn.length || ex.materialOut.length || ex.labourEntries.length || ex.equipment.length;
    if (c.add <= 0 && c.calc.today <= 0 && !hasEx) { toast("Enter the quantity completed today"); return; }
    const short = PB_DU_ROWS.stockShort(ex.materialOut, selectedProject); if (short) { toast(short); return; }
    const dup = (c.calc.today > 0 || c.add > 0) && (db.progress || []).some((x) => x.source === "stage-update" && x.boqId === c.b.id && x.date === f.date && (n(x.stageToday) > 0 || n(x.todayQty) > 0));
    const corr = document.getElementById("duCorr")?.checked, why = document.getElementById("duCorrWhy")?.value.trim();
    if (dup && !(corr && why)) { toast("An update for this work and date already exists. Tick 'Authorized correction' and give a reason."); return; }
    if (c.exec + c.add > c.appr + 1e-6) { toast("This would exceed the approved BOQ quantity"); return; }
    const by = window.PB_CURRENT_USER_EMAIL || document.querySelector(".pb-account-email")?.textContent || "Office user";
    const prevQty = c.exec, next = prevQty + c.add, b = c.b;
    b.executedQty = next;
    db.stageProgress = db.stageProgress || {};
    const updated = {}; c.calc.rows.forEach((r) => { updated[r.name] = r.updated; });
    db.stageProgress[b.id] = { stages: updated, trade: c.key, overall: c.calc.overall, updatedAt: new Date().toISOString() };
    const rep = { id: id(), date: f.date, projectId: selectedProject, ...(f.building || b.building ? { building: f.building || b.building } : {}), floor: f.floor, room: f.room,
      title: f.description || b.description, description: f.description, percent: next && c.appr ? Math.min(100, (next / c.appr) * 100) : c.calc.overall, foreman: f.foreman, team: f.team,
      boqId: b.id, boqCode: b.boqId, todayQty: c.add, previousQty: prevQty, totalCompleted: next, remainingQty: Math.max(0, c.appr - next), unit: b.unit, rate: n(b.rate),
      location: [f.building || b.building, f.floor, f.room].filter(Boolean).join(" / "), labourWorkers: f.labourWorkers, labourEntries: ex.labourEntries, materialIn: ex.materialIn, materialOut: ex.materialOut, ...(ex.equipment.length ? { equipment: ex.equipment } : {}),
      ...(f.weather ? { weather: f.weather } : {}), ...(f.shift ? { shift: f.shift } : {}), ...(n(f.workHours) > 0 ? { workHours: n(f.workHours) } : {}),
      photoData: photos.slice(), photos: photos.length, problems: [f.problems, f.delay && "Delay: " + f.delay].filter(Boolean).join(" · "), note: [f.materialNote && "Material: " + f.materialNote, f.manpowerNote && "Manpower: " + f.manpowerNote].filter(Boolean).join(" · "),
      source: "stage-update", stageTrade: c.key, stageRows: c.calc.rows, stageOverall: c.calc.overall, stageToday: c.calc.today, ...(dup ? { correction: true, correctionReason: why } : {}),
      submittedBy: by, submittedAt: new Date().toISOString(), approvalStatus: "Submitted" };
    db.progress.push(rep);
    PB_DU_ROWS.post(rep, ex);
    if (state.draftId) { const d = (db.progressDrafts || []).find((x) => x.id === state.draftId); if (d) { d.status = "Submitted"; d.submittedReportId = rep.id; } }
    try { projectHistoryAdd(selectedProject, dup ? "Daily progress corrected" : "Daily progress update", `${f.date} · ${b.boqId} · +${fmt(c.add)} ${b.unit || ""} · ${c.calc.overall.toFixed(1)}%${dup ? " · " + why : ""}`); } catch (e) {}
    save(); closeModal(); render(); toast("Progress update submitted — BOQ and dashboard updated");
  }
  function history() {
    const pid = selectedProject;
    const ups = (db.progress || []).filter((x) => x.projectId === pid && x.source === "stage-update").sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const drafts = (db.progressDrafts || []).filter((d) => d.projectId === pid && d.status === "Draft");
    const bName = (bid) => { const b = (db.boq || []).find((x) => x.id === bid); return b ? `${b.boqId || ""} — ${b.description || ""}` : "—"; };
    openModal("Previous Progress Updates", `${drafts.length ? `<h4 style="margin:0 0 6px">Drafts (${drafts.length})</h4><table class="du-tbl"><thead><tr><th>Date</th><th>Work</th><th>Saved</th><th></th></tr></thead><tbody>${drafts.map((d) => `<tr><td>${esc(d.date)}</td><td>${esc(bName(d.boqId))}</td><td>${esc(String(d.savedAt).slice(0, 16).replace("T", " "))}</td><td><button class="btn small" onclick="PB_DAILY_UPDATE.open('${d.id}')">Continue</button></td></tr>`).join("")}</tbody></table><br>` : ""}
<table class="du-tbl"><thead><tr><th>Date</th><th>Work</th><th>Location</th><th>Today %</th><th>Overall %</th><th>Qty added</th><th>By</th><th></th></tr></thead><tbody>${ups.map((x) => `<tr><td>${esc(x.date)}${x.correction ? ' <span class="pill amber" title="' + esc(x.correctionReason || "") + '">Correction</span>' : ""}</td><td>${esc(bName(x.boqId))}</td><td>${esc(x.location || "—")}</td><td>${n(x.stageToday).toFixed(1)}</td><td>${n(x.stageOverall).toFixed(1)}</td><td>${fmt(x.todayQty)} ${esc(x.unit || "")}</td><td>${esc(x.foreman || "")}</td><td><button class="btn small" onclick="viewProgressDetail('${x.id}')">View</button></td></tr>`).join("") || '<tr><td colspan="8" class="empty">No stage updates yet.</td></tr>'}</tbody></table>`, () => true);
    document.getElementById("modalSave").style.display = "none"; wide();
  }
  function stages() {
    const t = templates(); let cur = Object.keys(t)[0];
    const draw = () => {
      const rows = t[cur] || [], tot = C().weightTotal(rows);
      document.getElementById("modalBody").innerHTML = `<div class="du-grid" style="margin-bottom:8px"><div><label>Work activity</label><select id="stKey" class="select">${Object.keys(t).map((k) => `<option ${k === cur ? "selected" : ""}>${esc(k)}</option>`).join("")}</select></div><div><label>New activity name</label><input id="stNew" placeholder="e.g. Waterproofing"></div><div style="align-self:end"><button class="btn small" id="stAdd" type="button">+ Add activity</button></div></div>
<table class="du-tbl"><thead><tr><th>Stage</th><th>Weight %</th><th></th></tr></thead><tbody>${rows.map((r, i) => `<tr><td><input data-n="${i}" value="${esc(r.name)}" style="width:100%"></td><td><input data-w="${i}" type="number" min="0" max="100" value="${n(r.weight)}"></td><td><button class="btn small" data-x="${i}" type="button">Remove</button></td></tr>`).join("")}</tbody></table>
<button class="btn small" id="stRow" type="button" style="margin-top:6px">+ Add stage</button><div class="${Math.abs(tot - 100) > 0.001 ? "du-warn" : "muted"}" style="margin-top:8px">Total weight: <b>${tot}%</b> (must be 100%). Overall completion = Σ(stage weight × stage %).</div><div class="muted" style="font-size:11px;margin-top:6px">BOQ items use the list whose name matches their Trade/Category, otherwise one found in the description, otherwise General.</div>`;
      const sync = () => { document.querySelectorAll("[data-n]").forEach((i) => { rows[i.dataset.n].name = i.value; }); document.querySelectorAll("[data-w]").forEach((i) => { rows[i.dataset.w].weight = n(i.value); }); };
      document.getElementById("stKey").onchange = (e) => { sync(); cur = e.target.value; draw(); };
      document.getElementById("stRow").onclick = () => { sync(); rows.push({ name: "", weight: 0 }); t[cur] = rows; draw(); };
      document.getElementById("stAdd").onclick = () => { sync(); const k = document.getElementById("stNew").value.trim(); if (!k || t[k]) { toast("Enter a new, unique activity name"); return; } t[k] = [{ name: "Execution", weight: 100 }]; cur = k; draw(); };
      document.querySelectorAll("[data-x]").forEach((b) => b.onclick = () => { sync(); rows.splice(Number(b.dataset.x), 1); draw(); });
      document.querySelectorAll("[data-w]").forEach((i) => i.oninput = () => { sync(); });
    };
    const snapshot = JSON.stringify(t);
    openModal("Work Stages & Weights", "", () => {
      document.querySelectorAll("[data-n]").forEach((i) => { t[cur][i.dataset.n].name = i.value.trim(); });
      document.querySelectorAll("[data-w]").forEach((i) => { t[cur][i.dataset.w].weight = n(i.value); });
      for (const [k, rows] of Object.entries(t)) { const bad = C().validStages(rows); if (bad) { toast(`${k}: ${bad}`); return false; } }
      save(); toast("Work stages saved"); setTimeout(() => { if (page === "progress") render(); }, 0); return true;
    });
    const cancel = document.querySelector("#modal .modalfoot .btn:not(#modalSave)");
    if (cancel) cancel.addEventListener("click", () => { db.stageTemplates = JSON.parse(snapshot); }, { once: true });
    draw();
  }
  window.PB_DAILY_UPDATE = { open, history, stages, saveDraft, submit, rmPhoto: (i) => { photos.splice(i, 1); drawPhotos(); drawSum(); } };
  if (typeof page !== "undefined" && page === "progress") try { render(); } catch (e) {}
})();
