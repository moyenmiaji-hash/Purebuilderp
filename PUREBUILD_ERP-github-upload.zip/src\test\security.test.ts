import { describe, expect, it } from "vitest";
import { isStrongPassword, isUuid } from "../lib/security";

describe("security input validation", () => {
  it("requires long passwords with mixed character classes", () => {
    expect(isStrongPassword("Short1!")).toBe(false);
    expect(isStrongPassword("onlylowercasepassword")).toBe(false);
    expect(isStrongPassword("NoNumberOrSymbol")).toBe(false);
    expect(isStrongPassword("StrongPassword12!")).toBe(true);
  });

  it("accepts only canonical UUIDs", () => {
    expect(isUuid("c0a80101-0000-4000-8000-000000000001")).toBe(true);
    expect(isUuid("c0a80101-0000-0000-0000-000000000001")).toBe(false);
    expect(isUuid("not-a-uuid")).toBe(false);
  });
});
