ALTER TABLE public.foreman_tasks ADD COLUMN IF NOT EXISTS assigned_team text;
ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS workers integer;
ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS work_hours numeric;

CREATE OR REPLACE FUNCTION public.pb_task_extras_on_create() RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public' AS $$
BEGIN RETURN NEW; END $$;
DROP FUNCTION public.pb_task_extras_on_create();

CREATE OR REPLACE FUNCTION public.set_foreman_task_team(p_task uuid, p_team text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE t public.foreman_tasks;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can change tasks'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = p_task FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Task not found'; END IF;
  IF coalesce(t.assigned_team,'') IS NOT DISTINCT FROM coalesce(trim(p_team),'') THEN RETURN jsonb_build_object('saved', false); END IF;
  UPDATE public.foreman_tasks SET assigned_team = nullif(trim(p_team),''), updated_at = now() WHERE id = p_task;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, actor)
    VALUES (p_task, 'edited', jsonb_build_object('assigned_team', t.assigned_team), jsonb_build_object('assigned_team', nullif(trim(p_team),'')), auth.uid());
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE ALL ON FUNCTION public.set_foreman_task_team(uuid, text) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_foreman_task_team(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.set_task_update_labour(p_update uuid, p_workers integer, p_hours numeric)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE u public.foreman_task_updates;
BEGIN
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.submitted_by <> auth.uid() THEN RAISE EXCEPTION 'This update is not yours'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF coalesce(p_workers,0) < 0 OR coalesce(p_hours,0) < 0 OR coalesce(p_hours,0) > 24 THEN RAISE EXCEPTION 'Workers or hours are not valid'; END IF;
  UPDATE public.foreman_task_updates SET workers = p_workers, work_hours = p_hours WHERE id = p_update;
  RETURN jsonb_build_object('saved', true);
END $$;
REVOKE ALL ON FUNCTION public.set_task_update_labour(uuid, integer, numeric) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.set_task_update_labour(uuid, integer, numeric) TO authenticated;