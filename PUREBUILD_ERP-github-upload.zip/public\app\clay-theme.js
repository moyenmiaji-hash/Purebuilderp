/* Clay theme: display-only colour/shadow/radius layer for light theme. Never changes sizes, layout, IDs or logic. */
(function(){
  var S='html body.light-theme:not(.cx1):not(.cx2):not(.cx3):not(.cx4)',
  css=`${S}{--bg:#F1F0F8;--panel:#F7F6FC;--ink:#29283A;--muted:#858398;--line:#E7E4F0;--heading:#29283A;--primary:#8875DC;
--clay-hi:-6px -6px 14px rgba(255,255,255,.9);--clay-lo:6px 8px 18px rgba(118,106,170,.16);
--shadow:var(--clay-lo),var(--clay-hi);background:#F1F0F8!important;color:#29283A}
${S} .app,${S} .main,${S} .content{background:#F1F0F8!important}
${S} .panel,${S} .card,${S} .dashboard-panel,${S} .small-card,${S} .hr-kpi,${S} .quote-panel,${S} .quote-kpi,${S} .metricrow>*{background:#F7F6FC!important;border-color:#E7E4F0!important;border-radius:16px!important;box-shadow:var(--clay-lo),var(--clay-hi)!important;transition:transform .18s,box-shadow .18s}
${S} .card:hover,${S} .small-card:hover,${S} .hr-kpi:hover,${S} .quote-kpi:hover{transform:translateY(-2px);box-shadow:8px 12px 22px rgba(118,106,170,.2),var(--clay-hi)!important}
${S} .sidebar{background:#F7F6FC!important;border-color:#E7E4F0!important;box-shadow:6px 0 22px rgba(118,106,170,.12)!important}
${S} .sidebar,${S} .sidebar .nav button,${S} .sidebar .nav a,${S} .sidebar .nav button *,${S} .sidebar .nav a *,${S} .sidebar .brand *,${S} .sidebar h1,${S} .sidebar strong{color:#29283A!important}
${S} .sidebar small,${S} .sidebar .muted{color:#858398!important}
${S} .sidebar .sidebar-visual *{color:#fff!important}
${S} .sidebar .brand>:first-child,${S} .sidebar .brand>:first-child *{color:#fff!important}
${S} .sidebar button:not(.nav button){color:#29283A!important}
${S} .sidebar .nav button,${S} .sidebar .nav a{border-radius:12px!important;transition:background .15s,box-shadow .15s}
${S} .sidebar .nav button:hover,${S} .sidebar .nav a:hover{background:#EEEBFA!important}
${S} .sidebar .nav .active{background:linear-gradient(135deg,#8875DC,#A99AEF)!important;color:#fff!important;box-shadow:4px 6px 14px rgba(136,117,220,.35)!important}
${S} .sidebar .nav .active *{color:#fff!important}
${S} .topbar{background:rgba(247,246,252,.92)!important;border-color:#E7E4F0!important;box-shadow:0 4px 16px rgba(118,106,170,.08)!important}
${S} .btn{border-radius:12px!important;border-color:#E7E4F0!important;background:#F7F6FC;color:#29283A;box-shadow:3px 4px 10px rgba(118,106,170,.16),-3px -3px 8px rgba(255,255,255,.9)!important;transition:transform .12s,box-shadow .12s}
${S} .btn:hover{transform:translateY(-1px)}
${S} .btn:active{transform:translateY(1px);box-shadow:inset 2px 2px 6px rgba(118,106,170,.2)!important}
${S} .btn:disabled{opacity:.55;transform:none}
${S} .btn.primary{background:linear-gradient(135deg,#8875DC,#A99AEF)!important;border-color:#8875DC!important;color:#fff!important}
${S} .btn.success,${S} .btn.green{background:#38B98A!important;border-color:#38B98A!important;color:#fff!important}
${S} .btn.danger,${S} .btn.red{background:#E87582!important;border-color:#E87582!important;color:#fff!important}
${S} input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]),${S} select,${S} textarea{background:#F1F0F8!important;border-color:#E7E4F0!important;border-radius:10px!important;color:#29283A!important;box-shadow:inset 2px 2px 5px rgba(118,106,170,.14),inset -2px -2px 5px rgba(255,255,255,.85)!important}
${S} input:focus,${S} select:focus,${S} textarea:focus{outline:none!important;border-color:#A99AEF!important;box-shadow:inset 2px 2px 5px rgba(118,106,170,.14),0 0 0 3px rgba(136,117,220,.2)!important}
${S} .tablewrap{border-radius:14px!important;border-color:#E7E4F0!important;background:#F7F6FC!important}
${S} table th{background:#EEEBFA!important;color:#4A4470!important;border-color:#E7E4F0!important}
${S} table td{border-color:#E7E4F0!important}
${S} table tbody tr:hover td{background:#F1EEFC!important}
${S} .pill{border-radius:999px!important}
${S} .pill.green{background:#E3F6EE!important;color:#23875F!important}
${S} .pill.amber{background:#FDF2DF!important;color:#A86F14!important}
${S} .pill.red{background:#FCE6E9!important;color:#B84552!important}
${S} .notice{border-radius:12px!important;border-color:#E7E4F0!important;background:#F3F0FD!important}
${S} .modalbox{background:#F7F6FC!important;border-radius:20px!important;border-color:#E7E4F0!important;box-shadow:12px 18px 40px rgba(80,70,140,.25),var(--clay-hi)!important}
${S} .modalhead,${S} .modalfoot{border-color:#E7E4F0!important}
${S} .muted{color:#858398}
@media print{${S}{background:#fff!important}${S} *{box-shadow:none!important}}`;
  var st=document.createElement('style');st.id='clay-theme';st.textContent=css;
  (document.head||document.documentElement).appendChild(st);
})();
