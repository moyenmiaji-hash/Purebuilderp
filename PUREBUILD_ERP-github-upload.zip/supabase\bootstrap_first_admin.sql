do $$
declare
  admin_user_id uuid;
begin
  if (select count(*) from auth.users) <> 1 then
    raise exception 'Create exactly one Supabase Auth user first. This setup only promotes the sole user in a new project.';
  end if;

  if exists (select 1 from public.user_roles where role = 'admin') then
    raise exception 'An Admin already exists. This setup can only be used before the first Admin is created.';
  end if;

  select id into strict admin_user_id from auth.users;

  update public.profiles
  set role = 'admin',
      status = 'active',
      permissions = '{"invite_staff":true,"manage_projects":true,"manage_boq":true,"manage_materials":true,"review_progress":true,"manage_staff":true,"submit_progress":true,"submit_attendance":true,"submit_materials":true,"submit_equipment":true,"submit_diary":true}'::jsonb
  where id = admin_user_id;

  insert into public.user_roles(user_id, role)
  values (admin_user_id, 'admin')
  on conflict (user_id, role) do nothing;
end
$$;
