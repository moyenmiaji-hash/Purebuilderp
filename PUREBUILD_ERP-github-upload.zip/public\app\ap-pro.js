/* Accounts Payable – 10 sections. Reuses existing AP tabs/helpers; new data only in side lists
   db.apMatch (3-way match notes per bill) and db.apAdvances (vendor advance register). Never edits old records. */
(function () {
  if (typeof payables !== "function") return;
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (n) => (typeof money === "function" ? money(n) : "AED " + Number(n || 0).toFixed(2));
  const N = (v) => Number(v) || 0;
  const today = () => new Date().toISOString().slice(0, 10);
  const isAdmin = () => !window.PB_CLOUD_ROLE || window.PB_CLOUD_ROLE === "admin";
  const who = () => window.PB_CLOUD_NAME || (typeof salesUser === "function" ? salesUser() : "Office");
  const projName = (id) => (db.projects || []).find((p) => p.id === id)?.name || "—";
  const bills = () => (typeof pfilter === "function" ? pfilter(db.payables || []) : db.payables || []);
  const posted = () => bills().filter((p) => apIsPosted(p));
  const out = (p) => apOutstandingAmount(p);
  const dueIn = (p) => { if (!p.dueDate) return 0; const t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((new Date(p.dueDate + "T00:00:00") - t) / 86400000); };
  const txs = () => (typeof pfilter === "function" ? pfilter(db.transactions || []) : db.transactions || []);
  const pays = () => txs().filter((x) => (x.type === "Supplier Payment" && ["Paid", "Posted"].includes(x.status)) || (x.type === "Supplier Payment Reversal" && x.status === "Posted"));
  const credits = () => txs().filter((x) => ["Supplier Credit Note", "Supplier Credit Reversal"].includes(x.type) && x.status === "Posted");
  const advs = () => (db.apAdvances = Array.isArray(db.apAdvances) ? db.apAdvances : []);
  const matches = () => (db.apMatch = db.apMatch && typeof db.apMatch === "object" ? db.apMatch : {});
  const advLeft = (a) => N(a.amount) - (a.adjustments || []).reduce((s, x) => s + N(x.amount), 0) - N(a.refunded);
  const vendors = () => [...new Set([...(db.suppliers || []).map((s) => s.name), ...bills().map((p) => p.supplier)].filter(Boolean).map((s) => String(s).trim()))].sort();
  const F = () => (window.apF = window.apF || { vendor: "", from: "", to: "", q: "" });
  const inF = (r) => { const f = F(); const d = r.date || ""; return (!f.vendor || String(r.supplier || "").trim().toLowerCase() === f.vendor.toLowerCase()) && (!f.from || d >= f.from) && (!f.to || d <= f.to) && (!f.q || JSON.stringify(r).toLowerCase().includes(f.q.toLowerCase())); };

  const TABS = [["overview", "dashboard", "AP Dashboard"], ["suppliers", "usersRound", "Suppliers & Vendors"], ["bills", "receiptText", "Purchase Bills"], ["verify", "shieldCheck", "Bill Verification"], ["approval", "circleCheck", "Bill Approval"], ["payments", "creditCard", "Payments"], ["advances", "wallet", "Advance & Adjustments"], ["notes", "fileText", "Debit / Credit Notes"], ["ledger", "bookOpen", "Vendor Ledger"], ["reports", "chartColumn", "AP Reports"]];
  const NEW = ["verify", "advances", "notes", "ledger", "reports"];
  const ic = (n) => { try { return icon(n); } catch (e) { return ""; } };

  const css = `.ap-tabs.appro{display:flex;flex-wrap:wrap;gap:6px}.ap-tabs.appro .ap-tab{padding:7px 10px;font-size:12px}
.appx-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:end;margin:0 0 10px}.appx-bar label{display:flex;flex-direction:column;font-size:11px;color:var(--muted,#64748b);gap:3px}.appx-bar input,.appx-bar select{padding:6px 8px;border:1px solid var(--line,#dbe3ee);border-radius:8px;font-size:12px;background:var(--panel,#fff);color:inherit}
.appx-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-bottom:10px}.appx-kpi{border:1px solid var(--line,#dbe3ee);border-radius:12px;padding:10px 12px;background:var(--panel,#fff)}.appx-kpi small{display:block;font-size:11px;color:var(--muted,#64748b)}.appx-kpi b{font-size:16px}
.appx-table{width:100%;border-collapse:collapse;font-size:12px}.appx-table th{text-align:left;background:var(--soft,#f1f5f9);padding:8px;font-size:11px;white-space:nowrap}.appx-table td{padding:7px 8px;border-bottom:1px solid var(--line,#e5eaf1);vertical-align:top}.appx-table td.n,.appx-table th.n{text-align:right;white-space:nowrap}
.appx-wrap{overflow:auto;max-height:62vh;border:1px solid var(--line,#e5eaf1);border-radius:10px}.appx-warn{color:#b45309;font-weight:600}.appx-ok{color:#047857;font-weight:600}.appx-bad{color:#b91c1c;font-weight:600}
.appx-rep{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px;margin-bottom:10px}.appx-rep button{text-align:left;padding:10px;border:1px solid var(--line,#dbe3ee);border-radius:10px;background:var(--panel,#fff);cursor:pointer;font-size:12px;color:inherit}.appx-rep button.on{border-color:var(--primary,#2563eb);box-shadow:0 0 0 2px color-mix(in oklab,var(--primary,#2563eb) 25%,transparent)}
.appx-head{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px}.appx-head h3{margin:0;font-size:15px}.appx-head p{margin:2px 0 0;font-size:11px;color:var(--muted,#64748b)}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  function filterBar(extra = "") {
    const f = F();
    return `<div class="appx-bar"><label>Vendor<select onchange="apF.vendor=this.value;render()"><option value="">All vendors</option>${vendors().map((v) => `<option ${f.vendor === v ? "selected" : ""}>${E(v)}</option>`).join("")}</select></label><label>From<input type="date" value="${E(f.from)}" onchange="apF.from=this.value;render()"></label><label>To<input type="date" value="${E(f.to)}" onchange="apF.to=this.value;render()"></label><label>Search<input value="${E(f.q)}" placeholder="Bill no, ref…" onchange="apF.q=this.value;render()"></label>${extra}</div>`;
  }
  const table = (cols, rows, id) => `<div class="appx-wrap"><table class="appx-table" ${id ? `id="${id}"` : ""}><thead><tr>${cols.map((c) => `<th class="${c.n ? "n" : ""}">${E(c.t)}</th>`).join("")}</tr></thead><tbody>${rows.length ? rows.join("") : `<tr><td colspan="${cols.length}" style="text-align:center;padding:18px;color:#64748b">No records</td></tr>`}</tbody></table></div>`;

  /* ---------- Bill Verification (3-way match) ---------- */
  function grnQty(no) {
    if (!no) return null; const v = (db.stockVouchers || []).find((x) => String(x.no || x.voucherNo || "").toLowerCase() === String(no).toLowerCase());
    if (!v) return null; const lines = v.lines || v.items || []; return lines.reduce((s, l) => s + N(l.qty || l.quantity), 0) || N(v.qty);
  }
  function verifyCheck(p) {
    const m = matches()[p.id] || {}; const recv = m.grnNo && grnQty(m.grnNo) != null ? grnQty(m.grnNo) : m.recvQty;
    const iq = N(m.invQty), oq = N(m.poQty), rq = N(recv), pr = N(m.poRate), ir = N(m.invRate);
    const issues = [];
    if (!m.poNo && !m.grnNo) return { m, recv, issues: ["Not checked yet"], state: "none" };
    if (oq && iq > oq) issues.push(`Invoiced qty ${iq} > ordered ${oq}`);
    if (rq && iq > rq) issues.push(`Invoiced qty ${iq} > received ${rq}`);
    if (pr && ir && Math.abs(ir - pr) > 0.0001) issues.push(`Rate ${ir} vs PO ${pr}`);
    if (iq && ir) { const vat = N(db.apSettings?.vatPct); const g = iq * ir; if (Math.abs(g - N(p.amount)) > 1 && Math.abs(g * (1 + vat / 100) - N(p.amount)) > 1) issues.push(`Qty×Rate ${M(g)} (+VAT ${vat}% = ${M(g * (1 + vat / 100))}) ≠ bill ${M(p.amount)}`); }
    return { m, recv, issues, state: issues.length ? (m.explanation ? "explained" : "mismatch") : "ok" };
  }
  window.apVerifyEdit = function (id) {
    const p = (db.payables || []).find((x) => x.id === id); if (!p) return; const m = matches()[id] || {};
    const f = (k, l, t = "text") => `<div class="field"><label>${l}</label><input id="apm_${k}" type="${t}" value="${E(m[k] ?? "")}"></div>`;
    openModal(`Verify bill ${E(p.invoiceNo || "")}`, `<p style="font-size:12px;margin:0 0 8px">${E(p.supplier)} · ${M(p.amount)}</p><div class="formgrid">${f("poNo", "PO Number")}${f("poQty", "Ordered Qty", "number")}${f("poRate", "PO Rate", "number")}${f("grnNo", "GRN Number (auto-reads Stock In)")}${f("recvQty", "Received Qty (if no GRN)", "number")}${f("invQty", "Invoiced Qty", "number")}${f("invRate", "Invoice Rate", "number")}<div class="field full"><label>Explanation for differences</label><textarea id="apm_explanation">${E(m.explanation || "")}</textarea></div></div><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="apVerifySave('${E(id)}')">Save check</button></div>`);
  };
  window.apVerifySave = function (id) {
    const g = (k) => document.getElementById("apm_" + k)?.value.trim() || "";
    const rec = { poNo: g("poNo"), poQty: g("poQty"), poRate: g("poRate"), grnNo: g("grnNo"), recvQty: g("recvQty"), invQty: g("invQty"), invRate: g("invRate"), explanation: g("explanation"), checkedBy: who(), checkedAt: new Date().toISOString() };
    matches()[id] = rec; const p = db.payables.find((x) => x.id === id); try { apLog(p, "Verification saved", rec.explanation || ""); } catch (e) {}
    save(); closeModal(); render(); toast("Verification saved");
  };
  function verifyBody() {
    const list = bills().filter((p) => !["Rejected"].includes(p.apStatus || "")).filter(inF).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const rows = list.map((p) => { const c = verifyCheck(p); const m = c.m; const s = c.state === "ok" ? '<span class="appx-ok">Matched</span>' : c.state === "none" ? '<span style="color:#64748b">Not checked</span>' : c.state === "explained" ? '<span class="appx-warn">Explained</span>' : '<span class="appx-bad">Mismatch</span>';
      return `<tr><td>${E(p.invoiceNo || "—")}<br><small>${E(p.date || "")}</small></td><td>${E(p.supplier)}</td><td>${E(m.poNo || "—")}</td><td>${E(m.grnNo || "—")}</td><td class="n">${E(m.poQty || "—")}</td><td class="n">${c.recv ?? "—"}</td><td class="n">${E(m.invQty || "—")}</td><td class="n">${E(m.poRate || "—")} / ${E(m.invRate || "—")}</td><td class="n">${M(p.amount)}</td><td>${s}${c.state !== "none" && c.issues.length ? `<br><small>${c.issues.map(E).join("<br>")}</small>` : ""}</td><td><button class="btn small" onclick="apVerifyEdit('${E(p.id)}')">Check</button></td></tr>`; });
    const all = list.map(verifyCheck);
    return `<div class="appx-head"><div><h3>Bill Verification — 3-way match</h3><p>Compare Purchase Order, Goods Receipt (Stock In) and supplier invoice. Mismatched bills are flagged in Approval and are never approved automatically.</p></div></div>
    <div class="appx-kpis"><div class="appx-kpi"><small>Bills</small><b>${all.length}</b></div><div class="appx-kpi"><small>Matched</small><b class="appx-ok">${all.filter((x) => x.state === "ok").length}</b></div><div class="appx-kpi"><small>Mismatch</small><b class="appx-bad">${all.filter((x) => x.state === "mismatch").length}</b></div><div class="appx-kpi"><small>Explained</small><b class="appx-warn">${all.filter((x) => x.state === "explained").length}</b></div><div class="appx-kpi"><small>Not checked</small><b>${all.filter((x) => x.state === "none").length}</b></div></div>
    ${filterBar()}${table([{ t: "Bill" }, { t: "Vendor" }, { t: "PO" }, { t: "GRN" }, { t: "Ordered", n: 1 }, { t: "Received", n: 1 }, { t: "Invoiced", n: 1 }, { t: "Rate PO / Inv", n: 1 }, { t: "Amount", n: 1 }, { t: "Result" }, { t: "" }], rows)}`;
  }

  /* ---------- Advances ---------- */
  window.apAddAdvance = function () {
    const n = advs().length + 1; const pid = selectedProject || "";
    openModal("New Vendor / Contractor Advance", `<div class="formgrid"><div class="field"><label>Advance No</label><input id="ava_no" value="ADV-${new Date().getFullYear()}-${String(n).padStart(4, "0")}"></div><div class="field"><label>Date</label><input id="ava_date" type="date" value="${today()}"></div><div class="field"><label>Type</label><select id="ava_type"><option>Vendor Advance</option><option>Contractor Advance</option></select></div><div class="field"><label>Vendor *</label><select id="ava_sup"><option value="">Select…</option>${vendors().map((v) => `<option>${E(v)}</option>`).join("")}</select></div><div class="field"><label>Project</label><select id="ava_pid"><option value="">—</option>${(db.projects || []).map((p) => `<option value="${E(p.id)}" ${p.id === pid ? "selected" : ""}>${E(p.name)}</option>`).join("")}</select></div><div class="field"><label>Amount (AED) *</label><input id="ava_amt" type="number" min="0" step="0.01"></div><div class="field"><label>Paid by</label><select id="ava_m"><option>Bank Transfer</option><option>Cash</option><option>Cheque</option><option>Online Transfer</option></select></div><div class="field"><label>Reference</label><input id="ava_ref"></div><div class="field full"><label>Remarks</label><input id="ava_rem"></div></div><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="apSaveAdvance()">Save advance</button></div>`);
  };
  window.apSaveAdvance = function () {
    const g = (k) => document.getElementById("ava_" + k)?.value.trim() || ""; const amt = N(g("amt"));
    if (!g("sup") || amt <= 0) { toast("Vendor and amount are required"); return; }
    if (advs().some((a) => a.no.toLowerCase() === g("no").toLowerCase())) { toast("This advance number already exists"); return; }
    advs().push({ id: id(), no: g("no"), date: g("date"), type: g("type"), supplier: g("sup"), projectId: g("pid"), amount: amt, method: g("m"), reference: g("ref"), remarks: g("rem"), adjustments: [], refunded: 0, createdBy: who(), createdAt: new Date().toISOString() });
    save(); closeModal(); render(); toast("Advance saved");
  };
  window.apAdjustAdvance = function (aid) {
    const a = advs().find((x) => x.id === aid); if (!a) return; const left = advLeft(a);
    const open = (db.payables || []).filter((p) => apIsPosted(p) && out(p) > 0 && String(p.supplier || "").trim().toLowerCase() === String(a.supplier).trim().toLowerCase());
    if (!open.length) { toast("No approved unpaid bill for this vendor"); return; }
    openModal(`Adjust ${E(a.no)}`, `<p style="font-size:12px">Remaining advance: <b>${M(left)}</b></p><div class="formgrid"><div class="field full"><label>Approved bill</label><select id="adj_bill">${open.map((p) => `<option value="${E(p.id)}">${E(p.invoiceNo || "—")} · due ${M(out(p))}</option>`).join("")}</select></div><div class="field"><label>Amount</label><input id="adj_amt" type="number" step="0.01" value="${Math.min(left, out(open[0])).toFixed(2)}"></div><div class="field"><label>Date</label><input id="adj_date" type="date" value="${today()}"></div></div><p style="font-size:11px;color:#64748b">The adjustment is posted to the bill as a supplier credit (reference = advance no), so the bill balance and Vendor Ledger update.</p><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" id="adj_go" onclick="apDoAdjust('${E(aid)}')">Adjust</button></div>`);
  };
  window.apDoAdjust = function (aid) {
    const a = advs().find((x) => x.id === aid); const bid = document.getElementById("adj_bill").value; const p = db.payables.find((x) => x.id === bid);
    const amt = N(document.getElementById("adj_amt").value); const date = document.getElementById("adj_date").value || today();
    if (!a || !p || amt <= 0) { toast("Enter a valid amount"); return; }
    if (amt > advLeft(a) + 0.005) { toast("More than remaining advance"); return; }
    if (amt > out(p) + 0.005) { toast("More than bill balance"); return; }
    if ((a.adjustments || []).some((x) => x.payableId === bid && x.date === date && Math.abs(x.amount - amt) < 0.005)) { toast("Same adjustment already recorded"); return; }
    document.getElementById("adj_go").disabled = true;
    const tid = id(); const reference = `${a.no}`;
    db.transactions.push({ id: tid, date, projectId: p.projectId, type: "Supplier Credit Note", amount: amt, category: "Vendor Advance", description: `Advance adjustment · ${a.no}`, supplier: p.supplier, status: "Posted", reference, invoiceNo: p.invoiceNo || "", payableId: p.id, postingKey: `ap-adv:${a.id}:${tid}`, advanceId: a.id });
    a.adjustments = a.adjustments || []; a.adjustments.push({ id: tid, payableId: p.id, invoiceNo: p.invoiceNo || "", amount: amt, date, by: who() });
    try { apLog(p, "Advance adjusted", `${a.no} · ${amt}`); } catch (e) {}
    save(); closeModal(); render(); toast("Advance adjusted against bill");
  };
  window.apRefundAdvance = function (aid) {
    const a = advs().find((x) => x.id === aid); if (!a) return; const v = N(prompt(`Refund received from vendor (max ${advLeft(a).toFixed(2)})`, "")); if (v <= 0) return;
    if (v > advLeft(a) + 0.005) { toast("More than remaining advance"); return; }
    a.refunded = N(a.refunded) + v; a.refunds = a.refunds || []; a.refunds.push({ amount: v, date: today(), by: who() }); save(); render(); toast("Refund recorded");
  };
  function advancesBody() {
    const list = advs().filter((a) => !selectedProject || a.projectId === selectedProject).filter(inF);
    const rows = list.map((a) => `<tr><td>${E(a.no)}<br><small>${E(a.date)}</small></td><td>${E(a.type)}</td><td>${E(a.supplier)}</td><td>${E(projName(a.projectId))}</td><td class="n">${M(a.amount)}</td><td class="n">${M((a.adjustments || []).reduce((s, x) => s + N(x.amount), 0))}</td><td class="n">${M(a.refunded)}</td><td class="n"><b>${M(advLeft(a))}</b></td><td>${(a.adjustments || []).map((x) => `<small>${E(x.date)} · ${E(x.invoiceNo)} · ${M(x.amount)}</small>`).join("<br>") || "—"}</td><td style="white-space:nowrap"><button class="btn small" onclick="apAdjustAdvance('${E(a.id)}')">Adjust</button> <button class="btn small" onclick="apRefundAdvance('${E(a.id)}')">Refund</button></td></tr>`);
    const tot = list.reduce((s, a) => s + N(a.amount), 0), left = list.reduce((s, a) => s + advLeft(a), 0);
    return `<div class="appx-head"><div><h3>Advance & Adjustments</h3><p>Vendor / contractor advances, adjustments against approved bills and refunds. Each adjustment is recorded once.</p></div><button class="btn primary" onclick="apAddAdvance()">+ New Advance</button></div><div class="appx-kpis"><div class="appx-kpi"><small>Advances given</small><b>${M(tot)}</b></div><div class="appx-kpi"><small>Adjusted / refunded</small><b>${M(tot - left)}</b></div><div class="appx-kpi"><small>Remaining advance</small><b>${M(left)}</b></div></div>${filterBar()}${table([{ t: "Advance" }, { t: "Type" }, { t: "Vendor" }, { t: "Project" }, { t: "Amount", n: 1 }, { t: "Adjusted", n: 1 }, { t: "Refunded", n: 1 }, { t: "Remaining", n: 1 }, { t: "History" }, { t: "" }], rows)}`;
  }

  /* ---------- Debit / Credit Notes ---------- */
  window.apPickCredit = function () {
    const open = posted().filter((p) => out(p) > 0);
    if (!open.length) { toast("No approved unpaid bill"); return; }
    openModal("New supplier Debit Note", `<p style="font-size:12px">Choose the original bill. A debit note reduces what you owe the vendor (return, price/quantity correction, discount).</p><select id="apcn_bill" class="select" style="width:100%">${open.map((p) => `<option value="${E(p.id)}">${E(p.invoiceNo || "—")} · ${E(p.supplier)} · due ${M(out(p))}</option>`).join("")}</select><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn primary" onclick="const v=document.getElementById('apcn_bill').value;closeModal();recordSupplierCredit(v)">Continue</button></div>`);
  };
  function notesBody() {
    const list = credits().filter(inF).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const rows = list.map((x) => `<tr><td>${E(x.reference || x.id)}</td><td>${E(x.date)}</td><td>${x.type === "Supplier Credit Reversal" ? "Reversal" : x.advanceId ? "Advance adjustment" : "Debit Note"}</td><td>${E(x.supplier)}</td><td>${E(x.invoiceNo || "—")}</td><td>${E(projName(x.projectId))}</td><td>${E(x.description || "")}</td><td class="n">${x.type === "Supplier Credit Reversal" ? "-" : ""}${M(x.amount)}</td><td>${E(x.status)}</td></tr>`);
    const net = list.reduce((s, x) => s + (x.type === "Supplier Credit Reversal" ? -1 : 1) * N(x.amount), 0);
    return `<div class="appx-head"><div><h3>Debit / Credit Notes</h3><p>Supplier notes linked to their original bill. Posted notes reduce the bill balance and post to the Ledger; corrections use a reversal, never a delete.</p></div><button class="btn primary" onclick="apPickCredit()">+ New Debit Note</button></div><div class="appx-kpis"><div class="appx-kpi"><small>Notes</small><b>${list.length}</b></div><div class="appx-kpi"><small>Net adjustment</small><b>${M(net)}</b></div></div>${filterBar()}${table([{ t: "Document" }, { t: "Date" }, { t: "Kind" }, { t: "Vendor" }, { t: "Original bill" }, { t: "Project" }, { t: "Reason" }, { t: "Amount", n: 1 }, { t: "Status" }], rows)}`;
  }

  /* ---------- Vendor Ledger ---------- */
  function ledgerRows(vendor) {
    const v = String(vendor || "").trim().toLowerCase(); const same = (s) => String(s || "").trim().toLowerCase() === v;
    const r = [];
    posted().filter((p) => same(p.supplier)).forEach((p) => r.push({ date: p.date, ref: p.invoiceNo || (p.openingBalance ? "Opening" : "—"), type: p.openingBalance ? "Opening Balance" : "Purchase Bill", desc: p.description || p.category || "", dr: 0, cr: N(p.amount), projectId: p.projectId }));
    pays().filter((x) => same(x.supplier)).forEach((x) => r.push({ date: x.date, ref: x.reference || x.invoiceNo || "", type: x.type === "Supplier Payment" ? "Payment" : "Payment Reversal", desc: x.description || "", dr: x.type === "Supplier Payment" ? N(x.amount) : 0, cr: x.type === "Supplier Payment" ? 0 : N(x.amount), projectId: x.projectId }));
    credits().filter((x) => same(x.supplier)).forEach((x) => r.push({ date: x.date, ref: x.reference || "", type: x.type === "Supplier Credit Note" ? (x.advanceId ? "Advance Adjustment" : "Debit Note") : "Note Reversal", desc: x.description || "", dr: x.type === "Supplier Credit Note" ? N(x.amount) : 0, cr: x.type === "Supplier Credit Note" ? 0 : N(x.amount), projectId: x.projectId }));
    const f = F(); let rows = r.filter((x) => (!f.q || JSON.stringify(x).toLowerCase().includes(f.q.toLowerCase()))).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let opening = 0; if (f.from) { rows.filter((x) => x.date < f.from).forEach((x) => (opening += x.cr - x.dr)); rows = rows.filter((x) => x.date >= f.from); }
    if (f.to) rows = rows.filter((x) => x.date <= f.to);
    let bal = opening; rows.forEach((x) => { bal += x.cr - x.dr; x.bal = bal; });
    return { rows, opening, closing: bal };
  }
  function ledgerBody() {
    const f = F(); const vs = vendors(); const vendor = f.vendor || vs[0] || "";
    if (!vendor) return `<p>No vendors yet.</p>`;
    const L = ledgerRows(vendor); const adv = advs().filter((a) => String(a.supplier).trim().toLowerCase() === vendor.toLowerCase()).reduce((s, a) => s + advLeft(a), 0);
    const rows = [`<tr><td colspan="4"><b>Opening balance</b></td><td class="n"></td><td class="n"></td><td class="n"><b>${M(L.opening)}</b></td></tr>`, ...L.rows.map((x) => `<tr><td>${E(x.date)}</td><td>${E(x.ref)}</td><td>${E(x.type)}</td><td>${E(x.desc)}<br><small>${E(projName(x.projectId))}</small></td><td class="n">${x.dr ? M(x.dr) : ""}</td><td class="n">${x.cr ? M(x.cr) : ""}</td><td class="n">${M(x.bal)}</td></tr>`), `<tr><td colspan="4"><b>Closing balance</b></td><td class="n"><b>${M(L.rows.reduce((s, x) => s + x.dr, 0))}</b></td><td class="n"><b>${M(L.rows.reduce((s, x) => s + x.cr, 0))}</b></td><td class="n"><b>${M(L.closing)}</b></td></tr>`];
    return `<div class="appx-head"><div><h3>Vendor Ledger — ${E(vendor)}</h3><p>Debit = payments / notes, Credit = bills. Balance is what you owe. Unadjusted advance: <b>${M(adv)}</b></p></div><div style="display:flex;gap:6px"><button class="btn" onclick="apExport('apLedgerT','Vendor-Ledger')">Excel</button><button class="btn" onclick="apPrint('apLedgerT','Vendor Ledger — ${E(vendor).replace(/'/g, "")}')">Print / PDF</button></div></div>${filterBar()}${table([{ t: "Date" }, { t: "Reference" }, { t: "Type" }, { t: "Description" }, { t: "Debit", n: 1 }, { t: "Credit", n: 1 }, { t: "Balance", n: 1 }], rows, "apLedgerT")}`;
  }

  /* ---------- Reports ---------- */
  const REPORTS = [["summary", "AP Summary"], ["outstanding", "Outstanding Payables"], ["ledger", "Vendor Ledger"], ["aging", "AP Aging"], ["due", "Due Payments"], ["overdue", "Overdue Invoices"], ["payhist", "Payment History"], ["advance", "Vendor Advances"], ["bills", "Purchase Bills"], ["project", "Project-wise Payables"], ["vendor", "Vendor-wise Outstanding"]];
  function report(k) {
    const P = posted().filter(inF); const bk = (p) => { const d = -dueIn(p); return d <= 30 ? 0 : d <= 60 ? 1 : d <= 90 ? 2 : 3; };
    const sumBy = (key) => { const g = {}; P.forEach((p) => { const kk = key(p); g[kk] = g[kk] || { amt: 0, paid: 0, out: 0, n: 0 }; g[kk].amt += N(p.amount); g[kk].paid += apPaidAmount(p); g[kk].out += out(p); g[kk].n++; }); return Object.entries(g).sort((a, b) => b[1].out - a[1].out); };
    const billRow = (p) => `<tr><td>${E(p.invoiceNo || "—")}</td><td>${E(p.date || "")}</td><td>${E(p.dueDate || "")}</td><td>${E(p.supplier)}</td><td>${E(projName(p.projectId))}</td><td class="n">${M(p.amount)}</td><td class="n">${M(apPaidAmount(p))}</td><td class="n">${M(out(p))}</td></tr>`;
    const billCols = [{ t: "Bill" }, { t: "Date" }, { t: "Due" }, { t: "Vendor" }, { t: "Project" }, { t: "Amount", n: 1 }, { t: "Paid", n: 1 }, { t: "Outstanding", n: 1 }];
    if (k === "summary") { const t = sumBy(() => "All")[0]?.[1] || { amt: 0, paid: 0, out: 0, n: 0 }; const od = P.filter((p) => out(p) > 0 && dueIn(p) < 0).reduce((s, p) => s + out(p), 0); return table([{ t: "Measure" }, { t: "Value", n: 1 }], [["Approved bills", t.n], ["Total billed", M(t.amt)], ["Total paid", M(t.paid)], ["Outstanding", M(t.out)], ["Overdue", M(od)], ["Pending approval", bills().filter((p) => ["Draft", "Submitted"].includes(p.apStatus || "")).length], ["Unadjusted advances", M(advs().reduce((s, a) => s + advLeft(a), 0))]].map(([a, b]) => `<tr><td>${a}</td><td class="n"><b>${b}</b></td></tr>`), "apRepT"); }
    if (k === "outstanding") return table(billCols, P.filter((p) => out(p) > 0).map(billRow), "apRepT");
    if (k === "aging") { const g = {}; P.filter((p) => out(p) > 0).forEach((p) => { const v = p.supplier || "—"; g[v] = g[v] || [0, 0, 0, 0]; g[v][bk(p)] += out(p); }); return table([{ t: "Vendor" }, { t: "0–30 Days", n: 1 }, { t: "31–60 Days", n: 1 }, { t: "61–90 Days", n: 1 }, { t: "Above 90", n: 1 }, { t: "Total", n: 1 }], Object.entries(g).map(([v, a]) => `<tr><td>${E(v)}</td>${a.map((x) => `<td class="n">${M(x)}</td>`).join("")}<td class="n"><b>${M(a.reduce((s, x) => s + x, 0))}</b></td></tr>`), "apRepT"); }
    if (k === "due") return table(billCols, P.filter((p) => out(p) > 0 && dueIn(p) >= 0).sort((a, b) => String(a.dueDate).localeCompare(String(b.dueDate))).map(billRow), "apRepT");
    if (k === "overdue") return table(billCols, P.filter((p) => out(p) > 0 && dueIn(p) < 0).map(billRow), "apRepT");
    if (k === "payhist") return table([{ t: "Date" }, { t: "Vendor" }, { t: "Bill" }, { t: "Method" }, { t: "Reference" }, { t: "Project" }, { t: "Amount", n: 1 }], pays().filter(inF).sort((a, b) => String(b.date).localeCompare(String(a.date))).map((x) => `<tr><td>${E(x.date)}</td><td>${E(x.supplier)}</td><td>${E(x.invoiceNo || "")}</td><td>${E(x.paymentMethod || "")}</td><td>${E(x.reference || "")}</td><td>${E(projName(x.projectId))}</td><td class="n">${x.type === "Supplier Payment" ? "" : "-"}${M(x.amount)}</td></tr>`), "apRepT");
    if (k === "advance") return table([{ t: "Advance" }, { t: "Date" }, { t: "Vendor" }, { t: "Amount", n: 1 }, { t: "Remaining", n: 1 }], advs().filter(inF).map((a) => `<tr><td>${E(a.no)}</td><td>${E(a.date)}</td><td>${E(a.supplier)}</td><td class="n">${M(a.amount)}</td><td class="n">${M(advLeft(a))}</td></tr>`), "apRepT");
    if (k === "bills") return table([...billCols, { t: "Status" }], bills().filter(inF).map((p) => billRow(p).replace("</tr>", `<td>${E(apPayableStatus(p))}</td></tr>`)), "apRepT");
    if (k === "project" || k === "vendor") return table([{ t: k === "project" ? "Project" : "Vendor" }, { t: "Bills", n: 1 }, { t: "Billed", n: 1 }, { t: "Paid", n: 1 }, { t: "Outstanding", n: 1 }], sumBy((p) => (k === "project" ? projName(p.projectId) : p.supplier || "—")).map(([n, g]) => `<tr><td>${E(n)}</td><td class="n">${g.n}</td><td class="n">${M(g.amt)}</td><td class="n">${M(g.paid)}</td><td class="n"><b>${M(g.out)}</b></td></tr>`), "apRepT");
    return "";
  }
  function reportsBody() {
    const k = window.apRep || "summary"; const name = REPORTS.find((r) => r[0] === k)?.[1] || "";
    const body = k === "ledger" ? ledgerBody().replace('id="apLedgerT"', 'id="apRepT"') : report(k);
    return `<div class="appx-head"><div><h3>AP Reports</h3><p>All figures come from saved bills, payments, notes and advances.</p></div><div style="display:flex;gap:6px"><button class="btn" onclick="apExport('apRepT','AP-${E(name).replace(/\s+/g, "-")}')">Excel</button><button class="btn" onclick="apPrint('apRepT','${E(name)}')">Print / PDF</button></div></div><div class="appx-rep">${REPORTS.map(([r, l]) => `<button class="${r === k ? "on" : ""}" onclick="apRep='${r}';render()"><b>${l}</b></button>`).join("")}</div>${k === "ledger" ? "" : filterBar()}${body}`;
  }

  window.apExport = function (tid, name) {
    const t = document.getElementById(tid); if (!t) return;
    const csv = [...t.querySelectorAll("tr")].map((tr) => [...tr.children].map((c) => `"${c.innerText.replace(/\s+/g, " ").trim().replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv" })); a.download = name + "-" + today() + ".csv"; a.click();
  };
  window.apPrint = function (tid, title) {
    const t = document.getElementById(tid); if (!t) return; const co = db.company?.name || db.settings?.companyName || "PURE_BUILD";
    const w = window.open("", "_blank"); if (!w) { toast("Allow pop-ups to print"); return; }
    w.document.write(`<html><head><title>${E(title)}</title><style>body{font-family:Arial,sans-serif;font-size:11px;margin:18px}h1{font-size:16px;margin:0}h2{font-size:13px;margin:4px 0 12px;color:#334155}table{width:100%;border-collapse:collapse}th,td{border:1px solid #cbd5e1;padding:5px;text-align:left}th{background:#f1f5f9}td.n,th.n{text-align:right}thead{display:table-header-group}button{display:none}</style></head><body><h1>${E(co)}</h1><h2>${E(title)} · printed ${today()}</h2>${t.outerHTML}</body></html>`);
    w.document.close(); setTimeout(() => w.print(), 300);
  };

  /* ---------- Admin-only approval + mismatch guard ---------- */
  if (typeof approvePayable === "function") {
    const orig = approvePayable;
    window.approvePayable = approvePayable = function (pid) {
      if (!isAdmin()) { toast("Only Admin can approve supplier bills"); return false; }
      const p = (db.payables || []).find((x) => String(x.id) === String(pid));
      if (p) { const c = verifyCheck(p); if (c.state === "mismatch") { toast("3-way match mismatch — add an explanation in Bill Verification first"); return false; } }
      return orig.apply(this, arguments);
    };
  }

  /* ---------- Page wrapper ---------- */
  const base = payables;
  window.payables = payables = function () {
    const tab = window.apTab || "overview"; const isNew = NEW.includes(tab);
    if (tab === "aging") window.apTab = "aging";
    if (isNew) window.apTab = "overview";
    const r = base.apply(this, arguments);
    window.apTab = tab;
    const tabsEl = document.querySelector("#view .ap-tabs");
    if (tabsEl) { tabsEl.classList.add("appro"); const cur = tab === "aging" ? "reports" : tab; tabsEl.innerHTML = TABS.map(([k, i, l]) => `<button class="ap-tab ${cur === k ? "active" : ""}" onclick="setApTab('${k}')">${ic(i)}<span>${l}</span></button>`).join(""); }
    if (isNew) { const ws = document.querySelector("#view .ap-workspace"); if (ws) ws.innerHTML = `<div class="panel ap-panel" style="padding:14px">${{ verify: verifyBody, advances: advancesBody, notes: notesBody, ledger: ledgerBody, reports: reportsBody }[tab]()}</div>`; }
    if (tab === "overview") { const ws = document.querySelector("#view .ap-workspace"); const adv = advs().filter((a) => !selectedProject || a.projectId === selectedProject).reduce((s, a) => s + advLeft(a), 0); const pend = bills().filter((p) => ["Draft", "Submitted"].includes(p.apStatus || "")).length; if (ws && !ws.querySelector(".appx-dash")) ws.insertAdjacentHTML("afterbegin", `<div class="appx-kpis appx-dash"><div class="appx-kpi" style="cursor:pointer" onclick="setApTab('approval')"><small>Pending Bills</small><b>${pend}</b></div><div class="appx-kpi" style="cursor:pointer" onclick="setApTab('advances')"><small>Vendor Advances</small><b>${M(adv)}</b></div><div class="appx-kpi" style="cursor:pointer" onclick="setApTab('verify')"><small>Match issues</small><b class="appx-bad">${bills().filter((p) => verifyCheck(p).state === "mismatch").length}</b></div></div>`); }
    return r;
  };
})();
