# Staff Approvals — one place to approve everything

## Problem now
Staff send 4 kinds of things from the phone app, but the office approves them in 4 different pages:
- Daily site report → Site Progress → Approval Center
- Task update → Task Management → task details
- Material request → Labour & HR / site operations box
- Expense request → Accounts Payable → Staff Expense Requests card

Easy to miss something waiting.

## Plan
1. **New "Staff Approvals" page in the office app** (side menu, with a red count badge).
   - Tabs: All · Site Reports · Task Updates · Material · Expense
   - Each row: date, site, staff name, short summary, amount/qty, photos, status.
   - Buttons on each row: **Approve**, **Return / Reject** (note required), **Open details**.
   - Filters: site, date (Today / This week / All), search.
2. **Dashboard**: the existing Alerts box gets one line "X staff items waiting approval" that opens this page.
3. **Phone app**: no approve button for foreman (foreman can never approve). Home screen shows clear colour status: Waiting (amber), Approved (green), Returned (red) with the office note.
4. Old approval places stay working exactly as now — the new page only reuses the same approve/reject actions, so totals, BOQ, stock and payments behave the same.

## Safety
- No saved data changed or deleted; nothing new stored except what the existing approve/reject already saves.
- Only Admin / Manager (and roles already allowed to review) see the buttons.

## Technical details
- New display file `public/app/staff-approvals.js`, page key `staffApprovals`, opened with `setPage`.
- Reads pending rows from existing Cloud tables (site reports, foreman_task_updates, site material requests, site_expense_requests) and calls the existing RPCs: report review in team-erp.js, `review_foreman_task_update`, `review_site_material_request`, `review_site_expense_request`.
- Badge count refreshed every 60 s; no new tables or migrations.
