// Active: new Lovable Cloud.
// Rollback (old Cloud): supabaseUrl 'https://hnvxhikorcufcbhnuelp.supabase.co', supabaseAnonKey 'sb_publishable_fRRex2MuWWLnBIplCT4aiQ_YHZ_iE79'
window.PURE_BUILD_CLOUD_CONFIG = {
  supabaseUrl: 'https://djqrhstifabqqylfrihh.supabase.co',
  supabaseAnonKey: 'sb_publishable_jMkcP6-jFIZVQZWxNUYyJQ_4YGaLqV8',
  turnstileSiteKey: ''
};
