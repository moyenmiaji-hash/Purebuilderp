-- Add append-only audit events for project access and private storage changes.
BEGIN;

CREATE OR REPLACE FUNCTION public.pb_log_security_event(
  p_actor uuid,
  p_organization uuid,
  p_action text,
  p_record_id text,
  p_module text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, pg_temp
AS $$
BEGIN
  IF coalesce(auth.role(), '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  IF p_action NOT IN (
    'user_created',
    'user_disabled',
    'user_reactivated',
    'password_reset',
    'project_access_changed'
  ) THEN
    RAISE EXCEPTION 'invalid audit action';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = p_actor
      AND p.organization_id = p_organization
      AND p.status = 'active'
      AND p.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'invalid audit actor';
  END IF;
  INSERT INTO public.audit_log (
    organization_id, actor_id, actor_role, module, record_id, action
  )
  VALUES (p_organization, p_actor, 'admin', p_module, p_record_id, p_action);
END
$$;
REVOKE ALL ON FUNCTION public.pb_log_security_event(uuid, uuid, text, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.pb_log_security_event(uuid, uuid, text, text, text) TO service_role;

CREATE OR REPLACE FUNCTION public.pb_audit_project_membership()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  target_organization uuid;
  target_project uuid;
  target_user uuid;
  actor_role text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    target_organization := OLD.organization_id;
    target_project := OLD.project_id;
    target_user := OLD.user_id;
  ELSE
    target_organization := NEW.organization_id;
    target_project := NEW.project_id;
    target_user := NEW.user_id;
  END IF;

  IF auth.uid() IS NULL THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
  END IF;

  SELECT p.role INTO actor_role FROM public.profiles p WHERE p.id = auth.uid();
  INSERT INTO public.audit_log (
    organization_id, actor_id, actor_role, module, record_id, action
  )
  VALUES (
    target_organization,
    auth.uid(),
    actor_role,
    'project_access',
    target_project::text || ':' || target_user::text,
    'project_access_changed'
  );

  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS pb_audit_project_membership ON public.team_project_members;
CREATE TRIGGER pb_audit_project_membership
  AFTER INSERT OR UPDATE OR DELETE ON public.team_project_members
  FOR EACH ROW EXECUTE FUNCTION public.pb_audit_project_membership();

CREATE OR REPLACE FUNCTION public.pb_audit_storage_object()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, pg_temp
AS $$
DECLARE
  target_bucket text;
  target_name text;
  folders text[];
  target_organization uuid;
  actor_id uuid := auth.uid();
  actor_role text;
  audit_action text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    target_bucket := OLD.bucket_id;
    target_name := OLD.name;
    audit_action := 'file_deleted';
  ELSE
    target_bucket := NEW.bucket_id;
    target_name := NEW.name;
    audit_action := CASE WHEN TG_OP = 'INSERT' THEN 'file_uploaded' ELSE 'file_updated' END;
  END IF;

  folders := storage.foldername(target_name);
  IF target_bucket = 'site-progress-photos'
    AND coalesce(array_length(folders, 1), 0) >= 2
    AND folders[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  THEN
    target_organization := folders[1]::uuid;
  ELSIF target_bucket = 'project-documents'
    AND coalesce(array_length(folders, 1), 0) >= 1
    AND folders[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
  THEN
    SELECT p.organization_id INTO target_organization
    FROM public.team_projects p
    WHERE p.id = folders[1]::uuid;
  END IF;

  IF target_organization IS NOT NULL AND actor_id IS NOT NULL THEN
    SELECT p.role INTO actor_role FROM public.profiles p WHERE p.id = actor_id;
    INSERT INTO public.audit_log (
      organization_id, actor_id, actor_role, module, record_id, action
    )
    VALUES (
      target_organization,
      actor_id,
      actor_role,
      'file_storage',
      target_bucket || '/' || target_name,
      audit_action
    );
  END IF;

  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS pb_audit_storage_object ON storage.objects;
CREATE TRIGGER pb_audit_storage_object
  AFTER INSERT OR UPDATE OR DELETE ON storage.objects
  FOR EACH ROW EXECUTE FUNCTION public.pb_audit_storage_object();

REVOKE ALL ON FUNCTION public.pb_audit_project_membership() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.pb_audit_storage_object() FROM PUBLIC, anon, authenticated;

COMMIT;