/* Staff app extras: login helpers, expense requests (with offline queue), drawings & documents. */
(function () {
  const cl = () => window.PB_STAFF_CLIENT;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const aed = (n) => "AED " + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const QKEY = "PB_STAFF_OFFLINE_QUEUE";
  const today = () => new Date(Date.now() + 4 * 3600e3).toISOString().slice(0, 10);

  /* ---------- Login extras ---------- */
  function loginExtras() {
    const f = $("sign-in-form"); if (!f || f.dataset.pbx) return; f.dataset.pbx = "1";
    const pw = $("password");
    const eye = document.createElement("button");
    eye.type = "button"; eye.textContent = "Show"; eye.className = "pbx-eye"; pw.style.paddingRight = "56px";
    eye.onclick = () => { const s = pw.type === "password"; pw.type = s ? "text" : "password"; eye.textContent = s ? "Hide" : "Show"; };
    pw.parentElement.style.position = "relative"; pw.parentElement.appendChild(eye);
    const row = document.createElement("div"); row.className = "pbx-row";
    row.innerHTML = `<label><input type="checkbox" id="pbx-keep" checked> Keep me logged in</label><span>Contact your Admin for password help.</span>`;
    f.querySelector("button[type=submit]").before(row);
    $("pbx-keep").checked = localStorage.getItem("PB_STAFF_KEEP") !== "0";
    f.addEventListener("submit", () => {
      const k = $("pbx-keep").checked; localStorage.setItem("PB_STAFF_KEEP", k ? "1" : "0");
      sessionStorage.setItem("PB_STAFF_ALIVE", "1");
    }, true);
  }
  // "Keep me logged in" off → sign out when the browser was closed.
  async function keepCheck() {
    if (localStorage.getItem("PB_STAFF_KEEP") === "0" && !sessionStorage.getItem("PB_STAFF_ALIVE") && cl()) {
      const { data } = await cl().auth.getSession();
      if (data.session) { await cl().auth.signOut(); location.reload(); return; }
    }
    sessionStorage.setItem("PB_STAFF_ALIVE", "1");
  }

  /* ---------- Shared: my sites ---------- */
  let sites = [];
  async function loadSites() {
    const c = cl(); const u = (await c.auth.getUser()).data.user; if (!u) return [];
    const { data: m } = await c.from("team_project_members").select("project_id").eq("user_id", u.id).eq("status", "active");
    const ids = (m || []).map((x) => x.project_id); if (!ids.length) return (sites = []);
    const { data } = await c.from("team_projects").select("id,name").in("id", ids);
    return (sites = data || []);
  }
  const siteOpts = () => `<option value="">Choose your site</option>` + sites.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
  const siteName = (id) => (sites.find((s) => s.id === id) || {}).name || "Site";

  /* ---------- Offline queue ---------- */
  const queue = () => { try { return JSON.parse(localStorage.getItem(QKEY) || "[]"); } catch { return []; } };
  const setQueue = (q) => localStorage.setItem(QKEY, JSON.stringify(q));
  async function flush() {
    if (!navigator.onLine || !cl()) return; const q = queue(); if (!q.length) return;
    const left = [];
    for (const it of q) {
      const { error } = await cl().rpc("submit_site_expense_request", { p_project_id: it.project_id, p: it.p });
      if (error && /fetch|network/i.test(error.message)) left.push(it);
    }
    setQueue(left); offlineBar(); loadExpenses();
  }
  function offlineBar() {
    let b = $("pbx-offline"); if (!b) { b = document.createElement("div"); b.id = "pbx-offline"; document.body.prepend(b); }
    const n = queue().length;
    b.hidden = navigator.onLine && !n;
    b.textContent = !navigator.onLine ? `You are offline. New expense requests are saved on this phone${n ? ` (${n} waiting)` : ""} and will send automatically.` : `${n} saved request(s) are being sent…`;
  }

  /* ---------- Expense requests ---------- */
  function buildExpense() {
    const s = document.createElement("form"); s.id = "pbx-expense"; s.className = "card"; s.dataset.tab = "expense";
    s.innerHTML = `<div class="body"><div class="section-title"><span>💵</span><h2>Expense / payment request</h2></div>
      <p class="hint">Send a request to the office. Accounts will approve or reject it. You cannot edit it after sending.</p>
      <div class="field"><label>Assigned site *</label><select id="pbx-e-site" required></select></div>
      <div class="grid"><div class="field"><label>Date *</label><input id="pbx-e-date" type="date" required></div>
      <div class="field"><label>Amount (AED) *</label><input id="pbx-e-amt" type="number" min="0.01" step="0.01" inputmode="decimal" required></div></div>
      <div class="grid"><div class="field"><label>Category *</label><select id="pbx-e-cat">${["Petty Cash", "Transport", "Small Materials", "Tools", "Food & Water", "Labour Advance", "Fuel", "Other"].map((x) => `<option>${x}</option>`).join("")}</select></div>
      <div class="field"><label>Pay to</label><input id="pbx-e-payee" maxlength="120" placeholder="Shop / person"></div></div>
      <div class="field"><label>What is it for? *</label><textarea id="pbx-e-desc" required maxlength="600" rows="3"></textarea></div>
      <button class="submit" type="submit">Send request</button><div class="notice" id="pbx-e-n" role="status"></div>
      <div class="sub" style="margin-top:14px">My requests</div><div id="pbx-e-list" class="hint">Loading…</div></div>`;
    document.querySelector("main.shell").appendChild(s);
    $("pbx-e-date").value = today(); $("pbx-e-date").max = today();
    s.onsubmit = async (e) => {
      e.preventDefault();
      const it = { project_id: $("pbx-e-site").value, p: { request_date: $("pbx-e-date").value, amount: $("pbx-e-amt").value, category: $("pbx-e-cat").value, payee: $("pbx-e-payee").value.trim(), description: $("pbx-e-desc").value.trim(), idempotency_key: "exp-" + Date.now() + "-" + Math.random().toString(36).slice(2) } };
      if (!it.project_id) return ($("pbx-e-n").textContent = "Choose your site.");
      if (!(Number(it.p.amount) > 0)) return ($("pbx-e-n").textContent = "Amount must be more than 0.");
      const btn = s.querySelector("button[type=submit]"); btn.disabled = true;
      try {
        if (!navigator.onLine) { setQueue([...queue(), it]); $("pbx-e-n").textContent = "Saved on this phone. It will send when internet is back."; s.reset(); $("pbx-e-date").value = today(); offlineBar(); return; }
        const { error } = await cl().rpc("submit_site_expense_request", { p_project_id: it.project_id, p: it.p });
        if (error) {
          if (/fetch|network/i.test(error.message)) { setQueue([...queue(), it]); offlineBar(); $("pbx-e-n").textContent = "No internet. Saved on this phone; will send later."; }
          else { $("pbx-e-n").textContent = "Not sent: " + error.message; return; }
        } else $("pbx-e-n").textContent = "Request sent to office for approval.";
        s.reset(); $("pbx-e-date").value = today(); $("pbx-e-site").value = it.project_id; loadExpenses();
      } finally { btn.disabled = false; }
    };
  }
  async function loadExpenses() {
    const box = $("pbx-e-list"); if (!box || !cl()) return;
    const { data, error } = await cl().from("site_expense_requests").select("*").order("created_at", { ascending: false }).limit(20);
    if (error) { box.textContent = "Could not load: " + error.message; return; }
    const pend = queue().map((q) => `<div class="pbx-it"><b>${aed(q.p.amount)}</b> · ${esc(q.p.category)}<span class="pill amber">Saved offline</span><small>${esc(q.p.description)}</small></div>`).join("");
    box.innerHTML = pend + ((data || []).map((r) => `<div class="pbx-it"><b>${aed(r.amount)}</b> · ${esc(r.category)} · ${esc(r.request_date)}<span class="pill ${r.review_status === "approved" ? "green" : r.review_status === "pending" ? "amber" : ""}">${r.review_status}</span><small>${esc(siteName(r.project_id))} — ${esc(r.description || "")}${r.review_note ? "<br>Office note: " + esc(r.review_note) : ""}</small></div>`).join("") || (pend ? "" : "No requests yet."));
  }

  /* ---------- Drawings & documents ---------- */
  function buildDocs() {
    const s = document.createElement("section"); s.id = "pbx-docs"; s.className = "card"; s.dataset.tab = "docs";
    s.innerHTML = `<div class="body"><div class="section-title"><span>📐</span><h2>Drawings &amp; documents</h2></div>
      <p class="hint">Approved drawings and instructions for your sites. View only.</p>
      <div class="field"><label>Site</label><select id="pbx-d-site"></select></div><div id="pbx-d-list" class="hint">Loading…</div></div>`;
    document.querySelector("main.shell").appendChild(s);
    $("pbx-d-site").onchange = loadDocs;
  }
  async function loadDocs() {
    const box = $("pbx-d-list"); if (!box) return;
    let q = cl().from("project_documents").select("*").eq("is_active", true).order("created_at", { ascending: false });
    const sid = $("pbx-d-site").value; if (sid) q = q.eq("project_id", sid);
    const { data, error } = await q;
    if (error) { box.textContent = "Could not load: " + error.message; return; }
    box.innerHTML = (data || []).map((d) => `<div class="pbx-it"><b>${esc(d.title)}</b><span class="pill">${esc(d.doc_type)}</span><small>${esc(siteName(d.project_id))} · ${esc(String(d.created_at).slice(0, 10))}</small><button type="button" class="btn" data-open="${esc(d.file_path)}">Open</button></div>`).join("") || "No drawings shared yet.";
  }
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("[data-open]"); if (!b) return;
    const w = window.open("", "_blank");
    const { data, error } = await cl().storage.from("project-documents").createSignedUrl(b.dataset.open, 600);
    if (error) { if (w) w.close(); alert("Could not open: " + error.message); return; }
    if (w) w.location = data.signedUrl; else location.href = data.signedUrl;
  });

  /* ---------- Quick links ---------- */
  function addQuick() {
    document.querySelectorAll(".fw-quick").forEach((q) => {
      if (q.querySelector("[data-goto=expense]")) return;
      q.insertAdjacentHTML("beforeend", `<button type="button" data-goto="expense">💵<span>Expense</span></button><button type="button" data-goto="docs">📐<span>Drawings</span></button>`);
    });
  }

  const css = document.createElement("style");
  css.textContent = `.pbx-eye{position:absolute;right:8px;bottom:8px;border:0;background:transparent;color:#7fb4ff;font-weight:800;font-size:12px}
  .pbx-row{display:flex;justify-content:space-between;align-items:center;margin:4px 0 12px;font-size:13px}.pbx-row a{color:#7fb4ff}
  .pbx-row label{display:flex;gap:6px;align-items:center;white-space:nowrap}.pbx-row input[type=checkbox]{width:18px!important;height:18px;min-width:0;padding:0;margin:0}
  .pbx-it{display:grid;grid-template-columns:1fr auto;gap:4px 8px;padding:10px;border:1px solid #2a4163;border-radius:12px;margin-top:8px}
  .pbx-it small{grid-column:1/-1;color:#9fb3c8}.pbx-it .btn{grid-column:1/-1}
  #pbx-offline{position:sticky;top:0;z-index:50;background:#7c2d12;color:#fff;padding:8px 12px;font-size:13px;text-align:center}
  .pbx-modal{position:fixed;inset:0;background:rgba(0,0,0,.6);display:grid;place-items:center;z-index:99;padding:16px}.pbx-modal .card{max-width:420px;width:100%}`;
  document.head.appendChild(css);

  async function ready() {
    addQuick(); setInterval(addQuick, 2000);
    await loadSites();
    ["pbx-e-site", "pbx-d-site"].forEach((id) => { const el = $(id); if (el) el.innerHTML = siteOpts(); });
    if ($("pbx-d-site")) $("pbx-d-site").options[0].textContent = "All my sites";
    if (sites.length === 1) $("pbx-e-site").value = sites[0].id;
    loadExpenses(); loadDocs(); flush();
  }
  const boot = setInterval(() => {
    if (!cl()) return; clearInterval(boot);
    loginExtras(); buildExpense(); buildDocs(); keepCheck(); offlineBar();
    if (window.PB_STAFF_PROFILE) ready(); window.addEventListener("pb:staff-ready", ready);
  }, 200);
  window.addEventListener("online", () => { offlineBar(); flush(); });
  window.addEventListener("offline", offlineBar);
})();
