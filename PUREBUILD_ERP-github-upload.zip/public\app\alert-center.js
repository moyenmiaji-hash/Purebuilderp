/* Alert & Notification Center. Alerts are worked out live from real ERP records (never stored as fake rows).
   Only the user's actions (read / dismiss / resolve / snooze) and settings are saved, in side maps
   db.alertState and db.alertPrefs, so no business record is ever changed or deleted. */
(function(){
  if(window.__pbAlertCenter)return;window.__pbAlertCenter=1;
  var E=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
  var M=function(v){try{return (window.dashboardMoney||window.money)(v)}catch(e){return 'AED '+Math.round(v)}};
  var today=function(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
  var addDays=function(n){var d=new Date();d.setDate(d.getDate()+n);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
  var pn=function(id){try{return projectName(id)}catch(e){return ''}};
  function st(){db.alertState=db.alertState||{};return db.alertState}
  function prefs(){db.alertPrefs=db.alertPrefs||{};var p=db.alertPrefs;['Financial','Accounting','Project','Payables','Tax','Stock','System'].forEach(function(c){if(p['cat_'+c]===undefined)p['cat_'+c]=true});if(p.sound===undefined)p.sound=false;if(p.dueDays===undefined)p.dueDays=7;return p}
  function persist(){try{save()}catch(e){console.warn(e)}}
  function role(){return String(window.PB_CLOUD_ROLE||'admin').toLowerCase()}
  var NOTE_CAT={Payment:'Financial',Invoice:'Financial',Expense:'Payables',Payroll:'Financial',Stock:'Stock',Project:'Project',HR:'Project'};
  var ALL_CATS=['Financial','Accounting','Project','Payables','Tax','Stock','System'],ROLES=['manager','accountant','auditor','staff'];
  function allowFor(r){if(r==='admin')return null;var m=(prefs().roleCats||{})[r];if(Array.isArray(m))return m;return ROLE_CATS[r]===undefined?['Stock','Project']:ROLE_CATS[r]}
  function canSee(cat){var a=allowFor(role());return !a||a.indexOf(NOTE_CAT[cat]||cat)>=0}
  var ROLE_CATS={admin:null,manager:null,accountant:['Financial','Accounting','Payables','Tax','Stock'],auditor:['Financial','Accounting','Payables','Tax'],staff:['Stock','Project']};

  function alerts(){
    var out=[],t=today(),soon=addDays(prefs().dueDays||7),add=function(a){out.push(a)};
    var inv=(db.invoices||[]).filter(function(x){return typeof invoiceIsConfirmed!=='function'||invoiceIsConfirmed(x)});
    inv.forEach(function(x){var o=typeof invoiceOutstanding==='function'?invoiceOutstanding(x):(+x.amount||0)-(+x.received||0);if(o<=0||!x.dueDate)return;
      var no=x.number||x.invoiceNo||x.id;
      if(x.dueDate<t)add({key:'inv-od-'+x.id,cat:'Financial',pr:'critical',icon:'💸',title:'Customer payment overdue',desc:'Invoice '+no+' was due '+x.dueDate,project:pn(x.projectId),amount:o,date:x.dueDate,page:'sales'});
      else if(x.dueDate<=soon)add({key:'inv-due-'+x.id,cat:'Financial',pr:'warning',icon:'📅',title:'Customer payment due soon',desc:'Invoice '+no+' due '+x.dueDate,project:pn(x.projectId),amount:o,date:x.dueDate,page:'sales'})});
    var seenInv={};inv.forEach(function(x){var k=String(x.number||x.invoiceNo||'').trim().toLowerCase();if(!k)return;if(seenInv[k])add({key:'inv-dup-'+k,cat:'Accounting',pr:'warning',icon:'🧾',title:'Duplicate invoice number',desc:'Invoice number '+(x.number||x.invoiceNo)+' is used more than once',project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'sales'});seenInv[k]=1});
    var pay=db.payables||[],seenBill={};
    pay.forEach(function(x){var posted=typeof apIsPosted!=='function'||apIsPosted(x);var o=typeof apOutstandingAmount==='function'?apOutstandingAmount(x):(+x.amount||0)-(+x.paid||0);
      var no=x.invoiceNo||x.billNo||x.id,s=String(x.status||'');
      if(/submitted|pending|review|verification/i.test(s))add({key:'ap-appr-'+x.id,cat:'Payables',pr:'warning',icon:'✅',title:'Supplier bill awaiting approval',desc:(x.supplier||'Supplier')+' · '+no,project:pn(x.projectId),amount:+x.amount||+x.total||0,date:x.date||x.billDate,page:'payables'});
      if(posted&&o>0&&x.dueDate){if(x.dueDate<t)add({key:'ap-od-'+x.id,cat:'Payables',pr:'critical',icon:'⏰',title:'Supplier bill overdue',desc:(x.supplier||'Supplier')+' · '+no+' was due '+x.dueDate,project:pn(x.projectId),amount:o,date:x.dueDate,page:'payables'});
        else if(x.dueDate<=soon)add({key:'ap-due-'+x.id,cat:'Payables',pr:'warning',icon:'📆',title:'Supplier payment due soon',desc:(x.supplier||'Supplier')+' · '+no+' due '+x.dueDate,project:pn(x.projectId),amount:o,date:x.dueDate,page:'payables'})}
      var k=(String(x.supplier||'')+'|'+String(x.invoiceNo||'')).toLowerCase();if(x.invoiceNo){if(seenBill[k])add({key:'ap-dup-'+k,cat:'Payables',pr:'warning',icon:'⚠️',title:'Possible duplicate supplier bill',desc:(x.supplier||'')+' bill '+x.invoiceNo+' entered more than once',project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'payables'});seenBill[k]=1}});
    (db.projects||[]).forEach(function(p){var b=+p.budget||0;if(!b)return;var c;try{var pl=plCalc('1900-01-01',today(),p.id);c=(pl.totalRevenue+pl.otherIncome)-pl.net}catch(e){return}
      if(c>b)add({key:'pj-over-'+p.id,cat:'Project',pr:'critical',icon:'🏗️',title:'Project over budget',desc:'Cost '+M(c)+' is above budget '+M(b)+' ('+Math.round(c/b*100)+'%)',project:p.name,amount:c-b,date:today(),page:'projects',pid:p.id});
      else if(c>=b*.85)add({key:'pj-85-'+p.id,cat:'Project',pr:'warning',icon:'📊',title:'Project budget almost used',desc:Math.round(c/b*100)+'% of budget used',project:p.name,amount:b-c,date:today(),page:'projects',pid:p.id})});
    var stock=db.stock||[];(db.materials||[]).forEach(function(m){var bal=stock.filter(function(x){return x.materialId===m.id||(!x.materialId&&String(x.item||'').trim().toLowerCase()===String(m.name||'').trim().toLowerCase())}).reduce(function(a,x){return a+(x.direction==='In'?1:-1)*(+x.qty||0)},0);
      var min=+m.minStock||0;if(bal<=0&&(min>0||stock.some(function(x){return x.materialId===m.id})))add({key:'st-out-'+m.id,cat:'Stock',pr:'critical',icon:'📦',title:'Out of stock',desc:(m.name||'Item')+' · on hand '+bal+' '+(m.unit||''),project:'',date:today(),page:'stock'});
      else if(min>0&&bal<=min)add({key:'st-low-'+m.id,cat:'Stock',pr:'warning',icon:'📉',title:'Low stock — reorder',desc:(m.name||'Item')+' · '+bal+' left, minimum '+min+' '+(m.unit||''),project:'',date:today(),page:'stock'})});
    var tx=db.transactions||[];
    var cash=tx.filter(function(x){return x.status!=='Due'&&/^cash/i.test(String(x.paymentMethod||''))}).reduce(function(a,x){var s=x.type==='Income'?1:(typeof isExpenseEntry==='function'&&isExpenseEntry(x))||/supplier payment|salary|payroll/i.test(String(x.type||''))?-1:0;return a+s*(+x.amount||0)},0);
    if(cash<0)add({key:'cash-neg',cat:'Financial',pr:'critical',icon:'🏦',title:'Cash in hand is negative',desc:'More cash was paid out than received. Check cash entries.',project:'',amount:cash,date:today(),page:'ledger'});
    tx.forEach(function(x){if(['Purchase','Expense'].indexOf(x.type)>=0&&(!x.category||!(+x.amount>0)))add({key:'tx-inc-'+x.id,cat:'Accounting',pr:'info',icon:'📝',title:'Incomplete ledger entry',desc:(x.type||'Entry')+' on '+(x.date||'?')+' has no '+(!x.category?'category':'amount'),project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'ledger'});
      if(/vat/i.test(String(x.category||''))&&x.status==='Due')add({key:'vat-due-'+x.id,cat:'Tax',pr:'warning',icon:'🧮',title:'VAT payment pending',desc:'VAT entry on '+x.date+' is not paid',project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'ledger'})});
    var big=tx.filter(function(x){return x.type!=='Income'&&+x.amount>0}).map(function(x){return +x.amount});if(big.length>=8){var avg=big.reduce(function(a,b){return a+b},0)/big.length;tx.forEach(function(x){if(x.type!=='Income'&&+x.amount>avg*5&&+x.amount>5000)add({key:'tx-big-'+x.id,cat:'Financial',pr:'info',icon:'🔎',title:'Unusually large payment',desc:(x.category||x.type)+' of '+M(+x.amount)+' on '+x.date+' (5× normal)',project:pn(x.projectId),amount:+x.amount,date:x.date,page:'ledger'})})}
    if(navigator.onLine===false)add({key:'sys-offline-'+today(),cat:'System',pr:'warning',icon:'📡',title:'Offline — cloud sync paused',desc:'Changes are kept on this computer and will sync when back online.',project:'',date:today(),page:'settings'});
    var p=prefs();
    return out.filter(function(a){return canSee(a.cat)&&p['cat_'+a.cat]!==false}).map(function(a){a.kind='alert';return a});
  }
  function notes(){
    var out=[],fin=true;
    if(fin)(db.transactions||[]).forEach(function(x){if(x.type==='Income')out.push({key:'n-tx-'+x.id,cat:'Payment',icon:'💰',title:'Customer payment received',desc:(x.description||x.category||'')+(x.client?' · '+x.client:''),project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'ledger'});
      else if(x.type==='Supplier Payment')out.push({key:'n-tx-'+x.id,cat:'Payment',icon:'📤',title:'Supplier payment completed',desc:(x.supplier||'')+' · '+(x.description||''),project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'payables'});
      else if(/salary|payroll/i.test(String(x.category||'')))out.push({key:'n-tx-'+x.id,cat:'Payroll',icon:'👷',title:'Payroll paid',desc:x.description||x.category,project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'ledger'})});
    if(fin)(db.invoices||[]).forEach(function(x){out.push({key:'n-inv-'+x.id,cat:'Invoice',icon:'🧾',title:'Invoice '+(x.status||'created'),desc:'Invoice '+(x.number||x.invoiceNo||'')+(x.client?' · '+x.client:''),project:pn(x.projectId),amount:+x.amount||0,date:x.date,page:'sales'})});
    if(fin)(db.payables||[]).forEach(function(x){out.push({key:'n-ap-'+x.id,cat:'Expense',icon:'📑',title:'Supplier bill '+(x.status||'entered'),desc:(x.supplier||'')+' · '+(x.invoiceNo||''),project:pn(x.projectId),amount:+x.amount||0,date:x.date||x.billDate,page:'payables'})});
    (db.stockVouchers||[]).forEach(function(v){out.push({key:'n-sv-'+v.id,cat:'Stock',icon:'📦',title:(v.type||'Stock')+' voucher '+(v.status||''),desc:v.no||v.number||'',project:pn(v.projectId),date:v.date,page:'stock'})});
    (db.projects||[]).forEach(function(p){if(p.createdAt||p.start)out.push({key:'n-pj-'+p.id,cat:'Project',icon:'🏗️',title:'Project: '+p.name,desc:'Status '+(p.status||'Active'),project:p.name,date:String(p.createdAt||p.start).slice(0,10),page:'projects',pid:p.id})});
    (db.workers||db.employees||[]).forEach(function(w){if(w.joinDate||w.createdAt)out.push({key:'n-emp-'+w.id,cat:'HR',icon:'🧑‍🔧',title:'Employee added',desc:w.name||'',project:pn(w.projectId),date:String(w.joinDate||w.createdAt).slice(0,10),page:'labour'})});
    return out.filter(function(n){return n.date&&canSee(n.cat)}).sort(function(a,b){return String(b.date).localeCompare(String(a.date))}).slice(0,300).map(function(n){n.kind='note';n.pr='info';return n});
  }
  function stOf(k){return st()[k]||{}}
  function setSt(k,patch,action){var s=st(),o=s[k]||{};Object.keys(patch).forEach(function(x){o[x]=patch[x]});o.history=(o.history||[]).concat([{a:action,at:new Date().toISOString(),by:(window.PB_CLOUD_NAME||'')}]).slice(-20);s[k]=o;persist()}
  function live(list){var t=today();return list.filter(function(a){var s=stOf(a.key);return !s.dismissed&&!s.resolved&&!(s.snoozeUntil&&s.snoozeUntil>t)})}
  window.pbAlertCounts=function(){var a=live(alerts()),n=notes();return {active:a.length,critical:a.filter(function(x){return x.pr==='critical'}).length,warning:a.filter(function(x){return x.pr==='warning'}).length,unread:a.concat(n).filter(function(x){return !stOf(x.key).read}).length}};

  var css=document.createElement('style');css.textContent=
  '.pac-ov{position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:99998;display:flex;align-items:center;justify-content:center}'+
  '.pac{background:#f6f8fb;width:min(1180px,96vw);height:min(860px,94vh);border-radius:16px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.35)}'+
  '.pac-h{display:flex;align-items:center;gap:10px;padding:14px 18px;background:linear-gradient(135deg,#0f2a4a,#1e4f86);color:#fff}.pac-h b{font-size:16px;flex:1}'+
  '.pac-h button,.pac-tb button,.pac-act button{border:0;border-radius:8px;padding:6px 10px;font-weight:700;cursor:pointer;font-size:12px}.pac-h button{background:rgba(255,255,255,.15);color:#fff}'+
  '.pac-k{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;padding:12px 18px}.pac-k div{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:10px 12px}.pac-k small{display:block;font-size:11px;color:#64748b;font-weight:700;text-transform:uppercase}.pac-k strong{font-size:20px}'+
  '.pac-k .c strong{color:#dc2626}.pac-k .w strong{color:#ea580c}.pac-k .i strong{color:#2563eb}'+
  '.pac-tabs{display:flex;gap:4px;padding:0 18px;flex-wrap:wrap}.pac-tabs button{border:0;background:transparent;padding:8px 14px;font-weight:800;color:#475569;border-bottom:3px solid transparent;cursor:pointer}.pac-tabs button.on{color:#1e4f86;border-color:#1e4f86}'+
  '.pac-tb{display:flex;gap:8px;padding:10px 18px;flex-wrap:wrap;align-items:center}.pac-tb input,.pac-tb select{height:32px;border:1px solid #d5dee8;border-radius:8px;padding:0 8px;background:#fff;font-size:12px}.pac-tb input[type=search]{flex:1;min-width:180px}.pac-tb button{background:#e8eff8;color:#1e4f86}'+
  '.pac-list{flex:1;overflow:auto;padding:0 18px 12px}.pac-it{display:flex;gap:10px;align-items:flex-start;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #2563eb;border-radius:10px;padding:10px 12px;margin-bottom:8px}'+
  '.pac-it.critical{border-left-color:#dc2626}.pac-it.warning{border-left-color:#ea580c}.pac-it.unread{background:#f3f8ff}.pac-it .ic{font-size:20px;line-height:1}.pac-it .bd{flex:1;min-width:0}.pac-it b{font-size:13.5px;color:#0f172a}'+
  '.pac-it p{margin:2px 0;font-size:12px;color:#475569}.pac-it .mt{font-size:11px;color:#64748b;display:flex;gap:10px;flex-wrap:wrap}.pac-pill{font-size:10px;font-weight:800;border-radius:999px;padding:2px 7px;text-transform:uppercase}'+
  '.pac-pill.critical{background:#fee2e2;color:#b91c1c}.pac-pill.warning{background:#ffedd5;color:#c2410c}.pac-pill.info{background:#dbeafe;color:#1d4ed8}.pac-amt{font-weight:800;color:#0f172a;white-space:nowrap}'+
  '.pac-act{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end;max-width:300px}.pac-act button{background:#eef2f7;color:#334155;padding:4px 8px;font-size:11px}.pac-act button.p{background:#1e4f86;color:#fff}'+
  '.pac-pg{display:flex;gap:8px;align-items:center;justify-content:flex-end;padding:8px 18px;border-top:1px solid #e2e8f0;background:#fff;font-size:12px}.pac-pg button{border:1px solid #d5dee8;background:#fff;border-radius:6px;padding:4px 10px;cursor:pointer}'+
  '.pac-empty{text-align:center;color:#64748b;padding:50px 0}.pac-set{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}.pac-set label{display:flex;gap:8px;align-items:center;font-size:13px}'+
  '.pac .pac-tb input,.pac .pac-tb select{width:auto!important;min-height:0!important;color:#0f172a!important;margin:0!important;flex:0 0 auto}.pac .pac-tb input[type=search]{flex:1 1 220px!important}.pac-k strong{color:#0f172a}.pac .pac-pg button{color:#1e4f86!important;font-weight:700}.pac .pac-pg button:disabled{opacity:.4}.pac .pac-pg span{color:#475569}'+
  '.pac-days{display:flex;gap:6px;align-items:center;padding:0 18px 10px;flex-wrap:wrap}.pac-days button{border:1px solid #d5dee8;background:#fff;color:#1e4f86;border-radius:999px;padding:4px 12px;font-weight:800;font-size:12px;cursor:pointer}.pac-days button.on{background:#1e4f86;color:#fff;border-color:#1e4f86}.pac .pac-days input{height:30px;border:1px solid #d5dee8;border-radius:8px;padding:0 8px;color:#0f172a;width:auto!important;margin:0!important}.pac-live{margin-left:auto;font-size:11px;font-weight:700;color:#16a34a}.pac-dh{position:sticky;top:0;z-index:1;background:#f6f8fb;font-size:12px;font-weight:800;color:#1e4f86;padding:8px 2px 6px;display:flex;gap:6px;align-items:center}.pac-dh span{background:#e0ebf8;border-radius:999px;padding:1px 8px;font-size:10.5px}'+
  '.pac-rt{border-collapse:collapse;font-size:12px;width:100%}.pac-rt th,.pac-rt td{border:1px solid #e2e8f0;padding:6px 8px;text-align:center;color:#0f172a}.pac-rt th{background:#eef4fb}.pac-rt td:first-child{text-align:left}'+
  '@media(max-width:760px){.pac-k{grid-template-columns:repeat(2,1fr)}.pac-it{flex-wrap:wrap}.pac-act{max-width:none}}';
  document.head.appendChild(css);

  function t0(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
  function dayLabel(d){if(!d)return 'No date';var t=t0(),y=new Date(t+'T12:00:00');y.setDate(y.getDate()-1);var ys=y.toISOString().slice(0,10);var nice;try{nice=new Date(d+'T12:00:00').toLocaleDateString('en-GB',{weekday:'short',day:'2-digit',month:'short',year:'numeric'})}catch(e){nice=d}return d===t?'Today · '+nice:d===ys?'Yesterday · '+nice:nice}
  function pushState(){if(!('Notification' in window))return 'This browser does not support notifications.';if(window.top!==window.self)return 'Open the app in its own tab (not the editor preview) to allow.';return Notification.permission==='granted'?'✓ Allowed on this device':Notification.permission==='denied'?'Blocked — allow notifications in browser site settings.':'Not allowed yet'}
  function notify(title,body){try{if(navigator.serviceWorker&&navigator.serviceWorker.controller){navigator.serviceWorker.ready.then(function(r){r.showNotification(title,{body:body,tag:title+body})})}else new Notification(title,{body:body,tag:title+body})}catch(e){try{new Notification(title,{body:body})}catch(_){}}}
  function askPush(test){if(!('Notification' in window)||window.top!==window.self){var el=document.querySelector('.pac-pst');if(el)el.textContent=pushState();return}Notification.requestPermission().then(function(){var el=document.querySelector('.pac-pst');if(el)el.textContent=pushState();if(test&&Notification.permission==='granted')notify('PURE BUILD','✅ Test: critical alerts will appear like this.')})}
  function pushCheck(){try{if(!window.db||!prefs().push||!('Notification' in window)||Notification.permission!=='granted')return;var seen={};try{seen=JSON.parse(localStorage.getItem('PB_ALERT_PUSHED')||'{}')}catch(e){}var first=!localStorage.getItem('PB_ALERT_PUSHED');live(alerts()).filter(function(a){return a.pr==='critical'}).forEach(function(a){if(seen[a.key])return;seen[a.key]=1;if(!first)notify('⚠️ '+a.title,(a.desc||'')+(a.project?' · '+a.project:''))});localStorage.setItem('PB_ALERT_PUSHED',JSON.stringify(seen))}catch(e){}}
  setInterval(pushCheck,60000);setTimeout(pushCheck,8000);
  function go(it){var ov=document.querySelector('.pac-ov');if(ov)ov.remove();try{if(it.pid&&typeof projectDetail==='function'){setPage('projects');projectDetail(it.pid,'overview')}else if(typeof setPage==='function')setPage(it.page)}catch(e){console.warn(e)}}
  function open(tab){
    var state={tab:tab||'all',q:'',pr:'',cat:'',from:'',to:'',page:1},per=25;
    var ov=document.createElement('div');ov.className='pac-ov';document.body.appendChild(ov);
    ov.innerHTML='<div class="pac"><div class="pac-h"><b>🔔 Alert &amp; Notification Center</b><button data-x="readall">Mark all as read</button><button data-x="close">✕ Close</button></div><div class="pac-k"></div>'+
      '<div class="pac-tabs">'+[['all','All'],['alerts','Alerts'],['notes','Notifications'],['unread','Unread'],['resolved','Resolved / Dismissed'],['settings','Settings']].map(function(t){return '<button data-t="'+t[0]+'">'+t[1]+'</button>'}).join('')+'</div>'+
      '<div class="pac-tb"><input type="search" placeholder="Search alerts and notifications…"><select data-f="pr"><option value="">All priorities</option><option value="critical">Critical</option><option value="warning">Warning</option><option value="info">Information</option></select><select data-f="cat"><option value="">All categories</option></select><input type="date" data-f="from" title="From"><input type="date" data-f="to" title="To"></div><div class="pac-days"><button data-d="all" class="on">All time</button><button data-d="today">Today</button><button data-d="-1" title="Previous day">‹</button><input type="date" data-f="day" title="Show one day"><button data-d="1" title="Next day">›</button><span class="pac-live">● Auto refresh</span></div>'+
      '<div class="pac-list"></div><div class="pac-pg"></div></div>';
    var A,N;
    function rebuild(){A=alerts();N=notes();var cats={};A.concat(N).forEach(function(x){cats[x.cat]=1});var sel=ov.querySelector('[data-f=cat]'),v=sel.value;sel.innerHTML='<option value="">All categories</option>'+Object.keys(cats).sort().map(function(c){return '<option'+(c===v?' selected':'')+'>'+c+'</option>'}).join('')}
    function draw(){
      var t=today(),la=live(A),c={active:la.length,critical:la.filter(function(x){return x.pr==='critical'}).length,warning:la.filter(function(x){return x.pr==='warning'}).length,unread:la.concat(N).filter(function(x){return !stOf(x.key).read}).length,appr:la.filter(function(x){return /approval/i.test(x.title)}).length};
      ov.querySelector('.pac-k').innerHTML='<div><small>Active alerts</small><strong>'+c.active+'</strong></div><div class="c"><small>Critical</small><strong>'+c.critical+'</strong></div><div class="w"><small>Warning</small><strong>'+c.warning+'</strong></div><div class="i"><small>Unread</small><strong>'+c.unread+'</strong></div><div><small>Pending approvals</small><strong>'+c.appr+'</strong></div>';
      ov.querySelectorAll('[data-t]').forEach(function(b){b.classList.toggle('on',b.dataset.t===state.tab)});
      var tb=ov.querySelector('.pac-tb'),list=ov.querySelector('.pac-list'),pg=ov.querySelector('.pac-pg');
      if(state.tab==='settings'){tb.style.display='none';pg.innerHTML='';var p=prefs();
        list.innerHTML='<div class="pac-set">'+['Financial','Accounting','Project','Payables','Tax','Stock','System'].map(function(k){return '<label><input type="checkbox" data-p="cat_'+k+'"'+(p['cat_'+k]!==false?' checked':'')+'> '+k+' alerts</label>'}).join('')+
        '<label><input type="checkbox" data-p="sound"'+(p.sound?' checked':'')+'> Sound for new critical alerts</label><label>Remind me <input type="number" min="1" max="60" data-p="dueDays" value="'+(p.dueDays||7)+'" style="width:60px"> days before due dates</label>'+
        '<label><input type="checkbox" data-p="push"'+(p.push?' checked':'')+'> 📱 Phone / browser notification for new critical alerts</label><label><button type="button" data-x="pushtest" style="background:#1e4f86;color:#fff;border:0;border-radius:8px;padding:6px 10px;font-weight:700;cursor:pointer">Allow &amp; send test</button> <span class="pac-pst" style="color:#64748b;font-size:12px">'+pushState()+'</span></label></div>'+
        (role()==='admin'?'<div class="pac-set" style="margin-top:12px;display:block"><b style="font-size:14px">👥 Who sees which alerts (Admin only)</b><p style="font-size:12px;color:#64748b;margin:4px 0 10px">Admin always sees everything. Tick the alert types each role can see.</p><div style="overflow:auto"><table class="pac-rt"><thead><tr><th>Role</th>'+ALL_CATS.map(function(c){return '<th>'+c+'</th>'}).join('')+'</tr></thead><tbody>'+ROLES.map(function(rl){var a=allowFor(rl);return '<tr><td><b>'+rl.charAt(0).toUpperCase()+rl.slice(1)+'</b></td>'+ALL_CATS.map(function(c){return '<td><input type="checkbox" data-rc="'+rl+'|'+c+'"'+(!a||a.indexOf(c)>=0?' checked':'')+'></td>'}).join('')+'</tr>'}).join('')+'</tbody></table></div></div>':'<p style="font-size:12px;color:#64748b;margin-top:10px">Your role: <b>'+E(role())+'</b>. The Admin decides which alerts you can see.</p>');
        list.querySelectorAll('[data-p]').forEach(function(i){i.onchange=function(){var p=prefs();p[i.dataset.p]=i.type==='checkbox'?i.checked:Math.max(1,+i.value||7);if(i.dataset.p==='push'&&i.checked)askPush();persist();rebuild()}});
        list.querySelectorAll('[data-rc]').forEach(function(i){i.onchange=function(){if(role()!=='admin')return;var k=i.dataset.rc.split('|'),p=prefs();p.roleCats=p.roleCats||{};var cur=(allowFor(k[0])||ALL_CATS).slice();if(i.checked){if(cur.indexOf(k[1])<0)cur.push(k[1])}else cur=cur.filter(function(c){return c!==k[1]});p.roleCats[k[0]]=cur;persist()}});return}
      tb.style.display='';
      var items;if(state.tab==='alerts')items=live(A);else if(state.tab==='notes')items=N;else if(state.tab==='unread')items=live(A).concat(N).filter(function(x){return !stOf(x.key).read});
      else if(state.tab==='resolved')items=A.filter(function(a){var s=stOf(a.key);return s.dismissed||s.resolved||(s.snoozeUntil&&s.snoozeUntil>t)});else items=live(A).concat(N);
      var rank={critical:0,warning:1,info:2};
      items=items.filter(function(x){var hay=(x.title+' '+x.desc+' '+x.project+' '+x.cat).toLowerCase();return (!state.q||hay.indexOf(state.q)>=0)&&(!state.pr||x.pr===state.pr)&&(!state.cat||x.cat===state.cat)&&(!state.from||String(x.date)>=state.from)&&(!state.to||String(x.date)<=state.to)&&(!state.day||String(x.date).slice(0,10)===state.day)})
        .sort(function(a,b){return String(b.date||'').slice(0,10).localeCompare(String(a.date||'').slice(0,10))||(a.kind===b.kind?0:a.kind==='alert'?-1:1)||(rank[a.pr]-rank[b.pr])});
      var pages=Math.max(1,Math.ceil(items.length/per));if(state.page>pages)state.page=pages;var view=items.slice((state.page-1)*per,state.page*per);
      var lastD=null;list.innerHTML=view.length?view.map(function(x){var s=stOf(x.key),ia=x.kind==='alert',dd=String(x.date||'').slice(0,10),gh='';if(dd!==lastD){lastD=dd;var cnt=items.filter(function(y){return String(y.date||'').slice(0,10)===dd}).length;gh='<div class="pac-dh">📅 '+E(dayLabel(dd))+' <span>'+cnt+'</span></div>'}
        var tag=s.resolved?'Resolved':s.dismissed?'Dismissed':(s.snoozeUntil&&s.snoozeUntil>t)?'Snoozed until '+s.snoozeUntil:'';
        return gh+'<div class="pac-it '+x.pr+(s.read?'':' unread')+'" data-k="'+E(x.key)+'"><div class="ic">'+x.icon+'</div><div class="bd"><b>'+E(x.title)+'</b> <span class="pac-pill '+x.pr+'">'+(ia?(x.pr==='info'?'Information':x.pr):'Notification')+'</span>'+(tag?' <span class="pac-pill info">'+E(tag)+'</span>':'')+
        '<p>'+E(x.desc)+'</p><div class="mt"><span>'+E(x.cat)+'</span>'+(x.project?'<span>📍 '+E(x.project)+'</span>':'')+'<span>🗓 '+E(x.date||'')+'</span>'+(s.read?'<span>Read</span>':'<span style="color:#2563eb;font-weight:700">● Unread</span>')+'</div></div>'+
        (x.amount?'<div class="pac-amt">'+M(x.amount)+'</div>':'')+'<div class="pac-act"><button class="p" data-a="view">View details</button><button data-a="'+(s.read?'unread':'read')+'">'+(s.read?'Mark unread':'Mark read')+'</button>'+
        (ia?(state.tab==='resolved'?'<button data-a="restore">Restore</button>':'<button data-a="snooze">Snooze 1 day</button><button data-a="snooze7">Snooze 7 days</button><button data-a="resolve">Resolve</button><button data-a="dismiss">Dismiss</button>'):'')+'</div></div>'}).join('')
        :'<div class="pac-empty">'+(state.tab==='alerts'?'✅ No active alerts. Everything looks fine.':'Nothing to show here.')+'</div>';
      ov.querySelectorAll('[data-d]').forEach(function(b){b.classList.toggle('on',(b.dataset.d==='all'&&!state.day)||(b.dataset.d==='today'&&state.day===t))});ov.querySelector('[data-f=day]').value=state.day||'';var lv=ov.querySelector('.pac-live');if(lv)lv.textContent='● Auto refresh · updated '+new Date().toTimeString().slice(0,5);
      pg.innerHTML='<span>'+items.length+' item'+(items.length===1?'':'s')+'</span><button data-g="-1"'+(state.page<=1?' disabled':'')+'>‹ Previous</button><span>Page '+state.page+' of '+pages+'</span><button data-g="1"'+(state.page>=pages?' disabled':'')+'>Next ›</button>';
    }
    ov.addEventListener('click',function(e){var b=e.target.closest('button');if(e.target===ov){ov.remove();return}if(!b)return;
      if(b.dataset.x==='pushtest'){askPush(true);return}
      if(b.dataset.x==='close'){ov.remove();return}
      if(b.dataset.x==='readall'){var s=st();live(A).concat(N).forEach(function(x){if(!(s[x.key]||{}).read){s[x.key]=s[x.key]||{};s[x.key].read=true}});persist();draw();return}
      if(b.dataset.t){state.tab=b.dataset.t;state.page=1;draw();return}
      if(b.dataset.d){var d=b.dataset.d;if(d==='all')state.day='';else if(d==='today')state.day=t0();else{var base=new Date((state.day||t0())+'T12:00:00');base.setDate(base.getDate()+(+d));state.day=base.toISOString().slice(0,10)}state.page=1;draw();return}
      if(b.dataset.g){state.page+=+b.dataset.g;draw();return}
      var row=b.closest('[data-k]');if(!row)return;var k=row.dataset.k,it=A.concat(N).find(function(x){return x.key===k}),a=b.dataset.a;
      if(a==='view'){setSt(k,{read:true},'viewed');go(it);return}
      if(a==='read')setSt(k,{read:true},'marked read');if(a==='unread')setSt(k,{read:false},'marked unread');
      if(a==='snooze')setSt(k,{snoozeUntil:addDays(1),read:true},'snoozed 1 day');if(a==='snooze7')setSt(k,{snoozeUntil:addDays(7),read:true},'snoozed 7 days');
      if(a==='resolve')setSt(k,{resolved:true,read:true},'resolved');if(a==='dismiss')setSt(k,{dismissed:true,read:true},'dismissed');
      if(a==='restore')setSt(k,{resolved:false,dismissed:false,snoozeUntil:''},'restored');draw()});
    ov.querySelector('input[type=search]').oninput=function(e){state.q=e.target.value.toLowerCase();state.page=1;draw()};
    ov.querySelectorAll('[data-f]').forEach(function(i){i.onchange=function(){state[i.dataset.f]=i.value;state.page=1;draw()}});
    rebuild();draw();
    var iv=setInterval(function(){if(!document.body.contains(ov)){clearInterval(iv);return}if(ov.querySelector('.pac-it:hover'))return;try{rebuild();draw()}catch(e){}},30000);
  }
  window.pbOpenAlertCenter=open;
  // Dashboard Alerts box "View all" and the top bell open the center.
  document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('.dashboard-alert-panel .dpx-va, .dashboard-alert-panel .pac-open');
    if(b){e.preventDefault();e.stopImmediatePropagation();open('all')}},true);
  // Compact counts strip in the dashboard Alerts box header.
  var lastCrit=-1;
  function deco(){var h=document.querySelector('.dashboard-alert-panel .panel-head');if(!h||!window.db)return;var c;try{c=window.pbAlertCounts()}catch(e){return}
    var el=h.querySelector('.pac-strip');if(!el){el=document.createElement('button');el.type='button';el.className='pac-strip pac-open';el.style.cssText='border:0;background:#eef4fb;border-radius:999px;padding:2px 8px;font-size:10.5px;font-weight:800;cursor:pointer;white-space:nowrap;color:#1e4f86';var va=h.querySelector('.dpx-va');h.insertBefore(el,va||null)}
    var txt='🔴 '+c.critical+' · 🟠 '+c.warning+' · ● '+c.unread+' unread';if(el.textContent!==txt){el.textContent=txt;el.title='Open Alert & Notification Center'}
    if(prefs().sound&&lastCrit>=0&&c.critical>lastCrit){try{var ac=new (window.AudioContext||window.webkitAudioContext)(),o=ac.createOscillator();o.connect(ac.destination);o.frequency.value=880;o.start();o.stop(ac.currentTime+.2)}catch(e){}}lastCrit=c.critical}
  var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(deco,400)}).observe(document.documentElement,{childList:true,subtree:true});
})();
