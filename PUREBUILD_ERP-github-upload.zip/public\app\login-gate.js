// Welcome + sign-in screen for the main app. Visual gate only; data access is still enforced by Cloud rules.
(function () {
  document.documentElement.classList.add("pb-auth-pending");
  const css = `
.pb-auth-pending body>:not(#pbGate){visibility:hidden!important}
#pbGate{visibility:visible!important}
#pbGate{position:fixed;inset:0;z-index:99999;display:grid;place-items:center;padding:20px;overflow:hidden;
 background:radial-gradient(900px 500px at 15% 10%,#1d5fa866,transparent 60%),radial-gradient(800px 500px at 90% 90%,#0aa59755,transparent 60%),#081321;font-family:Inter,Segoe UI,Arial,sans-serif;color:#eaf3ff}
#pbGate .orb{position:absolute;border-radius:50%;filter:blur(40px);opacity:.55;animation:pbFloat 9s ease-in-out infinite}
#pbGate .o1{width:280px;height:280px;background:#1677d6;left:-60px;top:-40px}
#pbGate .o2{width:320px;height:320px;background:#0aa597;right:-80px;bottom:-60px;animation-delay:-4s}
@keyframes pbFloat{50%{transform:translate(30px,-25px) scale(1.08)}}
@keyframes pbUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
@keyframes pbShine{to{background-position:200% center}}
#pbGate .box{position:relative;width:min(420px,100%);padding:34px 28px;border-radius:26px;background:#0f1f33cc;border:1px solid #2b4769;
 box-shadow:0 30px 70px -20px #000d,inset 0 1px 0 #ffffff12;backdrop-filter:blur(14px);animation:pbUp .7s ease both}
#pbGate .mark{width:62px;height:62px;margin:0 auto 14px;display:grid;place-items:center;border-radius:18px;font-weight:900;font-size:22px;color:#fff;
 background:linear-gradient(145deg,#1677d6,#0aa597);box-shadow:0 12px 30px #0aa59766;animation:pbUp .7s .1s ease both}
#pbGate h1{margin:0;text-align:center;font-size:25px;line-height:1.25;animation:pbUp .7s .2s ease both}
#pbGate h1 b{background:linear-gradient(90deg,#7cd3ff,#5ef0d6,#7cd3ff);background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent;animation:pbShine 4s linear infinite}
#pbGate p{margin:8px 0 22px;text-align:center;color:#a9bfd8;font-size:13px;animation:pbUp .7s .3s ease both}
#pbGate form{display:grid;gap:12px;animation:pbUp .7s .4s ease both}
#pbGate label{font-size:11px;font-weight:700;color:#a9bfd8}
#pbGate input[type=email],#pbGate input[type=password]{width:100%;box-sizing:border-box;margin-top:5px;min-height:48px;padding:12px 14px;border-radius:14px;border:1px solid #2f4d72;background:#0a1828;color:#fff;font:inherit;outline:none}
#pbGate input:focus{border-color:#3fb6ff;box-shadow:0 0 0 3px #3fb6ff2a}
#pbGate .keep{display:flex;align-items:center;gap:8px;font-size:13px;color:#d6e4f5;cursor:pointer}
#pbGate .keep input{width:18px;height:18px;accent-color:#0aa597}
#pbGate button{min-height:52px;border:0;border-radius:15px;font:inherit;font-weight:800;color:#fff;cursor:pointer;background:linear-gradient(100deg,#1677d6,#0aa597);box-shadow:0 12px 26px -8px #0aa597aa}
#pbGate button:disabled{opacity:.6;cursor:wait}
#pbGate .err{min-height:18px;font-size:12px;color:#ff9aa4;text-align:center}
#pbGate .foot{margin-top:14px;text-align:center;font-size:11px;color:#7f97b3}
#pbGate.out{transition:opacity .45s;opacity:0;pointer-events:none}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  const g = document.createElement("div"); g.id = "pbGate";
  g.innerHTML = `<div class="orb o1"></div><div class="orb o2"></div><div class="box"><div class="mark">PB</div>
<h1>Welcome to <b>Purebuild ERP</b></h1><p>Construction Management & Accounting</p>
<form><div><label>Email</label><input type="email" required autocomplete="username"></div>
<div><label>Password</label><input type="password" required autocomplete="current-password"></div>
<div class="captcha"></div>
<label class="keep"><input type="checkbox" checked> Keep me logged in</label>
<button type="submit">Sign in</button><div class="err"></div></form>
<div class="foot">Site staff? Use the staff app: <a href="./staff-mobile.html" style="color:#7cd3ff">staff-mobile.html</a></div></div>`;
  const mount = () => document.body.appendChild(g);
  document.body ? mount() : document.addEventListener("DOMContentLoaded", mount);
  const hide = () => { document.documentElement.classList.add("pb-authenticated"); document.documentElement.classList.remove("pb-auth-pending"); g.classList.add("out"); setTimeout(() => g.remove(), 500); };
  const err = (t) => { g.querySelector(".err").textContent = t; };

  const waitClient = () => new Promise((res) => {
    let n = 0; const t = setInterval(() => { if (window.PB_ENTRY_CLIENT || ++n > 400) { clearInterval(t); res(window.PB_ENTRY_CLIENT); } }, 50);
  });

  async function isOffice(c, uid) {
    const { data, error } = await c.rpc("is_office_user", { _user_id: uid });
    if (error) throw error;
    return data === true;
  }

  (async () => {
    const c = await waitClient();
    if (!c) { err("Cloud is not reachable. Check internet and refresh."); return; }
    // "Keep me logged in" off: session ends when the browser is closed.
    if (localStorage.getItem("pb_no_keep") === "1" && !sessionStorage.getItem("pb_live")) await c.auth.signOut();
    const { data, error: sessionError } = await c.auth.getSession();
    if (sessionError) { err("Could not verify your session. Check your connection and refresh."); return; }
    if (data.session) {
      let ok = null;
      for (let i = 0; i < 3 && ok === null; i++) {
        try { ok = await isOffice(c, data.session.user.id); } catch (e) {}
        if (ok === null) await new Promise((r) => setTimeout(r, 800));
      }
      if (ok === true) { sessionStorage.setItem("pb_live", "1"); hide(); return; }
      if (ok === null) { err("Could not verify your account. Check your connection before opening the ERP."); return; }
      await c.auth.signOut();
      sessionStorage.removeItem("pb_live");
    }
    const f = g.querySelector("form"), [em, pw] = f.querySelectorAll("input[type=email],input[type=password]");
    const keep = f.querySelector(".keep input"), btn = f.querySelector("button");
    async function finishOfficeLogin(user) {
      if (!(await isOffice(c, user.id))) { await c.auth.signOut(); throw new Error("This account is not authorized for the office ERP."); }
      if (keep.checked) localStorage.removeItem("pb_no_keep"); else localStorage.setItem("pb_no_keep", "1");
      sessionStorage.setItem("pb_live", "1");
      hide();
    }
    f.addEventListener("submit", async (e) => {
      e.preventDefault(); err(""); btn.disabled = true; btn.textContent = "Signing in…";
      try {
        const turnstile = window.PB_TURNSTILE;
        const captchaToken = turnstile ? await turnstile.getToken(f.querySelector(".captcha")) : undefined;
        const { data: d, error } = await c.auth.signInWithPassword({
          email: em.value.trim(),
          password: pw.value,
          options: captchaToken ? { captchaToken } : undefined,
        });
        if (error) throw new Error(/confirm/i.test(error.message) ? "Email not confirmed yet." : "Wrong email or password.");
        pw.value = "";
        const { data: profile, error: profileError } = await c.from("profiles")
          .select("role,status").eq("id", d.user.id).maybeSingle();
        if (profileError || !profile || profile.status !== "active") {
          await c.auth.signOut();
          throw new Error("This account is inactive or is not configured for PURE_BUILD.");
        }
        await finishOfficeLogin(d.user);
      } catch (x) { err(x.message || "Sign-in failed."); }
      finally {
        btn.disabled = false;
        btn.textContent = "Sign in";
      }
    });
  })();
})();
