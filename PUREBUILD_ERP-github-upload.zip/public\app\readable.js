/* Readability layer (p243): display-only CSS. Makes form labels/headers larger + bold, text darker, and the Invoice window full screen. Never touches data. */
(function(){
  var css=`
  /* Invoice window: full screen */
  #modal.pb-full .modalbox{width:min(1500px,97vw)!important;max-width:97vw!important;height:95vh!important;max-height:95vh!important}
  #modal.pb-full #modalBody{max-height:calc(95vh - 140px)!important}
  /* Form field headers: bigger, bold, dark */
  #modal label,#view .panel label,#view form label,#modal .field>span,#modal .muted-label{font-size:12.5px!important;font-weight:800!important;color:#1e293b!important;letter-spacing:.01em!important;text-transform:none!important}
  #modal h3,#modal h4,#modal .section-title,#modal b.section,#modalBody>h4,#modalBody strong{font-size:14.5px!important;font-weight:800!important;color:#0f2a4d!important}
  #modalTitle{font-size:20px!important;font-weight:800!important}
  /* Inputs: clearer text */
  #modal input,#modal select,#modal textarea,#view input:not([type=checkbox]):not([type=radio]),#view select,#view textarea{font-size:13.5px!important;color:#0f172a!important}
  #modal input::placeholder,#modal textarea::placeholder,#view input::placeholder{color:#7b8aa0!important}
  #modal input:not([type=checkbox]):not([type=radio]):not([type=file]),#modal select{min-height:38px!important}
  /* Tables: headers bold and bigger, cells readable (dashboard kept as one-screen design) */
  body:not(.dashboard-mode) #view th{font-size:12px!important;font-weight:800!important;color:#24364f!important}
  body:not(.dashboard-mode) #view td{font-size:13px!important;color:#14243b}
  #modal th{font-size:12.5px!important;font-weight:800!important;color:#24364f!important}
  #modal td{font-size:13.5px!important;color:#0f172a}
  /* Muted text darker so it is easier to read */
  body:not(.dark-theme) .muted,body:not(.dark-theme) small.muted{color:#56657c!important}
  body:not(.dashboard-mode) #view small{font-size:max(11.5px,1em)}
  @media print{#modal.pb-full .modalbox{height:auto!important}}
  `;
  var st=document.createElement('style');st.id='pb-readable';st.textContent=css;document.head.appendChild(st);
  var FULL=/^(Create Invoice|Edit Invoice)$/;
  function check(){var m=document.getElementById('modal'),t=document.getElementById('modalTitle');if(!m||!t)return;m.classList.toggle('pb-full',m.classList.contains('open')&&FULL.test((t.textContent||'').trim()))}
  function init(){var m=document.getElementById('modal');if(!m)return setTimeout(init,300);new MutationObserver(check).observe(m,{attributes:true,attributeFilter:['class'],subtree:true,childList:true,characterData:true});check()}
  init();
})();
