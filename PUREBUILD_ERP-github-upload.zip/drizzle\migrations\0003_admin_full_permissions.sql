UPDATE public.profiles p SET permissions = coalesce(p.permissions,'{}'::jsonb) || '{"manage_projects":true,"manage_boq":true,"manage_materials":true,"review_progress":true,"manage_staff":true,"submit_progress":true,"submit_attendance":true,"submit_materials":true,"submit_equipment":true,"submit_diary":true}'::jsonb
WHERE p.id IN (SELECT user_id FROM public.user_roles WHERE role = 'admin');

CREATE OR REPLACE FUNCTION public.pb_handle_new_user()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.profiles(id, display_name) VALUES (NEW.id, coalesce(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  IF lower(NEW.email) = 'nazimuddin7892023@gmail.com' THEN
    UPDATE public.profiles SET role = 'admin', status = 'active',
      permissions = '{"manage_projects":true,"manage_boq":true,"manage_materials":true,"review_progress":true,"manage_staff":true,"submit_progress":true,"submit_attendance":true,"submit_materials":true,"submit_equipment":true,"submit_diary":true}'::jsonb
    WHERE id = NEW.id;
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $function$;