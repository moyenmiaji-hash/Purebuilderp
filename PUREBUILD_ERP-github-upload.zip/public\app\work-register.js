/* Site Progress "Work Register": read-only serial list of every work update (office + foreman)
   for the selected project, ordered Building → Floor → Room → Date. Never writes saved data. */
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const bq = { bld: "", floor: "", room: "", st: "", q: "" };
  const ui = { bld: "", floor: "", room: "", src: "", from: "", to: "", q: "", group: true };
  const fx = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));

  const css = document.createElement("style");
  css.textContent = `
.wr-panel{padding:12px 14px!important}
.wr-top{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}
.wr-top h3{margin:0;font-size:16px;color:#12233d}.wr-top small{color:#64748b;font-size:12px;display:block;margin-top:2px}
.wr-acts{display:flex;gap:6px;flex-wrap:wrap}
.wr-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-bottom:10px}
.wr-kpis div{background:#f6f9fd;border:1px solid #e3e9f1;border-left:4px solid #1d4ed8;border-radius:10px;padding:7px 10px}
.wr-kpis div:nth-child(2){border-left-color:#16a34a}.wr-kpis div:nth-child(3){border-left-color:#d97706}.wr-kpis div:nth-child(4){border-left-color:#7c3aed}.wr-kpis div:nth-child(5){border-left-color:#0891b2}
.wr-kpis small{display:block;font-size:11px;font-weight:700;color:#5b6b7f;text-transform:uppercase}.wr-kpis b{font-size:17px;color:#12233d}
.wr-f{display:grid;grid-template-columns:repeat(7,minmax(0,1fr)) auto;gap:6px;margin-bottom:10px}
.wr-f select,.wr-f input{height:32px;border:1px solid #cfdcec;border-radius:8px;padding:0 8px;font-size:12px;min-width:0;background:#fff}
.wr-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}.wr-host>.panel{margin:0}
.wd-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px}
.wd-card{display:flex;gap:12px;align-items:center;text-align:left;background:#fff;border:1px solid #e3e9f1;border-radius:12px;padding:10px 12px;cursor:pointer;transition:.15s}
.wd-card:hover{border-color:#2563eb;box-shadow:0 6px 18px rgba(37,99,235,.12);transform:translateY(-1px)}
.wd-card h4{margin:0 0 3px;font-size:14px;color:#12233d}.wd-card small{display:block;font-size:11.5px;color:#64748b}
.wd-ring{flex:0 0 58px;height:58px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--c) calc(var(--p)*1%),#e5e7eb 0)}
.wd-ring b{width:44px;height:44px;border-radius:50%;background:#fff;display:grid;place-items:center;font-size:12.5px;color:#12233d}
.wd-3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.wd-3>.panel{margin:0}
.wd-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
.wd-list li{display:flex;justify-content:space-between;gap:8px;padding:7px 9px;border:1px solid #eef2f7;border-radius:9px;font-size:12.5px;color:#1e293b;cursor:pointer}
.wd-list li:hover{background:#f5f8fd}.wd-list li small{display:block;color:#64748b;font-size:11px;margin-top:2px}.wd-list li span{text-align:right;white-space:nowrap;font-size:12px}
.wd-list .wd-empty{color:#64748b;cursor:default;justify-content:center}
#view.pt-on .wd-3[data-pt].pt-show{display:grid!important}
#view.pt-on .trade-table,#view.pt-on .trade-table th,#view.pt-on .trade-table td{font-size:12.5px!important}
@media(max-width:1100px){.wd-3{grid-template-columns:1fr}}
body.dark-theme .wd-card,body.dark-theme .wd-ring b{background:#17283c;border-color:#344960}body.dark-theme .wd-card h4,body.dark-theme .wd-ring b,body.dark-theme .wd-list li{color:#e2ecf8}
.wr-wrap{overflow:auto;max-height:70vh;border:1px solid #e3e9f1;border-radius:10px}
.wr-wrap table{width:100%;border-collapse:collapse;font-size:12.5px}
.wr-wrap th{position:sticky;top:0;z-index:1;background:#14213d;color:#fff;text-align:left;padding:8px;font-size:11.5px;white-space:nowrap}
.wr-wrap td{padding:7px 8px;border-bottom:1px solid #eef2f7;vertical-align:top}
.wr-wrap td.r,.wr-wrap th.r{text-align:right;white-space:nowrap}
.wr-wrap tr.wr-g td{background:#eaf1fb;font-weight:800;color:#0f3d6e;font-size:12px;border-top:2px solid #c9d8ee}
.wr-wrap tr.wr-g td span{font-weight:600;color:#5b6b7f;margin-left:8px}
.wr-wrap tbody tr:not(.wr-g):hover td{background:#f5f8fd}
.wr-loc{font-size:11.5px;color:#334155;white-space:nowrap}.wr-loc b{color:#12233d}
.wr-tag{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10.5px;font-weight:800}
.wr-tag.of{background:#e0ecff;color:#1d4ed8}.wr-tag.fm{background:#fff1d6;color:#a35a00}
.wr-st{font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:9px;background:#e6f6ec;color:#15803d}.wr-st.p{background:#fff6dd;color:#a16207}.wr-st.x{background:#fde8e8;color:#b91c1c}
.wr-bar{height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden;margin-top:3px;min-width:60px}.wr-bar i{display:block;height:100%;background:#16a34a}
.wr-help{font-size:12px;color:#475569;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:9px;padding:7px 10px;margin-bottom:10px}
@media(max-width:1100px){.wr-f{grid-template-columns:repeat(3,minmax(0,1fr))}.wr-kpis{grid-template-columns:repeat(2,1fr)}}
.wr-wrap td{color:#1e293b}.wr-wrap tr.wr-g td{color:#0f3d6e!important}body.dark-theme .wr-wrap tr:not(.wr-g) td,body.dark-theme .wr-loc,body.dark-theme .wr-loc b{color:#e2ecf8}
body.dark-theme .wr-top h3,body.dark-theme .wr-kpis b{color:#e2ecf8}body.dark-theme .wr-kpis div,body.dark-theme .wr-help{background:#17283c;border-color:#344960;color:#cbd5e1}
`;
  document.head.appendChild(css);

  function boqOf(x) { return (db.boq || []).find((b) => b.id === x.boqId || (x.boqCode && b.boqId === x.boqCode && b.projectId === x.projectId)); }
  function rows() {
    const pid = selectedProject;
    return (db.progress || []).filter((x) => x.projectId === pid && (n(x.todayQty) > 0 || x.boqId)).map((x, i) => {
      const b = boqOf(x) || {};
      const bld = x.building || b.building || "General";
      const fl = x.floor || b.floor || "—";
      const rm = x.room || b.area || b.room || "—";
      const office = x.source === "stage-update" || x.source === "room-entry" || (!String(x.id || "").startsWith("cloud-") && !x.sourceReportId && x.source !== "foreman" && x.source !== "Foreman" && !x.cloudReportId);
      const fromCloud = String(x.id || "").startsWith("cloud-") || x.cloudReportId;
      const st = x.approvalStatus || "Approved";
      const qty = n(b.qty);
      return { x, i, bld, fl, rm, boqCode: x.boqCode || b.boqId || "—", work: x.title || b.description || "Work", unit: x.unit || b.unit || "",
        today: n(x.todayQty), total: n(x.totalCompleted), qty, pct: qty ? Math.min(100, (n(x.totalCompleted) / qty) * 100) : n(x.percent),
        by: x.submittedBy || x.foreman || "—", src: fromCloud || !office ? "Foreman" : "Office", st, value: n(x.todayQty) * n(x.rate || b.rate), date: String(x.date || "") };
    });
  }
  function filtered(all) {
    const q = ui.q.trim().toLowerCase();
    return all.filter((r) => (!ui.bld || r.bld === ui.bld) && (!ui.floor || r.fl === ui.floor) && (!ui.room || r.rm === ui.room) && (!ui.src || r.src === ui.src)
      && (!ui.from || r.date >= ui.from) && (!ui.to || r.date <= ui.to)
      && (!q || [r.bld, r.fl, r.rm, r.boqCode, r.work, r.by, r.date].join(" ").toLowerCase().includes(q)))
      .sort((a, b) => a.bld.localeCompare(b.bld, undefined, { numeric: true }) || a.fl.localeCompare(b.fl, undefined, { numeric: true }) || a.rm.localeCompare(b.rm, undefined, { numeric: true }) || a.date.localeCompare(b.date) || a.i - b.i);
  }
  const uniq = (arr) => [...new Set(arr)].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  const opt = (list, cur, all) => `<option value="">${all}</option>` + list.map((v) => `<option ${v === cur ? "selected" : ""}>${E(v)}</option>`).join("");

  function stTag(s) { const p = /submit|pending/i.test(s), x = /reject|return/i.test(s); return `<span class="wr-st ${p ? "p" : x ? "x" : ""}">${E(p ? "Pending" : s)}</span>`; }

  function tableHtml(list) {
    if (!list.length) return `<tr><td colspan="12" style="text-align:center;color:#64748b;padding:22px">No work updates yet for this filter. Use “＋ Add Work Update” to enter one.</td></tr>`;
    let html = "", key = "", sl = 0;
    list.forEach((r) => {
      const k = r.bld + "|" + r.fl + "|" + r.rm;
      if (ui.group && k !== key) {
        key = k;
        const g = list.filter((z) => z.bld + "|" + z.fl + "|" + z.rm === k);
        html += `<tr class="wr-g"><td colspan="12">🏢 ${E(r.bld)} › ${E(r.fl)} › ${E(r.rm)}<span>${g.length} update(s)</span></td></tr>`;
      }
      sl++;
      html += `<tr><td>${sl}</td><td style="white-space:nowrap">${E(r.date)}</td><td class="wr-loc"><b>${E(r.bld)}</b><br>${E(r.fl)} · ${E(r.rm)}</td><td><b>${E(r.boqCode)}</b></td><td>${E(r.work)}</td>
        <td class="r"><b>${fx(r.today)}</b> ${E(r.unit)}</td><td class="r">${fx(r.total)}${r.qty ? " / " + fx(r.qty) : ""}</td><td class="r">${r.pct.toFixed(1)}%<div class="wr-bar"><i style="width:${r.pct}%"></i></div></td>
        <td class="r">${typeof money === "function" ? money(r.value) : fx(r.value)}</td><td>${E(r.by)}</td><td><span class="wr-tag ${r.src === "Office" ? "of" : "fm"}">${r.src}</span></td><td>${stTag(r.st)}</td></tr>`;
    });
    return html;
  }

  function html() {
    const all = rows(), list = filtered(all);
    const p = (db.projects || []).find((x) => x.id === selectedProject) || {};
    const bl = uniq(all.map((r) => r.bld)), fl = uniq(all.filter((r) => !ui.bld || r.bld === ui.bld).map((r) => r.fl)), rl = uniq(all.filter((r) => (!ui.bld || r.bld === ui.bld) && (!ui.floor || r.fl === ui.floor)).map((r) => r.rm));
    const rooms = new Set(list.map((r) => r.bld + r.fl + r.rm)).size;
    const val = list.reduce((s, r) => s + r.value, 0);
    return `<div class="panel wr-panel" data-pt="daily">
<div class="wr-top"><div><h3>📋 Daily &amp; Task Work Progress — ${E(p.name || "Project")}</h3><small>Every work update, serial by Building → Floor → Room → Date. Office and foreman updates in one list.</small></div>
<div class="wr-acts"><button class="btn primary" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ Add Work Update</button><button class="btn" onclick="PB_WORK_REGISTER.csv()">CSV</button><button class="btn" onclick="PB_WORK_REGISTER.print()">Print</button></div></div>
<div class="wr-help">ℹ “＋ Add Work Update” opens the same form foremen use (quantity, photos, materials, labour, equipment). After saving, the update appears here in its building/floor/room serial.</div>
<div class="wr-kpis"><div><small>Updates</small><b>${list.length}</b></div><div><small>Rooms worked</small><b>${rooms}</b></div><div><small>Office entries</small><b>${list.filter((r) => r.src === "Office").length}</b></div><div><small>Foreman entries</small><b>${list.filter((r) => r.src === "Foreman").length}</b></div><div><small>Work value</small><b>${typeof money === "function" ? money(val) : fx(val)}</b></div></div>
<div class="wr-f"><select id="wrB">${opt(bl, ui.bld, "All Buildings")}</select><select id="wrFl">${opt(fl, ui.floor, "All Floors")}</select><select id="wrR">${opt(rl, ui.room, "All Rooms")}</select>
<select id="wrS"><option value="">Office + Foreman</option><option ${ui.src === "Office" ? "selected" : ""}>Office</option><option ${ui.src === "Foreman" ? "selected" : ""}>Foreman</option></select>
<input type="date" id="wrFrom" value="${E(ui.from)}" title="From"><input type="date" id="wrTo" value="${E(ui.to)}" title="To"><input id="wrQ" placeholder="Search BOQ, work, name…" value="${E(ui.q)}">
<button class="btn small" id="wrReset">Reset</button></div>
<div class="wr-wrap pbpg-skip"><table><thead><tr><th>SL</th><th>Date</th><th>Building / Floor / Room</th><th>BOQ ID</th><th>Work</th><th class="r">Today Qty</th><th class="r">Done / BOQ</th><th class="r">Progress</th><th class="r">Value</th><th>By</th><th>Source</th><th>Status</th></tr></thead><tbody id="wrBody">${tableHtml(list)}</tbody></table></div></div>`;
  }


  // ---------- BOQ Work Progress ----------
  function boqRows() {
    const pid = selectedProject, pb = typeof progressBuilding !== "undefined" ? progressBuilding : "";
    const pname = ((db.projects || []).find((x) => x.id === pid) || {}).name || "Project";
    const last = {}; (db.progress || []).forEach((x) => { if (x.projectId === pid && n(x.todayQty) > 0) { const k = x.boqId; if (!last[k] || String(x.date) > last[k]) last[k] = String(x.date); } });
    return (db.boq || []).filter((b) => b.projectId === pid && (typeof matchBuilding !== "function" || matchBuilding(b, pb))).map((b, i) => {
      const qty = n(b.qty), done = Math.min(qty || Infinity, n(b.executedQty)), pc = qty ? Math.min(100, (n(b.executedQty) / qty) * 100) : 0;
      const st = pc >= 100 ? "Completed" : n(b.executedQty) > 0 ? "In Progress" : "Not Started";
      return { b, i, pname, bld: b.building || "General", fl: b.floor || "—", rm: b.area || b.room || "—", code: b.boqId || "—", work: b.description || "Work", unit: b.unit || "",
        qty, done: n(b.executedQty), rem: Math.max(0, qty - n(b.executedQty)), pc, st, last: last[b.id] || last[b.boqId] || "", appr: !["Draft", "Under Review", "Submitted"].includes(b.status) };
    });
  }
  function boqFiltered(all) {
    const q = bq.q.trim().toLowerCase(), c = (a, b) => a.localeCompare(b, undefined, { numeric: true });
    return all.filter((r) => (!bq.bld || r.bld === bq.bld) && (!bq.floor || r.fl === bq.floor) && (!bq.room || r.rm === bq.room) && (!bq.st || r.st === bq.st)
      && (!q || [r.bld, r.fl, r.rm, r.code, r.work].join(" ").toLowerCase().includes(q)))
      .sort((a, b) => c(a.bld, b.bld) || c(a.fl, b.fl) || c(a.rm, b.rm) || c(a.code, b.code) || a.i - b.i);
  }
  function boqBody(list) {
    if (!list.length) return `<tr><td colspan="11" style="text-align:center;color:#64748b;padding:22px">No BOQ work for this filter.</td></tr>`;
    let h = "", key = "", sl = 0;
    list.forEach((r) => {
      const k = r.bld + "|" + r.fl + "|" + r.rm;
      if (k !== key) { key = k; const g = list.filter((z) => z.bld + "|" + z.fl + "|" + z.rm === k), gq = g.reduce((s, z) => s + z.pc, 0) / g.length;
        h += `<tr class="wr-g"><td colspan="11">🏗 ${E(r.pname)} › 🏢 ${E(r.bld)} › ${E(r.fl)} › ${E(r.rm)}<span>${g.length} work item(s) · ${gq.toFixed(0)}% done</span></td></tr>`; }
      sl++;
      const cls = r.st === "Completed" ? "" : r.st === "In Progress" ? "p" : "x";
      h += `<tr><td>${sl}</td><td><b>${E(r.code)}</b></td><td>${E(r.work)}</td><td>${E(r.unit)}</td><td class="r">${fx(r.qty)}</td><td class="r"><b>${fx(r.done)}</b></td><td class="r">${fx(r.rem)}</td>
        <td class="r">${r.pc.toFixed(1)}%<div class="wr-bar"><i style="width:${r.pc}%"></i></div></td><td style="white-space:nowrap">${E(r.last || "—")}</td><td><span class="wr-st ${cls}">${r.st}</span></td>
        <td>${r.appr && r.rem > 0 ? `<button class="btn small primary" onclick="PB_WORK_REGISTER.update('${E(r.b.id)}')">Update</button>` : r.appr ? "✔" : '<small style="color:#a16207">Not approved</small>'}</td></tr>`;
    });
    return h;
  }
  function boqHtml() {
    const all = boqRows(), list = boqFiltered(all);
    const bl = uniq(all.map((r) => r.bld)), fl = uniq(all.filter((r) => !bq.bld || r.bld === bq.bld).map((r) => r.fl)), rl = uniq(all.filter((r) => (!bq.bld || r.bld === bq.bld) && (!bq.floor || r.fl === bq.floor)).map((r) => r.rm));
    const cnt = (s) => list.filter((r) => r.st === s).length, tq = list.reduce((s, r) => s + r.pc, 0) / (list.length || 1);
    return `<div class="panel wr-panel" data-pt="boqwork">
<div class="wr-top"><div><h3>📐 BOQ Work Progress</h3><small>All BOQ work in serial: Project → Building → Floor → Room → Work. Click “Update” to enter today's work — same form the foremen use. Approved foreman updates add here automatically.</small></div>
<div class="wr-acts"><button class="btn primary" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ Manual Update</button></div></div>
<div class="wr-kpis"><div><small>Work items</small><b>${list.length}</b></div><div><small>Completed</small><b>${cnt("Completed")}</b></div><div><small>In progress</small><b>${cnt("In Progress")}</b></div><div><small>Not started</small><b>${cnt("Not Started")}</b></div><div><small>Average progress</small><b>${tq.toFixed(1)}%</b></div></div>
<div class="wr-f" style="grid-template-columns:repeat(5,minmax(0,1fr)) auto"><select id="bqB">${opt(bl, bq.bld, "All Buildings")}</select><select id="bqF">${opt(fl, bq.floor, "All Floors")}</select><select id="bqR">${opt(rl, bq.room, "All Rooms")}</select>
<select id="bqS"><option value="">All Status</option>${["Not Started", "In Progress", "Completed"].map((x) => `<option ${x === bq.st ? "selected" : ""}>${x}</option>`).join("")}</select><input id="bqQ" placeholder="Search BOQ ID or work…" value="${E(bq.q)}"><button class="btn small" id="bqReset">Reset</button></div>
<div class="wr-wrap pbpg-skip"><table><thead><tr><th>SL</th><th>BOQ ID</th><th>Work</th><th>Unit</th><th class="r">BOQ Qty</th><th class="r">Done</th><th class="r">Remaining</th><th class="r">Progress</th><th>Last Update</th><th>Status</th><th></th></tr></thead><tbody id="bqBody">${boqBody(list)}</tbody></table></div></div>`;
  }
  function update(boqId) {
    if (!window.PB_DAILY_UPDATE) return;
    PB_DAILY_UPDATE.open();
    setTimeout(() => { const s = document.getElementById("duBoq"); if (s) { s.value = boqId; s.dispatchEvent(new Event("change", { bubbles: true })); } }, 60);
  }
  function tasksHtml() {
    const S = window.PB_TASKS_STATE, list = S && S.loaded ? (S.tasks || []).filter((t) => t.local_project_id === selectedProject) : null;
    const body = !list ? `<div class="wr-help">Foreman task list loads from Task Management. <button class="btn small" onclick="setPage('tasks')">Open Task Management</button></div>`
      : !list.length ? `<div class="wr-help">No foreman tasks for this project yet. <button class="btn small" onclick="setPage('tasks')">Assign a task</button></div>`
      : `<div class="wr-wrap pbpg-skip" style="max-height:300px"><table><thead><tr><th>Task</th><th>Location</th><th>Work</th><th class="r">Target</th><th>Due</th><th>Status</th></tr></thead><tbody>${list.slice().sort((a, b) => String(a.building || "").localeCompare(String(b.building || "")) || String(a.floor || "").localeCompare(String(b.floor || "")) || String(a.location || "").localeCompare(String(b.location || ""))).map((t) => `<tr><td><b>TSK-${String(t.task_no || 0).padStart(3, "0")}</b></td><td class="wr-loc"><b>${E(t.building || "General")}</b><br>${E(t.floor || "—")} · ${E(t.location || "—")}</td><td>${E(t.title)}</td><td class="r">${fx(t.target_qty)} ${E(t.unit)}</td><td>${E(t.due_date)}</td><td><span class="wr-st ${/complete/i.test(t.status) ? "" : "p"}">${E(t.status)}</span></td></tr>`).join("")}</tbody></table></div>`;
    return `<div class="panel wr-panel" data-pt="daily"><div class="wr-top"><div><h3>🎯 Foreman Tasks</h3><small>Tasks given to foremen for this project. Their approved updates appear in the list above.</small></div><div class="wr-acts"><button class="btn" onclick="setPage('tasks')">Task Management</button></div></div>${body}</div>`;
  }


  // ---------- Dashboard extras ----------
  function dashHtml() {
    const all = boqRows(); if (!all.length) return "";
    const by = {}; all.forEach((r) => { (by[r.bld] = by[r.bld] || []).push(r); });
    const cards = Object.keys(by).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map((k) => {
      const g = by[k], v = g.reduce((s, r) => s + r.qty * n(r.b.rate), 0), d = g.reduce((s, r) => s + Math.min(r.qty, r.done) * n(r.b.rate), 0);
      const pc = v ? (d / v) * 100 : g.reduce((s, r) => s + r.pc, 0) / g.length, fl = new Set(g.map((r) => r.fl)).size, rm = new Set(g.map((r) => r.fl + r.rm)).size;
      const col = pc >= 100 ? "#16a34a" : pc >= 50 ? "#2563eb" : pc > 0 ? "#d97706" : "#94a3b8";
      return `<button class="wd-card" onclick="PB_WORK_REGISTER.goBld('${E(k)}')"><div class="wd-ring" style="--p:${pc.toFixed(1)};--c:${col}"><b>${pc.toFixed(0)}%</b></div><div><h4>🏢 ${E(k)}</h4><small>${fl} floor(s) · ${rm} room(s) · ${g.length} work</small><small>${g.filter((r) => r.st === "Completed").length} done · ${g.filter((r) => r.st === "In Progress").length} running · ${g.filter((r) => r.st === "Not Started").length} not started</small></div></button>`;
    }).join("");
    const recent = rows().sort((a, b) => b.date.localeCompare(a.date) || b.i - a.i).slice(0, 7);
    const t = new Date(); t.setDate(t.getDate() - 7); const wk = t.toISOString().slice(0, 10);
    const stalled = all.filter((r) => r.st === "In Progress" && r.last && r.last < wk).sort((a, b) => a.last.localeCompare(b.last)).slice(0, 6);
    const top = all.filter((r) => r.rem > 0).sort((a, b) => b.rem * n(b.b.rate) - a.rem * n(a.b.rate)).slice(0, 6);
    const li = (r, right) => `<li onclick="PB_WORK_REGISTER.update('${E(r.b.id)}')"><div><b>${E(r.code)}</b> ${E(r.work)}<small>${E(r.bld)} › ${E(r.fl)} › ${E(r.rm)}</small></div><span>${right}</span></li>`;
    return `<div class="panel wr-panel" data-pt="overview"><div class="wr-top"><div><h3>🏢 Building-wise Progress</h3><small>Click a building to see its work list in serial.</small></div></div><div class="wd-cards">${cards}</div></div>
<div class="wd-3" data-pt="overview">
<div class="panel wr-panel"><div class="wr-top"><h3>🕒 Latest Updates</h3><button class="btn small" onclick="PB_PROGRESS_TABS_SET('daily')">View all</button></div><ul class="wd-list">${recent.map((r) => `<li><div><b>${E(r.code)}</b> ${E(r.work)}<small>${E(r.date)} · ${E(r.bld)} › ${E(r.fl)} › ${E(r.rm)} · ${E(r.by)}</small></div><span><b>+${fx(r.today)}</b> ${E(r.unit)}<br><i class="wr-tag ${r.src === "Office" ? "of" : "fm"}">${r.src}</i></span></li>`).join("") || '<li class="wd-empty">No updates yet.</li>'}</ul></div>
<div class="panel wr-panel"><div class="wr-top"><h3>⏸ No update in 7+ days</h3></div><ul class="wd-list">${stalled.map((r) => li(r, `last ${E(r.last)}<br><b>${r.pc.toFixed(0)}%</b>`)).join("") || '<li class="wd-empty">All running work updated this week 👍</li>'}</ul></div>
<div class="panel wr-panel"><div class="wr-top"><h3>💰 Biggest remaining work</h3></div><ul class="wd-list">${top.map((r) => li(r, `${typeof money === "function" ? money(r.rem * n(r.b.rate)) : fx(r.rem)}<br><small>${fx(r.rem)} ${E(r.unit)} left</small>`)).join("") || '<li class="wd-empty">All work completed 🎉</li>'}</ul></div>
</div>`;
  }
  function goBld(b) { bq.bld = b; bq.floor = ""; bq.room = ""; window.PB_PROGRESS_TABS_SET && PB_PROGRESS_TABS_SET("boqwork"); refresh(); }

  function inject(v) {
    v.querySelectorAll(".wr-host").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum || !selectedProject) return;
    const host = document.createElement("div"); host.className = "wr-host";
    try { host.innerHTML = dashHtml() + boqHtml() + html() + tasksHtml(); } catch (e) { console.warn("work-register", e); return; }
    (v.querySelector(".pp-host") || sum).insertAdjacentElement("afterend", host);
    const on = (id, ev, fn) => host.querySelector(id)?.addEventListener(ev, fn);
    on("#bqB", "change", (e) => { bq.bld = e.target.value; bq.floor = ""; bq.room = ""; refresh(); });
    on("#bqF", "change", (e) => { bq.floor = e.target.value; bq.room = ""; refresh(); });
    on("#bqR", "change", (e) => { bq.room = e.target.value; refresh(); });
    on("#bqS", "change", (e) => { bq.st = e.target.value; refresh(); });
    on("#bqReset", "click", () => { Object.assign(bq, { bld: "", floor: "", room: "", st: "", q: "" }); refresh(); });
    let tb; on("#bqQ", "input", (e) => { bq.q = e.target.value; clearTimeout(tb); tb = setTimeout(() => { const b = document.getElementById("bqBody"); if (b) b.innerHTML = boqBody(boqFiltered(boqRows())); }, 200); });
    on("#wrB", "change", (e) => { ui.bld = e.target.value; ui.floor = ""; ui.room = ""; refresh(); });
    on("#wrFl", "change", (e) => { ui.floor = e.target.value; ui.room = ""; refresh(); });
    on("#wrR", "change", (e) => { ui.room = e.target.value; refresh(); });
    on("#wrS", "change", (e) => { ui.src = e.target.value; refresh(); });
    on("#wrFrom", "change", (e) => { ui.from = e.target.value; refresh(); });
    on("#wrTo", "change", (e) => { ui.to = e.target.value; refresh(); });
    on("#wrReset", "click", () => { Object.assign(ui, { bld: "", floor: "", room: "", src: "", from: "", to: "", q: "" }); refresh(); });
    let tm; on("#wrQ", "input", (e) => { ui.q = e.target.value; clearTimeout(tm); tm = setTimeout(() => { const b = document.getElementById("wrBody"); if (b) b.innerHTML = tableHtml(filtered(rows())); }, 200); });
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }

  function csv() {
    const list = filtered(rows());
    const head = ["SL", "Date", "Building", "Floor", "Room", "BOQ ID", "Work", "Today Qty", "Unit", "Total Done", "BOQ Qty", "Progress %", "Value AED", "By", "Source", "Status"];
    const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
    const body = list.map((r, i) => [i + 1, r.date, r.bld, r.fl, r.rm, r.boqCode, r.work, r.today, r.unit, r.total, r.qty, r.pct.toFixed(1), r.value.toFixed(2), r.by, r.src, r.st].map(q).join(","));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + [head.map(q).join(","), ...body].join("\n")], { type: "text/csv" }));
    a.download = "work-register.csv"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  function print() {
    const list = filtered(rows()), s = db.settings || {}, p = (db.projects || []).find((x) => x.id === selectedProject) || {};
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0;right:0;bottom:0"; document.body.appendChild(f);
    const d = f.contentDocument;
    d.open(); d.write(`<html><head><title>Work Register</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Arial,sans-serif;font-size:10.5px;color:#111}h1{font-size:17px;margin:0}h2{font-size:13px;margin:2px 0 10px;color:#334}table{width:100%;border-collapse:collapse}th{background:#14213d;color:#fff;padding:5px;text-align:left}td{padding:4px 5px;border-bottom:1px solid #ddd}tr.g td{background:#eaf1fb;font-weight:bold}thead{display:table-header-group}.r{text-align:right}</style></head><body>
<h1>${E(s.companyName || "PURE_BUILD")}</h1><h2>Work Register — ${E(p.name || "")} · ${new Date().toISOString().slice(0, 10)}</h2>
<table><thead><tr><th>SL</th><th>Date</th><th>Location</th><th>BOQ</th><th>Work</th><th class="r">Today</th><th class="r">Done/BOQ</th><th class="r">%</th><th>By</th><th>Source</th><th>Status</th></tr></thead><tbody>
${(() => { let k = "", h = ""; list.forEach((r, i) => { const kk = r.bld + r.fl + r.rm; if (kk !== k) { k = kk; h += `<tr class="g"><td colspan="11">${E(r.bld)} › ${E(r.fl)} › ${E(r.rm)}</td></tr>`; } h += `<tr><td>${i + 1}</td><td>${E(r.date)}</td><td>${E(r.bld)} / ${E(r.fl)} / ${E(r.rm)}</td><td>${E(r.boqCode)}</td><td>${E(r.work)}</td><td class="r">${fx(r.today)} ${E(r.unit)}</td><td class="r">${fx(r.total)}${r.qty ? " / " + fx(r.qty) : ""}</td><td class="r">${r.pct.toFixed(1)}</td><td>${E(r.by)}</td><td>${r.src}</td><td>${E(r.st)}</td></tr>`; }); return h || '<tr><td colspan="11">No updates.</td></tr>'; })()}
</tbody></table></body></html>`); d.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  window.PB_WORK_REGISTER = { inject, csv, print, rows, update, goBld };
})();
