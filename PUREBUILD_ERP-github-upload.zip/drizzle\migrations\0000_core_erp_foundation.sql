CREATE TYPE public.app_role AS ENUM ('admin','manager','accountant','auditor','staff');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  display_name text,
  role text NOT NULL DEFAULT 'staff',
  status text NOT NULL DEFAULT 'active',
  permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.is_office_user(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','manager','accountant'))
$$;

CREATE POLICY "Users read own profile" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update profiles" ON public.profiles FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.erp_cloud_state (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  data jsonb NOT NULL,
  revision int NOT NULL DEFAULT 1,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.erp_cloud_state TO authenticated;
GRANT ALL ON public.erp_cloud_state TO service_role;
ALTER TABLE public.erp_cloud_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office users read ERP data" ON public.erp_cloud_state FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()));

CREATE TABLE public.erp_state_history (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  revision int NOT NULL,
  data jsonb NOT NULL,
  saved_by uuid,
  saved_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.erp_state_history TO service_role;
ALTER TABLE public.erp_state_history ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.erp_state_save(p_expected int, p_data jsonb)
RETURNS int LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE cur public.erp_cloud_state; nrev int;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'NOT_ALLOWED'; END IF;
  IF p_data IS NULL OR coalesce(jsonb_array_length(p_data->'projects'),0) = 0
     AND coalesce(jsonb_array_length(p_data->'transactions'),0) = 0 THEN
    RAISE EXCEPTION 'EMPTY_OVERWRITE_BLOCKED';
  END IF;
  SELECT * INTO cur FROM public.erp_cloud_state WHERE id = 1 FOR UPDATE;
  IF NOT FOUND THEN
    IF coalesce(p_expected,0) <> 0 THEN RAISE EXCEPTION 'REVISION_CONFLICT'; END IF;
    INSERT INTO public.erp_cloud_state(id,data,revision,updated_by) VALUES (1,p_data,1,auth.uid());
    RETURN 1;
  END IF;
  IF cur.revision <> p_expected THEN RAISE EXCEPTION 'REVISION_CONFLICT'; END IF;
  INSERT INTO public.erp_state_history(revision,data,saved_by) VALUES (cur.revision,cur.data,cur.updated_by);
  nrev := cur.revision + 1;
  UPDATE public.erp_cloud_state SET data=p_data, revision=nrev, updated_by=auth.uid(), updated_at=now() WHERE id=1;
  RETURN nrev;
END $$;
REVOKE EXECUTE ON FUNCTION public.erp_state_save(int,jsonb) FROM anon;
GRANT EXECUTE ON FUNCTION public.erp_state_save(int,jsonb) TO authenticated;