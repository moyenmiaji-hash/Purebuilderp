import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

// Loads the real Accounts Payable helpers from the app so tests check the code users run.
const html = readFileSync(resolve(__dirname, "../../public/app/erp.html"), "utf8");
function grab(name: string) {
  const start = html.indexOf(`function ${name}(`);
  if (start < 0) throw new Error("missing " + name);
  let i = html.indexOf("{", start), depth = 0;
  for (; i < html.length; i++) {
    if (html[i] === "{") depth++;
    else if (html[i] === "}" && --depth === 0) break;
  }
  return html.slice(start, i + 1);
}
const src = ["apPaidAmount", "apCreditedAmount", "apOutstandingAmount", "apPayableStatus", "apIsPosted", "apHasInvoiceNumber", "apHasOutstanding", "apCanPay"].map(grab).join("\n");

function load(transactions: any[]) {
  const factory = new Function("db", `let apPostingTotalsCache=null,apPostingTotalsSource=null,apPostingTotalsLength=-1;${src};return {apPaidAmount,apCreditedAmount,apOutstandingAmount,apPayableStatus,apCanPay};`);
  return factory({ transactions });
}
const bill = { id: "b1", amount: 1000, apStatus: "Posted", invoiceNo: "INV-1", paid: 0 };
const pay = (amount: number, extra: any = {}) => ({ type: "Supplier Payment", status: "Paid", payableId: "b1", amount, ...extra });

describe("Accounts Payable balances", () => {
  it("partial payment leaves the rest outstanding", () => {
    const ap = load([pay(400)]);
    expect(ap.apOutstandingAmount(bill)).toBe(600);
    expect(ap.apPayableStatus(bill)).toBe("Partially Paid");
  });
  it("two payments that add up to the bill make it Paid", () => {
    const ap = load([pay(400), pay(600)]);
    expect(ap.apOutstandingAmount(bill)).toBe(0);
    expect(ap.apPayableStatus(bill)).toBe("Paid");
    expect(ap.apCanPay(bill)).toBe(false);
  });
  it("a reversed payment brings the balance back", () => {
    const ap = load([pay(400), { type: "Supplier Payment Reversal", status: "Posted", payableId: "b1", amount: 400 }]);
    expect(ap.apOutstandingAmount(bill)).toBe(1000);
  });
  it("a credit note reduces the outstanding balance", () => {
    const ap = load([pay(400), { type: "Supplier Credit Note", status: "Posted", payableId: "b1", amount: 100 }]);
    expect(ap.apOutstandingAmount(bill)).toBe(500);
  });
  it("draft payments are not counted", () => {
    const ap = load([pay(400, { status: "Draft" })]);
    expect(ap.apOutstandingAmount(bill)).toBe(1000);
  });
  it("paid amount never goes above the bill total", () => {
    const ap = load([pay(1500)]);
    expect(ap.apPaidAmount(bill)).toBe(1000);
  });
  it("unposted bills cannot be paid", () => {
    const ap = load([]);
    expect(ap.apCanPay({ ...bill, apStatus: "Submitted" })).toBe(false);
    expect(ap.apCanPay({ ...bill, apStatus: "Draft" })).toBe(false);
    expect(ap.apCanPay(bill)).toBe(true);
  });
});
