import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const src = readFileSync(path.resolve(__dirname, "../../public/app/stage-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const c = box["PB_STAGE_CALC"];
const painting = [{ name: "Primer", weight: 5 }, { name: "1st Stucco", weight: 20 }, { name: "2nd Stucco", weight: 20 }, { name: "Sanding", weight: 5 }, { name: "1st Paint", weight: 20 }, { name: "Final Paint", weight: 20 }, { name: "Snagging", weight: 10 }];

describe("weighted stage progress", () => {
  it("stage weights must total 100%", () => {
    expect(c.validStages(painting)).toBe("");
    expect(c.validStages([{ name: "A", weight: 60 }, { name: "B", weight: 30 }])).toMatch(/100%/);
  });
  it("overall is weighted, not averaged", () => {
    const r = c.compute(painting, {}, { Primer: 100, "1st Stucco": 50 });
    expect(r.overall).toBeCloseTo(15); // 5 + 10, a plain average would be 75
  });
  it("today % cannot push a stage above 100%", () => {
    const r = c.compute(painting, { Primer: 80 }, { Primer: 50 });
    expect(r.rows[0].updated).toBe(100);
    expect(r.today).toBeCloseTo(1);
  });
  it("qty added never exceeds approved BOQ and never goes negative", () => {
    expect(c.qtyToAdd(15, 200, 0)).toBeCloseTo(30);
    expect(c.qtyToAdd(15, 200, 50)).toBe(0);
    expect(c.qtyToAdd(150, 200, 190)).toBeCloseTo(10);
  });
});
