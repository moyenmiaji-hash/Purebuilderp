// Audit Trail panel on the Access page. Read-only; data comes from the cloud audit_log table.
const PAGE_SIZE = 50;
let pageNo = 0;
let rows = [];
let total = 0;
let msg = "";
const f = { from: "", to: "", user: "", project: "", module: "", action: "", record: "" };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function diff(o, n) {
  const keys = [...new Set([...Object.keys(o || {}), ...Object.keys(n || {})])];
  return keys.filter((k) => JSON.stringify(o?.[k]) !== JSON.stringify(n?.[k]))
    .map((k) => `<div><b>${esc(k)}</b>: <span style="color:#b91c1c">${esc(JSON.stringify(o?.[k] ?? ""))}</span> → <span style="color:#15803d">${esc(JSON.stringify(n?.[k] ?? ""))}</span></div>`)
    .join("") || "—";
}

function query(client) {
  let q = client.from("audit_log").select("*", { count: "exact" }).order("created_at", { ascending: false });
  if (f.from) q = q.gte("created_at", f.from);
  if (f.to) q = q.lte("created_at", f.to + "T23:59:59");
  if (f.user) q = q.eq("actor_id", f.user);
  if (f.project) q = q.ilike("project_id", `%${f.project}%`);
  if (f.module) q = q.eq("module", f.module);
  if (f.action) q = q.eq("action", f.action);
  if (f.record) q = q.ilike("record_id", `%${f.record}%`);
  return q;
}

async function load() {
  const client = window.PB_CLOUD_CLIENT;
  if (!client) { msg = "Cloud not connected."; return draw(); }
  const { data: s } = await client.auth.getSession();
  if (!s.session) { msg = "Sign in to view the Audit Trail."; return draw(); }
  const { data, error, count } = await query(client).range(pageNo * PAGE_SIZE, pageNo * PAGE_SIZE + PAGE_SIZE - 1);
  if (error) {
    msg = /audit_log|relation|schema cache/i.test(error.message)
      ? "Audit Trail is not switched on yet in the Cloud (Stage 1 setup pending)."
      : `Could not load: ${error.message}`;
    rows = []; total = 0;
  } else { msg = data.length ? "" : "No audit entries found (only Admin/Auditor can see them)."; rows = data; total = count || 0; }
  draw();
}

async function exportAll() {
  const client = window.PB_CLOUD_CLIENT;
  const { data, error } = await query(client).limit(5000);
  if (error || !window.XLSX) return alert("Export not available.");
  const sheet = XLSX.utils.json_to_sheet(data.map((r) => ({
    Time: r.created_at, User: r.actor_id, Role: r.actor_role, Project: r.project_id, Module: r.module,
    Record: r.record_id, Action: r.action, Old: JSON.stringify(r.old_values || ""), New: JSON.stringify(r.new_values || ""), Reason: r.reason, Status: r.status,
  })));
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, "Audit Trail");
  XLSX.writeFile(book, `PURE_BUILD_Audit_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

function draw() {
  const el = document.getElementById("pb-audit-trail");
  if (!el) return;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const inp = (k, ph, type = "text") => `<input data-af="${k}" type="${type}" placeholder="${ph}" value="${esc(f[k])}" style="height:34px;padding:0 8px;border:1px solid #cbd5e1;border-radius:8px">`;
  el.innerHTML = `${window.pbUserAuditHtml?.() || ""}
  <div class="card" style="margin-top:14px;padding:14px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
      <h3 style="margin:0">Audit Trail</h3>
      <div style="display:flex;gap:6px"><button class="btn" data-aa="refresh">Search</button><button class="btn" data-aa="export">Export Excel</button></div>
    </div>
    <div class="pb-audit-filters" style="display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:6px;margin:10px 0">
      ${inp("from", "From", "date")}${inp("to", "To", "date")}${inp("user", "User ID")}${inp("project", "Project")}
      <select data-af="module" style="height:34px;border-radius:8px"><option value="">All modules</option>${["projects","transactions","boq","invoices","quotations","payables","stock","employees","progress","dailyReports","runningBills","projectLocations","user_management"].map((m) => `<option ${f.module === m ? "selected" : ""}>${m}</option>`).join("")}</select>
      <select data-af="action" style="height:34px;border-radius:8px"><option value="">All actions</option>${["create","update","delete","void","approve","reject","permission_change"].map((m) => `<option ${f.action === m ? "selected" : ""}>${m}</option>`).join("")}</select>
      ${inp("record", "Record ID")}
    </div>
    ${msg ? `<div class="notice">${esc(msg)}</div>` : ""}
    ${rows.length ? `<div style="overflow:auto"><table class="table" style="font-size:12px"><thead><tr><th>Time</th><th>User / Role</th><th>Project</th><th>Module</th><th>Record</th><th>Action</th><th>Old → New</th><th>Reason</th></tr></thead><tbody>
      ${rows.map((r) => `<tr><td style="white-space:nowrap">${esc(new Date(r.created_at).toLocaleString())}</td><td>${esc((r.actor_id || "").slice(0, 8))}<br><small>${esc(r.actor_role)}</small></td><td>${esc(r.project_id)}</td><td>${esc(r.module)}</td><td>${esc(r.record_id)}</td><td><b>${esc(r.action)}</b></td><td style="max-width:420px">${r.action === "update" || r.action === "permission_change" ? diff(r.old_values, r.new_values) : r.action === "delete" ? "deleted" : "new"}</td><td>${esc(r.reason)}</td></tr>`).join("")}
    </tbody></table></div>
    <div style="display:flex;gap:8px;align-items:center;margin-top:8px"><button class="btn" data-aa="prev" ${pageNo ? "" : "disabled"}>‹ Prev</button><span>Page ${pageNo + 1} / ${pages} · ${total} entries</span><button class="btn" data-aa="next" ${pageNo + 1 < pages ? "" : "disabled"}>Next ›</button></div>` : ""}
  </div>`;
  el.querySelectorAll("[data-af]").forEach((i) => i.addEventListener("change", () => { f[i.dataset.af] = i.value.trim(); }));
  el.querySelectorAll("[data-aa]").forEach((b) => b.addEventListener("click", () => {
    const a = b.dataset.aa;
    if (a === "export") return void exportAll();
    if (a === "prev") pageNo--; else if (a === "next") pageNo++; else pageNo = 0;
    void load();
  }));
  window.accessFit?.();
}

function attach() {
  if ((window.PB_APP_API?.getPage?.() || window.page) !== "access") return;
  const view = document.getElementById("view");
  if (!view || document.getElementById("pb-audit-trail")) return;
  const el = document.createElement("section");
  el.id = "pb-audit-trail";
  view.append(el);
  draw();
  void load();
}

window.addEventListener("pb:rendered", attach);
setTimeout(attach, 800);
