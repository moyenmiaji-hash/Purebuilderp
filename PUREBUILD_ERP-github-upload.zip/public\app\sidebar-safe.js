/* Side menu never breaks on any screen: fixed to screen height, scrolls inside, brand text shrinks/wraps. Display-only. */
(function () {
  var S = "html body:not(.zz1):not(.zz2) aside.sidebar";
  var css = `
${S}{height:100vh!important;height:100dvh!important;max-height:100dvh!important;overflow-y:auto!important;overflow-x:hidden!important;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:rgba(160,185,215,.45) transparent;box-sizing:border-box}
${S}::-webkit-scrollbar{width:6px}${S}::-webkit-scrollbar-thumb{background:rgba(160,185,215,.45);border-radius:999px}${S}::-webkit-scrollbar-track{background:transparent}
${S} *{min-width:0}
${S} .brand{display:flex!important;align-items:center;gap:8px;max-width:100%;overflow:hidden}
${S} .brand-mark{flex:0 0 auto}
${S} .brand-copy{min-width:0;flex:1 1 auto;overflow:hidden;font-size:clamp(12px,1.25vw,22px)!important;letter-spacing:0!important;line-height:1.1;white-space:nowrap}
${S} .brand-copy small{display:block;font-size:9px!important;white-space:normal!important}
${S} .pb-mini-btn{box-shadow:0 -10px 14px rgba(8,18,35,.85)}
${S} .brand-copy h1,${S} .brand-copy h2,${S} .brand-copy b,${S} .brand-copy strong{font-size:clamp(14px,1.55vw,22px)!important;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
${S} .brand-copy p,${S} .brand-copy small,${S} .brand-copy span{white-space:normal!important;overflow-wrap:anywhere}
${S} a,${S} button,${S} .nav-item{max-width:100%;overflow:hidden;text-overflow:ellipsis}
@media (max-height:760px){${S} a,${S} .nav-item,${S} nav button{padding-top:5px!important;padding-bottom:5px!important}}
`;
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
})();
