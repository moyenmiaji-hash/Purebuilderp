import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

async function requireOfficeUser(request: Request): Promise<Response | null> {
  const authorization = request.headers.get("authorization") || "";
  const token = /^Bearer ([^\s]+)$/.exec(authorization)?.[1];
  if (!token || token.split(".").length !== 3) {
    return Response.json({ error: "Please sign in first." }, { status: 401 });
  }

  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) {
    console.error("[Bill scan] Supabase authentication is not configured.");
    return Response.json({ error: "Authentication is temporarily unavailable." }, { status: 503 });
  }

  const supabase = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: `Bearer ${token}` },
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
  const { data: authData, error: authError } = await supabase.auth.getUser(token);
  const userId = authData?.user?.id;
  if (authError || !userId) {
    return Response.json({ error: "Please sign in again." }, { status: 401 });
  }

  const [{ data: profile, error: profileError }, { data: isOfficeUser, error: roleError }] =
    await Promise.all([
      supabase.from("profiles").select("status").eq("id", userId).maybeSingle(),
      supabase.rpc("is_office_user", { _user_id: userId }),
    ]);
  if (profileError || roleError) {
    console.error("[Bill scan] Could not verify the caller's account status or role.", {
      profileError,
      roleError,
    });
    return Response.json({ error: "Authorization is temporarily unavailable." }, { status: 503 });
  }
  if (profile?.status !== "active" || !isOfficeUser) {
    return Response.json({ error: "An active office account is required." }, { status: 403 });
  }

  return null;
}

// Reads a supplier bill photo/PDF with the Lovable AI Gateway and returns
// supplier, amount, due date and site for human review (nothing is saved here).
const SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    supplier: { type: ["string", "null"] },
    invoiceNo: { type: ["string", "null"] },
    invoiceDate: { type: ["string", "null"], description: "YYYY-MM-DD" },
    dueDate: { type: ["string", "null"], description: "YYYY-MM-DD" },
    amount: { type: ["number", "null"], description: "Grand total in AED" },
    site: { type: ["string", "null"] },
    notes: { type: ["string", "null"] },
  },
  required: ["supplier", "invoiceNo", "invoiceDate", "dueDate", "amount", "site", "notes"],
};

export const Route = createFileRoute("/api/scan-bill")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authorizationError = await requireOfficeUser(request);
        if (authorizationError) return authorizationError;

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ error: "AI is not configured" }, { status: 503 });
        let parsed: unknown;
        try {
          parsed = await request.json();
        } catch {
          return Response.json({ error: "Invalid request" }, { status: 400 });
        }
        if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
          return Response.json({ error: "Invalid request" }, { status: 400 });
        }
        const body = parsed as { dataUrl?: unknown; fileName?: unknown; sites?: unknown };
        const dataUrl = typeof body.dataUrl === "string" ? body.dataUrl : "";
        const m = /^data:([^;]+);base64,/.exec(dataUrl);
        if (!m || dataUrl.length > 14_000_000)
          return Response.json(
            { error: "Please upload an image or PDF under 10 MB" },
            { status: 400 },
          );
        const mime = m[1] ?? "";
        const fileName =
          typeof body.fileName === "string"
            ? body.fileName.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 128)
            : "bill.pdf";
        const part =
          mime === "application/pdf"
            ? { type: "input_file", filename: fileName || "bill.pdf", file_data: dataUrl }
            : mime.startsWith("image/")
              ? { type: "input_image", image_url: dataUrl }
              : null;
        if (!part)
          return Response.json({ error: "Only images or PDF are supported" }, { status: 400 });
        const sites = Array.isArray(body.sites)
          ? body.sites
              .filter((site): site is string => typeof site === "string")
              .slice(0, 50)
              .map((site) => site.slice(0, 80))
          : [];
        const prompt = `Read this supplier bill/invoice for a UAE construction company. Extract supplier name, invoice number, invoice date, due date, grand total amount (number only, AED), and the site/building it is for. ${sites.length ? `Known sites: ${sites.join(", ")}. If the bill mentions one, return that exact name.` : ""} Use null for anything not visible. Dates as YYYY-MM-DD.`;

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
          method: "POST",
          signal: request.signal,
          headers: {
            "Content-Type": "application/json",
            "Lovable-API-Key": key,
            "X-Lovable-AIG-SDK": "fetch",
          },
          body: JSON.stringify({
            model: "openai/gpt-6-astra",
            stream: true,
            store: false,
            reasoning: { effort: "low" },
            text: { format: { type: "json_schema", name: "bill", strict: true, schema: SCHEMA } },
            input: [{ role: "user", content: [{ type: "input_text", text: prompt }, part] }],
          }),
        });
        if (!upstream.ok || !upstream.body) {
          let msg = "AI could not read the bill";
          try {
            const j = await upstream.json();
            msg = j?.error?.message || j?.message || msg;
          } catch (error) {
            console.error("[Bill scan] Could not parse the AI gateway error response.", error);
          }
          return Response.json({ error: msg }, { status: upstream.status || 502 });
        }
        const reader = upstream.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        let text = "";
        let failed = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() || "";
          for (const line of lines) {
            if (!line.startsWith("data:")) continue;
            const d = line.slice(5).trim();
            if (!d || d === "[DONE]") continue;
            try {
              const ev = JSON.parse(d);
              if (ev.type === "response.output_text.delta") text += ev.delta || "";
              if (ev.type === "response.failed" || ev.type === "error")
                failed =
                  ev.response?.error?.message || ev.error?.message || ev.message || "AI failed";
            } catch {
              console.warn("[Bill scan] Ignoring an invalid AI stream event.");
            }
          }
        }
        if (failed) return Response.json({ error: failed }, { status: 502 });
        try {
          return Response.json({ result: JSON.parse(text) });
        } catch {
          return Response.json(
            { error: "AI could not read this bill. Please enter it by hand." },
            { status: 422 },
          );
        }
      },
    },
  },
});
