// Sales & Invoiced Overview redesign (p75): compact KPIs, collapsible filters, full invoice table
// (search/sort/paging/row menu) and side panels. Read-only: reuses existing sales helpers and data.
// Also adds an icon-only "mini" sidebar mode (phone-local preference PB_NAV_MINI).
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const st = { q: "", sort: "date", dir: -1, page: 1, size: 15, more: false };
  window.pbSalesOv = st;

  function rowsFor(invs) {
    const q = st.q.trim().toLowerCase();
    let r = invs.filter((x) => !q || [x.number, x.client, projectName(x.projectId), x.date, salesInvoiceStatus(x)].join(" ").toLowerCase().includes(q));
    const key = {
      number: (x) => String(x.number || ""), date: (x) => String(x.date || ""), project: (x) => projectName(x.projectId),
      client: (x) => String(x.client || ""), amount: (x) => +x.amount || 0, received: (x) => +x.received || 0,
      outstanding: (x) => salesInvoiceOutstanding(x), status: (x) => salesInvoiceStatus(x),
    }[st.sort];
    r.sort((a, b) => { const A = key(a), B = key(b); return (typeof A === "number" ? A - B : String(A).localeCompare(String(B), undefined, { numeric: true })) * st.dir; });
    return r;
  }

  function newOverview() {
    salesEnsureData(); salesSyncContracts();
    const f = salesFilters, invs = salesApplyFilters();
    const contracts = f.project ? db.contracts.filter((c) => c.projectId === f.project) : db.contracts;
    const contractValue = contracts.reduce((a, c) => a + Number(c.value || 0), 0);
    const issued = invs.filter(salesInvoiceIsIssued);
    const invoiced = issued.reduce((a, x) => a + Number(x.amount || 0), 0);
    const received = issued.reduce((a, x) => a + Number(x.received || 0), 0);
    const outstanding = issued.reduce((a, x) => a + salesInvoiceOutstanding(x), 0);
    const overdueList = issued.filter((x) => salesInvoiceStatus(x) === "Overdue");
    const overdue = overdueList.reduce((a, x) => a + salesInvoiceOutstanding(x), 0);
    const retention = (db.retentions || []).filter((x) => !f.project || x.projectId === f.project).reduce((a, x) => a + Math.max(0, Number(x.amount || 0) - Number(x.released || 0)), 0);
    const advance = (db.advances || []).filter((x) => !f.project || x.projectId === f.project).reduce((a, x) => a + Math.max(0, Number(x.amount || 0) - Number(x.adjusted || 0)), 0);
    const progressValue = (db.boq || []).filter((x) => !f.project || x.projectId === f.project).reduce((a, b) => a + Number(b.executedQty || 0) * Number(b.rate || 0), 0);
    const billedWork = issued.filter((x) => x.invoiceType === "Progress Invoice").reduce((a, x) => a + Number(x.grossWorkValue || x.amount || 0), 0);
    const unbilled = Math.max(0, progressValue - billedWork);
    const aging = salesAgingRows(issued), proj = salesProjectSummary(invs);
    const rows = rowsFor(invs), pages = Math.max(1, Math.ceil(rows.length / st.size));
    if (st.page > pages) st.page = pages;
    const shown = rows.slice((st.page - 1) * st.size, st.page * st.size);
    const pc = invoiced ? Math.round((received / invoiced) * 100) : 0;
    const active = ["project", "client", "contract", "status", "type", "payment", "from", "to"].filter((k) => f[k]).length;
    const th = (k, l, cls = "") => `<th class="${cls} sov-sort ${st.sort === k ? "on" : ""}" data-k="${k}">${l}${st.sort === k ? (st.dir > 0 ? " ▲" : " ▼") : ""}</th>`;
    const kpi = (tone, label, val, sub) => `<div class="sov-kpi ${tone}"><small>${label}</small><b title="${E(salesMoney(val))}">${salesMoney(val)}</b><span>${sub}</span></div>`;
    const mini = (label, val) => `<div><small>${label}</small><b>${salesMoney(val)}</b></div>`;

    document.getElementById("view").innerHTML = `<div class="sov">` +
      head("Sales & Invoiced", "Project billing, invoices, collections and receivables.", salesHeaderActions()) + salesTabs() +
      `<div class="sov-filters ${st.more ? "more" : ""}">${salesFilterBar()}<div class="sov-fbtns"><button class="btn small" id="sovMore">${st.more ? "Fewer filters ▴" : "More filters ▾"}${active ? ` <i class="sov-dot">${active}</i>` : ""}</button><button class="btn small" id="sovReset" ${active ? "" : "disabled"}>Reset</button></div></div>
      <div class="sov-kpis">${kpi("b", "Total Invoiced", invoiced, `${issued.length} issued invoices`)}${kpi("g", "Total Received", received, `${pc}% collected`)}${kpi("a", "Outstanding", outstanding, `${issued.filter((x) => salesInvoiceOutstanding(x) > 0).length} unpaid / partial`)}${kpi("r", "Overdue", overdue, `${overdueList.length} overdue invoices`)}</div>
      <div class="sov-sec">${mini("Contract Value", contractValue)}${mini("Retention", retention)}${mini("Advance Balance", advance)}${mini("Unbilled Progress", unbilled)}</div>
      <div class="sov-main">
        <section class="panel sov-table">
          <div class="sov-th"><h3>Invoice History <small>${rows.length} of ${invs.length}</small></h3><input id="sovSearch" type="search" placeholder="Search invoice, client, project…" value="${E(st.q)}"></div>
          <div class="sov-wrap"><table><thead><tr>${th("number", "Invoice No")}${th("date", "Date")}${th("project", "Project")}${th("client", "Client")}${th("amount", "Invoice Amount", "r")}${th("received", "Received", "r")}${th("outstanding", "Outstanding", "r")}${th("status", "Status")}<th></th></tr></thead><tbody>
          ${shown.map((x) => { const s = salesInvoiceStatus(x), o = salesInvoiceOutstanding(x); return `<tr data-id="${E(x.id)}"><td><b>${E(x.number)}</b></td><td>${E(x.date)}</td><td title="${E(projectName(x.projectId))}">${E(projectName(x.projectId))}</td><td title="${E(x.client || "")}">${E(x.client || "—")}</td><td class="r">${salesMoney(x.amount, x.currency)}</td><td class="r g">${salesMoney(x.received || 0, x.currency)}</td><td class="r ${o > 0 ? "o" : ""}">${salesMoney(o, x.currency)}</td><td><span class="sales-status ${salesStatusClass(s)}">${E(s)}</span></td><td class="sov-act"><button class="sov-dots" aria-label="Actions for ${E(x.number)}">⋯</button><div class="sov-menu"><button data-a="view">👁 View details</button><button data-a="edit">✎ Edit</button><button data-a="pdf">⎙ Print / PDF</button>${o > 0 ? `<button data-a="pay">＋ Receive payment</button>` : ""}<button data-a="stmt">📄 Project statement</button></div></td></tr>`; }).join("") ||
            `<tr><td colspan="9" class="sov-empty">${invs.length ? "No invoice matches your search." : "No invoices yet. Use “+ Create Invoice” to add one."}</td></tr>`}
          </tbody></table></div>
          <div class="sov-pager"><span>Showing ${rows.length ? (st.page - 1) * st.size + 1 : 0}–${Math.min(st.page * st.size, rows.length)} of ${rows.length}</span><div><button class="btn small" id="sovPrev" ${st.page <= 1 ? "disabled" : ""}>‹ Prev</button><b>${st.page} / ${pages}</b><button class="btn small" id="sovNext" ${st.page >= pages ? "disabled" : ""}>Next ›</button></div></div>
        </section>
        <aside class="sov-side">
          <div class="panel sov-qa"><h4>Quick Actions</h4><button class="btn primary" onclick="addInvoice()">＋ Create Invoice</button><button class="btn" onclick="receiveInvoicePayment()">Receive Payment</button><button class="btn" onclick="salesNav('receivables')">View Receivables</button><button class="btn" onclick="salesNav('billing')">Billing Progress</button></div>
          <details class="panel sov-det" open><summary>Receivable Aging <small>${salesMoney(outstanding)}</small></summary>${aging.map((a, i) => `<div class="sov-ag"><span>${a.label}</span><i><em class="c${i}" style="width:${a.amount > 0 ? Math.max(4, Math.min(100, a.pct)) : 0}%"></em></i><b>${salesMoney(a.amount)}</b></div>`).join("")}</details>
          <details class="panel sov-det"><summary>Project Billing Summary <small>${proj.length}</small></summary>${proj.map((p) => { const q = p.invoiced ? Math.round((p.received / p.invoiced) * 100) : 0; return `<div class="sov-pj"><b title="${E(p.name)}">${E(p.name)}</b><i><em style="width:${q}%"></em></i><small>${salesMoney(p.invoiced)} · due <span class="${p.due > 0 ? "o" : ""}">${salesMoney(p.due)}</span></small></div>`; }).join("") || '<p class="sov-empty">No billed projects.</p>'}</details>
        </aside>
      </div></div>`;
    bind();
  }

  function bind() {
    salesBindFilters();
    const g = (i) => document.getElementById(i);
    g("sovMore").onclick = () => { st.more = !st.more; render(); };
    g("sovReset").onclick = () => { salesFilters = { project: "", client: "", contract: "", status: "", type: "", payment: "", from: "", to: "" }; window.salesFilters = salesFilters; st.page = 1; render(); };
    const s = g("sovSearch"); let t;
    s.oninput = () => { clearTimeout(t); t = setTimeout(() => { st.q = s.value; st.page = 1; render(); const n = g("sovSearch"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } }, 250); };
    g("sovPrev").onclick = () => { st.page--; render(); };
    g("sovNext").onclick = () => { st.page++; render(); };
    document.querySelectorAll(".sov-sort").forEach((h) => (h.onclick = () => { const k = h.dataset.k; st.dir = st.sort === k ? -st.dir : (k === "date" || k === "amount" || k === "outstanding" ? -1 : 1); st.sort = k; render(); }));
    bindRows();
  }
  function bindRows() {
    document.querySelectorAll(".sov-table tbody tr[data-id]").forEach((tr) => {
      if (!tr.querySelector(".sov-dots")) return;
      const id = tr.dataset.id;
      tr.onclick = (e) => {
        const dots = e.target.closest(".sov-dots"), a = e.target.closest(".sov-menu button");
        if (dots) { e.stopPropagation(); const open = tr.classList.contains("menu"); document.querySelectorAll(".sov-table tr.menu").forEach((r) => r.classList.remove("menu")); if (!open) tr.classList.add("menu"); return; }
        if (a) {
          e.stopPropagation(); tr.classList.remove("menu");
          const x = (db.invoices || []).find((i) => i.id === id);
          ({ view: () => viewInvoice(id), edit: () => editSalesInvoice(id), pdf: () => salesInvoicePDF(id), pay: () => receiveInvoicePayment(id), stmt: () => window.pbProjectStatement && window.pbProjectStatement("invoices", x ? x.projectId || "" : "") }[a.dataset.a] || (() => {}))();
          return;
        }
        viewInvoice(id);
      };
    });
  }
  document.addEventListener("click", (e) => { if (!e.target.closest(".sov-act")) document.querySelectorAll(".sov-table tr.menu").forEach((r) => r.classList.remove("menu")); });


  // ===== Shared helpers for Billing / Invoices tabs (p76) =====
  const BST = (b) => (b.status === "Converted" ? "Invoiced" : b.status || "Draft");
  const bcls = (s) => ({ Invoiced: "good", Approved: "good", "Pending Approval": "warn", Rejected: "bad" }[s] || "gray");
  const billNet = (b) => { const g = +b.grossWorkValue || 0; const r = +b.retention || 0, a = +b.advanceRecovery || 0; return { g, r, a, n: Math.max(0, g - r - a) }; };
  function contractSummary() {
    const f = salesFilters, invs = salesApplyFilters(), issued = invs.filter(salesInvoiceIsIssued);
    const contracts = f.project ? db.contracts.filter((c) => c.projectId === f.project) : db.contracts;
    const cv = contracts.reduce((a, c) => a + Number(c.value || 0), 0);
    const billed = issued.reduce((a, x) => a + Number(x.grossWorkValue || x.amount || 0), 0);
    const pv = (db.boq || []).filter((x) => !f.project || x.projectId === f.project).reduce((a, b) => a + Number(b.executedQty || 0) * Number(b.rate || 0), 0);
    const bw = issued.filter((x) => x.invoiceType === "Progress Invoice").reduce((a, x) => a + Number(x.grossWorkValue || x.amount || 0), 0);
    return { cv, billed, remain: Math.max(0, cv - billed), unbilled: Math.max(0, pv - bw) };
  }
  const bills = () => (db.bills || []).filter((b) => (!salesFilters.project || b.projectId === salesFilters.project) && (!salesFilters.contract || b.contractId === salesFilters.contract) && (!salesFilters.from || String(b.date) >= salesFilters.from) && (!salesFilters.to || String(b.date) <= salesFilters.to));
  const invOf = (b) => (db.invoices || []).find((i) => i.sourceBillId === b.id || (b.invoiceId && i.id === b.invoiceId));
  function filtersBlock(stx, key) {
    const f = salesFilters, active = ["project", "client", "contract", "status", "type", "payment", "from", "to"].filter((k) => f[k]).length;
    return `<div class="sov-filters ${stx.more ? "more" : ""}" data-key="${key}">${salesFilterBar()}<div class="sov-fbtns"><button class="btn small sov-more">${stx.more ? "Fewer filters ▴" : "More filters ▾"}${active ? ` <i class="sov-dot">${active}</i>` : ""}</button><button class="btn small sov-reset" ${active ? "" : "disabled"}>Reset</button></div></div>`;
  }
  function bindFilters(stx) {
    salesBindFilters();
    document.querySelectorAll(".sov-more").forEach((b) => (b.onclick = () => { stx.more = !stx.more; render(); }));
    document.querySelectorAll(".sov-reset").forEach((b) => (b.onclick = () => { salesFilters = { project: "", client: "", contract: "", status: "", type: "", payment: "", from: "", to: "" }; window.salesFilters = salesFilters; stx.page = 1; render(); }));
  }

  // ===== BILLING TAB =====
  const bst = { more: false, tab: "open" };
  function newBilling() {
    salesEnsureData(); salesSyncContracts(); db.bills = db.bills || [];
    const s = contractSummary(), all = bills().sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.number).localeCompare(String(a.number), undefined, { numeric: true }));
    const open = all.filter((b) => BST(b) !== "Invoiced"), done = all.filter((b) => BST(b) === "Invoiced");
    const cnt = (k) => all.filter((b) => BST(b) === k).length;
    const mini = (l, v) => `<div><small>${l}</small><b>${salesMoney(v)}</b></div>`;
    const act = (b) => { const t = BST(b), i = invOf(b); let h = `<button class="btn small" data-b="view">View</button><button class="btn small" data-b="print">Print</button>`;
      if (t === "Draft" || t === "Rejected") h += `<button class="btn small" data-b="edit">Edit</button><button class="btn small" data-b="submit">Submit</button>`;
      if (t === "Pending Approval") h += `<button class="btn small sov-ok" data-b="approve">Approve</button><button class="btn small sov-no" data-b="reject">Reject</button>`;
      if (t === "Approved" && !i) h += `<button class="btn small primary" data-b="gen">Generate Invoice</button>`;
      if (i) h += `<button class="btn small" data-b="inv">${E(i.number)}</button>`;
      return h; };
    const row = (b) => { const n = billNet(b), t = BST(b); return `<tr data-id="${E(b.id)}"><td><b>${E(b.number)}</b></td><td>${E(b.date)}</td><td title="${E(projectName(b.projectId))}">${E(projectName(b.projectId))}</td><td>${E(b.type || "Progress Invoice")}</td><td class="r">${(b.items || []).length}</td><td class="r">${salesMoney(n.g)}</td><td class="r">${n.r || n.a ? "−" + salesMoney(n.r + n.a) : "—"}</td><td class="r"><b>${salesMoney(n.n)}</b></td><td><span class="sales-status ${bcls(t)}">${E(t)}</span></td><td class="sov-btns">${act(b)}</td></tr>`; };
    const list = bst.tab === "open" ? open : done;
    document.getElementById("view").innerHTML = `<div class="sov">` + head("Sales & Invoiced", "Billing — prepare, approve and convert project progress bills.", `<button class="btn" onclick="salesImportExcel()">Import Excel</button><button class="btn primary" onclick="salesCreateProgressBill()">+ Create Bill</button>`) + salesTabs() + filtersBlock(bst, "b") +
      `<div class="sov-sec">${mini("Contract Value", s.cv)}${mini("Billed to Date", s.billed)}${mini("Remaining Contract", s.remain)}${mini("Unbilled Progress", s.unbilled)}</div>
      <div class="sov-flow">${["Draft", "Pending Approval", "Approved", "Rejected", "Invoiced"].map((k, i) => `${i ? "<span>›</span>" : ""}<div class="${bcls(k)}"><b>${cnt(k)}</b><small>${k}</small></div>`).join("")}</div>
      <section class="panel sov-table"><div class="sov-th"><div class="sov-sw"><button class="${bst.tab === "open" ? "on" : ""}" data-t="open">Progress Bills (${open.length})</button><button class="${bst.tab === "done" ? "on" : ""}" data-t="done">Billing Register — Invoiced (${done.length})</button></div><small class="muted">Only Approved bills can become invoices · one invoice per bill</small></div>
      <div class="sov-wrap"><table><thead><tr><th>Bill No</th><th>Date</th><th>Project</th><th>Type</th><th class="r">Items</th><th class="r">Gross</th><th class="r">Deductions</th><th class="r">Net Payable</th><th>Status</th><th>Actions</th></tr></thead><tbody>${list.map(row).join("") || `<tr><td colspan="10" class="sov-empty">${bst.tab === "open" ? "No open bills. Use “+ Create Bill” to bill completed BOQ work." : "No bill has been converted to an invoice yet."}</td></tr>`}</tbody></table></div></section></div>`;
    bindFilters(bst);
    document.querySelectorAll(".sov-sw button").forEach((b) => (b.onclick = () => { bst.tab = b.dataset.t; render(); }));
    document.querySelectorAll(".sov-table tr[data-id] [data-b]").forEach((btn) => (btn.onclick = () => billAction(btn.closest("tr").dataset.id, btn.dataset.b)));
  }
  function setBillStatus(b, st, note) { b.status = st; b.statusHistory = b.statusHistory || []; b.statusHistory.push({ status: st, by: salesUser(), at: salesNow(), note: note || "" }); salesAudit(b.invoiceId || "", "Bill " + st, b.number + (note ? " · " + note : "")); save(); render(); toast("Bill " + b.number + " → " + st); }
  function billAction(idv, a) {
    const b = (db.bills || []).find((x) => x.id === idv); if (!b) return;
    if (a === "view") return billView(b);
    if (a === "print") return billPrint(b);
    if (a === "edit") return billEdit(b);
    if (a === "submit") return setBillStatus(b, "Pending Approval");
    if (a === "approve") { if (!confirm("Approve bill " + b.number + "?")) return; return setBillStatus(b, "Approved"); }
    if (a === "reject") { const r = prompt("Reason for rejecting " + b.number + "?"); if (r === null) return; return setBillStatus(b, "Rejected", r); }
    if (a === "gen") return window.salesConvertBillToInvoice(b.id);
    if (a === "inv") { const i = invOf(b); if (i) viewInvoice(i.id); }
  }
  function prevCertified(b) { return (db.invoices || []).filter((i) => i.projectId === b.projectId && salesInvoiceIsIssued(i) && i.sourceBillId !== b.id && i.id !== b.invoiceId && String(i.date) <= String(b.date)).reduce((a, i) => a + Number(i.grossWorkValue || i.amount || 0), 0); }
  function billHtml(b) {
    const n = billNet(b), prev = prevCertified(b);
    return `<div class="sov-bill"><div class="sov-bh"><div><small>Bill No</small><b>${E(b.number)}</b></div><div><small>Date</small><b>${E(b.date)}</b></div><div><small>Project</small><b>${E(projectName(b.projectId))}</b></div><div><small>Status</small><b>${E(BST(b))}</b></div></div>
    <table class="sov-bt"><thead><tr><th>Item</th><th>Description</th><th class="r">Contract Qty</th><th class="r">Prev. Billed</th><th class="r">This Bill</th><th class="r">Cumulative</th><th>Unit</th><th class="r">Rate</th><th class="r">Amount</th></tr></thead><tbody>${(b.items || []).map((i) => `<tr><td>${E(i.itemCode || "")}</td><td>${E(i.description)}</td><td class="r">${fmt(i.contractQty || 0)}</td><td class="r">${fmt(i.previousBilledQty || 0)}</td><td class="r"><b>${fmt(i.qty)}</b></td><td class="r">${fmt((+i.previousBilledQty || 0) + (+i.qty || 0))}</td><td>${E(i.unit || "")}</td><td class="r">${salesMoney(i.rate)}</td><td class="r">${salesMoney(i.amount)}</td></tr>`).join("")}</tbody></table>
    <div class="sov-btot"><div><span>Previous certified amount</span><b>${salesMoney(prev)}</b></div><div><span>Current bill (gross)</span><b>${salesMoney(n.g)}</b></div><div><span>Cumulative billed</span><b>${salesMoney(prev + n.g)}</b></div><div><span>Retention${b.retentionPct ? " (" + b.retentionPct + "%)" : ""}</span><b>−${salesMoney(n.r)}</b></div><div><span>Advance recovery</span><b>−${salesMoney(n.a)}</b></div><div class="net"><span>Net payable</span><b>${salesMoney(n.n)}</b></div></div>
    ${(b.statusHistory || []).length ? `<div class="sov-hist">${b.statusHistory.map((h) => `<div>${E(h.at)} · <b>${E(h.status)}</b> · ${E(h.by)}${h.note ? " — " + E(h.note) : ""}</div>`).join("")}</div>` : ""}</div>`;
  }
  function billView(b) { openModal("Bill " + b.number, billHtml(b), () => true); const s = document.getElementById("modalSave"); if (s) s.style.display = "none"; }
  function billPrint(b) { const w = window.open("", "_blank"); if (!w) return; const co = (db.settings || {}).companyName || "PURE BUILD";
    w.document.write(`<html><head><title>${E(b.number)}</title><style>body{font-family:Arial;font-size:12px;padding:18px}table{border-collapse:collapse;width:100%;margin:10px 0}th,td{border:1px solid #bbb;padding:4px 6px;text-align:left}th{background:#14213d;color:#fff;-webkit-print-color-adjust:exact}.r{text-align:right}.sov-bh{display:flex;gap:24px}.sov-bh small{display:block;color:#666}.sov-btot div{display:flex;justify-content:space-between;max-width:360px;margin-left:auto;padding:2px 0}.net{border-top:2px solid #000;font-size:14px}.sov-hist{color:#555;margin-top:10px}</style></head><body><h2>${E(co)} · Progress Bill</h2>${billHtml(b)}</body></html>`); w.document.close(); setTimeout(() => w.print(), 250); }
  function billEdit(b) {
    const rows = (b.items || []).map((i, k) => `<tr><td>${E(i.itemCode || "")} ${E(i.description)}</td><td class="r">${fmt(i.previousBilledQty || 0)}</td><td><input type="number" min="0" step="0.001" class="be-q" data-k="${k}" value="${+i.qty || 0}"></td><td class="r">${salesMoney(i.rate)}</td></tr>`).join("");
    openModal("Edit Draft " + b.number, `<div class="sov-bill"><div class="sales-form-grid"><div><label>Bill Date</label><input id="beDate" type="date" value="${E(b.date)}"></div><div><label>Retention %</label><input id="beRet" type="number" min="0" max="100" step="0.01" value="${+b.retentionPct || 0}"></div><div><label>Advance Recovery (AED)</label><input id="beAdv" type="number" min="0" step="0.01" value="${+b.advanceRecovery || 0}"></div></div><table class="sov-bt"><thead><tr><th>Item</th><th class="r">Prev. Billed</th><th>This Bill Qty</th><th class="r">Rate</th></tr></thead><tbody>${rows}</tbody></table></div>`, () => {
      const items = (b.items || []).map((i, k) => { const q = Math.max(0, +document.querySelector(`.be-q[data-k="${k}"]`).value || 0); const lim = salesProgressRows(b.projectId, b.contractId).find((r) => r.id === i.boqItemId); if (lim && q > lim.unbilled + 0.0001) { toast("Qty exceeds unbilled work for " + i.description); throw new Error("qty"); } return { ...i, qty: q, amount: q * (+i.rate || 0) }; }).filter((i) => i.qty > 0);
      if (!items.length) { toast("At least one item with quantity is needed"); return false; }
      const g = items.reduce((a, i) => a + i.amount, 0), rp = Math.min(100, Math.max(0, +document.getElementById("beRet").value || 0)), adv = Math.max(0, +document.getElementById("beAdv").value || 0);
      if (adv + (g * rp) / 100 > g) { toast("Deductions cannot exceed the gross bill"); return false; }
      Object.assign(b, { items, date: document.getElementById("beDate").value || b.date, grossWorkValue: g, retentionPct: rp, retention: Math.round(g * rp) / 100, advanceRecovery: adv, updatedAt: salesNow() });
      salesAudit("", "Bill Edited", b.number); save(); render(); toast("Bill updated"); return true;
    });
  }
  function convertBill(idv) {
    const b = (db.bills || []).find((x) => x.id === idv); if (!b) return;
    if (BST(b) !== "Approved") { toast("Only Approved bills can be converted to an invoice"); return; }
    const ex = invOf(b); if (ex) { toast("Invoice " + ex.number + " already exists for this bill"); return; }
    const project = (db.projects || []).find((p) => p.id === b.projectId);
    const client = (db.clients || []).find((c) => c.id === project?.clientId) || (db.clients || []).find((c) => String(c.name || "").toLowerCase() === String(project?.client || "").toLowerCase());
    const n = billNet(b), invId = id();
    const q = { id: invId, number: salesInvoiceNumber(), date: salesToday(), dueDate: "", invoiceType: b.type || "Progress Invoice", projectId: b.projectId, contractId: b.contractId || "", clientId: client?.id || "", client: client?.name || project?.client || "", currency: "AED", paymentTerms: "", notes: "Generated from bill " + b.number, items: b.items || [], grossWorkValue: n.g, retention: n.r, retentionInput: +b.retentionPct || 0, retentionType: "Percentage", advanceRecovery: n.a, advanceRecoveryInput: n.a, advanceRecoveryType: "Amount", tax: 0, taxRate: 0, discount: 0, amount: n.n, received: 0, payments: [], status: "Draft", sourceBillId: b.id, sourceBillNumber: b.number, createdAt: salesNow(), createdBy: salesUser() };
    db.invoices.push(q);
    if (n.r > 0) db.retentions.push({ id: id(), invoiceId: invId, projectId: b.projectId, clientId: q.clientId, amount: n.r, released: 0, date: q.date, status: "Held" });
    if (n.a > 0) db.advances.push({ id: id(), invoiceId: invId, projectId: b.projectId, clientId: q.clientId, amount: n.a, adjusted: 0, date: q.date, reference: "ADV-REC-" + q.number });
    b.invoiceId = invId; setBillStatus(b, "Invoiced", "Invoice " + q.number);
    salesAudit(invId, "Invoice generated from bill", b.number); save();
    salesTab = window.salesTab = "invoices"; render(); toast("Invoice " + q.number + " created as Draft from " + b.number);
  }

  // ===== INVOICES TAB =====
  const ist = { q: "", sort: "date", dir: -1, page: 1, size: 20, more: false };
  function newInvoices(mode) {
    if (mode) return origInvoices(mode);
    salesEnsureData(); salesSyncContracts();
    const invs = salesApplyFilters(), issued = invs.filter(salesInvoiceIsIssued);
    const sum = (a, f) => a.reduce((s, x) => s + f(x), 0);
    const inv = sum(issued, (x) => +x.amount || 0), rec = sum(issued, (x) => +x.received || 0), out = sum(issued, salesInvoiceOutstanding), od = issued.filter((x) => salesInvoiceStatus(x) === "Overdue");
    const q = ist.q.trim().toLowerCase(), cn = (x) => { const c = (db.contracts || []).find((c) => c.id === x.contractId); return c ? c.number || c.name : "—"; };
    let rows = invs.filter((x) => !q || [x.number, x.client, projectName(x.projectId), x.date, cn(x), x.invoiceType, salesInvoiceStatus(x)].join(" ").toLowerCase().includes(q));
    const K = { number: (x) => String(x.number || ""), date: (x) => String(x.date || ""), project: (x) => projectName(x.projectId), client: (x) => String(x.client || ""), amount: (x) => +x.amount || 0, received: (x) => +x.received || 0, outstanding: salesInvoiceOutstanding, due: (x) => String(x.dueDate || "") }[ist.sort] || ((x) => String(x.date));
    rows.sort((a, b) => { const A = K(a), B = K(b); return (typeof A === "number" ? A - B : String(A).localeCompare(String(B), undefined, { numeric: true })) * ist.dir; });
    const pages = Math.max(1, Math.ceil(rows.length / ist.size)); if (ist.page > pages) ist.page = pages;
    const shown = rows.slice((ist.page - 1) * ist.size, ist.page * ist.size);
    const th = (k, l, c = "") => `<th class="${c} sov-sort ${ist.sort === k ? "on" : ""}" data-k="${k}">${l}${ist.sort === k ? (ist.dir > 0 ? " ▲" : " ▼") : ""}</th>`;
    const kpi = (t, l, v, s) => `<div class="sov-kpi ${t}"><small>${l}</small><b>${salesMoney(v)}</b><span>${s}</span></div>`;
    document.getElementById("view").innerHTML = `<div class="sov">` + head("Sales & Invoiced", "Invoices — customer invoices, collections and dues.", salesHeaderActions()) + salesTabs() + filtersBlock(ist, "i") +
      `<div class="sov-kpis">${kpi("b", "Total Invoiced", inv, issued.length + " issued")}${kpi("g", "Total Received", rec, (inv ? Math.round((rec / inv) * 100) : 0) + "% collected")}${kpi("a", "Total Outstanding", out, issued.filter((x) => salesInvoiceOutstanding(x) > 0).length + " unpaid / partial")}${kpi("r", "Overdue", sum(od, salesInvoiceOutstanding), od.length + " overdue")}</div>
      <section class="panel sov-table"><div class="sov-th"><h3>All Invoices <small>${rows.length} of ${invs.length}</small></h3><div class="sov-tools"><input id="sivSearch" type="search" placeholder="Search invoice, client, project, contract…" value="${E(ist.q)}"><button class="btn small" onclick="salesExportInvoices('csv')">Export CSV</button><button class="btn small" onclick="pbProjectStatement('invoices')">📄 Statement</button></div></div>
      <div class="sov-wrap"><table><thead><tr>${th("number", "Invoice No")}${th("date", "Date")}${th("project", "Project")}${th("client", "Client")}<th>Contract</th><th>Type</th>${th("amount", "Amount", "r")}${th("received", "Received", "r")}${th("outstanding", "Outstanding", "r")}${th("due", "Due Date")}<th>Payment</th><th>Status</th><th></th></tr></thead><tbody>
      ${shown.map((x) => { const s = salesInvoiceStatus(x), o = salesInvoiceOutstanding(x), ps = typeof salesPaymentStatus === "function" ? salesPaymentStatus(x) : ""; return `<tr data-id="${E(x.id)}"><td><b>${E(x.number)}</b>${x.sourceBillNumber ? `<small class="sov-src">from ${E(x.sourceBillNumber)}</small>` : ""}</td><td>${E(x.date)}</td><td title="${E(projectName(x.projectId))}">${E(projectName(x.projectId))}</td><td title="${E(x.client || "")}">${E(x.client || "—")}</td><td>${E(cn(x))}</td><td>${E(x.invoiceType || "—")}</td><td class="r">${salesMoney(x.amount, x.currency)}</td><td class="r g">${salesMoney(x.received || 0, x.currency)}</td><td class="r ${o > 0 ? "o" : ""}">${salesMoney(o, x.currency)}</td><td>${E(x.dueDate || "—")}</td><td><span class="sales-status ${salesStatusClass(ps)}">${E(ps)}</span></td><td><span class="sales-status ${salesStatusClass(s)}">${E(s)}</span></td><td class="sov-act"><button class="sov-dots" aria-label="Actions">⋯</button><div class="sov-menu"><button data-a="view">👁 View details</button><button data-a="edit">✎ Edit</button><button data-a="pdf">⎙ Print / PDF</button>${o > 0 ? `<button data-a="pay">＋ Receive payment</button>` : ""}<button data-a="stmt">📄 Project statement</button></div></td></tr>`; }).join("") || `<tr><td colspan="13" class="sov-empty">${invs.length ? "No invoice matches your search." : "No invoices yet."}</td></tr>`}
      </tbody></table></div><div class="sov-pager"><span>Showing ${rows.length ? (ist.page - 1) * ist.size + 1 : 0}–${Math.min(ist.page * ist.size, rows.length)} of ${rows.length}</span><div><button class="btn small" id="sivPrev" ${ist.page <= 1 ? "disabled" : ""}>‹ Prev</button><b>${ist.page} / ${pages}</b><button class="btn small" id="sivNext" ${ist.page >= pages ? "disabled" : ""}>Next ›</button></div></div></section></div>`;
    bindFilters(ist);
    const s = document.getElementById("sivSearch"); let t;
    s.oninput = () => { clearTimeout(t); t = setTimeout(() => { ist.q = s.value; ist.page = 1; render(); const n = document.getElementById("sivSearch"); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } }, 250); };
    document.getElementById("sivPrev").onclick = () => { ist.page--; render(); };
    document.getElementById("sivNext").onclick = () => { ist.page++; render(); };
    document.querySelectorAll(".sov-sort").forEach((h) => (h.onclick = () => { const k = h.dataset.k; ist.dir = ist.sort === k ? -ist.dir : (["date", "amount", "outstanding", "received"].includes(k) ? -1 : 1); ist.sort = k; render(); }));
    bindRows();
  }
  let origInvoices = null;

  function install() {
    if (typeof salesOverview !== "function" || typeof salesApplyFilters !== "function") return setTimeout(install, 200);
    window.salesOverview = newOverview;
    try { salesOverview = newOverview; } catch (e) {}
    if (typeof salesBilling === "function") { try { salesBilling = newBilling; } catch (e) {} window.salesBilling = newBilling; }
    if (typeof salesInvoicesPage === "function") { origInvoices = salesInvoicesPage; try { salesInvoicesPage = newInvoices; } catch (e) {} window.salesInvoicesPage = newInvoices; }
    if (typeof salesConvertBillToInvoice === "function") { try { salesConvertBillToInvoice = convertBill; } catch (e) {} window.salesConvertBillToInvoice = convertBill; }
    try { if (page === "billing") render(); } catch (e) {}
  }

  // Icon-only sidebar
  function navMini() {
    const sb = document.querySelector(".app>.sidebar"); if (!sb || sb.querySelector(".pb-mini-btn")) return;
    if (localStorage.getItem("PB_NAV_MINI") === "1") document.body.classList.add("nav-mini");
    sb.querySelectorAll(".nav button[data-page]").forEach((b) => { if (!b.title) b.title = b.textContent.trim(); });
    const btn = document.createElement("button"); btn.className = "pb-mini-btn"; btn.type = "button";
    const lab = () => { const m = document.body.classList.contains("nav-mini"); btn.textContent = m ? "»" : "« Collapse menu"; btn.title = m ? "Expand menu" : "Collapse to icons"; };
    btn.onclick = () => { document.body.classList.toggle("nav-mini"); localStorage.setItem("PB_NAV_MINI", document.body.classList.contains("nav-mini") ? "1" : "0"); lab(); };
    lab(); sb.appendChild(btn);
  }

  const css = `
  @media(min-width:901px){
    html body.nav-mini .app{grid-template-columns:64px minmax(0,1fr)!important}
    html body.nav-mini .app>.sidebar{width:64px!important;min-width:64px!important;padding-left:6px!important;padding-right:6px!important;overflow-x:hidden}
    html body.nav-mini .app>.sidebar .brand-copy,html body.nav-mini .app>.sidebar .group,html body.nav-mini .app>.sidebar .sidebar-visual{display:none!important}
    html body.nav-mini .app>.sidebar .brand{justify-content:center;padding:6px 0!important}
    html body.nav-mini .app>.sidebar .nav button{font-size:0!important;justify-content:center!important;padding:9px 0!important;gap:0!important}
    html body.nav-mini .app>.sidebar .nav button .navicon{font-size:14px;margin:0!important}
    html body.nav-mini .app>.sidebar .nav button *:not(.navicon):not(.navicon *){display:none!important}
  }
  .pb-mini-btn{position:sticky;bottom:6px;margin:8px 4px 4px;width:calc(100% - 8px);border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.08);color:#dbe6f5;border-radius:8px;padding:7px 6px;font-size:12px;font-weight:700;cursor:pointer}
  .pb-mini-btn:hover{background:rgba(255,255,255,.16)}
  @media(max-width:900px){.pb-mini-btn{display:none}}

  #view .sov{display:flex;flex-direction:column;gap:8px;min-width:0}
  #view .sov .sales-tabs{margin:0!important}
  .sov-filters{display:flex;gap:8px;align-items:center;background:#fff;border:1px solid #e1e8f1;border-radius:10px;padding:6px 8px}
  .sov-filters .sales-filterbar{display:grid!important;grid-template-columns:repeat(5,minmax(110px,1fr))!important;gap:6px!important;flex:1;margin:0!important;padding:0!important;border:0!important;box-shadow:none!important;background:none!important}
  .sov-filters.more .sales-filterbar{grid-template-columns:repeat(4,minmax(110px,1fr))!important}
  .sov-filters:not(.more) #sfContract,.sov-filters:not(.more) #sfType,.sov-filters:not(.more) #sfPayment{display:none}
  .sov-filters .sales-filterbar select,.sov-filters .sales-filterbar input{height:34px!important;min-height:34px!important;font-size:13px!important;border-radius:8px!important}
  .sov-fbtns{display:flex;gap:6px;white-space:nowrap}
  .sov-dot{font-style:normal;background:#1d4ed8;color:#fff;border-radius:9px;padding:0 6px;font-size:11px;margin-left:3px}
  .sov-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
  .sov-kpi{background:#fff;border:1px solid #e1e8f1;border-left:4px solid #64748b;border-radius:10px;padding:8px 12px;min-width:0}
  .sov-kpi small{display:block;font-size:12px;font-weight:700;color:#5b6b7f;text-transform:uppercase;letter-spacing:.03em}
  .sov-kpi b{display:block;font-size:19px;color:#12233f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:2px 0}
  .sov-kpi span{font-size:12px;color:#64748b}
  .sov-kpi.b{border-left-color:#1d4ed8}.sov-kpi.g{border-left-color:#16a34a}.sov-kpi.a{border-left-color:#d97706}.sov-kpi.r{border-left-color:#dc2626}
  .sov-kpi.g b{color:#15803d}.sov-kpi.a b{color:#b45309}.sov-kpi.r b{color:#b91c1c}
  .sov-sec{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;background:#f6f8fc;border:1px solid #e1e8f1;border-radius:10px}
  .sov-sec div{padding:6px 12px;display:flex;justify-content:space-between;align-items:center;gap:8px;border-right:1px solid #e1e8f1;min-width:0}
  .sov-sec div:last-child{border-right:0}
  .sov-sec small{font-size:12px;color:#5b6b7f;font-weight:700}.sov-sec b{font-size:14px;color:#12233f;white-space:nowrap}
  .sov-main{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:8px;min-height:0}
  .sov-table{display:flex;flex-direction:column;min-width:0;padding:0!important;overflow:hidden;margin:0!important}
  .sov-th{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid #e9eef5}
  .sov-th h3{margin:0;font-size:15px;color:#12233f}.sov-th h3 small{font-weight:600;color:#64748b;font-size:12px;margin-left:6px}
  .sov-th input{height:32px;border:1px solid #d5deea;border-radius:8px;padding:0 10px;font-size:13px;width:260px;max-width:50%}
  .sov-wrap{overflow:auto;max-height:calc(100vh - 380px);min-height:180px}
  .sov-wrap table{width:100%;border-collapse:collapse;font-size:13px;min-width:820px}
  .sov-wrap th{position:sticky;top:0;z-index:2;background:#14213d;color:#fff;text-align:left;font-size:12px;font-weight:700;padding:8px 10px;white-space:nowrap}
  .sov-sort{cursor:pointer;user-select:none}.sov-sort:hover,.sov-sort.on{background:#1f3160}
  .sov-wrap td{padding:7px 10px;border-bottom:1px solid #eef2f7;white-space:nowrap;max-width:220px;overflow:hidden;text-overflow:ellipsis;color:#1e293b}
  .sov-wrap tbody tr{cursor:pointer}.sov-wrap tbody tr:hover td{background:#f3f7fd}
  .sov-wrap .r{text-align:right}.sov-wrap td.g{color:#15803d;font-weight:700}.sov-wrap td.o{color:#b91c1c;font-weight:700}
  .sov-act{position:relative;overflow:visible!important;width:36px}
  .sov-dots{border:1px solid #d5deea;background:#fff;border-radius:6px;width:28px;height:26px;cursor:pointer;font-size:16px;line-height:1;color:#334155}
  .sov-menu{display:none;position:absolute;right:8px;top:30px;z-index:20;background:#fff;border:1px solid #d5deea;border-radius:9px;box-shadow:0 10px 24px rgba(15,30,60,.16);min-width:180px;padding:4px}
  tr.menu .sov-menu{display:block}
  .sov-wrap tbody tr:nth-last-child(-n+3) .sov-menu{top:auto;bottom:30px}
  .sov-menu button{display:block;width:100%;text-align:left;border:0;background:none;padding:7px 10px;font-size:13px;border-radius:6px;cursor:pointer;color:#1e293b}
  .sov-menu button:hover{background:#eef4ff}
  .sov-empty{text-align:center;color:#64748b;padding:22px!important}
  .sov-pager{display:flex;justify-content:space-between;align-items:center;padding:6px 12px;border-top:1px solid #e9eef5;font-size:12px;color:#5b6b7f}
  .sov-pager div{display:flex;gap:8px;align-items:center}
  .sov-side{display:flex;flex-direction:column;gap:8px;min-width:0;max-height:calc(100vh - 290px);overflow:auto}
  .sov-side .panel{margin:0!important;padding:10px 12px!important}
  .sov-qa{display:grid;gap:6px}.sov-qa h4,.sov-det summary{margin:0 0 2px;font-size:14px;color:#12233f;font-weight:800}
  .sov-qa .btn{justify-content:flex-start;height:34px;font-size:13px}
  .sov-det summary{cursor:pointer;display:flex;justify-content:space-between;align-items:center;list-style:none}
  .sov-det summary::after{content:"▾";color:#64748b}.sov-det[open] summary::after{content:"▴"}
  .sov-det summary small{margin-left:auto;margin-right:6px;font-size:12px;color:#64748b}
  .sov-ag{display:grid;grid-template-columns:72px 1fr auto;gap:6px;align-items:center;font-size:12px;margin-top:6px}
  .sov-ag i,.sov-pj i{display:block;height:7px;background:#e5e7eb;border-radius:4px;overflow:hidden}
  .sov-ag em,.sov-pj em{display:block;height:100%;background:#16a34a}
  .sov-ag em.c1{background:#0ea5e9}.sov-ag em.c2{background:#f59e0b}.sov-ag em.c3{background:#f97316}.sov-ag em.c4{background:#dc2626}
  .sov-ag b{font-size:12px}
  .sov-pj{display:grid;gap:3px;margin-top:8px;font-size:12px}.sov-pj b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sov-pj small{color:#64748b}.sov-pj .o{color:#b91c1c;font-weight:700}
  @media(max-width:1180px){.sov-main{grid-template-columns:1fr}.sov-side{max-height:none;display:grid;grid-template-columns:repeat(3,minmax(0,1fr))}.sov-filters .sales-filterbar{grid-template-columns:repeat(3,minmax(110px,1fr))!important}}
  @media(max-width:760px){.sov-kpis,.sov-sec{grid-template-columns:repeat(2,minmax(0,1fr))}.sov-side{grid-template-columns:1fr}.sov-filters{flex-direction:column;align-items:stretch}.sov-filters .sales-filterbar{grid-template-columns:1fr 1fr!important}.sov-th{flex-wrap:wrap}.sov-th input{max-width:100%;width:100%}}
  body.dark-theme .sov-filters,body.dark-theme .sov-kpi,body.dark-theme .sov-sec{background:#17283c;border-color:#344960}
  body.dark-theme .sov-kpi b,body.dark-theme .sov-sec b,body.dark-theme .sov-th h3,body.dark-theme .sov-wrap td{color:#e2ecf8}
  .sov-flow{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
  .sov-flow>span{color:#94a3b8;font-weight:800}
  .sov-flow div{display:flex;align-items:baseline;gap:6px;background:#fff;border:1px solid #e1e8f1;border-radius:9px;padding:5px 12px}
  .sov-flow div b{font-size:16px}.sov-flow small{font-size:12px;color:#5b6b7f;font-weight:700}
  .sov-flow .good b{color:#15803d}.sov-flow .warn b{color:#b45309}.sov-flow .bad b{color:#b91c1c}
  .sov-sw{display:flex;background:#eef2f9;border-radius:9px;padding:3px}
  .sov-sw button{border:0;background:none;padding:6px 12px;border-radius:7px;font-weight:700;color:#475569;cursor:pointer;font-size:13px}
  .sov-sw button.on{background:#14213d;color:#fff}
  .sov-btns{display:flex;gap:4px;flex-wrap:nowrap;overflow:visible!important;max-width:none!important}
  .sov-btns .btn{height:26px;padding:2px 8px;font-size:12px}
  .sov-ok{background:#dcfce7!important;color:#15803d!important;border-color:#86efac!important}.sov-no{background:#fee2e2!important;color:#b91c1c!important;border-color:#fca5a5!important}
  .sov-tools{display:flex;gap:6px;align-items:center}.sov-tools input{height:32px;border:1px solid #d5deea;border-radius:8px;padding:0 10px;font-size:13px;width:280px}
  .sov-src{display:block;font-size:11px;color:#64748b}
  .sov-wrap td:has(.sov-src){max-width:none}
  .sov-bill .sov-bh{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:8px}.sov-bh small{display:block;font-size:11px;color:#64748b}
  .sov-bt{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}.sov-bt th{background:#14213d;color:#fff;padding:6px 8px;text-align:left;font-size:12px}.sov-bt td{padding:6px 8px;border-bottom:1px solid #eef2f7}.sov-bt .r{text-align:right}.sov-bt input{width:110px;height:30px}
  .sov-btot{max-width:420px;margin-left:auto;font-size:13px}.sov-btot div{display:flex;justify-content:space-between;padding:3px 0}.sov-btot .net{border-top:2px solid #14213d;font-size:15px;margin-top:4px;padding-top:6px}
  .sov-hist{margin-top:10px;font-size:12px;color:#5b6b7f;border-top:1px dashed #d5deea;padding-top:6px}
  `;
  const s = document.createElement("style"); s.id = "pb-sales-pro"; s.textContent = css; document.head.appendChild(s);
  const start = () => { navMini(); install(); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
