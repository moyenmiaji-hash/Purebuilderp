// Supplier Statement (Accounts Payable): one click shows every purchase bill and every payment for a supplier,
// in date order with a running balance. Read-only: it only reads db.payables / db.transactions / db.suppliers.
(function () {
  const E = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const D = () => { try { return (typeof db !== "undefined" && db) || window.db || {}; } catch { return window.db || {}; } };
  const M = (n) => (typeof money === "function" ? money(n) : "AED " + (Number(n) || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const PN = (id) => { try { return typeof projectName === "function" ? projectName(id) : id || "—"; } catch { return id || "—"; } };
  const norm = (s) => String(s || "").trim().toLowerCase();
  const fn = (name, fb) => (typeof window[name] === "function" ? window[name] : fb);
  const st = { supplier: "", project: "", from: "", to: "", q: "" };

  function bldOf(p) { try { return typeof apBld === "function" ? apBld(p) : p?.building || ""; } catch { return p?.building || ""; } }
  function itemsText(p) {
    const li = Array.isArray(p.lineItems) ? p.lineItems.filter((x) => x && (x.description || x.qty)) : [];
    if (!li.length) return "";
    return li.map((x) => `${x.description || "Item"}${x.qty ? ` · ${x.qty} ${x.unit || ""}` : ""}${x.rate ? ` @ ${Number(x.rate).toLocaleString("en-US")}` : ""}`).join("; ");
  }

  // Build every row for one supplier (all projects, or one project).
  function build(supplier, project) {
    const d = D(), key = norm(supplier);
    const isPosted = fn("apIsPosted", (p) => !["Draft", "Submitted", "Rejected", "Cancelled", "Void"].includes(p?.apStatus));
    const statusOf = fn("apPayableStatus", (p) => p?.apStatus || "Posted");
    const paidOf = fn("apPaidAmount", (p) => Number(p?.paid) || 0);
    const bills = (d.payables || []).filter((p) => norm(p.supplier) === key && (!project || p.projectId === project));
    const billIds = new Map(bills.map((p) => [String(p.id), p]));
    const allPay = new Map((d.payables || []).map((p) => [String(p.id), p]));
    const rows = [];
    for (const p of bills) {
      const s = statusOf(p);
      if (["Rejected", "Cancelled", "Canceled", "Void"].includes(s)) continue;
      const counted = isPosted(p);
      rows.push({ kind: "bill", date: p.date || "", ref: p.invoiceNo || (p.openingBalance ? "Opening balance" : "No invoice no."), id: p.id,
        type: p.openingBalance ? "Opening Balance" : "Purchase Bill", project: p.projectId, site: bldOf(p),
        desc: p.description || "Supplier bill", items: itemsText(p), due: p.dueDate || "", debit: Number(p.amount) || 0, credit: 0, counted, status: s });
    }
    const linked = new Map();
    for (const tx of d.transactions || []) {
      const kind = tx.type === "Supplier Payment" ? "pay" : tx.type === "Supplier Payment Reversal" ? "rev" : tx.type === "Supplier Credit Note" ? "cn" : tx.type === "Supplier Credit Reversal" ? "cnr" : "";
      if (!kind) continue;
      const ok = kind === "pay" ? ["Paid", "Posted"].includes(tx.status) : tx.status === "Posted";
      if (!ok) continue;
      const pid = String(tx.payableId || tx.sourcePayableId || "");
      const p = pid ? allPay.get(pid) : null;
      const sup = p ? p.supplier : tx.supplier;
      if (norm(sup) !== key) continue;
      const proj = tx.projectId || p?.projectId || "";
      if (project && proj !== project) continue;
      const amt = Math.max(0, Number(tx.amount) || 0);
      if (pid && (kind === "pay" || kind === "rev")) linked.set(pid, (linked.get(pid) || 0) + (kind === "pay" ? amt : -amt));
      const label = { pay: "Payment", rev: "Payment Reversal", cn: "Credit Note", cnr: "Credit Reversal" }[kind];
      rows.push({ kind, date: tx.date || "", ref: tx.reference || tx.invoiceNo || p?.invoiceNo || "—", type: label, project: proj, site: tx.building || (p ? bldOf(p) : ""),
        desc: tx.description || label, items: tx.paymentMethod ? `Method: ${tx.paymentMethod}${p?.invoiceNo ? ` · for ${p.invoiceNo}` : ""}` : p?.invoiceNo ? `for ${p.invoiceNo}` : "",
        debit: kind === "rev" || kind === "cnr" ? amt : 0, credit: kind === "pay" || kind === "cn" ? amt : 0, counted: true, payId: pid });
    }
    // Old bills that were marked paid without a payment entry: show that paid amount once so the balance matches the AP page.
    for (const p of bills) {
      if (!isPosted(p) || linked.has(String(p.id))) continue;
      const paid = paidOf(p);
      if (paid > 0) rows.push({ kind: "pay", date: p.paidDate || p.date || "", ref: p.invoiceNo || "—", type: "Payment", project: p.projectId, site: bldOf(p),
        desc: "Paid amount recorded on the bill", items: "", debit: 0, credit: paid, counted: true });
    }
    const order = { bill: 0, rev: 1, cnr: 1, pay: 2, cn: 2 };
    rows.sort((a, b) => String(a.date).localeCompare(String(b.date)) || order[a.kind] - order[b.kind]);
    return { rows, billCount: bills.length, billIds };
  }

  function suppliers() {
    const d = D(), map = new Map();
    const add = (name, info) => { const k = norm(name); if (!k) return; const cur = map.get(k) || { name: String(name).trim(), contact: "", phone: "", email: "", projects: new Set() }; if (info) { cur.contact ||= info.contactPerson || ""; cur.phone ||= info.phone || ""; cur.email ||= info.email || ""; } if (info?.projectId) cur.projects.add(info.projectId); map.set(k, cur); };
    (d.suppliers || []).forEach((s) => s?.name && add(s.name, s));
    (d.payables || []).forEach((p) => p?.supplier && add(p.supplier, { projectId: p.projectId }));
    return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
  }

  function totals(rows) {
    const c = rows.filter((r) => r.counted);
    const purchase = c.filter((r) => r.kind === "bill").reduce((n, r) => n + r.debit, 0);
    const paid = c.filter((r) => r.kind === "pay").reduce((n, r) => n + r.credit, 0) - c.filter((r) => r.kind === "rev").reduce((n, r) => n + r.debit, 0);
    const credit = c.filter((r) => r.kind === "cn").reduce((n, r) => n + r.credit, 0) - c.filter((r) => r.kind === "cnr").reduce((n, r) => n + r.debit, 0);
    return { purchase, paid, credit, balance: purchase - paid - credit };
  }

  function view() {
    const all = build(st.supplier, st.project).rows;
    let opening = 0;
    const before = st.from ? all.filter((r) => r.date && r.date < st.from) : [];
    before.filter((r) => r.counted).forEach((r) => { opening += r.debit - r.credit; });
    const q = norm(st.q);
    let rows = all.filter((r) => (!st.from || !r.date || r.date >= st.from) && (!st.to || !r.date || r.date <= st.to));
    let bal = opening;
    rows = rows.map((r) => { if (r.counted) bal += r.debit - r.credit; return { ...r, bal }; });
    const shown = q ? rows.filter((r) => norm([r.ref, r.type, r.desc, r.items, PN(r.project), r.site].join(" ")).includes(q)) : rows;
    return { all, rows, shown, opening, closing: bal };
  }

  function lastDate(rows, kind) { const r = rows.filter((x) => x.kind === kind && x.date).map((x) => x.date).sort(); return r[r.length - 1] || "—"; }

  function render() {
    const ov = document.querySelector(".ss-ov"); if (!ov) return;
    const info = suppliers().find((s) => norm(s.name) === norm(st.supplier)) || { name: st.supplier, projects: new Set() };
    const v = view(), t = totals(v.rows), tAll = totals(v.all);
    const projIds = [...new Set(build(st.supplier, "").rows.map((r) => r.project).filter(Boolean))];
    const kpi = (label, val, sub, cls = "") => `<div class="ss-kpi ${cls}"><small>${label}</small><b>${val}</b><span>${sub}</span></div>`;
    const billsN = v.rows.filter((r) => r.kind === "bill").length, payN = v.rows.filter((r) => r.kind === "pay").length;
    const body = v.shown.map((r) => `<tr class="${r.counted ? "" : "ss-nc"} ss-${r.kind}"><td>${E(r.date || "—")}</td><td><span class="ss-tag ${r.kind}">${E(r.type)}</span>${r.counted ? "" : `<small class="ss-sub">${E(r.status)} · not counted yet</small>`}</td>
      <td>${r.kind === "bill" && r.id && typeof viewPayableInvoice === "function" ? `<a href="#" onclick="event.preventDefault();viewPayableInvoice('${E(r.id)}')"><b>${E(r.ref)}</b></a>` : `<b>${E(r.ref)}</b>`}${r.due ? `<small class="ss-sub">Due ${E(r.due)}</small>` : ""}</td>
      <td>${E(PN(r.project))}${r.site ? `<small class="ss-sub">${E(r.site)}</small>` : ""}</td>
      <td>${E(r.desc)}${r.items ? `<small class="ss-sub">${E(r.items)}</small>` : ""}</td>
      <td class="num">${r.debit ? M(r.debit) : ""}</td><td class="num">${r.credit ? M(r.credit) : ""}</td><td class="num"><b>${M(r.bal)}</b></td></tr>`).join("");
    ov.querySelector(".ss-body").innerHTML = `
      <div class="ss-head"><div class="ss-av">${E(info.name.slice(0, 1).toUpperCase())}</div><div class="ss-who"><span class="ss-eye">SUPPLIER STATEMENT</span><h2>${E(info.name)}</h2>
        <p>${[info.contact, info.phone, info.email].filter(Boolean).map(E).join(" · ") || "Purchases and payments in date order"}</p></div>
        <div class="ss-due ${tAll.balance > 0 ? "red" : "green"}"><small>Balance due now</small><b>${M(tAll.balance)}</b><span>${tAll.balance > 0 ? "We owe this supplier" : "Nothing due"}</span></div></div>
      <div class="ss-filters">
        <label>Project<select data-k="project"><option value="">All Projects</option>${projIds.map((id) => `<option value="${E(id)}" ${st.project === id ? "selected" : ""}>${E(PN(id))}</option>`).join("")}</select></label>
        <label>From<input type="date" data-k="from" value="${E(st.from)}"></label><label>To<input type="date" data-k="to" value="${E(st.to)}"></label>
        <label class="grow">Search<input data-k="q" placeholder="Bill no, item, site, payment ref…" value="${E(st.q)}"></label>
        <div class="ss-quick"><button data-r="month">This month</button><button data-r="year">This year</button><button data-r="all">All time</button></div></div>
      <div class="ss-kpis">${kpi("Total Purchases", M(t.purchase), `${billsN} bill(s) · last ${E(lastDate(v.rows, "bill"))}`)}${kpi("Total Paid", M(t.paid), `${payN} payment(s) · last ${E(lastDate(v.rows, "pay"))}`, "green")}${kpi("Credit Notes", M(t.credit), "Returns / discounts")}${kpi("Opening", M(v.opening), st.from ? `Before ${E(st.from)}` : "Start of record")}${kpi("Closing Balance", M(v.closing), st.to ? `On ${E(st.to)}` : "Up to today", v.closing > 0 ? "red" : "green")}</div>
      <div class="ss-tw"><table class="ss-t"><thead><tr><th>Date</th><th>Type</th><th>Bill / Ref</th><th>Project / Site</th><th>What was bought / paid</th><th class="num">Purchase</th><th class="num">Paid</th><th class="num">Balance</th></tr></thead>
        <tbody>${st.from ? `<tr class="ss-open"><td>${E(st.from)}</td><td colspan="6"><b>Balance brought forward</b></td><td class="num"><b>${M(v.opening)}</b></td></tr>` : ""}${body || `<tr><td colspan="8" class="ss-empty">No purchases or payments for this supplier${st.project || st.from || st.to || st.q ? " with these filters" : ""}.</td></tr>`}</tbody>
        <tfoot><tr><th colspan="5">Total (${v.rows.length} entries)</th><th class="num">${M(t.purchase + v.rows.filter((r) => r.counted && (r.kind === "rev" || r.kind === "cnr")).reduce((n, r) => n + r.debit, 0))}</th><th class="num">${M(v.rows.filter((r) => r.counted).reduce((n, r) => n + r.credit, 0))}</th><th class="num">${M(v.closing)}</th></tr></tfoot></table></div>
      <p class="ss-note">Grey rows are bills not yet approved/posted — shown for information, not added to the balance.</p>`;
    ov.querySelectorAll(".ss-filters [data-k]").forEach((el) => {
      const k = el.dataset.k;
      el.addEventListener(k === "q" ? "input" : "change", () => { st[k] = el.value; if (k === "q") { clearTimeout(st.qt); st.qt = setTimeout(() => { render(); const i = document.querySelector('.ss-filters [data-k="q"]'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 250); } else render(); });
    });
    ov.querySelectorAll(".ss-quick [data-r]").forEach((b) => b.addEventListener("click", () => {
      const n = new Date(), pad = (x) => String(x).padStart(2, "0"), td = `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`;
      if (b.dataset.r === "month") { st.from = `${n.getFullYear()}-${pad(n.getMonth() + 1)}-01`; st.to = td; }
      else if (b.dataset.r === "year") { st.from = `${n.getFullYear()}-01-01`; st.to = td; } else { st.from = ""; st.to = ""; }
      render();
    }));
  }

  function shell(title, inner, actions) {
    document.querySelector(".ss-ov")?.remove();
    const ov = document.createElement("div"); ov.className = "ss-ov";
    ov.innerHTML = `<div class="ss-modal" role="dialog" aria-label="${E(title)}"><div class="ss-bar"><b>${E(title)}</b><div class="ss-act">${actions || ""}<button class="btn small" data-close>✕ Close</button></div></div><div class="ss-body">${inner || ""}</div></div>`;
    ov.addEventListener("click", (e) => { if (e.target === ov || e.target.closest("[data-close]")) ov.remove(); });
    document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { ov.remove(); document.removeEventListener("keydown", esc); } });
    document.body.append(ov); return ov;
  }

  function open(supplier, project) {
    st.supplier = decodeURIComponent(supplier || ""); st.project = project || ""; st.q = ""; st.from = ""; st.to = "";
    if (typeof closeModal === "function") { try { closeModal(); } catch {} }
    const ov = shell("Supplier Statement", "", `<button class="btn small" data-csv>⬇ CSV</button><button class="btn small primary" data-print>🖨 Print / PDF</button>`);
    ov.querySelector("[data-csv]").onclick = csv; ov.querySelector("[data-print]").onclick = print;
    render();
  }

  function picker() {
    const list = suppliers(), payOut = fn("apOutstandingAmount", () => 0), isPosted = fn("apIsPosted", () => true);
    const due = (name) => (D().payables || []).filter((p) => norm(p.supplier) === norm(name) && isPosted(p)).reduce((n, p) => n + payOut(p), 0);
    const cards = (q) => list.filter((s) => !q || norm(s.name + " " + s.contact + " " + s.phone).includes(norm(q))).map((s) => { const d = due(s.name);
      return `<button class="ss-pick" data-s="${E(encodeURIComponent(s.name))}"><span class="ss-av sm">${E(s.name.slice(0, 1).toUpperCase())}</span><span class="ss-pn"><b>${E(s.name)}</b><small>${E([s.contact, s.phone].filter(Boolean).join(" · ") || [...s.projects].map(PN).join(", ") || "Supplier")}</small></span><span class="ss-pd ${d > 0 ? "red" : ""}">${d > 0 ? M(d) + " due" : "No due"}</span></button>`; }).join("") || '<div class="ss-empty">No suppliers yet. Add a bill or supplier first.</div>';
    const ov = shell("Supplier Statement — choose supplier", `<div class="ss-pickhead"><input class="ss-search" placeholder="Search supplier name or phone…" autofocus></div><div class="ss-picks">${cards("")}</div>`);
    const wire = () => ov.querySelectorAll(".ss-pick").forEach((b) => b.onclick = () => open(b.dataset.s, ""));
    ov.querySelector(".ss-search").oninput = (e) => { ov.querySelector(".ss-picks").innerHTML = cards(e.target.value); wire(); };
    wire();
  }

  function csv() {
    const v = view(), cell = (x) => `"${String(x ?? "").replace(/"/g, '""')}"`;
    const lines = [["Supplier", st.supplier], ["Project", st.project ? PN(st.project) : "All Projects"], ["From", st.from || "Start"], ["To", st.to || "Today"], [],
      ["Date", "Type", "Bill / Ref", "Project", "Site", "Description", "Items / Method", "Purchase (AED)", "Paid (AED)", "Balance (AED)", "Counted"]];
    if (st.from) lines.push([st.from, "Balance brought forward", "", "", "", "", "", "", "", v.opening.toFixed(2), "yes"]);
    v.shown.forEach((r) => lines.push([r.date, r.type, r.ref, PN(r.project), r.site, r.desc, r.items, r.debit ? r.debit.toFixed(2) : "", r.credit ? r.credit.toFixed(2) : "", r.bal.toFixed(2), r.counted ? "yes" : "no (not posted)"]));
    const blob = new Blob(["\ufeff" + lines.map((l) => l.map(cell).join(",")).join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `Supplier_Statement_${st.supplier.replace(/[^\w]+/g, "_")}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  function print() {
    const v = view(), t = totals(v.rows), d = D(), co = (d.settings && (d.settings.companyName || d.settings.company)) || "PURE_BUILD";
    const rows = (st.from ? `<tr><td>${E(st.from)}</td><td colspan="5"><b>Balance brought forward</b></td><td class="n"><b>${M(v.opening)}</b></td></tr>` : "") + v.shown.map((r) => `<tr style="${r.counted ? "" : "color:#999"}"><td>${E(r.date)}</td><td>${E(r.type)}</td><td>${E(r.ref)}</td><td>${E(PN(r.project))}${r.site ? " / " + E(r.site) : ""}</td><td>${E(r.desc)}${r.items ? `<br><small>${E(r.items)}</small>` : ""}</td><td class="n">${r.debit ? M(r.debit) : ""}${r.credit ? "−" + M(r.credit) : ""}</td><td class="n">${M(r.bal)}</td></tr>`).join("");
    const w = window.open("", "_blank"); if (!w) return alert("Please allow pop-ups to print.");
    w.document.write(`<!doctype html><html><head><title>Supplier Statement - ${E(st.supplier)}</title><style>body{font-family:Arial,sans-serif;color:#172337;margin:28px;font-size:12px}h1{margin:0;font-size:20px}.top{display:flex;justify-content:space-between;border-bottom:2px solid #1d4f91;padding-bottom:10px;margin-bottom:14px}.k{display:flex;gap:10px;margin:12px 0}.k div{flex:1;border:1px solid #dde4ee;border-radius:6px;padding:8px}.k small{display:block;color:#667}.k b{font-size:14px}table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #e3e8ef;padding:6px;text-align:left;vertical-align:top}th{background:#f1f5fa}.n{text-align:right;white-space:nowrap}tfoot th{border-top:2px solid #1d4f91}@media print{body{margin:10mm}}</style></head><body>
      <div class="top"><div><h1>${E(co)}</h1><div>Supplier Statement</div></div><div style="text-align:right"><b>${E(st.supplier)}</b><br>${E(st.project ? PN(st.project) : "All Projects")}<br>${E(st.from || "Start")} → ${E(st.to || new Date().toISOString().slice(0, 10))}</div></div>
      <div class="k"><div><small>Total Purchases</small><b>${M(t.purchase)}</b></div><div><small>Total Paid</small><b>${M(t.paid)}</b></div><div><small>Credit Notes</small><b>${M(t.credit)}</b></div><div><small>Closing Balance</small><b>${M(v.closing)}</b></div></div>
      <table><thead><tr><th>Date</th><th>Type</th><th>Bill / Ref</th><th>Project / Site</th><th>Details</th><th class="n">Amount</th><th class="n">Balance</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><th colspan="6">Closing balance</th><th class="n">${M(v.closing)}</th></tr></tfoot></table>
      <p style="margin-top:30px;color:#667">Printed ${new Date().toLocaleString()}</p><script>setTimeout(()=>print(),300)<\/script></body></html>`);
    w.document.close();
  }

  window.openSupplierStatement = open;
  window.openSupplierStatementPicker = picker;
  window.PB_SUPPLIER_STATEMENT_ROWS = build; // used by tests / other screens (read-only)

  const css = document.createElement("style");
  css.textContent = `
  .ss-ov{position:fixed;inset:0;z-index:9000;background:rgba(15,27,45,.55);display:flex;align-items:center;justify-content:center;padding:16px}
  .ss-modal{background:#fff;color:#172337;width:min(1320px,100%);max-height:calc(100vh - 32px);border-radius:14px;display:flex;flex-direction:column;box-shadow:0 24px 60px rgba(10,25,50,.35);overflow:hidden}
  .ss-bar{display:flex;justify-content:space-between;align-items:center;padding:10px 16px;border-bottom:1px solid #e6ecf3;background:#f7f9fc}.ss-bar>b{font-size:14px}.ss-act{display:flex;gap:6px}
  .ss-body{padding:14px 16px;overflow:auto}
  .ss-head{display:flex;gap:14px;align-items:center;margin-bottom:12px}.ss-av{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#1d4f91,#2b7bd6);color:#fff;display:grid;place-items:center;font-weight:800;font-size:20px;flex:none}.ss-av.sm{width:34px;height:34px;font-size:14px;border-radius:9px}
  .ss-who{flex:1;min-width:0}.ss-eye{font-size:10px;letter-spacing:.12em;color:#5a7393;font-weight:700}.ss-who h2{margin:2px 0;font-size:21px}.ss-who p{margin:0;color:#6b7c93;font-size:12px}
  .ss-due{border-radius:12px;padding:10px 16px;text-align:right;min-width:200px}.ss-due small,.ss-due span{display:block;font-size:11px}.ss-due b{font-size:22px}.ss-due.red{background:#fff1f1;color:#b42318}.ss-due.green{background:#ecf9f1;color:#17663a}
  .ss-filters{display:flex;gap:10px;align-items:end;flex-wrap:wrap;padding:10px;background:#f7f9fc;border:1px solid #e6ecf3;border-radius:10px}.ss-filters label{display:grid;gap:3px;font-size:11px;color:#5a6b80;font-weight:600}.ss-filters label.grow{flex:1;min-width:200px}
  .ss-filters select,.ss-filters input{height:34px;border:1px solid #d6dee9;border-radius:8px;padding:4px 9px;font-size:13px;background:#fff;color:inherit}
  .ss-quick{display:flex;gap:4px}.ss-quick button{height:34px;border:1px solid #d6dee9;background:#fff;border-radius:8px;padding:0 10px;font-size:12px;cursor:pointer;color:inherit}.ss-quick button:hover{border-color:#2b7bd6;color:#1d4f91}
  .ss-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:12px 0}.ss-kpi{border:1px solid #e6ecf3;border-radius:10px;padding:10px 12px;border-top:3px solid #2b7bd6}.ss-kpi.green{border-top-color:#1f9d55}.ss-kpi.red{border-top-color:#d92d20}
  .ss-kpi small{display:block;font-size:11px;color:#6b7c93;font-weight:600}.ss-kpi b{display:block;font-size:17px;margin:3px 0}.ss-kpi span{font-size:11px;color:#8090a5}
  .ss-tw{border:1px solid #e6ecf3;border-radius:10px;overflow:auto;max-height:calc(100vh - 380px);min-height:160px}
  .ss-t{width:100%;border-collapse:collapse;font-size:12.5px}.ss-t th,.ss-t td{padding:8px 10px;border-bottom:1px solid #eef2f7;text-align:left;vertical-align:top}
  .ss-t thead th{position:sticky;top:0;background:#f1f5fa;font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#5a6b80;z-index:1}
  .ss-t tfoot th{position:sticky;bottom:0;background:#eef3fa;border-top:2px solid #c9d6e8}.ss-t .num{text-align:right;white-space:nowrap}
  .ss-t tbody tr:hover{background:#f8fbff}.ss-sub{display:block;color:#7b8ba0;font-size:11px;margin-top:2px}.ss-nc td{color:#9aa6b5}.ss-open td{background:#fbfaf3}
  .ss-tag{display:inline-block;font-size:10.5px;font-weight:700;padding:2px 8px;border-radius:20px;background:#e8f0fb;color:#1d4f91;white-space:nowrap}.ss-tag.pay{background:#e6f6ec;color:#17663a}.ss-tag.cn{background:#f1ecfb;color:#5b3aa8}.ss-tag.rev,.ss-tag.cnr{background:#fff1e6;color:#9a4b00}
  .ss-t a{color:#1d4f91;text-decoration:none}.ss-t a:hover{text-decoration:underline}.ss-empty{text-align:center;color:#8090a5;padding:26px}.ss-note{font-size:11px;color:#8090a5;margin:8px 2px 0}
  .ss-pickhead{margin-bottom:10px}.ss-search{width:100%;height:40px;border:1px solid #d6dee9;border-radius:10px;padding:0 12px;font-size:14px;box-sizing:border-box}
  .ss-picks{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:8px}.ss-pick{display:flex;align-items:center;gap:10px;border:1px solid #e3e9f1;background:#fff;border-radius:10px;padding:10px;text-align:left;cursor:pointer;color:inherit}.ss-pick:hover{border-color:#2b7bd6;box-shadow:0 4px 14px rgba(29,79,145,.12)}
  .ss-pn{flex:1;min-width:0}.ss-pn b{display:block}.ss-pn small{display:block;color:#7b8ba0;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ss-pd{font-size:11.5px;font-weight:700;color:#17663a;white-space:nowrap}.ss-pd.red{color:#b42318}
  body.dark-theme .ss-modal,body.dark-theme .ss-pick,body.dark-theme .ss-kpi{background:#142235;color:#e3edf8;border-color:#2a4163}body.dark-theme .ss-bar,body.dark-theme .ss-filters,body.dark-theme .ss-t thead th,body.dark-theme .ss-t tfoot th{background:#0f1b2b;border-color:#2a4163;color:#cfdbea}
  body.dark-theme .ss-filters select,body.dark-theme .ss-filters input,body.dark-theme .ss-quick button,body.dark-theme .ss-search{background:#0f1b2b;color:#e3edf8;border-color:#2a4163}body.dark-theme .ss-t td{border-color:#22344f}body.dark-theme .ss-t tbody tr:hover{background:#18293f}body.dark-theme .ss-tw{border-color:#2a4163}
  body.dark-theme .ss-bar .btn:not(.primary){background:#142235!important;color:#e3edf8!important;border-color:#2a4163!important}body.dark-theme .ss-due.red{background:#2e1517;color:#ffb4ab}body.dark-theme .ss-due.green{background:#10291d;color:#8fe0ad}body.dark-theme .ss-t a{color:#8cb8ff}body.dark-theme .ss-open td{background:#1c2a20}
  @media(max-width:900px){.ss-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.ss-head{flex-wrap:wrap}.ss-due{width:100%;text-align:left}.ss-tw{max-height:none}}
  `;
  document.head.append(css);
})();
