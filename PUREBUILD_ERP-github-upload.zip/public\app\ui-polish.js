// UI polish layer (p64): material statement, tidy Labour & HR reports, compact stock overview.
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const F = (n) => Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
  const pn = (id) => (typeof projectName === "function" ? projectName(id) : id || "—");
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  // ---------- One-click Material Statement ----------
  function moves() { return (window._stockCsv && window._stockCsv.arr) || (window.db && db.stock) || []; }
  function keyOf(x) { return String(x.item || "").trim().toLowerCase() + "|" + String(x.unit || ""); }
  function draw(item, unit, proj, from, to) {
    const all = moves();
    const names = [...new Map(all.map((x) => [keyOf(x), { item: x.item, unit: x.unit }])).values()].sort((a, b) => String(a.item).localeCompare(String(b.item)));
    const projects = [...new Set(all.map((x) => x.projectId).filter(Boolean))];
    const k = item ? String(item).trim().toLowerCase() + "|" + String(unit || "") : "";
    let rows = all.filter((x) => (!k || keyOf(x) === k) && (!proj || x.projectId === proj)).slice().sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let opening = 0;
    if (from) { rows.filter((x) => String(x.date) < from).forEach((x) => { opening += (x.direction === "In" ? 1 : -1) * Number(x.qty || 0); }); rows = rows.filter((x) => String(x.date) >= from); }
    if (to) rows = rows.filter((x) => String(x.date) <= to);
    let bal = opening, tin = 0, tout = 0;
    const body = rows.map((x) => {
      const q = Number(x.qty || 0), isIn = x.direction === "In";
      if (isIn) tin += q; else tout += q;
      bal += isIn ? q : -q;
      return `<tr><td>${E(x.date)}</td>${k ? "" : `<td><b>${E(x.item)}</b></td>`}<td>${E(pn(x.projectId))}${x.building ? ` <small class="muted">· ${E(x.building)}</small>` : ""}</td><td>${E(x.movement || x.type || (isIn ? "In" : "Out"))}</td><td class="r g">${isIn ? F(q) : ""}</td><td class="r o">${isIn ? "" : F(q)}</td>${k ? `<td class="r"><b>${F(bal)}</b></td>` : ""}<td>${E(x.note || x.ref || x.supplier || "")}</td></tr>`;
    }).join("");
    const u = k ? E(unit) : "";
    return `<div class="pbms">
      <div class="pbms-f"><label>Material<select id="pbmsItem"><option value="">All materials</option>${names.map((n) => `<option value="${E(n.item)}|${E(n.unit)}" ${keyOf(n) === k ? "selected" : ""}>${E(n.item)} (${E(n.unit)})</option>`).join("")}</select></label>
      <label>Project<select id="pbmsProj"><option value="">All projects</option>${projects.map((p) => `<option value="${E(p)}" ${p === proj ? "selected" : ""}>${E(pn(p))}</option>`).join("")}</select></label>
      <label>From<input type="date" id="pbmsFrom" value="${E(from || "")}"></label><label>To<input type="date" id="pbmsTo" value="${E(to || "")}"></label>
      <button class="btn small" onclick="pbMatStatementPrint()">⎙ Print</button></div>
      <div class="pbms-k">${k ? `<div><small>Opening</small><b>${F(opening)} ${u}</b></div>` : ""}<div class="g"><small>Total In</small><b>${F(tin)} ${u}</b></div><div class="o"><small>Total Out</small><b>${F(tout)} ${u}</b></div>${k ? `<div class="b"><small>Closing balance</small><b>${F(bal)} ${u}</b></div>` : `<div><small>Entries</small><b>${rows.length}</b></div>`}</div>
      ${k ? "" : `<p class="muted" style="margin:0 0 6px">Pick one material to see its running balance.</p>`}
      <div class="pbms-t" id="pbmsPrint"><table><thead><tr><th>Date</th>${k ? "" : "<th>Material</th>"}<th>Project / Site</th><th>Type</th><th class="r">In</th><th class="r">Out</th>${k ? '<th class="r">Balance</th>' : ""}<th>Note</th></tr></thead><tbody>${body || `<tr><td colspan="8" class="empty">No movements found.</td></tr>`}</tbody></table></div></div>`;
  }
  function bind() {
    const go = () => {
      const v = document.getElementById("pbmsItem").value, i = v.lastIndexOf("|");
      const html = draw(v ? v.slice(0, i) : "", v ? v.slice(i + 1) : "", document.getElementById("pbmsProj").value, document.getElementById("pbmsFrom").value, document.getElementById("pbmsTo").value);
      document.getElementById("modalBody").innerHTML = html; bind();
    };
    ["pbmsItem", "pbmsProj", "pbmsFrom", "pbmsTo"].forEach((id) => { const el = document.getElementById(id); if (el) el.onchange = go; });
  }
  window.pbMatStatement = function (item, unit) {
    if (typeof openModal !== "function") return;
    openModal("Material Statement", draw(item || "", unit || "", "", "", ""), () => true);
    const s = document.getElementById("modalSave"); if (s) s.style.display = "none";
    const box = document.querySelector("#modal .modalbox"); if (box) box.style.width = "min(1100px,96vw)";
    bind();
  };
  window.pbMatStatementPrint = function () {
    const o = document.getElementById("pbmsPrint"), k = document.querySelector(".pbms-k"); if (!o) return;
    const sel = document.getElementById("pbmsItem"), title = sel && sel.value ? sel.options[sel.selectedIndex].text : "All materials";
    const w = window.open("", "_blank"); if (!w) return;
    w.document.write(`<html><head><title>Material Statement</title><style>body{font-family:Arial;font-size:12px;padding:16px}h2{margin:0 0 4px}.pbms-k{display:flex;gap:10px;margin:8px 0}.pbms-k div{border:1px solid #ccc;padding:4px 10px;border-radius:6px}.pbms-k small{display:block;color:#555}table{border-collapse:collapse;width:100%}th,td{border:1px solid #bbb;padding:4px 6px;text-align:left}th{background:#14213d;color:#fff;-webkit-print-color-adjust:exact}.r{text-align:right}</style></head><body><h2>PURE BUILD · Material Statement</h2><div>${E(title)} · Printed ${E(new Date().toLocaleString())}</div><div class="pbms-k">${k ? k.innerHTML : ""}</div>${o.innerHTML}</body></html>`);
    w.document.close(); setTimeout(() => w.print(), 250);
  };

  // ---------- Labour & HR report: hide raw system ids ----------
  function tidyReport() {
    const out = document.getElementById("hrReportOutput"); if (!out) return;
    out.querySelectorAll("td").forEach((td) => { const t = td.textContent.trim(); if (UUID.test(t)) { td.textContent = "—"; td.title = "No worker ID set"; } });
  }
  const wrap = () => {
    if (typeof window.hrBuildReport === "function" && !window.hrBuildReport.__pb) {
      const orig = window.hrBuildReport;
      window.hrBuildReport = function () { const r = orig.apply(this, arguments); tidyReport(); return r; };
      window.hrBuildReport.__pb = true;
    }
  };
  wrap(); document.addEventListener("DOMContentLoaded", wrap);
  const v = () => document.getElementById("view");
  const obs = () => { const el = v(); if (el) new MutationObserver(() => { wrap(); tidyReport(); }).observe(el, { childList: true }); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", obs); else obs();

  // ---------- Styles ----------
  const css = `
  .pbms-f{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;margin-bottom:10px}
  .pbms-f label{display:flex;flex-direction:column;font-size:11px;font-weight:700;color:#5b6b7f;gap:3px}
  .pbms-f select,.pbms-f input{height:34px;border:1px solid #d5deea;border-radius:8px;padding:0 8px;font-size:13px;min-width:150px}
  .pbms-k{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-bottom:10px}
  .pbms-k div{border:1px solid #e3e9f2;border-left:4px solid #64748b;border-radius:10px;padding:8px 12px;background:#fff}
  .pbms-k div.g{border-left-color:#16a34a}.pbms-k div.o{border-left-color:#dc2626}.pbms-k div.b{border-left-color:#1d4ed8}
  .pbms-k small{display:block;font-size:11px;color:#64748b;font-weight:700}.pbms-k b{font-size:17px}
  .pbms-t{max-height:52vh;overflow:auto;border:1px solid #e3e9f2;border-radius:10px}
  .pbms-t table{width:100%;border-collapse:collapse;font-size:13px}
  .pbms-t th{position:sticky;top:0;background:#14213d;color:#fff;padding:8px;text-align:left;font-size:12px}
  .pbms-t td{padding:7px 8px;border-bottom:1px solid #eef2f7}.pbms-t .r{text-align:right}
  .pbms-t td.g{color:#15803d;font-weight:700}.pbms-t td.o{color:#b91c1c;font-weight:700}
  /* stock overview: fit one screen */
  @media (min-width:1100px){
   .stock-ov .stock-ov-kpi{padding:8px 12px!important}
   .stock-ov .stock-ov-kpi strong{font-size:19px!important}
   .stock-ov .stock-ov-grid>.panel,.stock-ov .stock-ov-grid2>.panel{max-height:250px;overflow:auto;padding:10px 12px!important}
   .stock-ov .stock-ov-grid2>.panel{max-height:200px}
   .stock-ov .panel h3{font-size:14px!important;margin:0 0 6px!important}
   .stock-ov .stock-ov-row{padding:5px 0!important}
   .stock-ov-bar{padding:3px 0}
   .stock-ov-bar:hover b{color:#1d4ed8;text-decoration:underline}
   /* p65: whole Stock Overview fits one desktop screen */
   #view:has(.stock-ov) .pb-pend-stock{padding:6px 12px!important;margin:0 0 8px!important;font-size:13px}
   #view:has(.stock-ov) .pb-pend-stock>div:not(:first-child):not(.table-wrap){display:none}
   #view:has(.stock-ov) .pb-pend-stock .table-wrap{max-height:110px;overflow:auto}
   #view:has(.stock-ov) .pagehead{padding:8px 14px!important;margin-bottom:8px!important;min-height:0!important;align-items:center}
   #view:has(.stock-ov) .pagehead h1{font-size:20px!important;margin:0!important}
   #view:has(.stock-ov) .pagehead .actions{display:flex;flex-wrap:nowrap;gap:6px;align-items:center}
   #view:has(.stock-ov) .pagehead .actions select{height:34px;min-width:160px;max-width:220px}
   #view:has(.stock-ov) .pagehead .actions .btn{height:34px;padding:0 12px}
   #view:has(.stock-ov) .stock-tabs{margin:0 0 8px!important;padding:3px!important}
   #view:has(.stock-ov) .stock-tabs button{padding:6px 11px!important}
   .stock-ov .stock-ov-kpis{margin-bottom:8px!important}
   .stock-ov .stock-ov-kpi{padding:6px 10px!important}
   .stock-ov .stock-ov-kpi strong{font-size:17px!important;margin:1px 0!important}
   .stock-ov .stock-ov-grid>.panel{height:calc((100vh - 372px) * .55);min-height:150px!important;max-height:none!important}
   .stock-ov .stock-ov-grid2{margin-top:8px!important}
   .stock-ov .stock-ov-grid2>.panel{height:calc((100vh - 372px) * .45);min-height:130px;max-height:none!important;overflow:auto}
   .stock-ov .stock-ov-grid2 svg{max-height:calc((100vh - 372px) * .45 - 60px)}
  }
  /* Labour & HR report: readable */
  .hrr-toolbar select,.hrr-toolbar input{font-size:13px!important;height:36px!important}
  .hrr-f small{font-size:11px!important;font-weight:700;color:#5b6b7f;text-transform:uppercase;letter-spacing:.03em}
  .hrr-out{max-height:calc(100vh - 230px);overflow:auto}
  .hrr-out table{font-size:13px}
  .hrr-out thead th{position:sticky;top:0;z-index:1}
  .hrr-out tbody tr:nth-child(even) td{background:#f8fafc}
  .hrr-out tbody td{padding:7px 10px!important;white-space:nowrap}
  .hrr-side{max-height:calc(100vh - 230px);overflow:auto}
  .hrr-item{font-size:13px!important;padding:6px 10px!important}
  /* p100: every Warehouse/Stock tab fits one desktop screen (layout only) */
  @media (min-width:1100px){
   #view:has(.stock-tabs) .pb-pend-stock{padding:5px 12px!important;margin:0 0 6px!important;font-size:12.5px}
   #view:has(.stock-tabs) .pb-pend-stock>div:not(:first-child):not(.table-wrap){display:none}
   #view:has(.stock-tabs) .pb-pend-stock .table-wrap{max-height:90px;overflow:auto}
   #view:has(.stock-tabs) .pagehead{display:flex!important;flex-wrap:nowrap!important;align-items:center!important;justify-content:space-between;gap:10px;padding:6px 14px!important;margin-bottom:6px!important;min-height:0!important}
   #view:has(.stock-tabs) .pagehead h1{font-size:19px!important;margin:0!important;white-space:nowrap}
   #view:has(.stock-tabs) .pagehead p{display:none}
   #view:has(.stock-tabs) .pagehead .actions{display:flex!important;flex-wrap:nowrap!important;gap:6px;align-items:center;flex-direction:row!important}
   #view:has(.stock-tabs) .pagehead .actions select{height:32px;padding-top:0!important;padding-bottom:0!important;line-height:30px;min-width:150px;max-width:220px;width:auto!important}
   #view:has(.stock-tabs) .pagehead .actions .btn{height:32px;padding:0 11px;white-space:nowrap}
   #view:has(.stock-tabs) .stock-tabs{margin:0 0 6px!important;padding:3px!important;display:flex!important;flex-wrap:wrap!important;gap:2px!important;align-items:center}
   #view:has(.stock-tabs) .stock-tabs button{padding:5px 9px!important;font-size:12px!important;white-space:nowrap;flex:0 0 auto}
   #view:has(.stock-tabs) .stock-tabs .stock-tab-tools{display:flex;gap:4px;margin-left:auto;flex:0 0 auto}
   #view:has(.stock-tabs) .sp-filters{padding:4px 6px!important;margin:0 0 6px!important;flex-wrap:nowrap!important}
   #view:has(.stock-tabs) .sp-filters select,#view:has(.stock-tabs) .sp-filters input{min-height:30px!important;height:30px;font-size:12px!important;flex:1 1 0;min-width:0}
   #view:has(.stock-tabs) .sp-filters>*:not(select):not(input){white-space:nowrap;font-size:11px}
   #view:has(.stock-tabs) .sp-kpis{margin-bottom:6px!important;gap:6px!important}
   #view:has(.stock-tabs) .sp-kpis>*{padding:5px 10px!important}
   #view:has(.stock-tabs) .sp-kpis b,#view:has(.stock-tabs) .sp-kpis strong{font-size:17px!important}
   #view:has(.stock-tabs) .stock-tab-body .panel{padding:8px 12px!important;margin-top:0!important}
   #view:has(.stock-tabs) .stock-tab-body .panel .toolbar{margin-bottom:6px!important}
   #view:has(.stock-tabs) .stock-tab-body .panel h3{font-size:14px!important}
   #view:has(.stock-tabs) .stock-tab-body th,#view:has(.stock-tabs) .stock-tab-body td{padding-top:6px!important;padding-bottom:6px!important}
  }
  `;
  const st = document.createElement("style"); st.id = "pb-ui-polish"; st.textContent = css; document.head.appendChild(st);
})();
