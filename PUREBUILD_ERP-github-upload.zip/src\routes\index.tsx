import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PURE BUILD ERP" },
      { name: "description", content: "PURE BUILD construction ERP and staff portal." },
      { property: "og:title", content: "PURE BUILD ERP" },
      { property: "og:description", content: "PURE BUILD construction ERP and staff portal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    window.location.replace("/app/erp.html");
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-muted-foreground">
      <a href="/app/erp.html">Opening PURE BUILD ERP…</a>
    </div>
  );
}
