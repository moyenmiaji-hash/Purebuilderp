/* Sales "View all" (read-only): full-screen list of every filtered invoice with search + print; plus phone-screen compact layout for all Sales tabs. Never changes data. */
(function(){
  function E(v){return String(v??'').replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function open(title){
    var invs=(typeof salesApplyFilters==='function'?salesApplyFilters():(db.invoices||[])).slice().sort(function(a,b){return String(b.date).localeCompare(String(a.date))});
    var M=function(v,c){return salesMoney(v,c)};
    var tot={a:0,r:0,o:0};
    var rows=invs.map(function(x){var o=salesInvoiceOutstanding(x),s=salesInvoiceStatus(x);tot.a+=+x.amount||0;tot.r+=+x.received||0;tot.o+=o;
      return '<tr><td><b>'+E(x.number)+'</b></td><td>'+E(x.date)+'</td><td>'+E(projectName(x.projectId))+'</td><td>'+E(x.client||'—')+'</td><td>'+E(x.invoiceType||'')+'</td><td class="r">'+M(x.amount,x.currency)+'</td><td class="r g">'+M(x.received||0,x.currency)+'</td><td class="r '+(o>0?'o':'')+'">'+M(o,x.currency)+'</td><td><span class="sales-status '+salesStatusClass(s)+'">'+E(s)+'</span></td></tr>'}).join('');
    var d=document.createElement('div');d.className='svx-ov';
    d.innerHTML='<div class="svx-box"><div class="svx-hd"><div><h3>'+E(title)+' — View all</h3><small>'+invs.length+' invoices · current filters</small></div><input type="search" placeholder="Search…"><button class="btn small" data-p>⎙ Print</button><button class="btn small" data-x>✕ Close</button></div><div class="svx-wrap"><table><thead><tr><th>Invoice No</th><th>Date</th><th>Project</th><th>Client</th><th>Type</th><th class="r">Amount</th><th class="r">Received</th><th class="r">Outstanding</th><th>Status</th></tr></thead><tbody>'+(rows||'<tr><td colspan="9">No invoices.</td></tr>')+'</tbody><tfoot><tr><td colspan="5"><b>Total</b></td><td class="r"><b>'+M(tot.a)+'</b></td><td class="r g"><b>'+M(tot.r)+'</b></td><td class="r o"><b>'+M(tot.o)+'</b></td><td></td></tr></tfoot></table></div></div>';
    document.body.appendChild(d);document.body.classList.add('svx-open');
    var close=function(){d.remove();document.body.classList.remove('svx-open')};
    d.querySelector('[data-x]').onclick=close;d.onclick=function(e){if(e.target===d)close()};
    d.querySelector('[data-p]').onclick=function(){window.print()};
    d.querySelector('input').oninput=function(){var q=this.value.toLowerCase();d.querySelectorAll('tbody tr').forEach(function(t){t.style.display=t.textContent.toLowerCase().includes(q)?'':'none'})};
  }
  function inject(){document.querySelectorAll('body.sales-mode #view .sov-th').forEach(function(th){var h=th.querySelector('h3');if(!h||th.querySelector('.svx-btn'))return;var t=h.firstChild.textContent.trim();if(!/Invoice History|All Invoices/.test(t))return;var b=document.createElement('button');b.className='btn small svx-btn';b.textContent='⤢ View all';b.onclick=function(){open(t)};th.appendChild(b)})}
  new MutationObserver(inject).observe(document.documentElement,{childList:true,subtree:true});
  var css=`.svx-ov{position:fixed;inset:0;z-index:9000;background:rgba(15,27,61,.45);display:grid;place-items:center;padding:16px}
.svx-box{background:#fff;border-radius:12px;width:min(1400px,100%);height:min(92vh,100%);display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)}
.svx-hd{display:flex;gap:8px;align-items:center;padding:12px 16px;border-bottom:1px solid #e5eaf2;flex-wrap:wrap}
.svx-hd>div{margin-right:auto}.svx-hd h3{margin:0;font-size:16px}.svx-hd small{color:#64748b}
.svx-hd input{height:32px;border:1px solid #dbe3ee;border-radius:8px;padding:0 10px}
.svx-wrap{flex:1;overflow:auto}.svx-wrap table{width:100%;border-collapse:collapse;font-size:13px}
.svx-wrap th{position:sticky;top:0;background:#0f1b3d;color:#fff;text-align:left;padding:8px 10px;white-space:nowrap}
.svx-wrap td{padding:7px 10px;border-bottom:1px solid #eef2f7;white-space:nowrap}
.svx-wrap .r{text-align:right}.svx-wrap .g{color:#15803d}.svx-wrap .o{color:#dc2626}
.svx-wrap tfoot td{background:#f8fafc;position:sticky;bottom:0}
.svx-btn{margin-left:6px}
@media print{body.svx-open>*:not(.svx-ov){display:none!important}.svx-ov{position:static;background:none;padding:0}.svx-box{height:auto;box-shadow:none}.svx-wrap{overflow:visible}.svx-hd input,.svx-hd button{display:none}}
@media(max-width:760px){
body.sales-mode #view .sov-kpis,body.sales-mode #view .sov-sec{grid-template-columns:1fr 1fr!important;gap:6px!important}
body.sales-mode #view .sov-kpi{padding:8px 10px!important}body.sales-mode #view .sov-kpi b{font-size:15px!important}
body.sales-mode #view .sov-sec>div{padding:6px 8px!important;font-size:11px}
body.sales-mode #view .sales-tabs,body.sales-mode #view .sov-tabs{overflow-x:auto!important;flex-wrap:nowrap!important}
body.sales-mode #view .sov-th{flex-wrap:wrap!important;gap:6px!important}
body.sales-mode #view .sov-th input{width:100%!important;min-width:0!important}
body.sales-mode #view .sov-wrap{overflow-x:auto!important}
body.sales-mode #view .sov-wrap table{font-size:12px!important}
body.sales-mode #view .sov-wrap td,body.sales-mode #view .sov-wrap th{padding:6px 7px!important;white-space:nowrap!important}
body.sales-mode #view .sov-filters{grid-template-columns:1fr 1fr!important}
body.sales-mode #view .sov-side{grid-template-columns:1fr!important}
}`;
  var s=document.createElement('style');s.textContent=css;document.head.appendChild(s);
})();
