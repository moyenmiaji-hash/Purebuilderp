/* PURE_BUILD — shared professional pagination for tables.
   First / Previous / page numbers / Next / Last + rows-per-page (10, 25, 50, 100).
   Display only: hides extra rows, never changes data. Skips tables that already
   have their own pager (Sales, Task Management, Audit) so nothing is doubled.
   Print always shows every row. Rows-per-page choice is remembered per menu page. */
(function () {
  const SIZES = [10, 25, 50, 100];
  const isStock = () => /^#stock/i.test(location.hash || "");
  const pageGroup = () => ((location.hash || "#").split(/[?/&]/)[0] || "#").toLowerCase();
  const LS = "PB_PAGE_SIZE";
  function loadSizes() { try { return JSON.parse(localStorage.getItem(LS) || "{}") || {}; } catch (e) { return {}; } }
  function pageSize() {
    const v = Number(loadSizes()[pageGroup()]);
    if (Number.isInteger(v) && v >= 1 && v <= 1000) return v; // preset or the user's own number
    return isStock() ? 10 : 25; // Stock pages default to 10 so each page fits one screen
  }
  function setPageSize(n) {
    const all = loadSizes(); all[pageGroup()] = n;
    try { localStorage.setItem(LS, JSON.stringify(all)); } catch (e) {}
  }
  const state = {}; // key -> page number
  let busy = false, queued = false;
  const css = document.createElement("style");
  css.textContent = `
  .pbpg-hide{display:none!important}
  .pbpg-bar{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:8px 6px 2px;font-size:12px;color:#55657a}
  .pbpg-bar .pbpg-info{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
  .pbpg-bar .pbpg-info b{color:inherit;font-weight:800}
  .pbpg-bar label{display:flex;align-items:center;gap:6px;font-weight:600}
  .pbpg-bar select{border:1px solid #d9e1ec;background:#fff;border-radius:8px;padding:3px 6px;font-size:12px;font-weight:600;color:#1f2d3d;cursor:pointer;width:auto;min-width:0;height:auto}
  .pbpg-bar .pbpg-btns{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
  .pbpg-bar button{border:1px solid #d9e1ec;background:#fff;border-radius:8px;padding:4px 9px;min-width:30px;font-size:12px;font-weight:600;color:#1f2d3d;cursor:pointer;line-height:1.2}
  .pbpg-bar button:hover:not(:disabled){border-color:#c79a3b;color:#8a6417}
  .pbpg-bar button.on{background:#1f2d3d;color:#fff;border-color:#1f2d3d}
  .pbpg-bar button:disabled{opacity:.4;cursor:default}
  .pbpg-bar .pbpg-gap{padding:0 2px;color:#8a97a8}
  .pbpg-fit{max-height:calc(100vh - 360px);min-height:180px;overflow:auto}
  .pbpg-fit thead th{position:sticky;top:0;z-index:2;background:inherit}
  .pbpg-fit thead{background:#f4f7fb}
  @media print{tr.pbpg-hide{display:table-row!important}.pbpg-hide:not(tr){display:revert!important}.pbpg-bar{display:none!important}.pbpg-fit{max-height:none!important;overflow:visible!important}}`;
  document.head.appendChild(css);

  const OWN_PAGER = ".ft-pager,.sov-pager,[class*='pager'],[class*='pagination'],[id*='Pager'],[id*='pager']";
  function hasOwnPager(table) {
    let el = table.parentElement;
    for (let i = 0; i < 2 && el && el !== document.body; i++, el = el.parentElement) {
      const found = el.querySelector(OWN_PAGER);
      if (found && !found.classList.contains("pbpg-bar")) return true;
    }
    return false;
  }
  function keyFor(table, idx) {
    const h = [...table.querySelectorAll("thead th")].map((t) => t.textContent.trim()).join("|").slice(0, 120);
    return (location.hash || "#") + "::" + idx + "::" + h;
  }
  function pages(cur, total) {
    const out = [];
    for (let p = 1; p <= total; p++) if (p === 1 || p === total || Math.abs(p - cur) <= 1) out.push(p);
    return out.reduce((a, p) => { if (a.length && p - a[a.length - 1] > 1) a.push("…"); a.push(p); return a; }, []);
  }
  function isEmptyRow(r) { return !!r.cells && r.cells.length === 1 && (r.cells[0].colSpan || 1) > 1; }
  function removeBar(table, rows) {
    rows.forEach((r) => r.classList.remove("pbpg-hide"));
    if (table.__pbpgBar) { table.__pbpgBar.remove(); table.__pbpgBar = null; }
  }
  // Card lists (not tables) that also get the pager.
  const LISTS = ".stock-row-list";
  function apply(table, key) {
    const isList = table.matches(LISTS);
    const body = isList ? table : table.tBodies[0];
    if (!body) return;
    const rows = isList ? [...body.children].filter((r) => !r.classList.contains("pbpg-bar")) : [...body.rows];
    const SIZE = pageSize();
    const realRows = rows.filter((r) => !isEmptyRow(r));
    // Stock pages always show the pager (so rows-per-page is available); others only when long.
    if (!realRows.length || (!isStock() && rows.length <= SIZES[0])) { removeBar(table, rows); return; }
    const total = Math.max(1, Math.ceil(rows.length / SIZE));
    let pg = Math.min(Math.max(1, state[key] || 1), total);
    state[key] = pg;
    rows.forEach((r, i) => r.classList.toggle("pbpg-hide", i < (pg - 1) * SIZE || i >= pg * SIZE));
    const wrap = isList ? table : table.closest(".tablewrap,.table-wrap");
    const anchor = wrap || table;
    // Keep bigger page sizes inside one screen: the table scrolls, the pager stays visible.
    const fit = isStock() || SIZE > 25;
    if (wrap) {
      wrap.classList.toggle("pbpg-fit", fit);
      // Size the scroll box to the space left on screen so the pager never falls below the fold.
      if (fit && isStock()) {
        const top = wrap.getBoundingClientRect().top + window.scrollY;
        let h = Math.max(170, Math.floor(window.innerHeight - top - 88));
        if (wrap.__pbpgH !== h) { wrap.style.maxHeight = h + "px"; wrap.__pbpgH = h; }
        // If the page still scrolls, shrink the box by exactly the extra amount.
        const extra = document.documentElement.scrollHeight - window.innerHeight;
        if (extra > 0 && h > 170) { h = Math.max(170, h - extra - 4); wrap.style.maxHeight = h + "px"; wrap.__pbpgH = h; }
      }
    }
    let bar = table.__pbpgBar;
    if (!bar || !bar.isConnected) {
      bar = document.createElement("div");
      bar.className = "pbpg-bar";
      anchor.insertAdjacentElement("afterend", bar);
      table.__pbpgBar = bar;
    }
    const from = (pg - 1) * SIZE + 1, to = Math.min(pg * SIZE, rows.length);
    const btn = (p, label, dis, title, on) => `<button type="button" data-p="${p}" title="${title}" ${dis ? "disabled" : ""} class="${on ? "on" : ""}">${label}</button>`;
    const html =
      `<span class="pbpg-info"><span>Showing <b>${from}–${to}</b> of <b>${rows.length}</b></span>` +
      `<label>Rows per page <select data-size>${[...new Set([...SIZES, SIZE])].sort((a, b) => a - b).map((s) => `<option value="${s}" ${s === SIZE ? "selected" : ""}>${s}</option>`).join("")}<option value="custom">Custom…</option></select></label>` +
      `<span>Page <b>${pg}</b> of <b>${total}</b></span></span>` +
      `<span class="pbpg-btns">` +
      btn(1, "« First", pg <= 1, "First page") +
      btn(pg - 1, "‹ Previous", pg <= 1, "Previous page") +
      pages(pg, total).map((p) => p === "…" ? `<span class="pbpg-gap">…</span>` : btn(p, p, false, "Page " + p, p === pg)).join("") +
      btn(pg + 1, "Next ›", pg >= total, "Next page") +
      btn(total, "Last »", pg >= total, "Last page") +
      `</span>`;
    // Only rewrite when something changed, so the page watcher does not loop.
    if (bar.__html !== html) { bar.innerHTML = html; bar.__html = html; }
    bar.onclick = (e) => {
      const b = e.target.closest("button[data-p]");
      if (!b || b.disabled) return;
      state[key] = Number(b.dataset.p);
      run();
      anchor.scrollTop = 0;
    };
    bar.onchange = (e) => {
      const s = e.target.closest("select[data-size]");
      if (!s) return;
      let n = Number(s.value);
      if (s.value === "custom") {
        const ans = window.prompt("How many rows per page? (1 – 1000)", String(SIZE));
        n = Math.floor(Number(ans));
        if (!ans || !Number.isFinite(n) || n < 1 || n > 1000) { s.value = String(SIZE); return; }
      }
      setPageSize(n);
      Object.keys(state).forEach((k) => { state[k] = 1; });
      run();
      anchor.scrollTop = 0;
    };
  }
  function run() {
    if (busy) return;
    busy = true;
    try {
      const tables = [...document.querySelectorAll("table," + LISTS)].filter((t) => t.offsetParent !== null || t.closest(".modal"));
      tables.forEach((t, i) => {
        if (t.closest(".pbpg-skip,[data-no-pager]") || hasOwnPager(t)) return;
        apply(t, keyFor(t, i));
      });
    } catch (e) { console.error("page-nav", e); }
    finally { setTimeout(() => { busy = false; }, 0); }
  }
  function schedule() {
    if (busy || queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; run(); });
  }
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  window.addEventListener("hashchange", schedule);
  window.addEventListener("resize", () => { document.querySelectorAll(".pbpg-fit").forEach((w) => { w.__pbpgH = 0; }); schedule(); });
  window.addEventListener("beforeprint", () => document.querySelectorAll(".pbpg-hide").forEach((r) => r.classList.remove("pbpg-hide")));
  window.addEventListener("afterprint", schedule);
  schedule();
})();
