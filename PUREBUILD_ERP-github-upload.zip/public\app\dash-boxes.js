/* Dashboard Alerts & Site Progress boxes: display-only styling + Site Progress log viewer
   (day-by-day, All time, search, auto refresh). Reads db.progress only; never changes data. */
(function(){
  var css=document.createElement('style');css.textContent=
  '.dashboard-alert-panel .panel-head,.dashboard-progress-panel .panel-head{flex-wrap:wrap;row-gap:4px}'+
  '.dashboard-alert-panel .panel-head h3,.dashboard-progress-panel .panel-head h3{flex:1 1 auto;min-width:0;white-space:nowrap;overflow:visible}'+
  '.dashboard-alert-panel .panel-head .dpx-chips{order:5;flex:1 1 100%;margin-left:0}.dashboard-alert-panel .panel-head .pac-strip{order:6}'+
  '.dashboard-alert-panel .dbn-row{border-radius:10px;transition:transform .15s,box-shadow .15s}.dashboard-alert-panel .dbn-row:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(15,42,74,.12)}'+
  '.dbp-va{border:0;background:transparent;cursor:pointer}'+
  '.dbp-list{display:flex;flex-direction:column;gap:7px;padding:2px}.dbp-row{background:linear-gradient(180deg,#fff,#f7faff);border:1px solid #e3eaf3;border-left:4px solid #2a79dc;border-radius:10px;padding:7px 10px}'+
  '.dbp-top{display:flex;gap:8px;align-items:center}.dbp-top b{flex:1;min-width:0;font-size:12.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'+
  '.dbp-pct{font-weight:800;font-size:12px;color:#1e4f86;background:#e6f0fb;border-radius:999px;padding:1px 8px}'+
  '.dbp-meta{display:flex;gap:10px;font-size:10.5px;color:#64748b;margin:2px 0 5px;flex-wrap:wrap}.dbp-meta span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}'+
  '.dbp-bar{height:6px;background:#e8eef6;border-radius:99px;overflow:hidden}.dbp-bar i{display:block;height:100%;background:linear-gradient(90deg,#2a79dc,#16a34a);border-radius:99px}'+
  '.dpl-ov{position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:99998;display:flex;align-items:center;justify-content:center}'+
  '.dpl{background:#f6f8fb;width:min(1000px,96vw);height:min(820px,92vh);border-radius:16px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.35)}'+
  '.dpl-h{display:flex;align-items:center;gap:10px;padding:14px 18px;background:linear-gradient(135deg,#0f2a4a,#1e4f86);color:#fff}.dpl-h b{flex:1;font-size:16px}.dpl-h button{border:0;border-radius:8px;padding:6px 10px;font-weight:700;background:rgba(255,255,255,.15);color:#fff;cursor:pointer}'+
  '.dpl-tb{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:10px 18px}.dpl .dpl-tb input{height:32px;border:1px solid #d5dee8;border-radius:8px;padding:0 8px;background:#fff;color:#0f172a;width:auto!important;margin:0!important}.dpl .dpl-tb input[type=search]{flex:1 1 220px!important}'+
  '.dpl-tb button{border:1px solid #d5dee8;background:#fff;color:#1e4f86;border-radius:999px;padding:4px 12px;font-weight:800;font-size:12px;cursor:pointer}.dpl-tb button.on{background:#1e4f86;color:#fff}.dpl-live{font-size:11px;font-weight:700;color:#16a34a}'+
  '.dpl-list{flex:1;overflow:auto;padding:0 18px 14px}.dpl-dh{position:sticky;top:0;background:#f6f8fb;font-size:12px;font-weight:800;color:#1e4f86;padding:8px 2px 6px;z-index:1}.dpl-list .dbp-row{margin-bottom:7px}.dpl-ft{padding:8px 18px;border-top:1px solid #e2e8f0;background:#fff;font-size:12px;color:#475569;text-align:right}';
  document.head.appendChild(css);
  function t0(){var d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
  function E(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function pn(id){try{return projectName(id)}catch(e){return ''}}
  function lbl(d){var t=t0(),y=new Date(t+'T12:00:00');y.setDate(y.getDate()-1);var n;try{n=new Date(d+'T12:00:00').toLocaleDateString('en-GB',{weekday:'short',day:'2-digit',month:'short',year:'numeric'})}catch(e){n=d}return d===t?'Today · '+n:d===y.toISOString().slice(0,10)?'Yesterday · '+n:n}
  window.pbOpenProgressLog=function(){
    var st={q:'',day:''},ov=document.createElement('div');ov.className='dpl-ov';
    ov.innerHTML='<div class="dpl"><div class="dpl-h"><b>📈 Site Progress Log</b><button data-x="close">✕ Close</button></div><div class="dpl-tb"><input type="search" placeholder="Search work, project, building, foreman…"><button data-d="all">All time</button><button data-d="today">Today</button><button data-d="-1">‹</button><input type="date"><button data-d="1">›</button><span class="dpl-live"></span></div><div class="dpl-list"></div><div class="dpl-ft"></div></div>';
    document.body.appendChild(ov);
    function draw(){var rows=((window.db&&db.progress)||[]).filter(function(x){var h=[x.title,pn(x.projectId),x.building,x.floor,x.room,x.foreman,x.note].join(' ').toLowerCase();return (!st.q||h.indexOf(st.q)>=0)&&(!st.day||String(x.date).slice(0,10)===st.day)}).sort(function(a,b){return String(b.date).localeCompare(String(a.date))});
      var last=null;ov.querySelector('.dpl-list').innerHTML=rows.map(function(x){var d=String(x.date||'').slice(0,10),pr=Math.max(0,Math.min(100,+x.percent||0)),g='';if(d!==last){last=d;g='<div class="dpl-dh">📅 '+E(lbl(d))+'</div>'}
        var loc=[x.building,x.floor,x.room].filter(Boolean).join(' · ');
        return g+'<div class="dbp-row"><div class="dbp-top"><b>'+E(x.title||'Site progress')+'</b><span class="dbp-pct">'+(pr%1?pr.toFixed(1):pr)+'%</span></div><div class="dbp-meta"><span>📍 '+E(pn(x.projectId))+(loc?' · '+E(loc):'')+'</span>'+(x.foreman?'<span>👷 '+E(x.foreman)+'</span>':'')+'</div><div class="dbp-bar"><i style="width:'+pr+'%"></i></div></div>'}).join('')||'<div style="text-align:center;color:#64748b;padding:50px 0">No site progress for this selection.</div>';
      ov.querySelector('.dpl-ft').textContent=rows.length+' update'+(rows.length===1?'':'s');
      ov.querySelectorAll('[data-d]').forEach(function(b){b.classList.toggle('on',(b.dataset.d==='all'&&!st.day)||(b.dataset.d==='today'&&st.day===t0()))});
      ov.querySelector('input[type=date]').value=st.day;ov.querySelector('.dpl-live').textContent='● Auto refresh · updated '+new Date().toTimeString().slice(0,5)}
    ov.addEventListener('click',function(e){if(e.target===ov){ov.remove();return}var b=e.target.closest('button');if(!b)return;if(b.dataset.x){ov.remove();return}
      var d=b.dataset.d;if(!d)return;if(d==='all')st.day='';else if(d==='today')st.day=t0();else{var x=new Date((st.day||t0())+'T12:00:00');x.setDate(x.getDate()+(+d));st.day=x.toISOString().slice(0,10)}draw()});
    ov.querySelector('input[type=search]').oninput=function(e){st.q=e.target.value.toLowerCase();draw()};
    ov.querySelector('input[type=date]').onchange=function(e){st.day=e.target.value;draw()};
    draw();var iv=setInterval(function(){if(!document.body.contains(ov)){clearInterval(iv);return}draw()},30000);
  };
})();
