# Foreman Task / Target Management — পরিকল্পনা

লাল ভুল বার্তাটা আসল কোড-ভুল না, নোটের লেখা। নোটে ফোরম্যানদের কাজ (Task) দেওয়া, টার্গেট ঠিক করা আর তাদের কাজের মান মাপার পুরো ব্যবস্থা চাওয়া হয়েছে। ছবির মতো চেহারা হবে। পুরনো কোনো তথ্য মোছা বা বদলানো হবে না। কাজটা বড়, তাই ৩টা ধাপে করব; প্রতিটা ধাপ শেষে আপনি Publish করে দেখবেন।

## কোথায় থাকবে
- Projects / Sites পাতার উপরে নতুন **"Task Management"** বোতাম (ছবির মতো "Projects / Sites / Task Management")। বাম পাশের মেনুতে নতুন কিছু যোগ হবে না।
- ফোরম্যানের ফোনের অ্যাপে নিচের বারে নতুন **"My Tasks"** ঘর।
- ফোরম্যান মানে Access থেকে Cloud-এ যোগ করা স্টাফ (যেমন Md Hasan)। Task Cloud-এ সেভ হবে, যাতে অফিস আর ফোন দুই জায়গাতেই দেখা যায়।

## ধাপ ১: Task দেওয়া + ফোরম্যানের My Tasks
- উপরে ৮টা বাক্স: মোট Task, Assigned, In Progress, Review-এ জমা, Completed, Overdue, গড় টার্গেট পূরণ %, সক্রিয় ফোরম্যান। সব আসল তথ্য থেকে হিসাব।
- Task List টেবিল: খোঁজা, Project / Site / Building / ফোরম্যান / অবস্থা / Priority / তারিখ ফিল্টার, সাজানো, পাতা ভাগ।
- New Task ফর্ম: শিরোনাম, নির্দেশনা, Project, Site, Building/Floor, ফোরম্যান, কাজের ধরন, BOQ আইটেম (ঐচ্ছিক), শুরু ও শেষ তারিখ, Priority (Low/Medium/High/Urgent), মোট টার্গেট, Unit, দৈনিক বা সাপ্তাহিক টার্গেট, দিন সংখ্যা, শ্রমিক, মালামাল, কাজ শেষের শর্ত, ফাইল, নোট।
- অন্য ফোরম্যানকে দেওয়া (কারণসহ), টার্গেট বা শেষ তারিখ বদলালে আগের মান ইতিহাসে থাকবে।
- ফোরম্যানের My Tasks: শুধু নিজের Task দেখবে; Start, আজকের পরিমাণ জমা, নোট, দেরির কারণ (মাল কম, শ্রমিক কম, যন্ত্র নষ্ট, আবহাওয়া, নকশা বদল, Client নির্দেশ, অন্য), ছবি, সমস্যা জানানো। কোনটা Approve/Reject হয়েছে দেখবে।
- অফিস জমাগুলো Approve বা Reject (কারণসহ) করবে। কিছু অংশ Approve করা যাবে, পুরো Task Completed না করেই।
- অবস্থা: Assigned → In Progress → Review-এ জমা → Approved/Rejected → Completed। বাতিল (Cancelled) Task হিসাবে ধরা হবে না, কিন্তু ইতিহাস থাকবে।
- ফোরম্যান নিজের কাজ Approve করতে পারবে না, Approve হওয়া পরিমাণ বদলাতে পারবে না। এটা Cloud-এ আটকানো থাকবে, শুধু পর্দায় না।

## ধাপ ২: ৭ দিনের Performance + ফোরম্যান তুলনা
- প্রতি ফোরম্যানের কার্ড: Task সংখ্যা, Completed, চলমান, Overdue, পরিকল্পিত বনাম Approve হওয়া পরিমাণ, টার্গেট পূরণ %, সময়মতো শেষ %, দৈনিক টার্গেট মিস, রিপোর্ট না দেওয়া দিন, উন্নতি/অবনতি।
- নিচে ৭ দিনের দিনভিত্তিক টেবিল।
- Compare Foremen: দুই বা বেশি ফোরম্যান বাছলে একই সময়ের তুলনা টেবিল আর চার্ট। আলাদা Unit বা আলাদা ধরনের কাজ একসাথে যোগ হবে না; কাজের ধরন অনুযায়ী আলাদা দেখাবে।
- তথ্য না থাকলে "No Data" দেখাবে, ভুল করে 0% দেখাবে না। রিপোর্ট না দেওয়া দিনকে শূন্য কাজ হিসেবে গোনা হবে না, আলাদা দেখাবে।
- প্রতিটা হিসাবের পাশে ছোট "i" দিয়ে সহজ ভাষায় লেখা থাকবে হিসাবটা কীভাবে হয়।

## ধাপ ৩: সতর্কবার্তা, ইতিহাস, রিপোর্ট
- সতর্কবার্তা: Overdue, দৈনিক টার্গেট মিস, সাপ্তাহিক পিছিয়ে পড়া, বারবার দেরি, রিপোর্ট নেই, Approve বাকি, মাল/শ্রমিক কম, আটকে থাকা Task। কতটা হলে সতর্ক করবে, Admin ঠিক করবেন।
- বাইরের কারণে দেরি (যাচাই হওয়া) হলে ফোরম্যানের নম্বর কাটা যাবে না।
- Task-এর পুরো ইতিহাস: কে দিল, কবে, কাকে, টার্গেট বদল, জমা, Approve/Reject, কারণ, ছবি। শুধু Admin দেখবে, কেউ মুছতে পারবে না।
- রিপোর্ট: একজন ফোরম্যান, ৭ দিন, মাসিক, দেরি, পরিকল্পিত বনাম আসল, Overdue, তুলনা — Print ও CSV।

## হিসাবের নিয়ম (নোট অনুযায়ী)
- টার্গেট পূরণ % = মোট Approve হওয়া পরিমাণ ÷ মোট পরিকল্পিত টার্গেট × ১০০
- Task শেষের হার = Approve হয়ে শেষ Task ÷ এই সময়ে শেষ হওয়ার কথা ছিল এমন Task × ১০০
- সময়মতো শেষ % = শেষ তারিখের মধ্যে শেষ Task ÷ শেষ হওয়া Task × ১০০
- বাকি = টার্গেট − Approve হওয়া পরিমাণ (কখনো মাইনাস না; বেশি হলে "যাচাই করুন" চিহ্ন)
- Overdue = শেষ তারিখ পার হয়েছে কিন্তু Approve হয়ে শেষ হয়নি। তারিখ দুবাই সময় ধরে।
- জমা দেওয়া পরিমাণ আর Approve হওয়া পরিমাণ আলাদা রাখা হবে।

## অন্য অংশের সাথে সম্পর্ক
- Task-এর পরিমাণ Approve হলেও BOQ-এর অগ্রগতি, মালামাল, শ্রমিকের টাকা বা খরচ নিজে থেকে বাড়বে না বা দুবার গোনা হবে না। Task শুধু BOQ আইটেমের সাথে যুক্ত থাকবে, BOQ-এর অগ্রগতি আগের মতো রিপোর্ট Approve থেকেই আসবে।

## পরীক্ষা
- নকল ফোরম্যান আর নকল Task দিয়ে Cloud-এর পরীক্ষার কপিতে (আসল তথ্য না) পুরো পথ: Task দেওয়া → ফোনে দেখা → জমা → Approve/Reject → হিসাব ঠিক → রিফ্রেশে থাকে কিনা → ফোরম্যান অন্যের Task দেখতে পারে কিনা। কম্পিউটার আর ফোন দুই মাপে। শেষে বাংলায় রিপোর্ট।

## এবার যা করা হবে না
- বাম মেনুতে নতুন জিনিস, পুরনো পাতার চেহারা বদল, পুরনো তথ্যে হাত দেওয়া।
- আগের পরিকল্পনার (Projects মডিউল) বাকি কাজ এই সময় থেমে থাকবে, পরে করা হবে।

## Technical details
- New Cloud tables (additive migration, GRANTs + RLS): `foreman_tasks` (org, project_id → team_projects, building/floor, assigned_to uuid, boq_item_id nullable, dates, priority, target_qty, unit, period, daily/weekly target, status, original_target/original_due, cancelled flag), `foreman_task_updates` (task_id, report_date, reported_qty, approved_qty, delay_reason, delay_external bool, blockers, photos paths, review_status, reviewed_by/at, review_note, idempotency_key unique), `foreman_task_events` (append-only history: type, old/new jsonb, by, at, reason), `foreman_task_settings` (alert thresholds per org).
- RLS: office users (`is_office_user`) full read; insert/update tasks via permission check (`manage_projects`/`review_reports`); staff read only rows where `assigned_to = auth.uid()` and `pb_is_member`. Staff writes only via SECURITY DEFINER RPCs `submit_task_update` (validates qty ≥ 0, unit, own task, not approved, idempotent) and `start_task`; review via `review_task_update` (office only, cannot review own). Events written by triggers; no UPDATE/DELETE on events.
- Photos reuse existing private progress-photo bucket with signed URLs.
- Office UI: new `public/app/foreman-tasks.js`, page `tasks` via `setPage('tasks')`, opened from a button on Projects/Sites. Staff: "My Tasks" tab added in `foreman-wizard.js` nav, data via `team-staff.js` supabase client.
- Performance calculations in a pure JS module with unit tests (vitest) for the formulas, No Data cases, unit grouping and missing-report handling.
- Bump `PB_SAFETY_VERSION` and cache `?v=` each phase.
