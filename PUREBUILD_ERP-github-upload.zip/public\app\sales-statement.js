// Sales Project Statement (p73): read-only per-project invoice & payment statement + scroll boxes on Sales pages.
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const D = () => (typeof db !== "undefined" ? db : window.db) || {};
  const M = (n) => (typeof salesMoney === "function" ? salesMoney(n) : "AED " + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  const PN = (id) => (typeof projectName === "function" ? projectName(id) : id || "—");
  const OUT = (x) => (typeof salesInvoiceOutstanding === "function" ? salesInvoiceOutstanding(x) : Math.max(0, (+x.amount || 0) - (+x.received || 0)));
  const ST = (x) => (typeof salesInvoiceStatus === "function" ? salesInvoiceStatus(x) : x.status || "");
  let mode = "invoices", proj = "", from = "", to = "", lastSum = [];

  function build() {
    const d = D();
    const invs = (d.invoices || []).filter((x) => (!proj || x.projectId === proj) && (!from || String(x.date) >= from) && (!to || String(x.date) <= to));
    const pays = (d.payments || []).filter((x) => (!proj || x.projectId === proj) && (!from || String(x.date) >= from) && (!to || String(x.date) <= to));
    const pids = [...new Set([...(d.invoices || []), ...(d.payments || [])].map((x) => x.projectId).filter(Boolean))];
    const groups = {};
    (mode === "invoices" ? invs : pays).forEach((x) => { (groups[x.projectId || ""] = groups[x.projectId || ""] || []).push(x); });
    let gi = 0, gr = 0, go = 0, sn = 0, body = "";
    const summary = [];
    Object.keys(groups).sort((a, b) => PN(a).localeCompare(PN(b))).forEach((pid) => {
      const rows = groups[pid].slice().sort((a, b) => String(a.date).localeCompare(String(b.date)) || String(a.number || a.reference || "").localeCompare(String(b.number || b.reference || ""), undefined, { numeric: true }));
      const pInv = invs.filter((x) => (x.projectId || "") === pid);
      const ti = pInv.reduce((s, x) => s + (+x.amount || 0), 0), tr = pInv.reduce((s, x) => s + (+x.received || 0), 0), to_ = pInv.reduce((s, x) => s + OUT(x), 0);
      summary.push({ pid, n: pInv.length, ti, tr, to: to_, pc: ti ? Math.round((tr / ti) * 100) : 0 });
      body += `<tr class="pss-grp"><td colspan="7">🏗 ${E(PN(pid))} <small>· ${rows.length} ${mode === "invoices" ? "invoices" : "payments"}</small></td></tr>`;
      let i = 0, sa = 0, sb = 0, sc = 0;
      rows.forEach((x) => {
        sn++; i++;
        if (mode === "invoices") {
          const a = +x.amount || 0, r = +x.received || 0, o = OUT(x); sa += a; sb += r; sc += o;
          body += `<tr><td>${sn}</td><td>${E(x.date)}</td><td><b>${E(x.number)}</b></td><td>${E(x.client || "—")}</td><td class="r">${M(a)}</td><td class="r g">${M(r)}</td><td class="r ${o > 0 ? "o" : ""}">${M(o)} <span class="pss-st">${E(ST(x))}</span></td></tr>`;
        } else {
          const a = +x.amount || 0; sa += a;
          body += `<tr><td>${sn}</td><td>${E(x.date)}</td><td><b>${E(x.reference || "—")}</b></td><td>${E(x.invoiceNumber || "Multiple")}</td><td>${E(x.client || "—")}</td><td>${E(x.method || "—")}</td><td class="r g">${M(a)}</td></tr>`;
        }
      });
      if (mode === "invoices") { gi += sa; gr += sb; go += sc; body += `<tr class="pss-sub"><td colspan="4">Subtotal · ${E(PN(pid))}</td><td class="r">${M(sa)}</td><td class="r">${M(sb)}</td><td class="r">${M(sc)}</td></tr>`; }
      else { gr += sa; body += `<tr class="pss-sub"><td colspan="6">Subtotal · ${E(PN(pid))}</td><td class="r">${M(sa)}</td></tr>`; }
    });
    lastSum = summary;
    if (mode === "invoices") { gi = invs.reduce((s, x) => s + (+x.amount || 0), 0); }
    const allInv = invs.reduce((s, x) => s + (+x.amount || 0), 0), allRec = invs.reduce((s, x) => s + (+x.received || 0), 0), allOut = invs.reduce((s, x) => s + OUT(x), 0);
    const head = mode === "invoices"
      ? "<th>#</th><th>Date</th><th>Invoice No</th><th>Client</th><th class='r'>Invoiced</th><th class='r'>Received</th><th class='r'>Outstanding</th>"
      : "<th>#</th><th>Date</th><th>Receipt</th><th>Invoice</th><th>Client</th><th>Method</th><th class='r'>Received</th>";
    const grand = mode === "invoices"
      ? `<tr class="pss-grand"><td colspan="4">GRAND TOTAL</td><td class="r">${M(allInv)}</td><td class="r">${M(allRec)}</td><td class="r">${M(allOut)}</td></tr>`
      : `<tr class="pss-grand"><td colspan="6">GRAND TOTAL</td><td class="r">${M(gr)}</td></tr>`;
    return `<div class="pss">
      <div class="pss-f"><div class="pss-sw"><button class="${mode === "invoices" ? "on" : ""}" data-m="invoices">Invoice Statement</button><button class="${mode === "payments" ? "on" : ""}" data-m="payments">Payment Statement</button></div>
      <label>Project / Site<select id="pssProj"><option value="">All projects</option>${pids.map((p) => `<option value="${E(p)}" ${p === proj ? "selected" : ""}>${E(PN(p))}</option>`).join("")}</select></label>
      <label>From<input type="date" id="pssFrom" value="${E(from)}"></label><label>To<input type="date" id="pssTo" value="${E(to)}"></label>
      <button class="btn small" id="pssPrint">⎙ Print</button><button class="btn small" id="pssCsv">Excel / CSV</button></div>
      <div class="pss-k"><div class="b"><small>Total Invoiced (${invs.length})</small><b>${M(allInv)}</b></div><div class="g"><small>Total Received</small><b>${M(allRec)}</b></div><div class="o"><small>Outstanding</small><b>${M(allOut)}</b></div><div><small>Collected</small><b>${allInv ? Math.round((allRec / allInv) * 100) : 0}%</b></div></div>
      <div class="pss-sum">${summary.map((s) => `<div class="pss-card"><b>${E(PN(s.pid))}</b><small>${s.n} invoices · Invoiced ${M(s.ti)}</small><div class="pss-bar"><i style="width:${Math.min(100, s.pc)}%"></i></div><small>Received ${M(s.tr)} · <span class="${s.to > 0 ? "o" : "g"}">Due ${M(s.to)}</span> · ${s.pc}%</small></div>`).join("")}</div>
      <div class="pss-t" id="pssTable"><table><thead><tr>${head}</tr></thead><tbody>${body || `<tr><td colspan="7" class="empty">No records found.</td></tr>`}${body ? grand : ""}</tbody></table></div></div>`;
  }
  function csv() {
    const rows = [...document.querySelectorAll("#pssTable tr")].map((tr) => [...tr.children].map((td) => '"' + td.textContent.trim().replace(/"/g, '""') + '"').join(","));
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + rows.join("\n")], { type: "text/csv" }));
    a.download = `project-${mode}-statement.csv`; a.click();
  }
  function print() {
    const t = document.getElementById("pssTable"); if (!t) return;
    const st = D().settings || {}, co = st.companyName || "PURE_BUILD";
    const logo = st.companyLogo ? `<img src="${E(st.companyLogo)}" alt="">` : "";
    const now = new Date(), pad = (n) => String(n).padStart(2, "0");
    const ref = `PS-${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
    const kv = [...document.querySelectorAll(".pss-k > div")].map((d) => `<div class="k ${d.className}"><small>${E(d.querySelector("small")?.textContent)}</small><b>${E(d.querySelector("b")?.textContent)}</b></div>`).join("");
    const sum = lastSum.length > 1 ? `<h3>Project Summary</h3><table class="tb"><thead><tr><th>Project / Site</th><th class="r">Invoices</th><th class="r">Invoiced</th><th class="r">Received</th><th class="r">Outstanding</th><th class="r">Collected</th></tr></thead><tbody>${lastSum.map((x) => `<tr><td>${E(PN(x.pid))}</td><td class="r">${x.n}</td><td class="r">${M(x.ti)}</td><td class="r">${M(x.tr)}</td><td class="r">${M(x.to)}</td><td class="r">${x.pc}%</td></tr>`).join("")}</tbody></table>` : "";
    const tbl = t.querySelector("table").cloneNode(true); tbl.className = "tb main";
    tbl.querySelectorAll(".pss-st").forEach((e) => { e.parentNode.insertAdjacentHTML("afterend", ""); });
    if (mode === "invoices") { tbl.querySelectorAll("tr").forEach((tr) => { const c = tr.lastElementChild, sp = c && c.querySelector(".pss-st"); if (sp) { const s2 = sp.textContent; sp.remove(); tr.insertAdjacentHTML("beforeend", `<td>${E(s2)}</td>`); } else if (c) { if (tr.parentNode.tagName === "THEAD") tr.insertAdjacentHTML("beforeend", "<th>Status</th>"); else if (c.hasAttribute("colspan") && tr.children.length === 1) c.colSpan = 8; else tr.insertAdjacentHTML("beforeend", "<td></td>"); } }); }
    // keep project heading with its first row
    const rows = [...tbl.tBodies[0].rows]; let html = "", grp = null;
    rows.forEach((r) => { if (r.classList.contains("pss-grp")) { if (grp) html += grp + "</tbody>"; grp = `<tbody class="g">` + r.outerHTML; } else if (r.classList.contains("pss-grand")) { if (grp) { html += grp + "</tbody>"; grp = null; } html += `<tbody class="gt">${r.outerHTML}</tbody>`; } else { if (grp == null) grp = "<tbody>"; grp += r.outerHTML; } });
    if (grp) html += grp + "</tbody>";
    const wide = mode === "invoices";
    const period = from || to ? `${E(from || "Beginning")} – ${E(to || "Today")}` : "All dates";
    const doc = `<!doctype html><html><head><meta charset="utf-8"><title>Project Financial Statement ${ref}</title><style>
@page{size:A4 ${wide ? "landscape" : "portrait"};margin:12mm 11mm 16mm;@bottom-right{content:"Page " counter(page) " of " counter(pages);font:9px Arial;color:#555}@bottom-left{content:"${E(co)} · ${ref}";font:9px Arial;color:#555}}
*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font-family:Arial,Helvetica,sans-serif;font-size:10.5px;color:#111;margin:0}
.hd{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2.5px solid #14213d;padding-bottom:8px;margin-bottom:10px}
.hl{display:flex;gap:10px;align-items:center}.hl img{width:46px;height:46px;object-fit:contain}
.hl b{display:block;font-size:17px;color:#14213d}.hl small{color:#666;font-size:9.5px}
.hr{text-align:right}.hr h1{margin:0 0 4px;font-size:15px;letter-spacing:1px;color:#14213d}
.hr div{font-size:9.5px;color:#333;line-height:1.5}.hr b{color:#111}
.ks{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:0 0 12px}
.k{border:1px solid #cfd6e2;border-left:4px solid #64748b;border-radius:4px;padding:6px 10px}
.k.b{border-left-color:#1d4ed8}.k.g{border-left-color:#16a34a}.k.o{border-left-color:#dc2626}
.k small{display:block;font-size:9px;color:#555;text-transform:uppercase;font-weight:700}.k b{font-size:14px}
h3{font-size:11.5px;color:#14213d;margin:10px 0 5px;text-transform:uppercase;letter-spacing:.5px}
.tb{width:100%;border-collapse:collapse;margin-bottom:8px}
.tb th{background:#14213d;color:#fff;font-size:9.5px;padding:5px 6px;text-align:left;border:1px solid #14213d}
.tb td{padding:4px 6px;border:1px solid #d9dee7;vertical-align:top}
.tb tbody tr:nth-child(even) td{background:#f6f8fb}
.r{text-align:right;white-space:nowrap}thead{display:table-header-group}
tr{break-inside:avoid;page-break-inside:avoid}tbody.g{break-inside:auto}
.pss-grp td{background:#e3eaf7!important;color:#14213d;font-weight:700;font-size:11px;break-after:avoid;page-break-after:avoid}
.pss-grp small{font-weight:400;color:#555}
.pss-sub td{background:#eef1f6!important;font-weight:700;border-top:1.5px solid #8a96ab}
.pss-grand td{background:#14213d!important;color:#fff;font-weight:800;font-size:11px}
td.g{color:#15803d}td.o{color:#b91c1c}
.ft{margin-top:26px;break-inside:avoid;page-break-inside:avoid}
.sig{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:30px}
.sig div{border-top:1px solid #333;padding-top:4px;font-size:10px;font-weight:700;text-align:center}
.pn{font-size:9px;color:#555;margin-top:12px;text-align:center}
</style></head><body>
<div class="hd"><div class="hl">${logo}<div><b>${E(co)}</b><small>Construction Management &amp; Accounting</small></div></div>
<div class="hr"><h1>PROJECT FINANCIAL STATEMENT</h1><div>${mode === "invoices" ? "Invoice" : "Payment"} Statement · Project/Site: <b>${E(proj ? PN(proj) : "All projects")}</b><br>Period: <b>${period}</b> · Ref: <b>${ref}</b><br>Generated: ${E(now.toLocaleString())}</div></div></div>
<div class="ks">${kv}</div>${sum}
<h3>${mode === "invoices" ? "Invoice" : "Payment"} Statement</h3>
<table class="tb main"><thead>${tbl.tHead.innerHTML}</thead>${html}</table>
<div class="ft"><div class="sig"><div>Prepared By</div><div>Checked By</div><div>Authorized By</div></div><div class="pn">Printed on ${E(now.toLocaleString())} · This is a system-generated statement from ${E(co)} ERP.</div></div>
</body></html>`;
    let f = document.getElementById("pssPrintFrame"); if (f) f.remove();
    f = document.createElement("iframe"); f.id = "pssPrintFrame";
    f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden";
    document.body.appendChild(f);
    const fd = f.contentWindow.document; fd.open(); fd.write(doc); fd.close();
    const go = () => { const imgs = [...fd.images]; Promise.all(imgs.map((i) => i.complete ? 1 : new Promise((r) => { i.onload = i.onerror = r; }))).then(() => setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 150)); };
    if (fd.readyState === "complete") go(); else f.onload = go;
  }
  function bind() {
    const re = () => { document.getElementById("modalBody").innerHTML = build(); bind(); };
    document.querySelectorAll(".pss-sw button").forEach((b) => (b.onclick = () => { mode = b.dataset.m; re(); }));
    const p = document.getElementById("pssProj"); if (p) p.onchange = () => { proj = p.value; re(); };
    const f = document.getElementById("pssFrom"); if (f) f.onchange = () => { from = f.value; re(); };
    const t = document.getElementById("pssTo"); if (t) t.onchange = () => { to = t.value; re(); };
    document.getElementById("pssPrint").onclick = print; document.getElementById("pssCsv").onclick = csv;
  }
  window.pbProjectStatement = function (m, pid) {
    if (typeof openModal !== "function") return;
    mode = m || "invoices"; proj = pid != null ? pid : (window.salesFilters && salesFilters.project) || "";
    openModal("Project Statement", build(), () => true);
    const s = document.getElementById("modalSave"); if (s) s.style.display = "none";
    const box = document.querySelector("#modal .modalbox"); if (box) box.style.width = "min(1150px,96vw)";
    bind();
  };

  // Add "Statement" buttons into Sales panels
  const TARGETS = { "Invoice History": "invoices", "Project Billing Summary": "invoices", "All Invoices": "invoices", "Due Invoices": "invoices", "Payment Register": "payments" };
  function decorate() {
    const v = document.getElementById("view"); if (!v || !v.querySelector(".sales-tabs")) return;
    v.querySelectorAll(".panel-head h3").forEach((h) => {
      const name = Object.keys(TARGETS).find((k) => h.textContent.trim().endsWith(k)); if (!name) return;
      const ph = h.closest(".panel-head"); if (ph.querySelector(".pss-btn")) return;
      ph.closest(".panel").classList.add("pss-scroll");
      const b = document.createElement("button"); b.className = "btn small pss-btn"; b.textContent = "📄 Statement";
      b.onclick = (e) => { e.stopPropagation(); window.pbProjectStatement(TARGETS[name]); };
      ph.appendChild(b);
    });
  }
  const start = () => { const v = document.getElementById("view"); if (!v) return; decorate(); new MutationObserver(decorate).observe(v, { childList: true }); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();

  const css = `
  .pss-btn{margin-left:auto;background:linear-gradient(135deg,#1d4ed8,#0ea5e9)!important;color:#fff!important;border:0!important;font-weight:700}
  .panel-head:has(.pss-btn){display:flex;align-items:center;gap:8px}
  .pss-scroll .tablewrap{max-height:260px;overflow:auto}
  .pss-scroll .tablewrap thead th{position:sticky;top:0;z-index:1}
  .pss-scroll .sales-invoice-table-wrap{max-height:calc(100vh - 330px)}
  #salesPaymentsTable{min-width:100%}
  .panel:has(#salesPaymentsTable) .tablewrap{max-height:calc(100vh - 330px);overflow:auto}
  .panel:has(#salesPaymentsTable) thead th{position:sticky;top:0;z-index:1}
  .pss-f{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;margin-bottom:10px}
  .pss-f label{display:flex;flex-direction:column;font-size:11px;font-weight:700;color:#5b6b7f;gap:3px}
  .pss-f select,.pss-f input{height:34px;border:1px solid #d5deea;border-radius:8px;padding:0 8px;font-size:13px;min-width:150px}
  .pss-sw{display:flex;background:#eef2f9;border-radius:10px;padding:3px}
  .pss-sw button{border:0;background:none;padding:7px 12px;border-radius:8px;font-weight:700;color:#475569;cursor:pointer}
  .pss-sw button.on{background:#14213d;color:#fff}
  .pss-k{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}
  .pss-k div{border:1px solid #e3e9f2;border-left:4px solid #64748b;border-radius:10px;padding:8px 12px;background:#fff}
  .pss-k div.g{border-left-color:#16a34a}.pss-k div.o{border-left-color:#dc2626}.pss-k div.b{border-left-color:#1d4ed8}
  .pss-k small{display:block;font-size:11px;color:#64748b;font-weight:700}.pss-k b{font-size:17px}
  .pss-sum{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-bottom:10px;max-height:150px;overflow:auto}
  .pss-card{border:1px solid #e3e9f2;border-radius:10px;padding:8px 10px;background:linear-gradient(180deg,#fff,#f6f9ff);display:flex;flex-direction:column;gap:3px}
  .pss-card small{font-size:11px;color:#64748b}.pss-card .o{color:#b91c1c;font-weight:700}.pss-card .g{color:#15803d;font-weight:700}
  .pss-bar{height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden}.pss-bar i{display:block;height:100%;background:linear-gradient(90deg,#16a34a,#22c55e)}
  .pss-t{max-height:46vh;overflow:auto;border:1px solid #e3e9f2;border-radius:10px}
  .pss-t table{width:100%;border-collapse:collapse;font-size:13px}
  .pss-t th{position:sticky;top:0;background:#14213d;color:#fff;padding:8px;text-align:left;font-size:12px;z-index:1}
  .pss-t td{padding:7px 8px;border-bottom:1px solid #eef2f7}.pss-t .r{text-align:right}
  .pss-t td.g{color:#15803d;font-weight:700}.pss-t td.o{color:#b91c1c;font-weight:700}
  .pss-grp td{background:#e8eefb;color:#14213d;font-weight:800}.pss-grp small{font-weight:600;color:#64748b}
  .pss-sub td{background:#f8fafc;font-weight:700;border-bottom:2px solid #cbd5e1}
  .pss-grand td{background:#14213d;color:#fff;font-weight:800;position:sticky;bottom:0}
  .pss-st{font-size:10px;font-weight:700;background:#eef2f9;color:#475569;border-radius:6px;padding:1px 6px;margin-left:4px}
  @media (min-width:1000px){
    #view:has(.sales-invoice-table-wrap) .sales-filterbar{grid-template-columns:repeat(8,minmax(90px,1fr))!important;gap:6px!important;padding:8px 10px!important;margin-bottom:8px!important}
    #view:has(.sales-invoice-table-wrap) .sales-filterbar .select,#view:has(.sales-invoice-table-wrap) .sales-filterbar input,#view:has(.sales-invoice-table-wrap) .sales-filterbar select{height:32px!important;min-height:32px!important;font-size:11px!important}
    #view:has(.sales-invoice-table-wrap) .sales-kpis{margin-bottom:8px!important}
    #view:has(.sales-invoice-table-wrap) .sales-kpis .kpi{min-height:54px!important;padding:8px 14px!important}
    #view:has(.sales-invoice-table-wrap) .sales-kpis .kpi strong{font-size:16px!important;margin-top:2px!important}
    #view .sales-invoice-table-wrap{max-height:calc(100vh - 300px)!important;overflow:auto!important}
    #view .sales-invoice-table-wrap thead th{position:sticky;top:0;z-index:2;padding:7px 8px!important;font-size:11px!important}
    #view .sales-invoice-table-wrap td{padding:5px 8px!important;font-size:12px!important;white-space:nowrap}
    #view .sales-invoice-table-wrap td .btn,#view .sales-invoice-table-wrap td button{padding:3px 8px!important;font-size:11px!important;min-height:0!important;height:24px!important}
    #view .sales-invoice-table-wrap td:last-child{white-space:nowrap}
    #view .sales-invoice-table-wrap td:last-child>*{display:inline-flex!important;flex-wrap:nowrap!important;gap:4px}
  }
  `;
  const st = document.createElement("style"); st.id = "pb-sales-statement"; st.textContent = css; document.head.appendChild(st);
})();
