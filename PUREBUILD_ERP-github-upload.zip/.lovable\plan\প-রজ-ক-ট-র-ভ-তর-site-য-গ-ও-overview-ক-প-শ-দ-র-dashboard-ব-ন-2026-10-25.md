# প্রজেক্টের ভেতরে Site যোগ ও Overview-কে পেশাদার Dashboard বানানোর পরিকল্পনা

এই ভুল বার্তাটা আসল কোড-ভুল না, এটা নোট ফাইলের লেখা। নোটে যা চাওয়া হয়েছে তার পরিকল্পনা নিচে। পুরনো তথ্য মোছা বা বদলানো হবে না, নতুন মেনু যোগ হবে না।

## ১. প্রজেক্ট খোলার পর আলাদা Site যোগ
- প্রজেক্ট পাতায় "Building / Site" বোতামগুলোর শেষে একটা "+ Add Site" বোতাম থাকবে।
- চাপলে ছোট একটা ঘর খুলবে, নাম লিখে Save দিলেই নতুন Site বোতাম হিসেবে দেখাবে।

## ২. "General" বোতাম সরানো
- উপরের বাছাই থেকে "General" বোতাম মুছে দেওয়া হবে। থাকবে শুধু "All Sites" আর প্রতিটা Site।
- পুরনো যে এন্ট্রিতে Site দেওয়া নেই, সেগুলো "All Sites"-এর মোট হিসাবে ঠিকই গোনা হবে, কিছু হারাবে না।

## ৩. Site বাছলেই সাথে সাথে সব বদলাবে
- একটা Site চাপলে Overview থেকে শুরু করে প্রতিটা ট্যাব (Locations, BOQ & Work Progress, Daily Reports, Materials, Labour, Expenses, Quotations, Drawings, History) শুধু ওই Site-এর তথ্য দেখাবে।
- "All Sites" চাপলে সব Site মিলিয়ে মোট দেখাবে।
- কোন Site বাছা আছে, সেটা উপরে পরিষ্কার করে লেখা থাকবে।

## ৪. Overview: পেশাদার Dashboard ও Profit & Loss
- উপরে রঙিন ছোট কার্ড: Contract Value, Income (Received), Expense (Actual Cost), Profit / Loss, Work Complete %, Client Due।
- একটা Profit & Loss বাক্স: আয় − খরচ (মাল, শ্রমিক, Supplier, অন্যান্য) = লাভ/ক্ষতি, সাথে লাভের %। লাভ হলে সবুজ, ক্ষতি হলে লাল।
- বাজেট বনাম খরচ আর কাজের অগ্রগতির progress bar।
- প্রতিটা কার্ড চাপলে সংশ্লিষ্ট ট্যাবে নিয়ে যাবে (যেমন Expense চাপলে Expenses & Payments, Work Complete চাপলে BOQ & Work Progress, History-তে লেনদেনের তালিকা)।
- অপ্রয়োজনীয় ব্যাখ্যার লেখা (যেমন "Attendance-based estimate; not ledger cost") সরিয়ে ছোট ও সহজ রাখা হবে।

## ৫. সব ট্যাব চেক
- Overview থেকে Projects History পর্যন্ত প্রতিটা ট্যাব খুলে, Site বদলে, নকল তথ্য দিয়ে আলাদা টেস্ট ব্রাউজারে যাচাই করা হবে।

## যা করা হবে না
- নতুন মেনু বা পাতা যোগ হবে না, পুরনো তথ্য মোছা বা বদলানো হবে না, হিসাবের নিয়ম বদলাবে না।

## Technical details
- "+ Add Site" pushes `{building}` into the project's existing `projectLocations` (same source as `projectBuildings(pid)`).
- Remove the `"__general"` chip; `""` (All) still includes records without a building.
- P&L from existing filtered data via `matchBuilding`: income = client receipts; expense = posted ledger costs (materials, labour, supplier, other). Cards call the existing tab switcher; pages still change via `setPage()`.
- Tested only in a throwaway browser.
