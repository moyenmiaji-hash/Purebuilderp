/* Simple Site Progress: two main tabs — "Foreman Updates" (what each foreman reported) and "Manual Update"
   (office entry through the existing Daily Progress Update form). Read-only over db.progress / db.boq; all saving
   still goes through the existing forms and foreman approval flow. Old tabs stay reachable via "More views". */
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const F = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));
  const today = () => new Date().toISOString().slice(0, 10);
  const ui = { fq: "", fd: "", who: "", mq: "", mb: "" };

  const css = document.createElement("style");
  css.textContent = `
.sp-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.sp-big{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;background:linear-gradient(135deg,#0f3d6e,#1d5fa3);color:#fff;border-radius:14px;padding:16px 18px}
.sp-big h3{margin:0;font-size:18px;color:#fff}.sp-big p{margin:3px 0 0;font-size:12.5px;opacity:.85}
.sp-big .btn{background:#fff;color:#0f3d6e;font-weight:800;font-size:14px;padding:10px 18px;border:0}
.sp-who{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.sp-who button{border:1px solid #cfdcec;background:#fff;border-radius:20px;padding:5px 12px;font-size:12px;font-weight:700;color:#334155;cursor:pointer}
.sp-who button.on{background:#0f3d6e;color:#fff;border-color:#0f3d6e}.sp-who b{margin-left:4px;opacity:.75}
.sp-bar{height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden;min-width:70px}.sp-bar i{display:block;height:100%;background:#16a34a}
.sp-more{margin-left:auto;flex:0 0 auto!important;min-width:0!important;font-size:12px!important;color:#64748b!important}
body.dark-theme .sp-who button{background:#17283c;color:#e2ecf8;border-color:#344960}
`;
  document.head.appendChild(css);

  const boqOf = (x) => (db.boq || []).find((b) => b.id === x.boqId || (x.boqCode && b.boqId === x.boqCode && b.projectId === x.projectId)) || {};
  const isForeman = (x) => !(x.source === "stage-update" || x.source === "room-entry" || (!String(x.id || "").startsWith("cloud-") && !x.sourceReportId && x.source !== "foreman" && x.source !== "Foreman" && !x.cloudReportId));
  const loc = (x, b) => [x.building || b.building, x.floor || b.floor, x.room || x.area || b.area || b.room].filter(Boolean).join(" › ") || "General";
  const stOf = (x) => { const s = String(x.approvalStatus || ""); return /reject/i.test(s) ? "Rejected" : /submit|pending/i.test(s) ? "Waiting" : "Approved"; };
  const badge = (s) => `<span class="ps-b ${s === "Approved" ? "g" : s === "Rejected" ? "r" : "a"}">${s === "Waiting" ? "Waiting approval" : s}</span>`;
  const who = (x) => x.foreman || x.submittedBy || x.createdBy || "Foreman";

  function foremanHtml() {
    const all = (db.progress || []).filter((x) => x.projectId === selectedProject && n(x.todayQty) > 0 && isForeman(x)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const t = today(), wk = new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10);
    const names = {}; all.forEach((x) => { names[who(x)] = (names[who(x)] || 0) + 1; });
    const list = all.filter((x) => (!ui.who || who(x) === ui.who) && (!ui.fd || String(x.date).slice(0, 10) === ui.fd) && (!ui.fq || (loc(x, boqOf(x)) + " " + (boqOf(x).boqId || "") + " " + (boqOf(x).description || x.title || "")).toLowerCase().includes(ui.fq.toLowerCase())));
    return `<div class="panel ps-p" data-pt="foreman"><div class="ps-h"><div><h3>👷 Foreman Updates</h3><small>Everything your foremen sent from the phone app, newest first. New phone reports waiting for approval are in the Cloud box at the top — Approve there and they appear here.</small></div>
<div class="ps-f"><input type="date" id="spFd" value="${E(ui.fd)}"><input id="spFq" placeholder="Search work / room…" value="${E(ui.fq)}"></div></div>
<div class="ps-k" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div><small>Today</small><b>${all.filter((x) => String(x.date).slice(0, 10) === t).length}</b><i>updates</i></div><div><small>Last 7 days</small><b>${all.filter((x) => String(x.date) >= wk).length}</b></div><div class="a"><small>Waiting approval</small><b>${all.filter((x) => stOf(x) === "Waiting").length}</b></div><div><small>Foremen</small><b>${Object.keys(names).length}</b></div></div>
<div class="sp-who"><button type="button" data-w="" class="${ui.who ? "" : "on"}">All foremen<b>${all.length}</b></button>${Object.entries(names).map(([k, c]) => `<button type="button" data-w="${E(k)}" class="${ui.who === k ? "on" : ""}">${E(k)}<b>${c}</b></button>`).join("")}</div>
<div class="ps-t" style="max-height:520px;overflow:auto"><table><thead><tr><th>Date</th><th>Foreman</th><th>Location</th><th>BOQ</th><th>Work</th><th class="r">Today qty</th><th>Done / BOQ</th><th>Status</th></tr></thead><tbody>
${list.slice(0, 300).map((x) => { const b = boqOf(x), q = n(b.qty), d = n(b.executedQty), pc = q ? Math.min(100, (d / q) * 100) : 0; return `<tr><td>${E(String(x.date).slice(0, 10))}</td><td><b>${E(who(x))}</b></td><td>${E(loc(x, b))}</td><td>${E(b.boqId || x.boqCode || "—")}</td><td>${E(b.description || x.title || "Work")}${x.note || x.remarks ? `<br><small style="color:#64748b">${E(String(x.note || x.remarks).slice(0, 80))}</small>` : ""}</td><td class="r"><b>+${F(x.todayQty)}</b> ${E(b.unit || "")}</td><td><div style="display:flex;gap:6px;align-items:center"><div class="sp-bar"><i style="width:${pc}%"></i></div><small>${F(d)}/${F(q)} · ${pc.toFixed(0)}%</small></div></td><td>${badge(stOf(x))}</td></tr>`; }).join("") || '<tr><td colspan="8" class="empty">No foreman updates yet for this project.</td></tr>'}
</tbody></table></div></div>`;
  }

  function manualHtml() {
    const items = (db.boq || []).filter((b) => b.projectId === selectedProject && !["Draft", "Under Review", "Submitted"].includes(b.status));
    const blds = [...new Set(items.map((b) => b.building || "General"))];
    const list = items.filter((b) => (!ui.mb || (b.building || "General") === ui.mb) && (!ui.mq || ((b.boqId || "") + " " + (b.description || "") + " " + (b.floor || "") + " " + (b.area || b.room || "")).toLowerCase().includes(ui.mq.toLowerCase())));
    const office = (db.progress || []).filter((x) => x.projectId === selectedProject && n(x.todayQty) > 0 && !isForeman(x)).sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 10);
    return `<div data-pt="manual" class="sp-host" style="margin:0"><div class="sp-big"><div><h3>✍️ Manual Update</h3><p>Enter work done the same way a foreman does — quantity, photos, materials, labour. It is added to the BOQ immediately.</p></div><button class="btn" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ New Work Update</button></div>
<div class="panel ps-p"><div class="ps-h"><div><h3>Pick the work to update</h3><small>Click "Update" next to a BOQ item — the form opens with it already selected.</small></div><div class="ps-f"><select id="spMb"><option value="">All buildings</option>${blds.map((s) => `<option ${ui.mb === s ? "selected" : ""}>${E(s)}</option>`).join("")}</select><input id="spMq" placeholder="Search BOQ / room…" value="${E(ui.mq)}"></div></div>
<div class="ps-t" style="max-height:420px;overflow:auto"><table><thead><tr><th>BOQ ID</th><th>Work</th><th>Location</th><th class="r">BOQ qty</th><th class="r">Done</th><th class="r">Remaining</th><th>Progress</th><th></th></tr></thead><tbody>
${list.map((b) => { const q = n(b.qty), d = n(b.executedQty), r = Math.max(0, q - d), pc = q ? Math.min(100, (d / q) * 100) : 0; return `<tr><td>${E(b.boqId || "—")}</td><td><b>${E(b.description || "Work")}</b></td><td>${E([b.building, b.floor, b.area || b.room].filter(Boolean).join(" › ") || "General")}</td><td class="r">${F(q)} ${E(b.unit || "")}</td><td class="r">${F(d)}</td><td class="r">${F(r)}</td><td><div style="display:flex;gap:6px;align-items:center"><div class="sp-bar"><i style="width:${pc}%"></i></div><small>${pc.toFixed(0)}%</small></div></td><td>${r > 0 ? `<button class="btn small primary" onclick="PB_WORK_REGISTER&&PB_WORK_REGISTER.update('${E(b.id)}')">Update</button>` : '<span class="ps-b g">Done</span>'}</td></tr>`; }).join("") || '<tr><td colspan="8" class="empty">No approved BOQ work for this project.</td></tr>'}
</tbody></table></div></div>
<div class="panel ps-p"><div class="ps-h"><h3>🕒 My last office updates</h3></div><div class="ps-t"><table><thead><tr><th>Date</th><th>Location</th><th>Work</th><th class="r">Qty</th><th>By</th></tr></thead><tbody>${office.map((x) => { const b = boqOf(x); return `<tr><td>${E(String(x.date).slice(0, 10))}</td><td>${E(loc(x, b))}</td><td>${E(b.description || x.title || "Work")}</td><td class="r">+${F(x.todayQty)} ${E(b.unit || "")}</td><td>${E(x.foreman || x.createdBy || "Office")}</td></tr>`; }).join("") || '<tr><td colspan="5" class="empty">No office updates yet.</td></tr>'}</tbody></table></div></div></div>`;
  }

  function inject(v) {
    v.querySelectorAll(".sp-host.sp-root").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum) return;
    const host = document.createElement("div"); host.className = "sp-host sp-root";
    try { host.innerHTML = selectedProject ? foremanHtml() + manualHtml() : `<div class="panel ps-p" data-pt="foreman"><b>Select a project above to see foreman updates.</b></div><div class="panel ps-p" data-pt="manual"><b>Select a project above to add a manual update.</b></div>`; } catch (e) { console.warn("simple-progress", e); return; }
    sum.insertAdjacentElement("afterend", host);
    const on = (id, ev, fn) => host.querySelector(id)?.addEventListener(ev, fn);
    const deb = (key, id) => { let tm; on("#" + id, "input", (e) => { ui[key] = e.target.value; clearTimeout(tm); tm = setTimeout(() => { refresh(); const i = document.getElementById(id); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); }); };
    deb("fq", "spFq"); deb("mq", "spMq");
    on("#spFd", "change", (e) => { ui.fd = e.target.value; refresh(); }); on("#spMb", "change", (e) => { ui.mb = e.target.value; refresh(); });
    host.querySelectorAll(".sp-who button").forEach((b) => b.addEventListener("click", () => { ui.who = b.dataset.w; refresh(); }));
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }
  window.PB_SIMPLE_PROGRESS = { inject, foremanHtml, manualHtml, ui };
})();
