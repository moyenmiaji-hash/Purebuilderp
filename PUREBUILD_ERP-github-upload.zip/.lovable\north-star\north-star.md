<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# মূল লক্ষ্য

ঠিকাদার বাজেটের মধ্যে নির্মাণ কাজ শেষ করে এবং তার টাকা পায়।

## মাপকাঠি

প্রতি সপ্তাহে ফোরম্যানের যে কাজের রিপোর্ট অনুমোদিত হয়ে BOQ অগ্রগতিতে যোগ হয়
