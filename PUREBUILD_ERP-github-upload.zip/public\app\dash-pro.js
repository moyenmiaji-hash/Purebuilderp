/* Dashboard polish (display only, never saves):
   - 3D style icons on KPI cards and box headers
   - Project Financial Overview "View All" opens a full-screen statement (search, sort, totals, print)
   - amounts in the financial table never get cut (horizontal scroll instead)
   - "View all" on Alerts & Reminders and Recent Transactions boxes opens the full list */
(function () {
  var css = `
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-kpis .kpi .kpi-icon,html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-panel .panel-head h3 .dashboard-icon,.dbn-sec-icon,.dbn-icon{
  position:relative;border-radius:10px!important;
  background:radial-gradient(120% 120% at 30% 20%,#ffffff8c 0,#ffffff00 42%),linear-gradient(145deg,color-mix(in srgb,var(--accent,#2a9eea) 78%,#fff),var(--accent,#2a9eea) 55%,color-mix(in srgb,var(--accent,#2a9eea) 70%,#000))!important;
  color:#fff!important;
  box-shadow:inset 0 2px 1px #ffffff80,inset 0 -3px 4px #00000040,0 6px 12px -3px color-mix(in srgb,var(--accent,#2a9eea) 65%,transparent),0 2px 3px #0002!important;
  transform:perspective(160px) rotateX(10deg);transition:transform .2s}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-kpis .kpi:hover .kpi-icon,html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-panel:hover .panel-head h3 .dashboard-icon{transform:perspective(160px) rotateX(0) translateY(-2px) scale(1.06)}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-kpis .kpi .kpi-icon svg,html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-panel .panel-head h3 .dashboard-icon svg{filter:drop-shadow(0 1px 1px #0005);stroke:#fff!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-panel .panel-head h3 .dashboard-icon{display:inline-grid!important;place-items:center;width:24px!important;height:24px!important;flex:0 0 24px!important;--accent:var(--panel-accent,#2a79dc)}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .dashboard-panel .panel-head h3 .dashboard-icon svg{width:14px!important;height:14px!important}
.dbn-sec-icon,.dbn-icon{--accent:#f97316}.dbn-row.red .dbn-icon{--accent:#e5484d}.dbn-row.green .dbn-icon{--accent:#16a34a}.dbn-row.blue .dbn-icon{--accent:#2a79dc}
body.dashboard-mode .project-financial-panel .pf-scroll{overflow:auto!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table{min-width:900px!important;table-layout:auto!important;width:max-content!important;min-width:100%!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table th,html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table td{white-space:nowrap!important;overflow:visible!important;text-overflow:clip!important;max-width:none!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table td:first-child{max-width:190px!important;overflow:hidden!important;text-overflow:ellipsis!important}
.dpx-va{margin-left:6px}
.dpx-ov{position:fixed;inset:0;z-index:9999;background:#0b1626cc;backdrop-filter:blur(3px);display:flex}
.dpx-win{margin:14px;flex:1;background:#fff;color:#172337;border-radius:16px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 30px 80px #0008}
body.dark-theme .dpx-win{background:#0f2236;color:#edf5ff}
.dpx-top{display:flex;gap:10px;align-items:center;padding:12px 16px;background:linear-gradient(135deg,#0f2a4a,#1d4f86);color:#fff}
.dpx-top h2{margin:0;font-size:17px;flex:1;white-space:nowrap}
.dpx-top input{border:0;border-radius:9px;padding:8px 10px;width:260px;flex:none}
.dpx-top button{border:0;border-radius:9px;padding:8px 12px;font-weight:800;cursor:pointer;background:#ffffff26;color:#fff}.dpx-top button.x{background:#e5484d}
.dpx-cards{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;padding:12px 16px}
.dpx-card{border:1px solid #dce6ef;border-radius:12px;padding:10px 12px;background:linear-gradient(150deg,#fff,#f4f8fc)}
body.dark-theme .dpx-card{background:#14283d;border-color:#2b4159}
.dpx-card small{display:block;font-size:11px;color:#6b7f95;font-weight:700}.dpx-card b{font-size:16px;white-space:nowrap}
.dpx-body{flex:1;overflow:auto;padding:0 16px 16px}
.dpx-body table{width:100%;border-collapse:collapse;font-size:13px}
.dpx-body th{position:sticky;top:0;background:#eef4fa;color:#34506e;text-align:right;padding:10px;cursor:pointer;white-space:nowrap;z-index:1}
body.dark-theme .dpx-body th{background:#1a3350;color:#cfe0f5}
.dpx-body th:first-child,.dpx-body td:first-child{text-align:left}
.dpx-body td{padding:10px;border-bottom:1px solid #e6edf4;text-align:right;white-space:nowrap}
body.dark-theme .dpx-body td{border-color:#24405e}
.dpx-body tfoot td{position:sticky;bottom:0;background:#f7fafc;font-weight:900;border-top:2px solid #9fb3c8}
body.dark-theme .dpx-body tfoot td{background:#14283d}
.dpx-body .pos{color:#15945b;font-weight:800}.dpx-body .neg{color:#d84149;font-weight:800}
.dpx-body tbody tr:hover{background:#2a79dc12}
.dpx-list .dbn-row{margin-bottom:6px}
@media(max-width:900px){.dpx-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media print{.dpx-ov{display:none!important}}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table tr>*{position:static!important;box-shadow:none!important;padding-left:5px!important;padding-right:5px!important;font-size:11px!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table{min-width:0!important;width:100%!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table tr>*:nth-last-child(2){min-width:92px;text-align:right!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .dashboard-table tr>td.bad:last-child{background:#fff4f4!important}
.dpx-chips{display:flex;gap:5px;margin-left:auto;align-items:center;flex-wrap:nowrap;overflow:hidden}
.dpx-chip{font-size:10.5px;font-weight:800;padding:3px 8px;border-radius:999px;white-space:nowrap;border:1px solid transparent;line-height:1.3}
.dpx-chip.g{background:#e8f8ef;color:#12784a;border-color:#bfe8d1}.dpx-chip.r{background:#fdecec;color:#c03a41;border-color:#f5c6c8}.dpx-chip.a{background:#fff4e2;color:#a8620b;border-color:#f6d8a8}.dpx-chip.b{background:#e9f2fd;color:#1f62b8;border-color:#c5dbf6}
.dpx-chips+.mini-link,.dpx-chips~.dpx-va{margin-left:6px}
/* Financial box: no status labels under project names, smooth styled scrollbar */
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .pf-st{display:none!important}
html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3):not(.zz4):not(.zz5) #view#view#view#view#view .project-financial-panel .tablewrap.pf-scroll{overflow-y:auto!important;scroll-behavior:smooth;scrollbar-width:thin;scrollbar-color:#7fa3cf #eef3f9;scrollbar-gutter:stable}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar{width:8px;height:8px}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar-track{background:#eef3f9;border-radius:999px}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#8fb2dc,#4f7fbf);border-radius:999px;border:2px solid #eef3f9}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar-thumb:hover{background:linear-gradient(180deg,#6f97cc,#2f5f9f)}
body.dashboard-mode.dark-theme .project-financial-panel .pf-scroll::-webkit-scrollbar-track{background:#1c2836}
body.dashboard-mode.dark-theme .project-financial-panel .pf-scroll::-webkit-scrollbar-thumb{border-color:#1c2836}
html:root body.dashboard-mode #view#view#view#view#view#view .project-financial-panel.pf-v2 .tablewrap.pf-scroll{box-sizing:border-box!important;min-width:0!important;max-width:100%!important;overflow-x:auto!important;overflow-y:auto!important;scrollbar-width:thin!important;scrollbar-color:#7fa3cf #eef3f9!important;scrollbar-gutter:stable}
html:root body.dashboard-mode #view#view#view#view#view#view .project-financial-panel.pf-v2 .dashboard-table{width:max-content!important;min-width:1080px!important;max-width:none!important;table-layout:auto!important}
html:root body.dashboard-mode #view#view#view#view#view#view .project-financial-panel.pf-v2 .dashboard-table th,html:root body.dashboard-mode #view#view#view#view#view#view .project-financial-panel.pf-v2 .dashboard-table td{white-space:nowrap!important}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar{width:8px;height:8px}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar-track{background:#eef3f9;border-radius:999px}
body.dashboard-mode .project-financial-panel .pf-scroll::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#8fb2dc,#4f7fbf);border-radius:999px;border:2px solid #eef3f9}
.dpx-financial .dpx-body{box-sizing:border-box;min-width:0;max-width:100%;overflow:auto!important;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:#7fa3cf #eef3f9}
.dpx-financial .dpx-body table{width:max-content!important;min-width:1200px!important;max-width:none!important;table-layout:auto!important}
.dpx-financial .dpx-body th,.dpx-financial .dpx-body td{white-space:nowrap!important}
.dpx-financial .dpx-body th:first-child,.dpx-financial .dpx-body td:first-child{min-width:150px}
.dpx-financial .dpx-body::-webkit-scrollbar{width:8px;height:8px}
.dpx-financial .dpx-body::-webkit-scrollbar-track{background:#eef3f9;border-radius:999px}
.dpx-financial .dpx-body::-webkit-scrollbar-thumb{background:linear-gradient(180deg,#8fb2dc,#4f7fbf);border-radius:999px;border:2px solid #eef3f9}
body.dark-theme .dpx-financial .dpx-body{scrollbar-color:#56789b #14283d}
body.dark-theme .dpx-financial .dpx-body::-webkit-scrollbar-track{background:#1c2836}
body.dark-theme .dpx-financial .dpx-body::-webkit-scrollbar-thumb{border-color:#1c2836}
@media(max-width:720px){
  .dpx-financial .dpx-win{min-width:0!important;margin:6px!important}
  .dpx-financial .dpx-top{flex-wrap:wrap!important;gap:6px!important;padding:8px!important}
  .dpx-financial .dpx-top h2{flex:1 1 100%!important;min-width:0!important;font-size:13px!important}
  .dpx-financial .dpx-top input{flex:1 1 120px!important;width:auto!important;min-width:0!important}
  .dpx-financial .dpx-top select{flex:1 1 110px!important;min-width:0!important}
  .dpx-financial .dpx-top button{padding:6px 8px!important}
  .dpx-financial .dpx-cards{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:6px!important;padding:8px!important}
  .dpx-financial .dpx-body{padding:0 8px 8px!important}
}`;
  var st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
  var M = function (v) { return typeof money === "function" ? money(v) : "AED " + Number(v || 0).toLocaleString(); };
  var E = function (s) { return typeof esc === "function" ? esc(s) : String(s == null ? "" : s); };

  function shell(title, inner, extraTop) {
    var ov = document.createElement("div"); ov.className = "dpx-ov";
    ov.innerHTML = '<div class="dpx-win"><div class="dpx-top"><h2></h2>' + (extraTop || "") + '<button type="button" data-p>🖨 Print</button><button type="button" class="x">✕ Close</button></div>' + inner + "</div>";
    ov.querySelector("h2").textContent = title;
    ov.querySelector(".x").onclick = function () { ov.remove(); };
    ov.querySelector("[data-p]").onclick = function () { printOv(ov, title); };
    ov.addEventListener("click", function (e) { if (e.target === ov) ov.remove(); });
    document.body.appendChild(ov); return ov;
  }
  addEventListener("keydown", function (e) { if (e.key === "Escape") document.querySelectorAll(".dpx-ov").forEach(function (o) { o.remove(); }); });


  /* ---- Clean print: only the popup content, in its own page (never the dashboard behind) ---- */
  function printOv(ov, title) {
    var S = (window.db && db.settings) || {}, co = S.companyName || "PURE_BUILD", logo = S.companyLogo || "";
    var body = "";
    var cards = ov.querySelector(".dpx-cards"); if (cards) body += '<div class="cards">' + cards.innerHTML + "</div>";
    var b = ov.querySelector(".dpx-body"); if (b) body += '<div class="body">' + b.innerHTML + "</div>";
    var q = ov.querySelector(".dpx-top input"); var flt = q && q.value ? " · Search: " + E(q.value) : "";
    var wide = !!ov.querySelector(".dpx-body table th:nth-child(8)");
    var css = "@page{size:A4 " + (wide ? "landscape" : "portrait") + ";margin:10mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}" +
      "body{font-family:Arial,Helvetica,sans-serif;color:#172337;margin:0;font-size:11px}" +
      ".hd{display:flex;align-items:center;gap:12px;border-bottom:2px solid #0f2a4a;padding-bottom:8px;margin-bottom:8px}.hd img{height:42px}.hd h1{margin:0;font-size:18px}.hd p{margin:2px 0 0;color:#5b6f86;font-size:10px}.hd .m{margin-left:auto;text-align:right;font-size:10px;color:#5b6f86}" +
      "h2{font-size:14px;margin:6px 0 8px;color:#0f2a4a}" +
      ".cards{display:grid;grid-template-columns:repeat(6,1fr);gap:6px;margin-bottom:8px}.dpx-card{border:1px solid #cfdbe7;border-radius:6px;padding:5px 7px}.dpx-card small{display:block;font-size:9px;color:#6b7f95;font-weight:700}.dpx-card b{font-size:12px;white-space:nowrap}" +
      "table{width:100%;border-collapse:collapse;font-size:" + (wide ? "9.5px" : "10.5px") + "}thead{display:table-header-group}tfoot{display:table-row-group}tr{page-break-inside:avoid}" +
      "th{background:#eef4fa;color:#34506e;text-align:right;padding:5px 6px;border:1px solid #d5e0ea;white-space:nowrap}td{padding:5px 6px;border:1px solid #e1e8ef;text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left;white-space:normal}" +
      "tfoot td{font-weight:900;background:#f3f7fb;border-top:2px solid #8fa5bb}.pos{color:#15945b;font-weight:700}.neg{color:#d84149;font-weight:700}" +
      "svg{width:13px!important;height:13px!important;max-width:13px!important;max-height:13px!important;flex:none}" +
      ".dbn-title{font-weight:800;font-size:12px;margin:4px 0 8px;display:flex;gap:6px;align-items:center}.dbn-sec{border:1px solid #dce6ef;border-radius:6px;margin-bottom:8px;page-break-inside:avoid}" +
      ".dbn-sec-head{margin:0;padding:6px 8px;background:#f3f7fb;font-size:11.5px;display:flex;gap:6px;align-items:center}.dbn-sec-count{margin-left:auto}.dbn-sec-body{padding:4px 8px}" +
      ".dbn-row{display:flex;gap:6px;align-items:flex-start;padding:4px 0;border-bottom:1px dashed #e3eaf1}.dbn-row:last-child{border:0}.dbn-row small{display:block;color:#5b6f86}.dbn-row.red b{color:#c03a41}.dbn-row.amber b{color:#a8620b}" +
      ".dbn-attendance-stats{display:flex;gap:6px}.dbn-attendance-stat{border:1px solid #dce6ef;background:none;border-radius:5px;padding:3px 8px;font-size:10.5px}button{font:inherit;color:inherit}" +
      ".ft{margin-top:10px;border-top:1px solid #cfdbe7;padding-top:4px;font-size:9px;color:#6b7f95;display:flex;justify-content:space-between}";
    var html = "<!doctype html><html><head><meta charset='utf-8'><title>" + E(title) + "</title><style>" + css + "</style></head><body>" +
      '<div class="hd">' + (logo ? '<img src="' + logo + '">' : "") + "<div><h1>" + E(co) + "</h1><p>Construction Management &amp; Accounting</p></div><div class='m'>Printed: " + new Date().toLocaleString("en-GB") + flt + "</div></div>" +
      "<h2>" + E(title) + "</h2>" + body + '<div class="ft"><span>' + E(co) + "</span><span>All amounts in AED</span></div></body></html>";
    var f = document.createElement("iframe"); f.setAttribute("aria-hidden", "true");
    f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden";
    document.body.appendChild(f);
    var d = f.contentWindow.document; d.open(); d.write(html); d.close();
    setTimeout(function () { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) {} setTimeout(function () { f.remove(); }, 1500); }, 250);
  }
  window.pbDashPrintOv = printOv;

  /* ---- Project Financial full screen ---- */
  function finRows() {
    var sel = typeof selectedProject !== "undefined" ? selectedProject : "";
    var ps = (db.projects || []).filter(function (p) { return !sel || p.id === sel; });
    var tx = db.transactions || [], inv = db.invoices || [];
    return ps.map(function (p) {
      var r = { p: p, contract: +p.contract || 0, budget: +p.budget || 0, income: 0, expense: 0, invoiced: 0, received: 0 };
      try {
        if (typeof projectFinancialData === "function") { var f = projectFinancialData(p.id); r.income = +(f.income || f.totalIncome || 0); r.expense = +(f.expense || f.totalExpense || f.cost || 0); }
      } catch (e) {}
      if (!r.income && !r.expense) tx.filter(function (t) { return t.projectId === p.id; }).forEach(function (t) { if (t.type === "Income") r.income += +t.amount || 0; else if (typeof isExpense === "function" ? isExpense(t) : /purchase|expense|labour|salary|payment/i.test(t.type)) r.expense += +t.amount || 0; });
      inv.filter(function (i) { return i.projectId === p.id; }).forEach(function (i) { r.invoiced += +i.amount || 0; r.received += +i.received || 0; });
      r.outstanding = Math.max(0, r.invoiced - r.received); r.net = r.income - r.expense;
      r.margin = r.income ? r.net / r.income * 100 : 0; r.used = r.budget ? r.expense / r.budget * 100 : 0;
      return r;
    });
  }
  function readTable() {
    // Use the dashboard's own numbers so the full screen always matches the box.
    var rows = [];
    document.querySelectorAll(".project-financial-panel .dashboard-table tbody tr[data-pid]").forEach(function (tr) {
      var c = tr.children; rows.push({ pid: tr.dataset.pid, cells: [].map.call(c, function (td) { return td.textContent.trim(); }) });
    });
    return rows;
  }
  function finCalc(from, to) {
    var sel = typeof selectedProject !== "undefined" ? selectedProject : "";
    var ps = (db.projects || []).filter(function (p) { return !sel || p.id === sel; });
    return ps.map(function (p) {
      var inv = (db.invoices || []).filter(function (x) { var d = String(x.date || "").slice(0, 10); return x.projectId === p.id && (typeof invoiceIsConfirmed !== "function" || invoiceIsConfirmed(x)) && (!from || (d >= from && d <= to)); });
      var pl = plCalc(from || "1900-01-01", to || plToday(), p.id), inc = (pl.totalRevenue || 0) + (pl.otherIncome || 0);
      var r = { p: p, contract: +p.contract || 0, budget: +p.budget || 0, income: inc, expense: inc - (pl.net || 0), net: pl.net || 0,
        invoiced: inv.reduce(function (a, x) { return a + (+x.amount || 0); }, 0), received: inv.reduce(function (a, x) { return a + (+x.received || 0); }, 0) };
      r.outstanding = Math.max(0, r.invoiced - r.received); r.margin = r.income ? r.net / r.income * 100 : 0; r.used = r.budget ? r.expense / r.budget * 100 : 0;
      return r;
    });
  }
  function monthOpts() {
    var ds = [];
    (db.transactions || []).concat(db.invoices || []).forEach(function (x) { var d = String(x.date || "").slice(0, 7); if (/^\d{4}-\d{2}$/.test(d)) ds.push(d); });
    var now = new Date(); ds.push(now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0"));
    ds = ds.filter(function (v, i, a) { return a.indexOf(v) === i; }).sort().reverse();
    return '<option value="">All time</option>' + ds.map(function (m) { var d = new Date(m + "-01T00:00:00"); return '<option value="' + m + '">' + d.toLocaleString("en-US", { month: "long", year: "numeric" }) + "</option>"; }).join("");
  }
  function openFinancial() {
    var data = finCalc("", ""), period = "All time";
    var cols = [["Project", "name"], ["Status", "status"], ["Contract", "contract"], ["Budget", "budget"], ["Income", "income"], ["Expense", "expense"], ["Budget used", "used"], ["Invoiced", "invoiced"], ["Received", "received"], ["Outstanding", "outstanding"], ["Profit / Loss", "net"], ["Margin", "margin"]];
    var sortK = "name", dir = 1, q = "";
    var ov = shell("Project Financial Overview — all projects", '<div class="dpx-cards"></div><div class="dpx-body"></div>', '<select class="dpx-month" title="Month" style="height:34px;border-radius:8px;border:0;padding:0 10px;font-weight:700">' + monthOpts() + '</select><input type="search" placeholder="Search project…">');
    ov.classList.add("dpx-financial");
    ov.querySelector(".dpx-month").onchange = function (e) { var m = e.target.value; if (!m) { data = finCalc("", ""); period = "All time"; } else { var y = +m.slice(0, 4), mo = +m.slice(5, 7), last = new Date(y, mo, 0).getDate(); data = finCalc(m + "-01", m + "-" + String(last).padStart(2, "0")); period = e.target.options[e.target.selectedIndex].text; } draw(); };
    ov.querySelector("input").oninput = function (e) { q = e.target.value.toLowerCase(); draw(); };
    function val(r, k) { return k === "name" ? r.p.name || "" : k === "status" ? r.p.status || "Active" : r[k]; }
    function draw() {
      var rows = data.filter(function (r) { return !q || String(r.p.name).toLowerCase().indexOf(q) >= 0; }).sort(function (a, b) { var x = val(a, sortK), y = val(b, sortK); if (a.general !== b.general) return a.general ? 1 : -1; return (typeof x === "number" ? x - y : String(x).localeCompare(String(y))) * dir; });
      var t = { contract: 0, budget: 0, income: 0, expense: 0, invoiced: 0, received: 0, outstanding: 0, net: 0 };
      rows.forEach(function (r) { for (var k in t) t[k] += r[k]; });
      ov.querySelector(".dpx-cards").innerHTML = [["Period", period], ["Projects", rows.filter(function (r) { return !r.general; }).length], ["Contract value", M(t.contract)], ["Income", M(t.income)], ["Expense", M(t.expense)], ["Outstanding", M(t.outstanding)], [t.net >= 0 ? "Net Profit" : "Net Loss", M(Math.abs(t.net))]].map(function (c) { return '<div class="dpx-card"><small>' + c[0] + "</small><b>" + c[1] + "</b></div>"; }).join("");
      var pc = function (v) { return '<td class="' + (v >= 0 ? "pos" : "neg") + '">' + v.toFixed(1) + "%</td>"; };
      ov.querySelector(".dpx-body").innerHTML = "<table><thead><tr>" + cols.map(function (c) { return '<th data-k="' + c[1] + '">' + c[0] + (sortK === c[1] ? (dir > 0 ? " ▲" : " ▼") : "") + "</th>"; }).join("") + "</tr></thead><tbody>" +
        (rows.map(function (r) { return '<tr data-pid="' + E(r.p.id) + '" style="cursor:pointer"><td><b>' + E(r.p.name) + "</b></td><td>" + E(r.p.status || "Active") + "</td><td>" + M(r.contract) + "</td><td>" + M(r.budget) + '</td><td class="pos">' + M(r.income) + '</td><td class="neg">' + M(r.expense) + "</td><td>" + (r.budget ? r.used.toFixed(1) + "%" : "—") + "</td><td>" + M(r.invoiced) + "</td><td>" + M(r.received) + "</td><td>" + M(r.outstanding) + '</td><td class="' + (r.net >= 0 ? "pos" : "neg") + '">' + M(r.net) + "</td>" + (r.income ? pc(r.margin) : "<td>—</td>") + "</tr>"; }).join("") || '<tr><td colspan="12" style="text-align:center">No projects found.</td></tr>') +
        "</tbody><tfoot><tr><td>Total</td><td></td><td>" + M(t.contract) + "</td><td>" + M(t.budget) + "</td><td>" + M(t.income) + "</td><td>" + M(t.expense) + "</td><td>" + (t.budget ? (t.expense / t.budget * 100).toFixed(1) + "%" : "—") + "</td><td>" + M(t.invoiced) + "</td><td>" + M(t.received) + "</td><td>" + M(t.outstanding) + '</td><td class="' + (t.net >= 0 ? "pos" : "neg") + '">' + M(t.net) + "</td>" + pc(t.income ? t.net / t.income * 100 : 0) + "</tr></tfoot></table>";
      ov.querySelectorAll("th[data-k]").forEach(function (th) { th.onclick = function () { if (sortK === th.dataset.k) dir = -dir; else { sortK = th.dataset.k; dir = 1; } draw(); }; });
      ov.querySelectorAll("tbody tr[data-pid]").forEach(function (tr) { if (!tr.dataset.pid) { tr.style.cursor = "default"; return; } tr.onclick = function () { ov.remove(); if (typeof projectDetail === "function") { if (typeof setPage === "function") setPage("projects"); projectDetail(tr.dataset.pid, "overview"); } }; });
    }
    draw();
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest(".project-financial-panel .panel-head .mini-link"); if (!b || !document.body.classList.contains("dashboard-mode")) return;
    e.preventDefault(); e.stopImmediatePropagation(); openFinancial();
  }, true);

  /* ---- View all for Alerts & Recent Transactions ---- */
  function openAlerts() {
    var src = document.querySelector(".dashboard-alert-content");
    var ov = shell("Alerts & Reminders", '<div class="dpx-body dpx-list" style="padding-top:14px"></div>');
    ov.querySelector(".dpx-body").innerHTML = src ? src.innerHTML : "No alerts.";
    ov.querySelectorAll("[data-dashboard-target]").forEach(function (r) { r.style.cursor = "pointer"; r.onclick = function () { ov.remove(); var o = document.querySelector('.dashboard-alert-content [data-dashboard-target="' + r.dataset.dashboardTarget + '"]'); if (o) o.click(); }; });
  }
  function openTx() {
    var sel = typeof selectedProject !== "undefined" ? selectedProject : "";
    var list = (db.transactions || []).filter(function (x) { return x.type !== "AP Invoice" && (!sel || x.projectId === sel); }).slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
    var ov = shell("All Transactions", '<div class="dpx-body" style="padding-top:12px"></div>', '<input type="search" placeholder="Search…">');
    function draw(q) {
      var rows = list.filter(function (x) { return !q || JSON.stringify([x.description, x.category, x.type, typeof projectName === "function" ? projectName(x.projectId) : ""]).toLowerCase().indexOf(q) >= 0; });
      ov.querySelector(".dpx-body").innerHTML = "<table><thead><tr><th>Date</th><th>Type</th><th style='text-align:left'>Description</th><th style='text-align:left'>Project</th><th>Amount</th></tr></thead><tbody>" + (rows.map(function (x) { var inc = x.type === "Income"; return "<tr><td>" + E(x.date || "—") + "</td><td>" + E(x.type || "") + "</td><td style='text-align:left'>" + E(x.description || x.category || "") + "</td><td style='text-align:left'>" + E(typeof projectName === "function" ? projectName(x.projectId) : "") + '</td><td class="' + (inc ? "pos" : "neg") + '">' + (inc ? "+" : "-") + M(x.amount) + "</td></tr>"; }).join("") || '<tr><td colspan="5" style="text-align:center">No transactions.</td></tr>') + "</tbody></table>";
    }
    ov.querySelector("input").oninput = function (e) { draw(e.target.value.toLowerCase()); }; draw("");
  }
  function chips(head, html) {
    var c = head.querySelector(".dpx-chips"); if (c && c.dataset.k === html) return;
    if (!c) { c = document.createElement("span"); c.className = "dpx-chips"; var ml = head.querySelector(".mini-link,.dpx-va"); head.insertBefore(c, ml); }
    c.dataset.k = html; c.innerHTML = html;
  }
  function pctTxt(n, d) { return d ? (n / d * 100).toFixed(1) + "%" : "—"; }
  function decorate() {
    if (!document.body.classList.contains("dashboard-mode")) return;
    // Financial box: no In/Ex/Profit chips (user asked to remove them)
    document.querySelectorAll(".project-financial-panel .dpx-chips").forEach(function (c) { c.remove(); });
    // Alerts box: urgent / due soon / info counts
    var ah = document.querySelector(".dashboard-alert-panel .panel-head"), ac = document.querySelector(".dashboard-alert-content");
    if (ah && ac) {
      var r = ac.querySelectorAll(".dbn-row.red").length, a = ac.querySelectorAll(".dbn-row.amber").length, bl = ac.querySelectorAll(".dbn-row.blue").length;
      chips(ah, (r ? '<span class="dpx-chip r">' + r + " urgent</span>" : "") + (a ? '<span class="dpx-chip a">' + a + " due soon</span>" : "") + (bl ? '<span class="dpx-chip b">' + bl + " info</span>" : "") + (!r && !a && !bl ? '<span class="dpx-chip g">All clear</span>' : ""));
    }
    [[".dashboard-alert-panel", openAlerts], [".dashboard-recent-panel", openTx]].forEach(function (x) {
      var head = document.querySelector(x[0] + " .panel-head"); if (!head || head.querySelector(".dpx-va")) return;
      var b = document.createElement("button"); b.type = "button"; b.className = "mini-link dpx-va"; b.textContent = "View all ⤢"; b.onclick = x[1]; head.appendChild(b);
    });
  }
  new MutationObserver(decorate).observe(document.body, { childList: true, subtree: true });
})();
