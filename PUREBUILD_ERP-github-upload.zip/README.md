# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Supabase + Cloudflare deployment

Client handover guide (Bangla): [HANDOVER_BANGLA.md](HANDOVER_BANGLA.md).

### 1) Supabase setup

- Create a new Supabase project.
- Copy the Project URL and the anon/public key from the project dashboard.
- Rename `.env.example` to `.env.local` and fill the values:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_ANON_KEY
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_ANON_KEY
# Server-only secret; never use a VITE_ prefix or commit its real value.
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SECRET_KEY
```

- Follow the exact new-project or existing-project migration order in [supabase/README.md](supabase/README.md). Back up existing data before applying hardening migrations.
- In Supabase Auth, enable email sign-in and set redirect URLs for your deployed app.

### 2) Cloudflare setup

This project builds as a TanStack Start/Nitro Cloudflare Worker with static assets and server API routes. Deploy it as a Worker, not as a static-only Pages site.

Connect the repository to Cloudflare Workers Builds and use:

```bash
npm install
npm run deploy:cloudflare
```

Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` as build variables. Set `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` as Worker runtime secrets/bindings. Never use a `VITE_` prefix for the service-role key.

Cloudflare WAF and rate limits protect requests that pass through your app domain. Browser requests sent directly to Supabase Auth do not pass through Cloudflare, so configure Supabase Auth rate limits and CAPTCHA in the Supabase dashboard.

### 3) Important note

- Only the public Supabase anon key should be used in the browser app.
- Keep the service role key server-side only and never expose it to the frontend.
- For the app to work live, the deployed domain must be added to allowed redirect URLs in Supabase Auth.

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS
