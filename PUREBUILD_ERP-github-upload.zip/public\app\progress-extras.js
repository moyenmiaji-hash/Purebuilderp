/* Site Progress extras (labels/side maps only, never changes BOQ quantities or totals):
   1) Inspection & Approval sign-off chain Engineer → Supervisor → Project Manager in side map db.progressSignoff[progressId] = [{level,decision,note,user,at}].
      It is an inspection record only; quantities still follow the existing rules (office = immediate, foreman = existing approval flow).
   2) Photo labels (Before/During/After, category, description) in side map db.photoMeta["progressId:index"].
   3) Extra reports: BOQ Execution, Planned vs Actual, Delayed, Manpower, Site Photos, Project Completion — CSV + A4 print. */
(function () {
  const C = () => window.PBProgressCalc;
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : n(v).toFixed(2));
  const F = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));
  const today = () => new Date().toISOString().slice(0, 10);
  const user = () => { try { return (typeof salesUser === "function" && salesUser()) || "User"; } catch (e) { return "User"; } };
  const LEVELS = ["Site Engineer", "Site Supervisor", "Project Manager"];
  const ui = { aq: "", ast: "", pst: "", pcat: "", pbld: "", rep: "boq" };

  const css = document.createElement("style");
  css.textContent = `
.px-host{display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.px-chain{display:flex;gap:3px;align-items:center;flex-wrap:wrap}.px-chain span{font-size:10.5px;font-weight:800;padding:2px 7px;border-radius:9px;background:#eef2f7;color:#64748b;white-space:nowrap}
.px-chain span.ok{background:#e6f6ec;color:#15803d}.px-chain span.no{background:#fde8e8;color:#b91c1c}.px-chain i{color:#cbd5e1;font-style:normal}
.px-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
.px-gal figure{margin:0;border:1px solid #e3e9f1;border-radius:10px;overflow:hidden;background:#fff}
.px-gal img{width:100%;height:115px;object-fit:cover;display:block;cursor:pointer}
.px-gal figcaption{padding:6px 8px;font-size:11px;color:#475569;line-height:1.35}.px-gal figcaption b{color:#12233d}
.px-tag{display:inline-block;font-size:10px;font-weight:800;padding:1px 6px;border-radius:8px;margin-right:4px}
.px-tag.Before{background:#fff6dd;color:#a16207}.px-tag.During{background:#e0efff;color:#1d4ed8}.px-tag.After{background:#e6f6ec;color:#15803d}.px-tag.none{background:#eef2f7;color:#64748b}
.px-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px}.px-tabs button{border:1px solid #cfdcec;background:#fff;border-radius:8px;padding:6px 10px;font-size:12px;font-weight:700;color:#334155;cursor:pointer}.px-tabs button.on{background:#0f3d6e;color:#fff;border-color:#0f3d6e}
body.dark-theme .px-gal figure{background:#17283c;border-color:#344960}body.dark-theme .px-gal figcaption,body.dark-theme .px-gal figcaption b{color:#e2ecf8}body.dark-theme .px-tabs button{background:#17283c;color:#e2ecf8;border-color:#344960}
`;
  document.head.appendChild(css);

  const proj = () => (db.projects || []).find((p) => p.id === selectedProject) || {};
  const boqOf = (x) => (db.boq || []).find((b) => b.id === x.boqId || (x.boqCode && b.boqId === x.boqCode && b.projectId === x.projectId)) || {};
  const entries = () => (db.progress || []).filter((x) => x.projectId === selectedProject && n(x.todayQty) > 0);
  const chain = (id) => ((db.progressSignoff || {})[id] || []);
  function signState(id) {
    const c = chain(id);
    if (c.some((s) => s.decision === "Rejected")) return "Rejected";
    const done = LEVELS.filter((l) => c.some((s) => s.level === l && s.decision === "Approved")).length;
    return done === 3 ? "Approved" : done ? "Under Review" : "Submitted";
  }
  const nextLevel = (id) => LEVELS.find((l) => !chain(id).some((s) => s.level === l && s.decision === "Approved"));
  const badge = (s) => `<span class="ps-b ${s === "Approved" ? "g" : s === "Rejected" ? "r" : s === "Under Review" ? "a" : "s"}">${E(s)}</span>`;

  // ---------- 1. Inspection & Approval ----------
  function apprHtml() {
    const all = entries().slice().sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const list = all.filter((x) => (!ui.ast || signState(x.id) === ui.ast) && (!ui.aq || (String(x.date) + " " + (boqOf(x).boqId || "") + " " + (boqOf(x).description || x.title || "")).toLowerCase().includes(ui.aq.toLowerCase())));
    const cnt = (s) => all.filter((x) => signState(x.id) === s).length;
    const ch = (x) => { const c = chain(x.id); return `<div class="px-chain">${LEVELS.map((l, i) => { const s = c.filter((z) => z.level === l).pop(); return `${i ? "<i>→</i>" : ""}<span class="${s ? (s.decision === "Approved" ? "ok" : "no") : ""}" title="${s ? E(s.user + " · " + s.at.slice(0, 16).replace("T", " ") + (s.note ? " · " + s.note : "")) : "Waiting"}">${["Eng", "Sup", "PM"][i]} ${s ? (s.decision === "Approved" ? "✔" : "✖") : "…"}</span>`; }).join("")}</div>`; };
    return `<div class="panel ps-p" data-pt="daily"><div class="ps-h"><div><h3>✅ Inspection &amp; Approval</h3><small>Sign-off chain: Site Engineer → Site Supervisor → Project Manager. This is the inspection record with full history; it does not change quantities already counted.</small></div>
<div class="ps-f"><select id="pxAs"><option value="">All</option>${["Submitted", "Under Review", "Approved", "Rejected"].map((s) => `<option ${ui.ast === s ? "selected" : ""}>${s}</option>`).join("")}</select><input id="pxAq" placeholder="Search…" value="${E(ui.aq)}"></div></div>
<div class="ps-k" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div><small>Submitted</small><b>${cnt("Submitted")}</b></div><div class="a"><small>Under review</small><b>${cnt("Under Review")}</b></div><div class="g"><small>Approved</small><b>${cnt("Approved")}</b></div><div class="r"><small>Rejected</small><b>${cnt("Rejected")}</b></div></div>
<div class="ps-t" style="max-height:420px;overflow:auto"><table><thead><tr><th>Date</th><th>BOQ</th><th>Work</th><th class="r">Qty</th><th>Entered by</th><th>Sign-off</th><th>Status</th><th></th></tr></thead><tbody>
${list.slice(0, 200).map((x) => { const b = boqOf(x), nl = nextLevel(x.id), st = signState(x.id); return `<tr><td>${E(String(x.date).slice(0, 10))}</td><td>${E(b.boqId || x.boqCode || "—")}</td><td>${E(b.description || x.title || "Work")}<br><small style="color:#64748b">${E([x.building || b.building, x.floor || b.floor, x.room || b.area].filter(Boolean).join(" · "))}</small></td><td class="r">${F(x.todayQty)} ${E(b.unit || "")}</td><td>${E(x.foreman || x.createdBy || x.by || "—")}</td><td>${ch(x)}</td><td>${badge(st)}</td><td style="white-space:nowrap">${st !== "Approved" && st !== "Rejected" && nl ? `<button class="btn small" onclick="PB_PROGRESS_EXTRAS.sign('${E(x.id)}')">${E(nl.replace("Site ", "").replace("Project ", "P."))} sign</button>` : ""} <button class="btn small" onclick="PB_PROGRESS_EXTRAS.hist('${E(x.id)}')">History</button></td></tr>`; }).join("") || '<tr><td colspan="8" class="empty">No work entries yet.</td></tr>'}
</tbody></table></div></div>`;
  }
  function sign(id) {
    const lvl = nextLevel(id); if (!lvl || typeof openModal !== "function") return;
    const x = (db.progress || []).find((p) => p.id === id) || {}, b = boqOf(x);
    openModal(`${lvl} inspection — ${E(b.boqId || "")} ${E(b.description || "")}`, `<div class="formgrid"><div class="field"><label>Decision</label><select id="pxDec" class="select"><option>Approved</option><option>Rejected</option></select></div><div class="field"><label>Inspected by</label><input value="${E(user())}" readonly></div><div class="field full"><label>Note / reason</label><textarea id="pxNote" placeholder="Required when rejecting"></textarea></div><div class="field full"><small class="muted">Saved as an inspection record. Quantities are not changed here.</small></div></div>`, () => {
      const dec = document.getElementById("pxDec").value, note = document.getElementById("pxNote").value.trim();
      if (dec === "Rejected" && !note) { typeof toast === "function" && toast("Please write the reason for rejection"); return false; }
      db.progressSignoff = db.progressSignoff || {}; (db.progressSignoff[id] = db.progressSignoff[id] || []).push({ level: lvl, decision: dec, note, user: user(), at: new Date().toISOString() });
      typeof save === "function" && save(); typeof render === "function" && render(); typeof toast === "function" && toast(`${lvl}: ${dec}`); return true;
    });
  }
  function hist(id) {
    const x = (db.progress || []).find((p) => p.id === id) || {}, b = boqOf(x), c = chain(id);
    const rows = [{ at: x.createdAt || x.date, user: x.foreman || x.createdBy || "—", what: `Entered ${F(x.todayQty)} ${b.unit || ""} (${x.source || "entry"})`, note: x.remarks || x.note || "" }]
      .concat(x.approvalStatus ? [{ at: x.reviewedAt || "", user: x.reviewedBy || "—", what: "Report status: " + x.approvalStatus, note: x.reviewNote || "" }] : [])
      .concat(c.map((s) => ({ at: s.at, user: s.user, what: `${s.level}: ${s.decision}`, note: s.note })));
    openModal(`History — ${E(b.boqId || "")} ${E(b.description || "")}`, `<div class="ps-t"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Note</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${E(String(r.at || "").slice(0, 16).replace("T", " "))}</td><td>${E(r.user)}</td><td>${E(r.what)}</td><td>${E(r.note)}</td></tr>`).join("")}</tbody></table></div>`, () => true);
  }

  // ---------- 2. Site photos with labels ----------
  function photos() {
    return entries().flatMap((x) => (Array.isArray(x.photoData) ? x.photoData : []).map((src, i) => { const b = boqOf(x), m = (db.photoMeta || {})[x.id + ":" + i] || {}; return { key: x.id + ":" + i, src, x, b, stage: m.stage || "", cat: m.cat || b.category || b.trade || "", desc: m.desc || "", bld: x.building || b.building || "General", fl: x.floor || b.floor || "", by: x.foreman || x.createdBy || "" }; }));
  }
  function photoHtml() {
    const all = photos(), bl = [...new Set(all.map((p) => p.bld))], cats = [...new Set(all.map((p) => p.cat).filter(Boolean))];
    const list = all.filter((p) => (!ui.pst || (ui.pst === "none" ? !p.stage : p.stage === ui.pst)) && (!ui.pcat || p.cat === ui.pcat) && (!ui.pbld || p.bld === ui.pbld)).sort((a, z) => String(z.x.date).localeCompare(String(a.x.date)));
    const c = (s) => all.filter((p) => p.stage === s).length;
    return `<div class="panel ps-p" data-pt="photos"><div class="ps-h"><div><h3>📷 Site Photos &amp; Documentation (${all.length})</h3><small>Photos from work updates. Click "Label" to mark Before / During / After, work category and description.</small></div>
<div class="ps-f"><select id="pxPs"><option value="">All stages</option>${["Before", "During", "After"].map((s) => `<option ${ui.pst === s ? "selected" : ""}>${s}</option>`).join("")}<option value="none" ${ui.pst === "none" ? "selected" : ""}>Not labelled</option></select><select id="pxPb"><option value="">All buildings</option>${bl.map((s) => `<option ${ui.pbld === s ? "selected" : ""}>${E(s)}</option>`).join("")}</select><select id="pxPc"><option value="">All categories</option>${cats.map((s) => `<option ${ui.pcat === s ? "selected" : ""}>${E(s)}</option>`).join("")}</select></div></div>
<div class="ps-k" style="grid-template-columns:repeat(4,minmax(0,1fr))"><div><small>Before</small><b>${c("Before")}</b></div><div><small>During</small><b>${c("During")}</b></div><div class="g"><small>After</small><b>${c("After")}</b></div><div class="a"><small>Not labelled</small><b>${all.filter((p) => !p.stage).length}</b></div></div>
<div class="px-gal">${list.slice(0, 80).map((p) => `<figure><img src="${p.src}" loading="lazy" alt="site photo" onclick="PB_PROGRESS_EXTRAS.big('${E(p.key)}')"><figcaption><span class="px-tag ${E(p.stage || "none")}">${E(p.stage || "No label")}</span><b>${E(String(p.x.date).slice(0, 10))}</b><br>${E(p.b.description || p.x.title || "Work")}<br>${E([p.bld, p.fl].filter(Boolean).join(" · "))}${p.cat ? " · " + E(p.cat) : ""}${p.desc ? "<br><i>" + E(p.desc) + "</i>" : ""}<br><small>${E(p.by)}</small> <button class="btn small" style="float:right" onclick="PB_PROGRESS_EXTRAS.label('${E(p.key)}')">Label</button></figcaption></figure>`).join("") || '<div class="empty">No photos for this filter.</div>'}</div></div>`;
  }
  function label(key) {
    const m = (db.photoMeta || {})[key] || {}, p = photos().find((z) => z.key === key) || {};
    openModal("Photo label", `<img src="${p.src || ""}" style="width:100%;max-height:260px;object-fit:contain;border-radius:8px"><div class="formgrid"><div class="field"><label>Stage</label><select id="pxSt" class="select">${["", "Before", "During", "After"].map((s) => `<option value="${s}" ${m.stage === s ? "selected" : ""}>${s || "—"}</option>`).join("")}</select></div><div class="field"><label>Work category</label><input id="pxCat" value="${E(m.cat || p.cat || "")}" placeholder="Tiling, Painting…"></div><div class="field full"><label>Description</label><textarea id="pxDs">${E(m.desc || "")}</textarea></div></div>`, () => {
      db.photoMeta = db.photoMeta || {};
      db.photoMeta[key] = { stage: document.getElementById("pxSt").value, cat: document.getElementById("pxCat").value.trim(), desc: document.getElementById("pxDs").value.trim(), by: user(), at: new Date().toISOString() };
      typeof save === "function" && save(); typeof render === "function" && render(); typeof toast === "function" && toast("Photo label saved"); return true;
    });
  }
  function big(key) { const p = photos().find((z) => z.key === key); if (p) openModal(`${String(p.x.date).slice(0, 10)} · ${E(p.b.description || "Site photo")}`, `<img src="${p.src}" style="width:100%;max-height:75vh;object-fit:contain;border-radius:10px"><div class="muted">${E([p.stage, p.bld, p.fl, p.cat, p.desc, p.by].filter(Boolean).join(" · "))}</div>`, () => true); }

  // ---------- 3. Extra reports ----------
  const REPS = { boq: "BOQ Execution", pva: "Planned vs Actual", delay: "Delayed Activities", man: "Manpower", photo: "Site Photos", done: "Project Completion" };
  function plan(b) { const m = (db.boqPlan || {})[b.id] || {}, p = proj(); return { start: m.start || p.start || "", end: m.end || p.end || "" }; }
  function repTable() {
    const t = today(), items = (db.boq || []).filter((b) => b.projectId === selectedProject && C().approvedish(b));
    const it = items.map((b) => { const c = C().itemCalc(b), r = n(b.rate), pl = plan(b), pp = C().planned(pl.start, pl.end, t); return { b, c, r, pl, pp, delay: C().delayDays(pl.end, "", c.pct, t) }; });
    if (ui.rep === "boq") return { h: ["BOQ ID", "Work", "Unit", "BOQ Qty", "Rate", "BOQ Amount", "Executed", "Remaining", "Executed Amount", "Remaining Amount", "Plan start", "Plan finish", "%"], rows: it.map((z) => [z.b.boqId, z.b.description, z.b.unit, F(z.c.qty), M(z.r), M(z.c.qty * z.r), F(z.c.done), F(z.c.remaining), M(z.c.done * z.r), M(z.c.remaining * z.r), z.pl.start, z.pl.end, z.c.pct.toFixed(1) + "%"]) };
    if (ui.rep === "pva") return { h: ["BOQ ID", "Work", "Plan finish", "Planned %", "Actual %", "Gap", "Status"], rows: it.map((z) => [z.b.boqId, z.b.description, z.pl.end, z.pp == null ? "—" : z.pp.toFixed(1) + "%", z.c.pct.toFixed(1) + "%", z.pp == null ? "—" : (z.c.pct - z.pp).toFixed(1), z.pp == null ? "No plan" : z.c.pct + 10 < z.pp ? "Behind" : "On track"]) };
    if (ui.rep === "delay") return { h: ["BOQ ID", "Work", "Location", "Plan finish", "Actual %", "Delay days", "Remaining"], rows: it.filter((z) => z.delay > 0).sort((a, b) => b.delay - a.delay).map((z) => [z.b.boqId, z.b.description, [z.b.building, z.b.floor].filter(Boolean).join(" · "), z.pl.end, z.c.pct.toFixed(1) + "%", z.delay, F(z.c.remaining) + " " + (z.b.unit || "")]) };
    if (ui.rep === "man") { const g = {}; (db.labour || []).filter((x) => x.projectId === selectedProject).forEach((x) => { (g[x.date] = g[x.date] || []).push(x); }); return { h: ["Date", "Workers", "Present", "Absent", "Skilled", "Unskilled", "Hours", "OT", "Labour cost"], rows: Object.keys(g).sort().reverse().map((d) => { const s = C().labourSummary(g[d]); return [d, F(s.workers), F(s.present), F(s.absent), F(s.skilled), F(s.unskilled), F(s.hours), F(s.overtime), M(s.cost)]; }) }; }
    if (ui.rep === "photo") return { h: ["Date", "Stage", "Work", "Building", "Floor", "Category", "Description", "By"], rows: photos().map((p) => [String(p.x.date).slice(0, 10), p.stage || "—", p.b.description || "", p.bld, p.fl, p.cat, p.desc, p.by]) };
    const done = it.filter((z) => z.c.pct >= 100).length, val = it.reduce((s, z) => s + z.c.qty * z.r, 0), ex = it.reduce((s, z) => s + z.c.done * z.r, 0), p = proj();
    return { h: ["Item", "Value"], rows: [["Project", p.name || ""], ["Start → End", (p.start || "?") + " → " + (p.end || "?")], ["BOQ items", it.length], ["Completed items", done], ["Remaining items", it.length - done], ["BOQ value", M(val)], ["Executed value", M(ex)], ["Remaining value", M(val - ex)], ["Physical progress (by value)", C().weighted(items).toFixed(1) + "%"], ["Planned progress today", (() => { const x = C().planned(p.start, p.end, t); return x == null ? "—" : x.toFixed(1) + "%"; })()], ["Delayed items", it.filter((z) => z.delay > 0).length], ["Status", done === it.length && it.length ? "Completed" : "In progress"]] };
  }
  function repHtml() {
    const d = repTable();
    return `<div class="panel ps-p" data-pt="reports"><div class="ps-h"><div><h3>📚 More Reports — ${E(REPS[ui.rep])}</h3><small>${E(proj().name || "")} · read-only from saved BOQ, progress, attendance and photos.</small></div><div class="ps-f"><button class="btn small" onclick="PB_PROGRESS_EXTRAS.csv()">Excel (CSV)</button><button class="btn small" onclick="PB_PROGRESS_EXTRAS.print()">PDF / Print</button></div></div>
<div class="px-tabs">${Object.entries(REPS).map(([k, l]) => `<button type="button" data-r="${k}" class="${ui.rep === k ? "on" : ""}">${l}</button>`).join("")}</div>
<div class="ps-t" style="max-height:460px;overflow:auto"><table id="pxRep"><thead><tr>${d.h.map((h) => `<th>${E(h)}</th>`).join("")}</tr></thead><tbody>${d.rows.map((r) => `<tr>${r.map((c) => `<td>${E(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${d.h.length}" class="empty">Nothing to show.</td></tr>`}</tbody></table></div></div>`;
  }
  function csv() {
    const d = repTable(), t = [d.h, ...d.rows].map((a) => a.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + t], { type: "text/csv" })); a.download = `${ui.rep}-report-${today()}.csv`; a.click();
  }
  function print() {
    const tb = document.getElementById("pxRep"); if (!tb) return; const s = db.settings || {};
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(`<html><head><title>${E(REPS[ui.rep])} Report</title><style>@page{size:A4 landscape;margin:11mm}body{font-family:Arial;font-size:10.5px}h1{font-size:16px;margin:0}table{width:100%;border-collapse:collapse}th{background:#14213d;color:#fff;padding:5px;text-align:left;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{padding:4px 5px;border-bottom:1px solid #ddd}thead{display:table-header-group}</style></head><body><h1>${E(s.companyName || "PURE_BUILD")} — ${E(REPS[ui.rep])} Report</h1><p>${E(proj().name || "")} · Printed ${today()}</p>${tb.outerHTML}<p style="margin-top:30px">Prepared by: ____________ &nbsp;&nbsp; Checked by: ____________ &nbsp;&nbsp; Approved by: ____________</p></body></html>`); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  function inject(v) {
    v.querySelectorAll(".px-host").forEach((e) => e.remove());
    const sum = v.querySelector(".progress-summary"); if (!sum || !C() || !C().labourSummary || !selectedProject) return;
    const host = document.createElement("div"); host.className = "px-host";
    try { host.innerHTML = apprHtml() + photoHtml() + repHtml(); } catch (e) { console.warn("progress-extras", e); return; }
    sum.insertAdjacentElement("afterend", host);
    const on = (id, ev, fn) => host.querySelector(id)?.addEventListener(ev, fn);
    on("#pxAs", "change", (e) => { ui.ast = e.target.value; refresh(); });
    let tm; on("#pxAq", "input", (e) => { ui.aq = e.target.value; clearTimeout(tm); tm = setTimeout(() => { refresh(); const i = document.getElementById("pxAq"); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); });
    on("#pxPs", "change", (e) => { ui.pst = e.target.value; refresh(); }); on("#pxPb", "change", (e) => { ui.pbld = e.target.value; refresh(); }); on("#pxPc", "change", (e) => { ui.pcat = e.target.value; refresh(); });
    host.querySelectorAll(".px-tabs button").forEach((b) => b.addEventListener("click", () => { ui.rep = b.dataset.r; refresh(); }));
  }
  function refresh() { const v = document.getElementById("view"); if (!v) return; inject(v); window.PB_PROGRESS_TABS_SHOW && window.PB_PROGRESS_TABS_SHOW(); }
  window.PB_PROGRESS_EXTRAS = { inject, sign, hist, label, big, csv, print, signState };
})();
