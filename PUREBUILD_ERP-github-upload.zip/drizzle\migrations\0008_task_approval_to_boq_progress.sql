ALTER TABLE public.foreman_task_updates ADD COLUMN IF NOT EXISTS boq_applied_qty numeric;
COMMENT ON COLUMN public.foreman_task_updates.boq_applied_qty IS 'Quantity of this approved update added to linked BOQ progress (after double-count check). NULL = not applied.';

CREATE OR REPLACE FUNCTION public.pb_apply_task_update_to_boq(p_update uuid)
RETURNS numeric LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; b public.team_boq_items; already numeric; q numeric;
BEGIN
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND OR u.review_status <> 'approved' OR u.boq_applied_qty IS NOT NULL THEN RETURN 0; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id;
  IF t.boq_item_id IS NULL THEN RETURN 0; END IF;
  SELECT * INTO b FROM public.team_boq_items WHERE id = t.boq_item_id FOR UPDATE;
  IF NOT FOUND THEN RETURN 0; END IF;
  -- Double-count check: same foreman, same BOQ item, same date already reported through a site progress report
  SELECT coalesce(sum(l.today_qty),0) INTO already FROM public.site_progress_report_boq_lines l
    JOIN public.site_progress_reports r ON r.id = l.report_id
   WHERE l.boq_item_id = b.id AND r.created_by = u.submitted_by AND r.report_date = u.report_date AND r.review_status IN ('submitted','approved');
  q := greatest(0, coalesce(u.approved_qty,0) - already);
  q := least(q, greatest(0, b.quantity - b.approved_completed_qty), greatest(0, b.quantity - b.completed_qty));
  UPDATE public.foreman_task_updates SET boq_applied_qty = q WHERE id = u.id;
  IF q > 0 THEN
    UPDATE public.team_boq_items SET completed_qty = completed_qty + q, approved_completed_qty = approved_completed_qty + q WHERE id = b.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, 'boq_progress', jsonb_build_object('update_id', u.id, 'approved_qty', u.approved_qty, 'already_reported', already),
      jsonb_build_object('added_to_site_progress', q), CASE WHEN already > 0 THEN 'Part already reported in a site progress report — not counted twice' END, auth.uid());
  RETURN q;
END $$;
REVOKE ALL ON FUNCTION public.pb_apply_task_update_to_boq(uuid) FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.review_foreman_task_update(p_update uuid, p_decision text, p_approved_qty numeric, p_note text, p_complete boolean)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE u public.foreman_task_updates; t public.foreman_tasks; aq numeric; nstatus text; added numeric := 0;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'Invalid decision'; END IF;
  SELECT * INTO u FROM public.foreman_task_updates WHERE id = p_update FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Update not found'; END IF;
  IF u.review_status <> 'submitted' THEN RAISE EXCEPTION 'This update was already reviewed'; END IF;
  IF u.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own work'; END IF;
  SELECT * INTO t FROM public.foreman_tasks WHERE id = u.task_id FOR UPDATE;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    aq := coalesce(p_approved_qty, u.reported_qty);
    IF aq < 0 OR aq > u.reported_qty THEN RAISE EXCEPTION 'Approved quantity must be between 0 and the reported quantity'; END IF;
  END IF;
  UPDATE public.foreman_task_updates SET review_status = p_decision, approved_qty = CASE WHEN p_decision='approved' THEN aq ELSE NULL END,
    reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_update;
  IF t.status NOT IN ('completed','cancelled') THEN
    nstatus := CASE WHEN p_decision = 'rejected' THEN 'rejected' WHEN coalesce(p_complete,false) THEN 'completed' ELSE 'in_progress' END;
    IF nstatus <> 'completed' AND EXISTS (SELECT 1 FROM public.foreman_task_updates WHERE task_id = t.id AND review_status = 'submitted') THEN nstatus := 'submitted'; END IF;
    UPDATE public.foreman_tasks SET status = nstatus, completed_at = CASE WHEN nstatus='completed' THEN now() ELSE completed_at END, updated_at = now() WHERE id = t.id;
  END IF;
  INSERT INTO public.foreman_task_events(task_id, event_type, old_values, new_values, reason, actor)
    VALUES (t.id, p_decision, jsonb_build_object('update_id', u.id, 'reported_qty', u.reported_qty),
      jsonb_build_object('approved_qty', aq, 'completed', coalesce(p_complete,false) AND p_decision='approved'), nullif(trim(p_note),''), auth.uid());
  IF p_decision = 'approved' THEN added := public.pb_apply_task_update_to_boq(u.id); END IF;
  RETURN jsonb_build_object('saved', true, 'status', p_decision, 'added_to_site_progress', added);
END $function$;

-- Backfill: updates approved before this change are added once
DO $$ DECLARE r record; BEGIN
  FOR r IN SELECT id FROM public.foreman_task_updates WHERE review_status = 'approved' AND boq_applied_qty IS NULL ORDER BY reviewed_at LOOP
    PERFORM public.pb_apply_task_update_to_boq(r.id);
  END LOOP;
END $$;