# Cloud বার্তা, মাল/সাইট রিপোর্ট Approve, শ্রমিক মোছা ও ছবি ঠিক করার পরিকল্পনা

পুরনো তথ্য মোছা বা বদলানো হবে না। নতুন মেনু যোগ হবে না। শুধু নিচের কাজগুলো।

## ১. "Data conflict" বার্তা ও বারবার Cloud offline/save
- এখন থেকে Cloud-ই আসল তথ্য। ব্রাউজারের তথ্য আর Cloud আলাদা হলে প্রশ্ন না করে Cloud-এর তথ্য দেখাবে, আর ব্রাউজারের তথ্যের একটা নিরাপদ কপি রেখে দেবে (হারাবে না)।
- ব্রাউজারে নতুন কিছু থাকলে (Cloud-এ যায়নি) সেটা নিজে Cloud-এ পাঠাবে।
- একটু পরপর "offline / saving" দেখানো বন্ধ: সংযোগ সত্যি কেটে গেলেই offline দেখাবে, ছোট বিরতির জন্য না।

## ২. স্টাফের ছবি তোলা
- ফোনের ছবি সাধারণত ৩ MB-এর বেশি হয়, তাই আটকে যাচ্ছিল। এখন ছবি পাঠানোর আগে নিজে থেকে ছোট করা হবে (দেখতে পরিষ্কার থাকবে), তাই বার্তা আর আসবে না।

## ৩. Foreman-এর মাল In/Out → Warehouse/Stock
- Warehouse/Stock পাতায় একটা "Site থেকে আসা মাল (অপেক্ষায়)" বক্স: কে, কোন Site, কোন মাল, কত, In না Out।
- সেখানেই Approve / Reject বোতাম। Approve করলে তবেই স্টকে যোগ হবে (একই রিপোর্ট দুইবার না)।
- ছোট সারাংশ: অপেক্ষায় কতটা, আজ Approve কতটা, প্রতিটা মালের আগের স্টক → এখনকার স্টক।

## ৪. Site Progress → Dashboard
- Dashboard-এর "Site Progress" বক্সে স্টাফের পাঠানো রিপোর্ট (অপেক্ষায়) দেখাবে, Approve বোতাম সহ।
- Approve করলে Menu → Site Progress-এ চলে যাবে, আর Dashboard বক্সে ছোট সারাংশ: অপেক্ষায় / Approved / আজকের কাজ।

## ৫. Labour & HR-এ শ্রমিক মোছা
- মোছার আগে নিশ্চিত করার বাক্স (কারণ লেখা)। শ্রমিককে শুধু তালিকা থেকে সরানো হবে; তাঁকে দেওয়া বেতন ও Ledger-এর টাকা যেমন আছে তেমনই থাকবে।

## ৬. Foreman সাইট থেকে শ্রমিক সরানোর অনুরোধ
- স্টাফ অ্যাপে শ্রমিকের পাশে "সরানোর অনুরোধ"। মূল অ্যাপে Labour & HR-এ সেই অনুরোধ আসবে, Admin Approve করলে তবেই সরবে (বেতন/Ledger অক্ষত)।

## ৭. যাচাই
- আলাদা টেস্ট ব্রাউজারে মোবাইল ও ডেস্কটপে দেখা হবে; আসল তথ্যে কিছু সেভ হবে না।

## Technical details
- cloud-sync.js: auto-resolve conflict to cloud (pbSafetySnapshot of local first); push local only if local revision newer; debounce status flicker (~15s).
- team-staff.js: canvas resize to ≤1600px JPEG q0.8 before size check.
- Pending material moves read from approved/submitted `report_payload.material_moves`; approval stores `cloudReportId` side field on stockTxn.
- Worker delete: soft flag `employee.removed=true` side field; payroll/transactions untouched. Foreman removal requests stored in report_payload `worker_remove[]`.
- Bump PB_SAFETY_VERSION.
