// User activity log for the Access page Audit Trail.
// Records add / edit / delete of ERP users into side list db.userAudit (additive; old data untouched).
(function(){
  var pending=null, actor='';
  function who(){
    try{var c=window.PB_CLOUD_CLIENT;if(c&&c.auth)c.auth.getSession().then(function(r){var u=r&&r.data&&r.data.session&&r.data.session.user;if(u)actor=u.email||u.id||''}).catch(function(){})}catch(e){}
  }
  function snap(){try{return JSON.parse(JSON.stringify((typeof db!=='undefined'&&db.users)||[]))}catch(e){return []}}
  var FIELDS=[['name','Name'],['email','Email'],['contact','Phone'],['role','Role'],['status','Status'],['projects','Project access'],['permissions','Permissions']];
  function changes(a,b){
    var out=[];
    FIELDS.forEach(function(f){var x=JSON.stringify(a[f[0]]==null?'':a[f[0]]),y=JSON.stringify(b[f[0]]==null?'':b[f[0]]);if(x!==y)out.push({field:f[1],from:fmt(a[f[0]]),to:fmt(b[f[0]])})});
    if((a.pwHash||'')!==(b.pwHash||''))out.push({field:'Password',from:a.pwHash?'set':'none',to:'changed'});
    return out;
  }
  function fmt(v){if(Array.isArray(v))return v.join(', ');return v==null?'':String(v)}
  function log(before){
    if(typeof db==='undefined'||!db)return;
    var after=snap(),ba={},aa={},rows=[],now=new Date().toISOString();
    before.forEach(function(u){ba[u.id]=u});after.forEach(function(u){aa[u.id]=u});
    after.forEach(function(u){
      if(!ba[u.id])rows.push({action:'User added',u:u,changes:[]});
      else{var ch=changes(ba[u.id],u);if(ch.length)rows.push({action:'User updated',u:u,changes:ch})}
    });
    before.forEach(function(u){if(!aa[u.id])rows.push({action:'User deleted',u:u,changes:[]})});
    if(!rows.length)return;
    if(!Array.isArray(db.userAudit))db.userAudit=[];
    rows.forEach(function(r){db.userAudit.push({id:'ua-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),at:now,action:r.action,userId:r.u.id,userName:r.u.name||'',email:r.u.email||r.u.contact||'',role:r.u.role||'',status:r.u.status||'',changes:r.changes,by:actor||'This device'})});
  }
  function wrap(){
    if(typeof window.save!=='function'||window.save.__ua)return false;
    var oSave=window.save;
    window.save=function(){if(pending){var b=pending;pending=null;try{log(b)}catch(e){}}return oSave.apply(this,arguments)};
    window.save.__ua=true;
    var oAdd=window.addUser;
    if(typeof oAdd==='function'){window.addUser=function(){pending=snap();who();return oAdd.apply(this,arguments)}}
    var oDel=window.del;
    if(typeof oDel==='function'){window.del=function(k){if(k==='users'){pending=snap();who()}return oDel.apply(this,arguments)}}
    return true;
  }
  var esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
  var q='';
  window.pbUserAuditHtml=function(){
    var list=((typeof db!=='undefined'&&db&&db.userAudit)||[]).slice().sort(function(a,b){return String(b.at).localeCompare(String(a.at))});
    var s=q.toLowerCase();
    if(s)list=list.filter(function(r){return (r.userName+' '+r.email+' '+r.action+' '+r.role+' '+r.by).toLowerCase().indexOf(s)>=0});
    var color={'User added':'#15803d','User updated':'#1d4ed8','User deleted':'#b91c1c'};
    var body=list.length?list.slice(0,200).map(function(r){
      var det=r.changes&&r.changes.length?r.changes.map(function(c){return '<div><b>'+esc(c.field)+'</b>: <span style="color:#b91c1c">'+esc(c.from||'—')+'</span> → <span style="color:#15803d">'+esc(c.to||'—')+'</span></div>'}).join(''):(r.action==='User added'?'New user · '+esc(r.role)+' · '+esc(r.status):r.action==='User deleted'?'Removed from user list':'—');
      return '<tr><td style="white-space:nowrap">'+esc(new Date(r.at).toLocaleString())+'</td><td><b style="color:'+(color[r.action]||'#334155')+'">'+esc(r.action)+'</b></td><td>'+esc(r.userName)+'<br><small style="color:#64748b">'+esc(r.email)+'</small></td><td>'+esc(r.role)+'</td><td style="max-width:380px;font-size:12px">'+det+'</td><td>'+esc(r.by)+'</td></tr>';
    }).join(''):'<tr><td colspan="6" style="text-align:center;color:#64748b;padding:16px">No user activity yet. Adding, editing or deleting a user will be recorded here.</td></tr>';
    return '<div class="card" id="pb-user-audit" style="margin-top:14px;padding:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><h3 style="margin:0">User Activity</h3><input id="uaSearch" placeholder="Search user / action…" value="'+esc(q)+'" style="height:34px;padding:0 8px;border:1px solid #cbd5e1;border-radius:8px;min-width:220px"></div><div style="overflow:auto;margin-top:10px;max-height:320px"><table class="table" style="font-size:12px"><thead><tr><th>Time</th><th>Action</th><th>User</th><th>Role</th><th>Details</th><th>Done by</th></tr></thead><tbody>'+body+'</tbody></table></div></div>';
  };
  document.addEventListener('input',function(e){if(e.target&&e.target.id==='uaSearch'){q=e.target.value;var c=document.getElementById('pb-user-audit');if(c){var pos=e.target.selectionStart;c.outerHTML=window.pbUserAuditHtml();var n=document.getElementById('uaSearch');if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}}}}});
  if(!wrap()){var t=setInterval(function(){if(wrap())clearInterval(t)},300)}
})();
