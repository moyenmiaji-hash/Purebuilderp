// Shared print preparation for the ERP page, popup documents, and same-origin print frames.
(function () {
  const sheet = () => document.getElementById("printSheet");
  const clean = (value) => String(value == null ? "" : value).trim();
  const DB = () => (typeof db !== "undefined" ? db : window.db) || {};
  const fontFiles = [
    ["NotoSansBengali-Regular.ttf", "normal"],
    ["NotoSansBengali-Bold.ttf", "bold"]
  ];
  let pdfFontPromise;

  function bengaliText(value) {
    return /[\u0980-\u09ff]/.test(String(value ?? ""));
  }

  async function loadPdfFonts(pdf) {
    if (!pdfFontPromise) {
      pdfFontPromise = Promise.all(fontFiles.map(async ([file]) => {
        const response = await fetch(new URL(`./fonts/${file}`, location.href));
        if (!response.ok) throw Error(`Bengali PDF font could not be loaded (${response.status})`);
        const bytes = new Uint8Array(await response.arrayBuffer());
        let binary = "";
        for (let start = 0; start < bytes.length; start += 0x8000) {
          binary += String.fromCharCode(...bytes.subarray(start, start + 0x8000));
        }
        return [file, btoa(binary)];
      }));
    }
    const fonts = await pdfFontPromise;
    fonts.forEach(([file, data], index) => {
      const style = fontFiles[index][1];
      pdf.addFileToVFS(file, data);
      pdf.addFont(file, "NotoSansBengali", style);
    });
  }

  function setPdfFont(pdf, value, style) {
    if (bengaliText(value)) pdf.setFont("NotoSansBengali", style || "normal");
    else pdf.setFont("helvetica", style || "normal");
  }

  function addPdfLogo(pdf, data, x, y, maxWidth, maxHeight) {
    if (!data) return;
    const image = pdf.getImageProperties(data);
    if (!image.width || !image.height) throw Error("Company logo has invalid dimensions");
    const scale = Math.min(maxWidth / image.width, maxHeight / image.height);
    const width = image.width * scale;
    const height = image.height * scale;
    pdf.addImage(data, image.fileType || "PNG", x + (maxWidth - width) / 2, y + (maxHeight - height) / 2, width, height, "company-logo", "FAST");
  }

  function companyInfo() {
    const data = DB();
    const settings = data.settings || {};
    const company = data.company || {};
    const value = (...values) => values.map(clean).find(Boolean) || "";
    let name = value(settings.companyName, company.name);
    if (/^pure[\s_-]*build$/i.test(name)) name = "";
    return {
      name,
      logo: value(settings.companyLogo, company.logo),
      address: value(settings.companyAddress, company.address),
      phone: value(settings.companyPhone, company.phone),
      email: value(settings.companyEmail, company.email),
      website: value(settings.companyWebsite, company.website),
      registration: value(
        settings.companyRegistration,
        settings.companyRegistrationNo,
        settings.companyRegistrationNumber,
        settings.registrationNumber,
        settings.companyTRN,
        settings.trn,
        settings.companyVAT,
        settings.companyVatNumber,
        settings.vatNumber,
        settings.companyTaxNumber,
        settings.taxNumber
      ),
      footer: value(settings.printFooter)
    };
  }

  function printTitle(root, fallback) {
    const company = companyInfo().name;
    const headings = [...root.querySelectorAll("h1,h2,h3")];
    const heading = headings.find((node) => clean(node.textContent) && clean(node.textContent) !== company);
    const fallbackTitle = clean(fallback).replace(/^pure[\s_-]*build\s*[·—-]?\s*/i, "");
    return fallbackTitle || clean(heading?.textContent).replace(/^pure[\s_-]*build\s*[·—-]?\s*/i, "") || "Document";
  }

  function brandHeader(doc, root, title) {
    const company = companyInfo();
    const brandCandidates = [...root.querySelectorAll(".print-head,.hd,.hrr-head,.q-brand,[data-pb-company-header]")];
    [...root.querySelectorAll("h1")].forEach((heading) => {
      if (company.name && clean(heading.textContent) === company.name && heading.parentElement) brandCandidates.push(heading.parentElement);
    });
    const existing = brandCandidates.find((node) => {
      const text = clean(node.textContent);
      return (company.name && text.includes(company.name)) || node.hasAttribute("data-pb-company-header") || node.classList.contains("q-brand");
    }) || brandCandidates.find((node) => node.matches(".print-head,.q-brand,[data-pb-company-header]")) || brandCandidates[0];
    const header = doc.createElement("header");
    header.className = "pb-print-brand";
    header.setAttribute("data-pb-company-header", "true");

    if (company.logo) {
      const logo = doc.createElement("img");
      logo.className = "pb-print-logo";
      logo.alt = company.name ? `${company.name} logo` : "Company logo";
      logo.src = company.logo;
      logo.addEventListener("error", () => logo.remove(), { once: true });
      header.appendChild(logo);
    }

    const identity = doc.createElement("div");
    identity.className = "pb-print-identity";
    if (company.name) {
      const name = doc.createElement("strong");
      name.textContent = company.name;
      identity.appendChild(name);
    }
    const details = [
      company.address,
      company.phone,
      company.email,
      company.website,
      company.registration
    ].filter(Boolean);
    if (details.length) {
      const meta = doc.createElement("div");
      meta.className = "pb-print-meta";
      meta.textContent = details.join(" · ");
      identity.appendChild(meta);
    }
    header.appendChild(identity);

    if (existing) {
      existing.setAttribute("data-pb-company-header", "true");
      const missingDetails = details.filter((value) => !clean(existing.textContent).includes(value));
      if (company.logo && !existing.querySelector("img") && !root.querySelector(".pb-print-logo")) {
        const logo = header.querySelector(".pb-print-logo").cloneNode();
        logo.dataset.pbPrintAdded = "true";
        existing.prepend(logo);
      }
      if (missingDetails.length) {
        const meta = doc.createElement("div");
        meta.className = "pb-print-meta pb-print-extra-meta";
        meta.dataset.pbPrintAdded = "true";
        meta.textContent = missingDetails.join(" · ");
        existing.appendChild(meta);
      }
      return;
    }

    if (!company.name && !company.logo && !details.length) return;
    const documentInfo = doc.createElement("div");
    documentInfo.className = "pb-print-document";
    const heading = doc.createElement("strong");
    heading.textContent = title;
    documentInfo.appendChild(heading);
    header.appendChild(documentInfo);
    root.prepend(header);
  }

  function addPrintStyles(doc) {
    if (doc.getElementById("pb-print-pro-shared")) return;
    const regularFont = new URL("./fonts/NotoSansBengali-Regular.ttf", location.href).href;
    const boldFont = new URL("./fonts/NotoSansBengali-Bold.ttf", location.href).href;
    const style = doc.createElement("style");
    style.id = "pb-print-pro-shared";
    style.textContent = `
      @font-face { font-family:"Noto Sans Bengali"; font-style:normal; font-weight:400; src:url("${regularFont}") format("truetype"); }
      @font-face { font-family:"Noto Sans Bengali"; font-style:normal; font-weight:700; src:url("${boldFont}") format("truetype"); }
      html,body { color:#111; font-family:"Noto Sans Bengali","Nirmala UI","Vrinda",Arial,sans-serif; font-size:10pt; line-height:1.35; }
      .pb-print-brand { display:flex; flex-wrap:wrap; align-items:flex-start; gap:8px 12px; width:100%; box-sizing:border-box; margin:0 0 9px; padding:0 0 7px; border-bottom:1px solid #9aa8b7; color:#15283e; font-size:10pt; line-height:1.35; }
      .pb-print-logo { display:block; flex:0 0 auto; width:auto; height:auto; max-width:110px; max-height:42px; object-fit:contain; object-position:left center; }
      .pb-print-identity { min-width:150px; flex:1 1 58%; }
      .pb-print-identity strong,.pb-print-document strong { display:block; font-size:12pt; font-weight:700; }
      .pb-print-meta { display:block; margin-top:3px; color:#4b5563; font-size:8.5pt; line-height:1.4; overflow-wrap:anywhere; }
      .pb-print-document { flex:1 1 100%; max-width:none; margin:0; padding-top:5px; border-top:1px solid #d5dce3; text-align:left; }
      .pb-print-extra-meta { flex:1 1 100%; min-width:100%; margin-top:4px; overflow-wrap:anywhere; }
      .pb-print-footer { margin-top:8px; padding-top:5px; border-top:1px solid #9aa8b7; color:#4b5563; font-size:8.5pt; line-height:1.4; overflow-wrap:anywhere; }
      @media print {
        * { -webkit-print-color-adjust:exact; print-color-adjust:exact; }
        table { max-width:100%; border-collapse:collapse; }
        thead { display:table-header-group; }
        tfoot { display:table-footer-group; }
        th,td { white-space:normal!important; word-break:normal; overflow-wrap:anywhere; vertical-align:top; }
        th.num,td.num,th.r,td.r { white-space:nowrap!important; overflow-wrap:normal; }
        tr { break-inside:avoid; page-break-inside:avoid; }
        th { position:static!important; }
        img { max-width:100%; }
        .pb-print-brand,.pb-print-footer { break-inside:avoid; page-break-inside:avoid; }
      }`;
    doc.head.appendChild(style);
  }

  function preparePrint(doc, root, title) {
    if (!doc?.body || !root || doc.documentElement.dataset.pbPrintPrepared === "true") return;
    doc.documentElement.dataset.pbPrintPrepared = "true";
    root.dataset.pbPrintPrepared = "true";
    addPrintStyles(doc);
    const company = companyInfo();
    root.querySelectorAll("h1,h2,.print-foot,.print-meta").forEach((node) => {
      if (/^pure[\s_-]*build(?:\s*[·—-].*)?$/i.test(clean(node.textContent))) {
        node.dataset.pbPrintOriginalHtml = node.innerHTML;
        node.textContent = clean(node.textContent).replace(/^pure[\s_-]*build\s*[·—-]?\s*/i, "");
      }
    });
    brandHeader(doc, root, printTitle(root, title));
    if (company.footer && !root.querySelector("[data-pb-print-footer]")) {
      const footer = doc.createElement("footer");
      footer.className = "pb-print-footer";
      footer.dataset.pbPrintFooter = "true";
      footer.textContent = company.footer;
      root.appendChild(footer);
    }
  }

  function hookPrintWindow(target) {
    try {
      if (!target || target === window || !target.document || target.print.__pbPrintWrapped) return;
      const native = target.print.bind(target);
      const wrapped = function () {
        const doc = target.document;
        preparePrint(doc, doc.body, doc.title);
        native();
      };
      wrapped.__pbPrintWrapped = true;
      target.print = wrapped;
    } catch (error) {
      if (error?.name !== "SecurityError") console.error("Could not prepare a print window", error);
    }
  }

  const nativeOpen = window.open.bind(window);
  window.open = function () {
    const target = nativeOpen.apply(this, arguments);
    hookPrintWindow(target);
    return target;
  };

  function hookFrame(frame) {
    const hook = () => {
      try {
        hookPrintWindow(frame.contentWindow);
      } catch (error) {
        if (error?.name !== "SecurityError") console.error("Could not prepare a print frame", error);
      }
    };
    frame.addEventListener("load", hook);
    hook();
    [0, 40, 180, 500].forEach((delay) => setTimeout(hook, delay));
  }

  function watchFrames() {
    document.querySelectorAll("iframe").forEach(hookFrame);
    new MutationObserver((records) => records.forEach((record) => record.addedNodes.forEach((node) => {
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      if (node.tagName === "IFRAME") hookFrame(node);
      node.querySelectorAll?.("iframe").forEach(hookFrame);
    }))).observe(document.body, { childList: true, subtree: true });
  }

  const nativePrint = window.print.bind(window);
  window.print = function () {
    const printSheet = sheet();
    const freshSheet = !!(printSheet && printSheet.innerHTML.trim());
    const modal = document.querySelector("#modal.open");
    let root;
    if (freshSheet) root = printSheet;
    else if (modal) root = document.getElementById("modalBody");
    else root = document.getElementById("view");

    if (freshSheet) document.body.classList.add("pb-print-sheet");
    else if (modal) document.body.classList.add("pb-print-modal");
    else document.body.classList.add("pb-print-page");

    if (root) {
      const title = modal
        ? document.getElementById("modalTitle")?.textContent
        : root.querySelector("h1,h2")?.textContent;
      preparePrint(document, root, title);
    }
    nativePrint();
  };

  window.addEventListener("afterprint", () => {
    document.body.classList.remove("pb-print-page", "pb-print-modal", "pb-print-sheet");
    delete document.documentElement.dataset.pbPrintPrepared;
    document.querySelectorAll("[data-pb-print-prepared]").forEach((node) => delete node.dataset.pbPrintPrepared);
    document.querySelectorAll("[data-pb-company-header]").forEach((node) => {
      if (node.classList.contains("pb-print-brand")) node.remove();
      else node.removeAttribute("data-pb-company-header");
    });
    document.querySelectorAll("[data-pb-print-added],.pb-print-extra-meta,[data-pb-print-footer]").forEach((node) => node.remove());
    document.querySelectorAll("[data-pb-print-original-html]").forEach((node) => {
      node.innerHTML = node.dataset.pbPrintOriginalHtml;
      delete node.dataset.pbPrintOriginalHtml;
    });
    const printSheet = sheet();
    if (printSheet) printSheet.innerHTML = "";
  });

  // ---------- Access page: Staff App link ----------
  function staffLink() {
    if (location.hash !== "#access") return;
    const act = document.querySelector("#view .pagehead .actions, #view .pagehead");
    if (!act || act.querySelector(".pb-staff-link")) return;
    const url = new URL("./staff-mobile.html", location.href).href.replace(/\?.*$/, "");
    const w = document.createElement("span"); w.className = "pb-staff-link";
    w.innerHTML = `<a class="btn" href="./staff-mobile.html" target="_blank" rel="noopener">📱 Open Staff App</a><button type="button" class="btn">🔗 Copy staff link</button>`;
    w.querySelector("button").onclick = () => { navigator.clipboard?.writeText(url).then(() => typeof toast === "function" && toast("Staff app link copied — send it to your foreman")); };
    act.appendChild(w);
  }
  const run = () => { try { staffLink(); } catch (error) { console.error("Could not add Staff App links", error); } };
  const boot = () => {
    const view = document.getElementById("view");
    if (view) new MutationObserver(run).observe(view, { childList: true });
    watchFrames();
    run();
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();

  const css = `
  #pbPrintHead{display:none}
  .pb-staff-link{display:inline-flex;gap:6px;margin-left:6px}
  @media print{
    #pbPrintHead{display:flex!important}
    body.pb-print-page .app{display:block!important}
    body.pb-print-page .sidebar,body.pb-print-page .topbar,body.pb-print-page .modal,body.pb-print-page .toast,body.pb-print-page #printSheet{display:none!important}
    body.pb-print-page .main{margin:0!important;padding:0!important;width:100%!important;max-width:none!important}
    body.pb-print-page #view{padding:0!important;max-width:none!important}
    body.pb-print-modal .app,body.pb-print-modal .toast,body.pb-print-modal #printSheet{display:none!important}
    body.pb-print-modal #modal{display:block!important;position:static!important;background:#fff!important;padding:0!important;inset:auto!important}
    body.pb-print-modal #modal .modalbox{width:100%!important;max-width:none!important;max-height:none!important;box-shadow:none!important;border:0!important;overflow:visible!important}
    body.pb-print-modal #modal .modalhead button,body.pb-print-modal #modal .modalfoot,body.pb-print-modal #modalTitle{display:none!important}
    body.pb-print-page,body.pb-print-modal,body.pb-print-sheet{background:#fff!important;color:#111!important}
    body.pb-print-page #view *,body.pb-print-modal #modalBody *,body.pb-print-sheet #printSheet *{max-height:none!important;overflow:visible!important;box-shadow:none!important}
    body.pb-print-page #view .btn,body.pb-print-page #view button,body.pb-print-page #view .hr-toolbar,body.pb-print-page #view .pb-staff-link,
    body.pb-print-modal #modalBody .btn,body.pb-print-modal #modalBody button{display:none!important}
    body.pb-print-sheet #printSheet .btn,body.pb-print-sheet #printSheet button{display:none!important}
    body.pb-print-page #view input,body.pb-print-page #view select{border:0!important;background:none!important;appearance:none;-webkit-appearance:none}
    table{border-collapse:collapse}
  }`;
  const style = document.createElement("style"); style.id = "pb-print-pro"; style.textContent = css; document.head.appendChild(style);
  window.PB_PRINT = { loadPdfFonts, setPdfFont, addPdfLogo, companyInfo };
})();
