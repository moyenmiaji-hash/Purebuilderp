/* BOQ progress formulas (display only). Used by boq-pro.js (office BOQ page)
   and staff-calc.js (foreman phone app). Tested in src/test/boq-calc.test.ts. */
(function (w) {
  function n(v) { v = Number(v); return isFinite(v) ? v : 0; }
  function pct(part, whole) { return whole > 0 ? Math.min(100, Math.max(0, part / whole * 100)) : 0; }

  /* One office BOQ line: qty, executedQty, rate. */
  function rowStats(x) {
    var q = Math.max(0, n(x && x.qty)), done = Math.min(q, Math.max(0, n(x && x.executedQty))), rate = n(x && x.rate);
    var left = Math.max(0, q - done), p = pct(done, q);
    var state = done <= 0 ? 'Not started' : (left <= 0 ? 'Completed' : 'In progress');
    return { qty: q, done: done, left: left, pct: p, state: state, doneValue: done * rate, leftValue: left * rate };
  }

  /* Many BOQ lines: progress weighted by amount (value), like the KPI card. */
  function groupStats(list) {
    var total = 0, done = 0, c = { 'Not started': 0, 'In progress': 0, 'Completed': 0 };
    (list || []).forEach(function (x) {
      var s = rowStats(x), amt = n(x.amount) || s.qty * n(x.rate);
      total += amt; done += s.qty ? amt * s.done / s.qty : 0; c[s.state]++;
    });
    return { total: total, doneValue: done, pct: pct(done, total), counts: c };
  }

  /* Foreman phone entry: quantity = BOQ qty, approved = office-approved qty,
     reported = all reported incl. waiting approval, today = entered now. */
  function foremanCalc(item, today) {
    var q = Math.max(0, n(item && item.quantity));
    var approved = Math.min(q, Math.max(0, n(item && item.approved)));
    var reported = Math.min(q, Math.max(approved, n(item && item.reported)));
    var leftBefore = Math.max(0, q - reported);
    var asked = Math.max(0, n(today)), t = Math.min(asked, leftBefore);
    var after = reported + t;
    return {
      quantity: q, approved: approved, pending: reported - approved, today: t,
      over: asked > leftBefore + 1e-9, leftBefore: leftBefore, leftAfter: Math.max(0, q - after), after: after,
      pctApproved: pct(approved, q), pctPending: pct(reported - approved, q), pctToday: pct(t, q),
      pctBefore: pct(reported, q), pctAfter: pct(after, q)
    };
  }

  w.PB_BOQ_CALC = { rowStats: rowStats, groupStats: groupStats, foremanCalc: foremanCalc };
})(typeof window !== 'undefined' ? window : this);
