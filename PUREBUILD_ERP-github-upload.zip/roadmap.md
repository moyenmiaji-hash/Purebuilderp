# Roadmap
- [x] Foreman Task Management phase 1: assign tasks, foreman My Tasks, submit, approve/reject, history (Cloud-checked)
- [ ] Foreman tasks phase 2: 7-day performance & foreman comparison page
- [ ] Foreman tasks phase 3: alerts, PDF/Excel reports
- [ ] Projects module phase 1 leftovers: KPI "i" notes, office progress reduces foreman remaining, joint progress history
- [x] Task form: BOQ qty / this target / outstanding boxes
- [x] Restore missing project AL HIKMAN VILLA; safer project delete (type name, copy kept)
- [x] Dashboard Project Financial Overview: all projects, scroll, Income/Expense/Net Profit-Loss columns
- [x] Accounts Payable: Supplier Statement (all purchases + payments by date, running balance, filters, Print/CSV)
- [x] Task form: BOQ quantity boxes showed 0 (fixed); Task page no longer shows Reports while loading
