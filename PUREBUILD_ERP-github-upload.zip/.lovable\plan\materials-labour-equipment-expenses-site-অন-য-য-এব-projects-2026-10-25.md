# Materials, Labour & Equipment, Expenses: Site অনুযায়ী এবং Projects/Sites-এর সাথে পুরো অ্যাপের সংযোগ

এই ভুল বার্তাটা আসল কোড-ভুল না, এটা নোট ফাইলের লেখা। নোটে যা চাওয়া হয়েছে তার পরিকল্পনা নিচে। পুরনো তথ্য মোছা হবে না, নতুন মেনু যোগ হবে না, অপ্রয়োজনীয় কিছু যোগ হবে না।

## ১. তিনটা ট্যাব Site অনুযায়ী
- **Expenses & Payments:** Site বাছলে উপরের সব বাক্স (Actual Cost, Material, Labour, Equipment, Other, Unpaid, Remaining, Forecast) আর নিচের তালিকা শুধু ওই Site-এর খরচ দেখাবে। "All Sites" বাছলে আগের মতো পুরো প্রজেক্ট।
- **Materials:** Site বাছলে শুধু ওই Site-এর মাল ঢোকানো/বের করা আর বাকি পরিমাণ দেখাবে।
- **Labour & Equipment:** Transaction Entry-তে ওই Site দিয়ে যে Labour / Equipment খরচ দেওয়া হয়েছে সেগুলো Site অনুযায়ী দেখাবে। হাজিরার (attendance) হিসাবে Site লেখা থাকে না, তাই সেটা পুরো প্রজেক্টের থাকবে এবং ছোট করে বলা থাকবে।
- নিয়ম একটাই: Site-এর খরচ Transaction Entry-তে প্রজেক্ট + Site বেছে দিলেই ওই Site-এর হিসাবে চলে যাবে।

## ২. প্রজেক্ট পাতা থেকে সরাসরি খরচ যোগ
- Expenses, Materials, Labour ট্যাবে একটা "+ Add Expense" বোতাম: চাপলে Transaction Entry খুলবে, প্রজেক্ট আর বাছাই করা Site আগে থেকেই বসানো থাকবে।

## ৩. Projects/Sites পুরো চেক ও অন্য মেনুর সাথে সংযোগ
- প্রতিটা ট্যাব খুলে যাচাই। যেখানে লিংক দরকার সেখানে ছোট লিংক:
  - Transaction Entry / Ledger: প্রজেক্ট + Site বাছাই করা অবস্থায় খুলবে।
  - Sales & Invoiced: ওই প্রজেক্টের Invoice দেখাবে।
  - Accounts Payable: ওই প্রজেক্টের Supplier বাকি।
  - Warehouse / Stock: প্রজেক্ট + Site ফিল্টার করা।
  - Site Progress, Quotation, BOQ & Drawings, Reports: ওই প্রজেক্ট বাছাই করা অবস্থায়।
- Dashboard-এর প্রজেক্ট তালিকা থেকে চাপলে সরাসরি প্রজেক্ট পাতা খুলবে (না থাকলে যোগ হবে)।
- কোনো লিংক ভাঙা বা কাজহীন থাকলে ঠিক করা হবে; অকেজো কিছু পেলে সরানো হবে, তবে কোনো তথ্য মোছা হবে না।

## ৪. যাচাই
- আলাদা টেস্ট ব্রাউজারে নকল তথ্য দিয়ে দুই Site-এ খরচ দিয়ে হিসাব আলাদা ঠিক আসে কিনা আর প্রতিটা লিংক ঠিক জায়গায় যায় কিনা দেখা হবে।

## যা করা হবে না
- নতুন মেনু/পাতা, হিসাবের নিয়ম বদল, পুরনো তথ্য মোছা।

## Technical details
- Filter project cost aggregates and Expenses/Materials/Labour rows with existing `matchBuilding(rec, selectedSite)` on `transaction.building` / `stockTxn.building`.
- Cross-menu links set the target page's existing project/building filter state, then call `setPage()`.
- "+ Add Expense" prefills Transaction Entry project and building selects.
