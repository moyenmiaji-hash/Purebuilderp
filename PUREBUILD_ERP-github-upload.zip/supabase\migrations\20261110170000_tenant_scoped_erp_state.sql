-- Keep the existing ERP snapshot and history, but scope each row to its company.
-- Apply only after 20261110161000_security_hardening.sql and a verified backup.
BEGIN;

ALTER TABLE public.erp_cloud_state
  ADD COLUMN IF NOT EXISTS organization_id uuid;

UPDATE public.erp_cloud_state s
SET organization_id = p.organization_id
FROM public.profiles p
WHERE s.organization_id IS NULL
  AND s.updated_by = p.id;

ALTER TABLE public.erp_state_history
  ADD COLUMN IF NOT EXISTS organization_id uuid;

UPDATE public.erp_state_history h
SET organization_id = p.organization_id
FROM public.profiles p
WHERE h.organization_id IS NULL
  AND h.saved_by = p.id;

DO $$
DECLARE
  organization_count integer;
  fallback_organization uuid;
BEGIN
  SELECT count(*), (array_agg(organization_id))[1]
  INTO organization_count, fallback_organization
  FROM (SELECT DISTINCT organization_id FROM public.profiles) organizations;

  IF EXISTS (SELECT 1 FROM public.erp_cloud_state WHERE organization_id IS NULL) THEN
    IF organization_count <> 1 THEN
      RAISE EXCEPTION 'Cannot safely assign the existing ERP snapshot to one company; resolve the company ownership before applying this migration.';
    END IF;
    UPDATE public.erp_cloud_state
    SET organization_id = fallback_organization
    WHERE organization_id IS NULL;
  END IF;

  IF EXISTS (SELECT 1 FROM public.erp_state_history WHERE organization_id IS NULL) THEN
    IF organization_count <> 1 THEN
      RAISE EXCEPTION 'Cannot safely assign ERP history to one company; resolve the company ownership before applying this migration.';
    END IF;
    UPDATE public.erp_state_history
    SET organization_id = fallback_organization
    WHERE organization_id IS NULL;
  END IF;
END
$$;

ALTER TABLE public.erp_cloud_state
  ALTER COLUMN organization_id SET NOT NULL,
  DROP CONSTRAINT IF EXISTS erp_cloud_state_pkey,
  ADD CONSTRAINT erp_cloud_state_pkey PRIMARY KEY (organization_id, id);

ALTER TABLE public.erp_state_history
  ALTER COLUMN organization_id SET NOT NULL;

CREATE INDEX IF NOT EXISTS erp_state_history_company_saved_idx
  ON public.erp_state_history (organization_id, saved_at DESC);

DROP POLICY IF EXISTS "Office users read ERP data" ON public.erp_cloud_state;
CREATE POLICY "Office users read ERP data" ON public.erp_cloud_state
  FOR SELECT TO authenticated
  USING (
    public.is_office_user(auth.uid())
    AND organization_id = public.pb_current_organization_id()
  );

DROP POLICY IF EXISTS pb_erp_cloud_state_tenant ON public.erp_cloud_state;
CREATE POLICY pb_erp_cloud_state_tenant ON public.erp_cloud_state
  AS RESTRICTIVE FOR ALL TO authenticated
  USING (
    public.pb_is_active_user()
    AND organization_id = public.pb_current_organization_id()
  )
  WITH CHECK (
    public.pb_is_active_user()
    AND organization_id = public.pb_current_organization_id()
  );

DROP POLICY IF EXISTS pb_erp_state_history_tenant ON public.erp_state_history;
CREATE POLICY pb_erp_state_history_tenant ON public.erp_state_history
  AS RESTRICTIVE FOR ALL TO authenticated
  USING (
    public.pb_is_active_user()
    AND organization_id = public.pb_current_organization_id()
  )
  WITH CHECK (
    public.pb_is_active_user()
    AND organization_id = public.pb_current_organization_id()
  );

CREATE OR REPLACE FUNCTION public.erp_state_save(p_expected int, p_data jsonb)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
DECLARE
  current_state public.erp_cloud_state;
  current_organization uuid := public.pb_current_organization_id();
  next_revision int;
BEGIN
  IF current_organization IS NULL OR NOT public.is_office_user(auth.uid()) THEN
    RAISE EXCEPTION 'NOT_ALLOWED';
  END IF;

  IF p_data IS NULL OR jsonb_typeof(p_data) <> 'object'
    OR coalesce(jsonb_typeof(p_data->'projects'), 'array') <> 'array'
    OR coalesce(jsonb_typeof(p_data->'transactions'), 'array') <> 'array'
  THEN
    RAISE EXCEPTION 'INVALID_ERP_STATE';
  END IF;

  IF coalesce(jsonb_array_length(p_data->'projects'), 0) = 0
    AND coalesce(jsonb_array_length(p_data->'transactions'), 0) = 0
  THEN
    RAISE EXCEPTION 'EMPTY_OVERWRITE_BLOCKED';
  END IF;

  SELECT * INTO current_state
  FROM public.erp_cloud_state
  WHERE organization_id = current_organization AND id = 1
  FOR UPDATE;

  IF NOT FOUND THEN
    IF coalesce(p_expected, 0) <> 0 THEN
      RAISE EXCEPTION 'REVISION_CONFLICT';
    END IF;
    INSERT INTO public.erp_cloud_state (organization_id, id, data, revision, updated_by)
    VALUES (current_organization, 1, p_data, 1, auth.uid());
    RETURN 1;
  END IF;

  IF current_state.revision <> p_expected THEN
    RAISE EXCEPTION 'REVISION_CONFLICT';
  END IF;

  INSERT INTO public.erp_state_history (organization_id, revision, data, saved_by)
  VALUES (current_organization, current_state.revision, current_state.data, current_state.updated_by);

  next_revision := current_state.revision + 1;
  UPDATE public.erp_cloud_state
  SET data = p_data,
      revision = next_revision,
      updated_by = auth.uid(),
      updated_at = now()
  WHERE organization_id = current_organization AND id = 1;

  RETURN next_revision;
END
$$;

REVOKE EXECUTE ON FUNCTION public.erp_state_save(int, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.erp_state_save(int, jsonb) TO authenticated;

COMMIT;