(function () {
  const WIDGETS = new WeakMap();
  let scriptPromise;

  function loadTurnstile() {
    if (window.turnstile) return Promise.resolve(window.turnstile);
    if (!scriptPromise) {
      scriptPromise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
        script.async = true;
        script.defer = true;
        script.onload = () => window.turnstile
          ? resolve(window.turnstile)
          : reject(new Error("Cloudflare Turnstile did not initialize."));
        script.onerror = () => reject(new Error("Cloudflare Turnstile could not load."));
        document.head.appendChild(script);
      });
    }
    return scriptPromise;
  }

  window.PB_TURNSTILE = {
    async getToken(container) {
      const siteKey = window.PURE_BUILD_CLOUD_CONFIG?.turnstileSiteKey;
      if (!siteKey) return undefined;
      if (!container) throw new Error("Turnstile container is missing.");

      const turnstile = await loadTurnstile();
      const previous = WIDGETS.get(container);
      if (previous !== undefined) turnstile.remove(previous);

      return new Promise((resolve, reject) => {
        let settled = false;
        const widget = turnstile.render(container, {
          sitekey: siteKey,
          callback: (token) => {
            if (settled) return;
            settled = true;
            resolve(token);
          },
          "error-callback": () => {
            if (settled) return;
            settled = true;
            reject(new Error("Turnstile verification failed. Please try again."));
          },
          "expired-callback": () => {
            if (settled) return;
            settled = true;
            reject(new Error("Turnstile verification expired. Please try again."));
          },
        });
        WIDGETS.set(container, widget);
      });
    },
  };
})();
