/* PURE_BUILD Warehouse & Stock Pro (phase 1)
   Adds Stock Dashboard, Stock In (GRN), Stock Out (Issue) and a full Movement Ledger
   inside the Warehouse / Stock page only. Vouchers live in the side list db.stockVouchers;
   only an approved voucher writes normal db.stock rows (same shape as before, tagged voucherId),
   exactly once. Old stock rows are read as approved and never changed. */
(function () {
  const C = () => window.PBStockCalc;
  const NEW_TABS = ["sdash", "grn", "issue", "ledger"];
  const F = (window.SP_F = window.SP_F || { period: "all", from: "", to: "", mat: "", cat: "", sup: "", type: "" });
  const today = () => new Date().toISOString().slice(0, 10);
  const vouchers = () => (db.stockVouchers = Array.isArray(db.stockVouchers) ? db.stockVouchers : []);
  const canApprove = () => !window.PB_CLOUD_ROLE || ["admin", "manager"].includes(window.PB_CLOUD_ROLE);
  const who = () => window.PB_CLOUD_NAME || "Office";
  const mats = () => (Array.isArray(db.materials) ? db.materials : []);

  function matOf(x) {
    return mats().find((m) => m.id === x.materialId) ||
      mats().find((m) => String(m.name || "").trim().toLowerCase() === String(x.item || "").trim().toLowerCase() && String(m.unit || "") === String(x.unit || ""));
  }
  function matKey(x) { const m = matOf(x); return m ? "id:" + m.id : "n:" + String(x.item || "").trim().toLowerCase() + "|" + (x.unit || ""); }
  function voucherOf(x) { return x.voucherId ? vouchers().find((v) => v.id === x.voucherId) : null; }
  function supplierOf(x) {
    const v = voucherOf(x); if (v && v.supplier) return v.supplier;
    if (x.sourcePurchaseId) { const t = (db.transactions || []).find((t) => String(t.id) === String(x.sourcePurchaseId)); if (t && t.supplier) return t.supplier; }
    return x.supplier || "";
  }
  function typeOf(x) {
    const v = voucherOf(x);
    if (v) return x.reversal ? "Reversal" : v.kind === "GRN" ? "Stock In (GRN)" : "Stock Out (Issue)";
    if (x.movement) return { In: "Stock In", Out: "Stock Out", Wastage: "Wastage", Transfer: "Transfer", AdjIn: "Adjustment +", AdjOut: "Adjustment −", Return: "Return" }[x.movement] || x.movement;
    if (x.sourcePurchaseId) return "Purchase Receipt";
    if (x.sourceReportId) return x.direction === "In" ? "Site Receipt (Foreman)" : "Site Use (Foreman)";
    return x.direction === "In" ? "Stock In" : "Stock Out";
  }
  const rateMap = () => {
    const r = new Map();
    (db.stock || []).forEach((x) => { if (Number(x.rate) > 0 && x.direction === "In") { const k = matKey(x), o = r.get(k) || { q: 0, a: 0 }; o.q += Number(x.qty) || 0; o.a += (Number(x.qty) || 0) * Number(x.rate); r.set(k, o); } });
    try { purchasedMaterialRows().forEach((p) => { const k = matKey({ item: p.item, unit: p.unit }), o = r.get(k) || { q: 0, a: 0 }; o.q += p.qty; o.a += p.amount; r.set(k, o); }); } catch (e) {}
    return (k) => { const o = r.get(k); return o && o.q ? o.a / o.q : 0; };
  };

  function baseRows() {
    let arr = pfilter(db.stock || []).filter((x) => matchBuilding({ building: stockBld(x) }, stockBuildingFilter));
    arr = arr.map((x, i) => Object.assign(Object.create(null), x, { _seq: i, _ref: x }));
    if (F.mat) arr = arr.filter((x) => matKey(x) === F.mat);
    if (F.cat) arr = arr.filter((x) => (matOf(x)?.category || "") === F.cat);
    if (F.sup) arr = arr.filter((x) => supplierOf(x) === F.sup);
    if (F.type) arr = arr.filter((x) => typeOf(x) === F.type);
    return arr;
  }
  const range = () => C().periodRange(F.period, today(), F.from, F.to);
  const inRange = (d, r) => (!r.from || d >= r.from) && (!r.to || d <= r.to);

  /* ---------- filters bar ---------- */
  function filterBar() {
    const all = pfilter(db.stock || []);
    const cats = [...new Set(mats().map((m) => m.category).filter(Boolean))].sort();
    const sups = [...new Set(all.map(supplierOf).filter(Boolean))].sort();
    const types = [...new Set(all.map(typeOf))].sort();
    const matOpts = mats().map((m) => [`id:${m.id}`, m.name + " (" + m.unit + ")"]);
    const o = (val, list) => list.map(([v, l]) => `<option value="${esc(v)}" ${val === v ? "selected" : ""}>${esc(l)}</option>`).join("");
    const periods = [["today", "Today"], ["month", "This Month"], ["lastMonth", "Last Month"], ["3m", "Last 3 Months"], ["6m", "Last 6 Months"], ["year", "This Year"], ["lastYear", "Last Year"], ["custom", "Custom Range"], ["all", "All History"]];
    return `<div class="sp-filters">
      <select data-f="period" class="select">${o(F.period, periods)}</select>
      ${F.period === "custom" ? `<input type="date" data-f="from" value="${esc(F.from)}"><input type="date" data-f="to" value="${esc(F.to)}">` : ""}
      <select data-f="mat" class="select"><option value="">All materials</option>${o(F.mat, matOpts)}</select>
      <select data-f="cat" class="select"><option value="">All categories</option>${o(F.cat, cats.map((c) => [c, c]))}</select>
      <select data-f="sup" class="select"><option value="">All suppliers</option>${o(F.sup, sups.map((c) => [c, c]))}</select>
      <select data-f="type" class="select"><option value="">All transaction types</option>${o(F.type, types.map((c) => [c, c]))}</select>
      ${F.mat || F.cat || F.sup || F.type || F.period !== "all" ? `<button type="button" class="btn small" data-f-reset>Clear</button>` : ""}
      <span class="sp-range muted">${(() => { const r = range(); return r.from || r.to ? esc((r.from || "…") + " → " + (r.to || "…")) : "All history"; })()}</span>
    </div>`;
  }
  function bindFilters(root) {
    root.querySelectorAll("[data-f]").forEach((el) => (el.onchange = () => { F[el.dataset.f] = el.value; render(); }));
    const r = root.querySelector("[data-f-reset]"); if (r) r.onclick = () => { Object.assign(F, { period: "all", from: "", to: "", mat: "", cat: "", sup: "", type: "" }); render(); };
  }

  /* ---------- dashboard ---------- */
  function dashboard() {
    const rows = baseRows(), r = range(), rate = rateMap();
    const st = C().statement(rows, r, matKey);
    const all = new Map(); mats().forEach((m) => all.set("id:" + m.id, m));
    st.forEach((s) => { if (!all.has(s.key)) all.set(s.key, null); });
    const lines = [...all.entries()].map(([k, m]) => {
      const s = st.find((x) => x.key === k) || { opening: 0, received: 0, returned: 0, adjIn: 0, transferIn: 0, issued: 0, damaged: 0, adjOut: 0, transferOut: 0, closing: 0 };
      const recv = s.received + s.returned + s.adjIn + s.transferIn, iss = s.issued + s.damaged + s.adjOut + s.transferOut;
      const min = Number(m?.minStock || 0), avail = s.closing;
      const status = avail <= 0 ? "Out of stock" : min > 0 && avail <= min ? "Low stock" : "In stock";
      return { k, code: m?.code || "", name: m?.name || s.item, cat: m?.category || "", unit: m?.unit || s.unit, opening: s.opening, recv, iss, avail, value: Math.max(0, avail) * rate(k), status, hasRows: st.some((x) => x.key === k) };
    }).filter((l) => (!F.mat || l.k === F.mat) && (!F.cat || l.cat === F.cat) && (!(F.sup || F.type) || l.hasRows)).sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const T = lines.reduce((a, l) => ({ avail: a.avail + Math.max(0, l.avail), recv: a.recv + l.recv, iss: a.iss + l.iss, value: a.value + l.value, low: a.low + (l.status !== "In stock" ? 1 : 0) }), { avail: 0, recv: 0, iss: 0, value: 0, low: 0 });
    const pend = vouchers().filter((v) => v.status === "Pending" && (!selectedProject || v.projectId === selectedProject)).length;
    const card = (cls, l, v, s) => `<div class="sp-kpi ${cls}"><small>${l}</small><strong>${v}</strong><span>${s}</span></div>`;
    window._spDash = lines;
    return `<div class="sp-kpis">${card("n", "Total Material Types", lines.length, "in this view")}${card("b", "Total Available Stock", fmt(T.avail), "qty on hand (all units)")}${card("g", "Total Stock In", fmt(T.recv), "qty in period")}${card("r", "Total Stock Out", fmt(T.iss), "qty in period")}${card("v", "Total Stock Value", money(T.value), "on hand × avg rate")}${card("a", "Low Stock Items", T.low, pend ? pend + " voucher(s) awaiting approval" : "at or below minimum")}</div>
    <section class="panel sp-panel"><div class="toolbar"><h3 style="margin:0">Material-wise Stock Summary</h3><div><button class="btn small" onclick="SPX.csv('dash')">⬇ Excel (CSV)</button> <button class="btn small" onclick="SPX.print('dash')">🖨 Print / PDF</button></div></div>
    <div class="tablewrap"><table class="table sp-table"><thead><tr><th>Code</th><th>Material</th><th>Category</th><th>Unit</th><th class="n">Opening</th><th class="n">Received</th><th class="n">Issued</th><th class="n">Available</th><th class="n">Stock Value</th><th>Status</th></tr></thead><tbody>${lines.map((l) => `<tr><td>${esc(l.code || "—")}</td><td><b>${esc(l.name)}</b></td><td>${esc(l.cat || "—")}</td><td>${esc(l.unit)}</td><td class="n">${fmt(l.opening)}</td><td class="n sp-in">${fmt(l.recv)}</td><td class="n sp-out">${fmt(l.iss)}</td><td class="n"><b>${fmt(l.avail)}</b></td><td class="n">${money(l.value)}</td><td><span class="pill ${l.status === "In stock" ? "green" : l.status === "Low stock" ? "amber" : "red"}">${l.status}</span></td></tr>`).join("") || '<tr><td colspan="10" class="empty">No materials or stock movements match these filters.</td></tr>'}</tbody></table></div></section>`;
  }

  /* ---------- ledger ---------- */
  function ledgerRows() {
    const r = range();
    return C().ledger(baseRows(), matKey).filter((l) => inRange(String(l.row.date || ""), r)).reverse();
  }
  function ledgerTab() {
    const L = ledgerRows(), rate = rateMap();
    window._spLedger = L;
    return `<section class="panel sp-panel"><div class="toolbar"><h3 style="margin:0">Complete Stock Movement History</h3><div><input id="spLedgerSearch" type="search" placeholder="Search…" style="max-width:200px"> <button class="btn small" onclick="SPX.csv('ledger')">⬇ Excel (CSV)</button> <button class="btn small" onclick="SPX.print('ledger')">🖨 Print / PDF</button></div></div>
    <p class="muted" style="margin:0 0 6px">Running balance is per material for the selected project/site. Click any row for full details.</p>
    <div class="tablewrap"><table class="table sp-table"><thead><tr><th>Date</th><th>Txn ID</th><th>Voucher</th><th>Material</th><th>Type</th><th>Supplier / Source</th><th>Project / Site</th><th class="n">In</th><th class="n">Out</th><th class="n">Balance</th><th>Unit</th><th class="n">Rate</th><th class="n">Value</th><th>Created</th><th>Approved</th></tr></thead><tbody id="spLedgerRows">${L.map((l) => { const x = l.row, v = voucherOf(x), rt = Number(x.rate) || rate(matKey(x)), q = Number(x.qty) || 0; return `<tr class="sp-click" data-sid="${esc(x.id)}"><td>${esc(x.date || "—")}</td><td><small>${esc(String(x.id || "").slice(0, 8))}</small></td><td>${esc(v?.no || "—")}</td><td><b>${esc(x.item)}</b></td><td>${esc(typeOf(x))}</td><td>${esc(supplierOf(x) || (x.sourceReportId ? "Foreman report" : x.note || "—"))}</td><td>${esc(projectName(x.projectId))}${stockBld(x) ? "<br><small class='muted'>" + esc(stockBld(x)) + "</small>" : ""}</td><td class="n sp-in">${x.direction === "In" ? fmt(q) : ""}</td><td class="n sp-out">${x.direction !== "In" ? fmt(q) : ""}</td><td class="n"><b>${fmt(l.balance)}</b></td><td>${esc(x.unit)}</td><td class="n">${rt ? fmt(rt) : "—"}</td><td class="n">${rt ? money(rt * q) : "—"}</td><td>${esc(v?.createdBy || x.enteredBy || "—")}</td><td>${esc(v?.approvedBy || "—")}</td></tr>`; }).join("") || '<tr><td colspan="15" class="empty">No movements in this period.</td></tr>'}</tbody></table></div></section>`;
  }
  function rowDetail(sid) {
    const x = (db.stock || []).find((r) => String(r.id) === String(sid)); if (!x) return;
    const v = voucherOf(x), bal = stockMaterialBalance(x.projectId, matOf(x) || { id: "", name: x.item, unit: x.unit });
    const kv = (k, val) => val || val === 0 ? `<div class="sp-kv"><small>${k}</small><b>${esc(val)}</b></div>` : "";
    openModal("Stock Transaction Details", `<div class="sp-kvgrid">${kv("Date", x.date)}${kv("Transaction ID", x.id)}${kv("Voucher", v?.no)}${kv("Type", typeOf(x))}${kv("Material", x.item + " (" + x.unit + ")")}${kv(x.direction === "In" ? "Quantity in" : "Quantity out", fmt(x.qty) + " " + x.unit)}${kv("Came from (supplier / source)", supplierOf(x) || (x.sourceReportId ? "Foreman site report" : x.source || ""))}${kv("Sent to / Project", projectName(x.projectId))}${kv("Building / Block", stockBld(x))}${kv("Floor / Room", [x.floor, x.room].filter(Boolean).join(" / "))}${kv("Unit rate", Number(x.rate) ? fmt(x.rate) : "")}${kv("Current project balance", fmt(bal) + " " + x.unit)}${kv("PO / Invoice / Challan", v ? [v.po, v.invoice, v.challan].filter(Boolean).join(" · ") : "")}${kv("Purpose", v?.purpose)}${kv("Requested by", v?.requestedBy)}${kv("Received by", v?.receivedBy)}${kv("Issued by", v?.issuedBy)}${kv("Created by", v?.createdBy || x.enteredBy)}${kv("Approved by", v?.approvedBy)}${kv("Note", x.note)}</div>${v ? `<div style="margin-top:10px"><button class="btn small" onclick="closeModal();SPX.view('${esc(v.id)}')">Open voucher ${esc(v.no)}</button></div>` : ""}`, () => true);
    document.getElementById("modalSave").style.display = "none";
  }

  /* ---------- vouchers ---------- */
  function voucherList(kind) {
    const list = vouchers().filter((v) => v.kind === kind && (!selectedProject || v.projectId === selectedProject)).filter((v) => inRange(v.date, range())).sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.no).localeCompare(String(a.no)));
    const isG = kind === "GRN", title = isG ? "Stock In — Material Receive (GRN)" : "Stock Out — Material Issue";
    const total = (v) => v.lines.reduce((a, l) => a + (Number(l.qty) || 0) * (Number(l.rate) || 0), 0);
    const cls = { Pending: "amber", Approved: "green", Cancelled: "red" };
    return `<section class="panel sp-panel"><div class="toolbar"><h3 style="margin:0">${title}</h3><button class="btn primary" onclick="SPX.form('${kind}')">＋ New ${isG ? "Receiving Voucher" : "Issue Voucher"}</button></div>
    <p class="muted" style="margin:0 0 6px">${isG ? "Stock is added only after the voucher is approved." : "Stock is deducted only after approval. You cannot issue more than is available."}${canApprove() ? "" : " Only Admin / Manager can approve."}</p>
    <div class="tablewrap"><table class="table sp-table"><thead><tr><th>Date</th><th>Voucher</th><th>Project / Site</th><th>${isG ? "Supplier" : "Purpose"}</th><th>Materials</th><th class="n">${isG ? "Amount" : "Lines"}</th><th>Status</th><th>Action</th></tr></thead><tbody>${list.map((v) => `<tr><td>${esc(v.date)}</td><td><b>${esc(v.no)}</b></td><td>${esc(projectName(v.projectId))}${v.building ? "<br><small class='muted'>" + esc(v.building) + "</small>" : ""}</td><td>${esc((isG ? v.supplier : v.purpose) || "—")}</td><td>${esc(v.lines.map((l) => l.item + " " + fmt(l.qty) + " " + l.unit).join(", "))}</td><td class="n">${isG ? money(total(v)) : v.lines.length}</td><td><span class="pill ${cls[v.status] || ""}">${esc(v.status)}</span></td><td style="white-space:nowrap"><button class="btn small" onclick="SPX.view('${esc(v.id)}')">View</button>${v.status === "Pending" && canApprove() ? ` <button class="btn small primary" onclick="SPX.approve('${esc(v.id)}')">Approve</button>` : ""}${v.status !== "Cancelled" ? ` <button class="btn small" onclick="SPX.cancel('${esc(v.id)}')">Cancel</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="8" class="empty">No ${isG ? "receiving" : "issue"} vouchers in this period.</td></tr>`}</tbody></table></div></section>`;
  }

  function lineRow(kind, l) {
    const opts = mats().map((m) => `<option value="${esc(m.id)}" ${l && l.materialId === m.id ? "selected" : ""}>${esc(m.name)}${m.code ? " · " + esc(m.code) : ""} (${esc(m.unit)})</option>`).join("");
    return `<tr class="sp-line"><td><select class="select sp-l-mat"><option value="">Select material</option>${opts}</select></td>${kind === "ISSUE" ? '<td class="n sp-l-av">—</td>' : ""}<td><input type="number" class="sp-l-qty" min="0" step="any" value="${l ? esc(l.qty) : ""}"></td><td class="sp-l-unit">—</td>${kind === "GRN" ? `<td><input type="number" class="sp-l-rate" min="0" step="any" value="${l ? esc(l.rate || "") : ""}"></td><td class="n sp-l-amt">—</td>` : ""}<td><button type="button" class="btn small sp-l-del" title="Remove">✕</button></td></tr>`;
  }

  function form(kind) {
    if (!mats().length) { toast("Add a material first in Material Master"); try { openStockMaterial(); } catch (e) {} return; }
    const isG = kind === "GRN";
    const no = C().nextNo(isG ? "GRN" : "ISS", vouchers().map((v) => v.no));
    const pOpts = db.projects.map((p) => `<option value="${esc(p.id)}" ${selectedProject === p.id ? "selected" : ""}>${esc(p.name)}</option>`).join("");
    const f = (lbl, idn, extra = "", full) => `<div class="field${full ? " full" : ""}"><label>${lbl}</label><input id="${idn}" ${extra}></div>`;
    const head = isG
      ? `${f("Receive date *", "spDate", `type="date" value="${today()}"`)}${f("GRN number", "spNo", `value="${no}" disabled`)}${f("Supplier name *", "spSup", 'list="spSupList" placeholder="Supplier"')}${f("Purchase order ref.", "spPo")}${f("Supplier invoice", "spInv")}${f("Challan number", "spCh")}`
      : `${f("Issue date *", "spDate", `type="date" value="${today()}"`)}${f("Issue voucher number", "spNo", `value="${no}" disabled`)}${f("Floor", "spFloor")}${f("Room", "spRoom")}${f("Purpose / work category", "spPurpose", 'placeholder="e.g. Block work"')}<div class="field"><label>BOQ reference</label><select id="spBoq" class="select"><option value="">— none —</option></select></div>`;
    const people = isG
      ? `${f("Received by", "spRecv", `value="${esc(who())}"`)}${f("Attachments (file names kept)", "spAtt", 'type="file" multiple')}`
      : `${f("Requested by", "spReq")}${f("Issued by", "spIss", `value="${esc(who())}"`)}${f("Received by (site)", "spRecv")}`;
    const sups = [...new Set([...(db.suppliers || []).map((s) => s.name), ...(db.transactions || []).map((t) => t.supplier)].filter(Boolean))];
    openModal(isG ? "New Material Receiving Voucher (GRN)" : "New Material Issue Voucher", `<div class="formgrid">
      <div class="field"><label>Project / Site *</label><select id="spProj" class="select"><option value="">Select project</option>${pOpts}</select></div>
      <div class="field"><label>Warehouse / Building</label><select id="spBld" class="select"></select></div>
      ${head}${people}
      <div class="field full"><label>Remarks</label><input id="spRem" maxlength="500"></div></div>
      <datalist id="spSupList">${sups.map((s) => `<option value="${esc(s)}">`).join("")}</datalist>
      <h4 style="margin:12px 0 6px">Materials</h4>
      <div class="tablewrap"><table class="table sp-lines"><thead><tr><th>Material</th>${isG ? "" : '<th class="n">Available</th>'}<th>Quantity</th><th>Unit</th>${isG ? '<th>Unit rate</th><th class="n">Total</th>' : ""}<th></th></tr></thead><tbody id="spLines">${lineRow(kind)}</tbody></table></div>
      <div class="toolbar" style="margin-top:6px"><button type="button" class="btn small" id="spAdd">＋ Add material line</button><b id="spTotal"></b></div>
      <p class="muted" style="margin-top:6px">Saved as <b>Pending</b>. Stock changes only after Admin / Manager approves.</p>`, () => saveVoucher(kind));
    const box = document.querySelector("#modal .modalbox"); if (box) box.style.width = "min(980px,100%)";
    const tb = document.getElementById("spLines");
    const fillBld = () => { const p = document.getElementById("spProj").value, b = p ? projectBuildings(p) : []; document.getElementById("spBld").innerHTML = `<option value="">Main store (no building)</option>` + b.map((x) => `<option ${x === stockBuildingFilter ? "selected" : ""}>${esc(x)}</option>`).join("");
      const boq = document.getElementById("spBoq"); if (boq) boq.innerHTML = '<option value="">— none —</option>' + (db.boq || []).filter((x) => x.projectId === p).map((x) => `<option value="${esc(x.id)}">${esc((x.code || x.boqId || "") + " " + (x.description || x.item || ""))}</option>`).join(""); };
    const refresh = () => {
      const p = document.getElementById("spProj").value; let tot = 0;
      tb.querySelectorAll(".sp-line").forEach((tr) => {
        const m = mats().find((x) => x.id === tr.querySelector(".sp-l-mat").value), q = Number(tr.querySelector(".sp-l-qty").value) || 0;
        tr.querySelector(".sp-l-unit").textContent = m ? m.unit : "—";
        const av = tr.querySelector(".sp-l-av"); if (av) { const a = m && p ? stockMaterialBalance(p, m) : null; av.textContent = a === null ? "—" : fmt(a); av.classList.toggle("sp-out", a !== null && q > a); }
        const rt = tr.querySelector(".sp-l-rate"); if (rt) { const amt = q * (Number(rt.value) || 0); tot += amt; tr.querySelector(".sp-l-amt").textContent = amt ? money(amt) : "—"; }
      });
      document.getElementById("spTotal").textContent = isG ? "Total: " + money(tot) : "";
    };
    document.getElementById("spProj").onchange = () => { fillBld(); refresh(); };
    tb.oninput = refresh; tb.onchange = refresh;
    tb.onclick = (e) => { if (e.target.closest(".sp-l-del")) { if (tb.querySelectorAll(".sp-line").length > 1) e.target.closest("tr").remove(); refresh(); } };
    document.getElementById("spAdd").onclick = () => { tb.insertAdjacentHTML("beforeend", lineRow(kind)); refresh(); };
    fillBld(); refresh();
  }

  let saving = false;
  function saveVoucher(kind) {
    if (saving) return false;
    const g = (i) => (document.getElementById(i)?.value || "").trim();
    const isG = kind === "GRN", projectId = g("spProj"), date = g("spDate");
    if (!projectId || !date) { toast("Project and date are required"); return false; }
    if (isG && !g("spSup")) { toast("Supplier name is required"); return false; }
    const lines = [];
    for (const tr of document.querySelectorAll("#spLines .sp-line")) {
      const m = mats().find((x) => x.id === tr.querySelector(".sp-l-mat").value), q = Number(tr.querySelector(".sp-l-qty").value);
      if (!m && !q) continue;
      if (!m || !Number.isFinite(q) || q <= 0) { toast("Each line needs a material and a quantity above zero"); return false; }
      const rate = Number(tr.querySelector(".sp-l-rate")?.value || 0);
      if (rate < 0) { toast("Rate cannot be negative"); return false; }
      lines.push({ materialId: m.id, item: m.name, unit: m.unit, qty: q, rate: rate || 0 });
    }
    if (!lines.length) { toast("Add at least one material line"); return false; }
    if (!isG) {
      const short = shortages(projectId, lines);
      if (short) { toast(short); return false; }
    }
    const att = document.getElementById("spAtt"); const files = att && att.files ? [...att.files].map((f) => f.name) : [];
    saving = true;
    try {
      const no = C().nextNo(isG ? "GRN" : "ISS", vouchers().map((v) => v.no));
      vouchers().push({ id: id(), kind, no, date, projectId, building: g("spBld"), floor: g("spFloor"), room: g("spRoom"), supplier: g("spSup"), po: g("spPo"), invoice: g("spInv"), challan: g("spCh"), purpose: g("spPurpose"), boqId: g("spBoq"), requestedBy: g("spReq"), issuedBy: g("spIss"), receivedBy: g("spRecv"), attachments: files, remarks: g("spRem"), lines, status: "Pending", createdBy: who(), createdAt: new Date().toISOString() });
      save(); render(); toast(no + " saved — waiting for approval");
    } finally { setTimeout(() => (saving = false), 600); }
    return true;
  }
  function shortages(projectId, lines) {
    const avail = {}; lines.forEach((l) => { const m = mats().find((x) => x.id === l.materialId); avail[l.materialId] = stockMaterialBalance(projectId, m); });
    const s = C().issueShortages(lines.map((l) => ({ key: l.materialId, qty: l.qty })), avail);
    if (!s.length) return "";
    const m = mats().find((x) => x.id === s[0].key);
    return `Not enough ${m?.name || "stock"}: need ${fmt(s[0].need)}, only ${fmt(s[0].available)} ${m?.unit || ""} available`;
  }
  function pushRows(v, reversal) {
    v.lines.forEach((l, i) => {
      const dirIn = (v.kind === "GRN") !== !!reversal;
      db.stock.push({ id: id(), date: reversal ? today() : v.date, projectId: v.projectId, materialId: l.materialId, item: l.item, unit: l.unit, direction: dirIn ? "In" : "Out", qty: Number(l.qty), rate: Number(l.rate) || undefined, source: reversal ? "Voucher Reversal" : v.kind === "GRN" ? "GRN" : "Material Issue", voucherId: v.id, voucherLine: i, ...(reversal ? { reversal: true } : {}), ...(v.building ? { building: v.building } : {}), ...(v.floor ? { floor: v.floor } : {}), ...(v.room ? { room: v.room } : {}), enteredBy: v.createdBy, note: (reversal ? "Reversal of " : "") + v.no + (v.remarks ? " · " + v.remarks : "") });
    });
  }
  function approve(vid) {
    const v = vouchers().find((x) => x.id === vid);
    if (!v || v.status !== "Pending") { toast("This voucher is not waiting for approval"); render(); return; }
    if (!canApprove()) { toast("Only Admin / Manager can approve"); return; }
    if ((db.stock || []).some((x) => x.voucherId === v.id && !x.reversal)) { v.status = "Approved"; save(); render(); toast("Already posted to stock"); return; }
    if (v.kind === "ISSUE") { const s = shortages(v.projectId, v.lines); if (s) { toast(s); return; } }
    if (!confirm(`Approve ${v.no}? Stock will be ${v.kind === "GRN" ? "added" : "deducted"} now.`)) return;
    pushRows(v, false);
    Object.assign(v, { status: "Approved", approvedBy: who(), approvedAt: new Date().toISOString() });
    save(); render(); toast(v.no + " approved — stock updated");
  }
  function cancel(vid) {
    const v = vouchers().find((x) => x.id === vid); if (!v || v.status === "Cancelled") return;
    if (v.status === "Approved") {
      if (!canApprove()) { toast("Only Admin / Manager can cancel an approved voucher"); return; }
      if ((db.stock || []).some((x) => x.voucherId === v.id && x.reversal)) { toast("Already reversed"); return; }
      if (v.kind === "GRN") { const s = shortages(v.projectId, v.lines); if (s) { toast("Cannot reverse: material already used. " + s); return; } }
      const reason = prompt(`Cancel approved ${v.no}? A reversal entry will be posted (nothing is deleted). Reason:`); if (!reason) return;
      pushRows(v, true); Object.assign(v, { status: "Cancelled", cancelReason: reason, cancelledBy: who(), cancelledAt: new Date().toISOString() });
    } else {
      const reason = prompt(`Cancel pending ${v.no}? Reason:`); if (!reason) return;
      Object.assign(v, { status: "Cancelled", cancelReason: reason, cancelledBy: who(), cancelledAt: new Date().toISOString() });
    }
    save(); render(); toast(v.no + " cancelled");
  }
  function view(vid) {
    const v = vouchers().find((x) => x.id === vid); if (!v) return;
    const isG = v.kind === "GRN", kv = (k, val) => val ? `<div class="sp-kv"><small>${k}</small><b>${esc(val)}</b></div>` : "";
    const tot = v.lines.reduce((a, l) => a + l.qty * (l.rate || 0), 0);
    openModal((isG ? "Receiving Voucher " : "Issue Voucher ") + v.no, `<div class="sp-kvgrid">${kv("Status", v.status)}${kv("Date", v.date)}${kv("Project", projectName(v.projectId))}${kv("Warehouse / Building", v.building || "Main store")}${kv("Floor / Room", [v.floor, v.room].filter(Boolean).join(" / "))}${kv("Supplier", v.supplier)}${kv("PO", v.po)}${kv("Supplier invoice", v.invoice)}${kv("Challan", v.challan)}${kv("Purpose", v.purpose)}${kv("BOQ", (() => { const b = (db.boq || []).find((x) => x.id === v.boqId); return b ? (b.code || "") + " " + (b.description || b.item || "") : ""; })())}${kv("Requested by", v.requestedBy)}${kv("Issued by", v.issuedBy)}${kv("Received by", v.receivedBy)}${kv("Created by", v.createdBy)}${kv("Approved by", v.approvedBy)}${kv("Attachments", (v.attachments || []).join(", "))}${kv("Remarks", v.remarks)}${kv("Cancel reason", v.cancelReason)}</div>
      <table class="table sp-table" style="margin-top:10px"><thead><tr><th>Material</th><th class="n">Qty</th><th>Unit</th>${isG ? '<th class="n">Rate</th><th class="n">Total</th>' : ""}</tr></thead><tbody>${v.lines.map((l) => `<tr><td>${esc(l.item)}</td><td class="n">${fmt(l.qty)}</td><td>${esc(l.unit)}</td>${isG ? `<td class="n">${fmt(l.rate)}</td><td class="n">${money(l.qty * (l.rate || 0))}</td>` : ""}</tr>`).join("")}${isG ? `<tr><td colspan="4"><b>Total</b></td><td class="n"><b>${money(tot)}</b></td></tr>` : ""}</tbody></table>
      <div style="margin-top:10px"><button class="btn small" onclick="SPX.printVoucher('${esc(v.id)}')">🖨 Print voucher</button></div>`, () => true);
    document.getElementById("modalSave").style.display = "none";
  }

  /* ---------- export / print ---------- */
  function table(kind) {
    if (kind === "dash") return { title: "Material-wise Stock Summary", head: ["Code", "Material", "Category", "Unit", "Opening", "Received", "Issued", "Available", "Stock Value (AED)", "Status"], rows: (window._spDash || []).map((l) => [l.code, l.name, l.cat, l.unit, fmt(l.opening), fmt(l.recv), fmt(l.iss), fmt(l.avail), fmt(Math.round(l.value)), l.status]) };
    return { title: "Stock Movement History", head: ["Date", "Voucher", "Material", "Type", "Supplier / Source", "Project", "Site", "In", "Out", "Balance", "Unit"], rows: (window._spLedger || []).map((l) => { const x = l.row; return [x.date, voucherOf(x)?.no || "", x.item, typeOf(x), supplierOf(x), projectName(x.projectId), stockBld(x), x.direction === "In" ? fmt(x.qty) : "", x.direction !== "In" ? fmt(x.qty) : "", fmt(l.balance), x.unit]; }) };
  }
  function csv(kind) {
    const t = table(kind), q = (v) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
    const blob = new Blob(["\ufeff" + [t.head, ...t.rows].map((r) => r.map(q).join(",")).join("\r\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = t.title.toLowerCase().replace(/\W+/g, "-") + "-" + today() + ".csv"; document.body.appendChild(a); a.click(); a.remove(); toast("Excel (CSV) downloaded");
  }
  function printHtml(title, inner) {
    const co = db.settings?.companyName || db.settings?.company || "PUREBUILD CONSTRUCTION ERP";
    const r = range(), sub = [selectedProject ? projectName(selectedProject) : "All projects", stockBuildingFilter || "", r.from || r.to ? (r.from || "…") + " → " + (r.to || "…") : "All history"].filter(Boolean).join(" · ");
    const html = `<!doctype html><html><head><title>${esc(title)}</title><style>@page{size:A4 landscape;margin:12mm}body{font:11px Arial,sans-serif;color:#0f172a}h1{font-size:16px;margin:0;color:#1e3a8a}h2{font-size:13px;margin:2px 0 8px}table{width:100%;border-collapse:collapse}th{background:#1e3a8a;color:#fff;text-align:left}th,td{border:1px solid #cbd5e1;padding:4px 6px}thead{display:table-header-group}.sig{display:flex;justify-content:space-between;margin-top:40px}.sig div{border-top:1px solid #64748b;width:28%;text-align:center;padding-top:4px}</style></head><body><h1>${esc(co)}</h1><h2>${esc(title)}</h2><div style="margin-bottom:8px;color:#475569">${esc(sub)} · Printed ${esc(today())}</div>${inner}<div class="sig"><div>Prepared By</div><div>Checked By</div><div>Approved By</div></div></body></html>`;
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(html); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 2000); }, 300);
  }
  function print(kind) { const t = table(kind); printHtml(t.title, `<table><thead><tr>${t.head.map((h) => "<th>" + esc(h) + "</th>").join("")}</tr></thead><tbody>${t.rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("")}</tbody></table>`); }
  function printVoucher(vid) {
    const v = vouchers().find((x) => x.id === vid); if (!v) return; const isG = v.kind === "GRN";
    printHtml((isG ? "Goods Receiving Note " : "Material Issue Voucher ") + v.no + " — " + v.status, `<p>Date: <b>${esc(v.date)}</b> · Project: <b>${esc(projectName(v.projectId))}</b> · Warehouse: <b>${esc(v.building || "Main store")}</b>${isG ? ` · Supplier: <b>${esc(v.supplier)}</b> · PO: ${esc(v.po || "—")} · Invoice: ${esc(v.invoice || "—")} · Challan: ${esc(v.challan || "—")}` : ` · Floor/Room: ${esc([v.floor, v.room].filter(Boolean).join(" / ") || "—")} · Purpose: ${esc(v.purpose || "—")}`}</p><table><thead><tr><th>#</th><th>Material</th><th>Qty</th><th>Unit</th>${isG ? "<th>Rate</th><th>Total</th>" : ""}</tr></thead><tbody>${v.lines.map((l, i) => `<tr><td>${i + 1}</td><td>${esc(l.item)}</td><td>${fmt(l.qty)}</td><td>${esc(l.unit)}</td>${isG ? `<td>${fmt(l.rate)}</td><td>${money(l.qty * (l.rate || 0))}</td>` : ""}</tr>`).join("")}</tbody></table><p>Created by: ${esc(v.createdBy || "—")} · Approved by: ${esc(v.approvedBy || "—")} · ${isG ? "Received by" : "Issued by"}: ${esc((isG ? v.receivedBy : v.issuedBy) || "—")}${v.remarks ? " · Remarks: " + esc(v.remarks) : ""}</p>`);
  }

  window.SPX = { form, approve, cancel, view, csv, print, printVoucher, detail: rowDetail };

  /* ---------- hook into the existing page ---------- */
  const css = document.createElement("style");
  css.textContent = `.stock-tabs.sp-nav{background:#0f2747;border-color:#0f2747}.stock-tabs.sp-nav button{color:#cbd5e1}.stock-tabs.sp-nav button:hover{background:rgba(255,255,255,.1);color:#fff}.stock-tabs.sp-nav button.active{background:#fff;color:#0f2747}.stock-tabs.sp-nav em{background:#f59e0b;color:#111;border-radius:9px;padding:0 6px;font-style:normal;font-size:11px}
  .sp-filters{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:0 0 10px;padding:8px;border:1px solid var(--line,#e3e8ef);border-radius:10px;background:var(--panel,#fff)}.sp-filters .select,.sp-filters input{min-height:34px;padding-top:4px;padding-bottom:4px;font-size:12.5px;max-width:190px;line-height:1.3}.sp-range{font-size:12px;margin-left:auto}
  .sp-kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-bottom:10px}.sp-kpi{border-radius:12px;padding:10px 12px;background:var(--panel,#fff);border:1px solid var(--line,#e3e8ef);border-top:4px solid #1e3a8a}.sp-kpi small{display:block;color:var(--muted,#64748b);font-weight:600;font-size:11.5px}.sp-kpi strong{display:block;font-size:20px;color:inherit;margin:2px 0}.sp-kpi span{font-size:11px;color:var(--muted,#64748b)}.sp-kpi.g{border-top-color:#16a34a}.sp-kpi.g strong{color:#22c55e}.sp-kpi.r{border-top-color:#ea580c}.sp-kpi.r strong{color:#f97316}.sp-kpi.a{border-top-color:#f59e0b}.sp-kpi.v{border-top-color:#0ea5e9}
  .sp-table th{background:#0f2747;color:#fff;font-size:12px;white-space:nowrap}.sp-table td{font-size:12.5px}.sp-table .n,.sp-lines .n{text-align:right}.sp-in{color:#15803d;font-weight:600}.sp-out{color:#c2410c;font-weight:600}.sp-click{cursor:pointer}.sp-click:hover td{background:rgba(30,58,138,.06)}
  .sp-lines input,.sp-lines select{width:100%;min-width:90px}.sp-kvgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.sp-kv{padding:8px;border:1px solid var(--line,#e3e8ef);border-radius:8px}.sp-kv small{display:block;color:var(--muted,#64748b);font-size:11px}.sp-kv b{word-break:break-word}
  @media(max-width:900px){.sp-kpis{grid-template-columns:repeat(2,1fr)}.sp-kvgrid{grid-template-columns:1fr 1fr}.sp-range{margin-left:0}}`;
  document.head.appendChild(css);

  const TABS = [["sdash", "Stock Dashboard", "dashboard"], ["catalog", "Material Master", "stock"], ["grn", "Stock In (GRN)", "income"], ["issue", "Stock Out (Issue)", "progress"], ["ledger", "Movement History", "history"], ["project", "Project Stock", "projects"], ["overview", "Charts", "dashboard"], ["receipts", "Purchase Receipts", "income"], ["compare", "Purchase vs Warehouse", "alert"]];
  const orig = window.stock;
  if (typeof orig !== "function") return;
  window.stock = function () {
    if (!window.stockTab || window.stockTab === "history") window.stockTab = window.stockTab === "history" ? "ledger" : "sdash";
    const T = window.stockTab, mine = NEW_TABS.includes(T);
    orig.apply(this, arguments);
    const view = document.getElementById("view"), nav = view && view.querySelector(".stock-tabs");
    if (!nav) return;
    const pend = (k) => vouchers().filter((v) => v.kind === k && v.status === "Pending" && (!selectedProject || v.projectId === selectedProject)).length;
    const badge = { grn: pend("GRN"), issue: pend("ISSUE") };
    nav.classList.add("sp-nav");
    const tools = nav.querySelector(".stock-tab-tools");
    nav.querySelectorAll(":scope > button").forEach((b) => b.remove());
    nav.insertAdjacentHTML("afterbegin", TABS.map(([k, l, ic]) => `<button type="button" class="${T === k ? "active" : ""}" onclick="stockGo('${k}')">${typeof icon === "function" ? icon(ic) : ""}<span>${l}</span>${badge[k] ? ` <em>${badge[k]}</em>` : ""}</button>`).join(""));
    if (tools && mine) tools.style.display = "none";
    if (!mine) return;
    const body = view.querySelector(".stock-tab-body");
    if (!body) return;
    body.className = "stock-tab-body stock-tab-" + T;
    let html = "";
    try { html = T === "sdash" ? dashboard() : T === "grn" ? voucherList("GRN") : T === "issue" ? voucherList("ISSUE") : ledgerTab(); }
    catch (e) { console.error("stock-pro", e); html = '<div class="panel"><div class="empty">This section could not be shown. Your data is safe.</div></div>'; }
    body.innerHTML = filterBar() + html;
    bindFilters(body);
    const rows = body.querySelector("#spLedgerRows");
    if (rows) rows.onclick = (e) => { const tr = e.target.closest("tr[data-sid]"); if (tr) rowDetail(tr.dataset.sid); };
    const s = body.querySelector("#spLedgerSearch");
    if (s) s.oninput = () => { const q = s.value.toLowerCase().trim(); body.querySelectorAll("#spLedgerRows tr[data-sid]").forEach((r) => (r.style.display = !q || r.textContent.toLowerCase().includes(q) ? "" : "none")); };
  };
})();
