// Sales Payments & Receivables workspace (p77). Read-only views over db.payments / db.paymentAllocations / db.invoices /
// db.retentions / db.advances. Never changes saved records; Receive Payment reuses the existing receiveInvoicePayment().
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const D = () => (typeof db !== "undefined" ? db : window.db) || {};
  const SF = () => { try { return salesFilters; } catch (e) { return {}; } };
  const M = (n) => (typeof salesMoney === "function" ? salesMoney(n) : "AED " + (+n || 0).toFixed(2));
  const PN = (id) => (typeof projectName === "function" ? projectName(id) : id || "—");
  const OUT = (x) => salesInvoiceOutstanding(x);
  const ISSUED = (x) => (typeof salesInvoiceIsIssued === "function" ? salesInvoiceIsIssued(x) : !["Cancelled", "Void", "Rejected"].includes(x.status));
  const TODAY = () => new Date().toISOString().slice(0, 10);
  const r2 = (n) => Math.round((+n || 0) * 100) / 100;
  const daysPast = (d) => (d ? Math.floor((new Date(TODAY() + "T00:00:00") - new Date(d + "T00:00:00")) / 86400000) : 0);
  const BUCKETS = [["Current", -1e9, 0], ["1–30 Days", 1, 30], ["31–60 Days", 31, 60], ["61–90 Days", 61, 90], ["90+ Days", 91, 1e9]];
  const bucketOf = (inv) => { const d = inv.dueDate ? daysPast(inv.dueDate) : 0; return BUCKETS.findIndex((b) => d >= b[1] && d <= b[2]); };
  const isOverdue = (inv) => OUT(inv) > 0.001 && inv.dueDate && daysPast(inv.dueDate) > 0;
  const clientKey = (x) => x.clientId || "n:" + String(x.client || "Unknown").toLowerCase();

  // ---------- allocations (one source of truth per payment) ----------
  function allocsOf(p) {
    const d = D(), list = (d.paymentAllocations || []).filter((a) => a.paymentId === p.id);
    if (list.length) return list.map((a) => ({ invoiceId: a.invoiceId, amount: +a.amount || 0 }));
    if (p.invoiceId) return [{ invoiceId: p.invoiceId, amount: +(p.allocated != null ? p.allocated : p.amount) || 0 }];
    // legacy: find invoice payment lines that carry this payment id
    const out = [];
    (d.invoices || []).forEach((i) => (i.payments || []).forEach((l) => { if (l.id === p.id) out.push({ invoiceId: i.id, amount: +l.amount || 0 }); }));
    return out;
  }
  const allocated = (p) => r2(allocsOf(p).reduce((s, a) => s + a.amount, 0) || +p.allocated || 0);
  const unalloc = (p) => Math.max(0, r2((+p.amount || 0) - allocated(p)));
  const payStatus = (p) => { const a = allocated(p); return a <= 0.001 ? "Unallocated" : unalloc(p) > 0.009 ? "Partially Allocated" : "Allocated"; };
  const isCash = (m) => /cash/i.test(m || "");
  const invById = (id) => (D().invoices || []).find((i) => i.id === id);
  const uniqPayments = () => { const seen = new Set(); return (D().payments || []).filter((p) => { const k = p.id || p.reference; if (seen.has(k)) return false; seen.add(k); return true; }); };

  // ---------- print / csv ----------
  function printDoc(title, meta, kpis, body, landscape) {
    const st = D().settings || {}, co = st.companyName || "PURE_BUILD", now = new Date();
    const logo = st.companyLogo ? `<img src="${E(st.companyLogo)}" alt="">` : "";
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${E(title)}</title><style>
@page{size:A4 ${landscape ? "landscape" : "portrait"};margin:12mm 11mm 15mm;@bottom-right{content:"Page " counter(page) " of " counter(pages);font:9px Arial;color:#555}}
*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font:10.5px Arial,sans-serif;color:#111;margin:0}
.hd{display:flex;justify-content:space-between;border-bottom:2.5px solid #14213d;padding-bottom:8px;margin-bottom:10px}.hl{display:flex;gap:10px;align-items:center}.hl img{width:44px;height:44px;object-fit:contain}
.hl b{display:block;font-size:16px;color:#14213d}.hl small{color:#666;font-size:9.5px}.hr{text-align:right}.hr h1{margin:0 0 3px;font-size:14px;letter-spacing:1px;color:#14213d}.hr div{font-size:9.5px;line-height:1.5}
.ks{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}.k{border:1px solid #cfd6e2;border-left:4px solid #1d4ed8;border-radius:4px;padding:5px 9px}.k small{display:block;font-size:9px;color:#555;font-weight:700;text-transform:uppercase}.k b{font-size:13px}
h3{font-size:11px;color:#14213d;margin:10px 0 4px;text-transform:uppercase}table{width:100%;border-collapse:collapse;margin-bottom:8px}th{background:#14213d;color:#fff;font-size:9.5px;padding:5px 6px;text-align:left}
td{padding:4px 6px;border:1px solid #d9dee7}tbody tr:nth-child(even) td{background:#f6f8fb}.r{text-align:right;white-space:nowrap}thead{display:table-header-group}tr{break-inside:avoid}
tr.sub td{background:#eef1f6!important;font-weight:700}tr.grand td{background:#14213d!important;color:#fff;font-weight:800}tr.grp td{background:#e3eaf7!important;font-weight:700;break-after:avoid}
.sig{display:grid;grid-template-columns:repeat(3,1fr);gap:28px;margin-top:34px;break-inside:avoid}.sig div{border-top:1px solid #333;padding-top:4px;text-align:center;font-weight:700}
</style></head><body><div class="hd"><div class="hl">${logo}<div><b>${E(co)}</b><small>Construction Management &amp; Accounting</small></div></div><div class="hr"><h1>${E(title.toUpperCase())}</h1><div>${meta}<br>Generated: ${E(now.toLocaleString())}</div></div></div>
${kpis ? `<div class="ks">${kpis.map(([l, v]) => `<div class="k"><small>${E(l)}</small><b>${E(v)}</b></div>`).join("")}</div>` : ""}${body}
<div class="sig"><div>Prepared By</div><div>Checked By</div><div>Authorized By</div></div></body></html>`;
    let f = document.getElementById("pscFrame"); if (f) f.remove();
    f = document.createElement("iframe"); f.id = "pscFrame"; f.style.cssText = "position:fixed;width:0;height:0;border:0;visibility:hidden";
    document.body.appendChild(f); const fd = f.contentWindow.document; fd.open(); fd.write(html); fd.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 300);
  }
  function csv(name, head, rows) {
    const q = (v) => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["\ufeff" + [head, ...rows].map((r) => r.map(q).join(",")).join("\n")], { type: "text/csv" }));
    a.download = name + ".csv"; a.click();
  }
  function modal(title, html, wide) {
    openModal(title, html, () => true);
    const s = document.getElementById("modalSave"); if (s) s.style.display = "none";
    const box = document.querySelector("#modal .modalbox"); if (box) box.style.width = wide ? "min(1100px,96vw)" : "min(820px,96vw)";
  }
  const filterMeta = (f) => [f.project ? "Project: <b>" + E(PN(f.project)) + "</b>" : "All projects", f.client ? "Client: <b>" + E(f.client) + "</b>" : "", f.from || f.to ? "Period: <b>" + E(f.from || "Beginning") + " – " + E(f.to || "Today") + "</b>" : "All dates"].filter(Boolean).join(" · ");

  // ================= PAYMENTS =================
  const pf = { q: "", client: "", project: "", invoice: "", method: "", status: "", from: "", to: "" };
  function filteredPayments() {
    return uniqPayments().filter((p) => {
      const al = allocsOf(p), invNos = al.map((a) => invById(a.invoiceId)?.number || "").concat(p.invoiceNumber || "");
      if (pf.client && (p.client || "") !== pf.client) return false;
      if (pf.project && p.projectId !== pf.project && !al.some((a) => invById(a.invoiceId)?.projectId === pf.project)) return false;
      if (pf.invoice && !invNos.includes(pf.invoice)) return false;
      if (pf.method && (p.method || "") !== pf.method) return false;
      if (pf.status && payStatus(p) !== pf.status) return false;
      if (pf.from && String(p.date) < pf.from) return false;
      if (pf.to && String(p.date) > pf.to) return false;
      if (pf.q && ![p.reference, p.client, p.method, p.account, p.notes, PN(p.projectId), ...invNos].join(" ").toLowerCase().includes(pf.q.toLowerCase())) return false;
      return true;
    }).sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.reference || "").localeCompare(String(a.reference || ""), undefined, { numeric: true }));
  }
  const invLabel = (p) => { const al = allocsOf(p); if (al.length > 1) return al.length + " invoices"; return invById(al[0]?.invoiceId)?.number || p.invoiceNumber || "—"; };
  function payKpis(ps) {
    const tot = ps.reduce((s, p) => s + (+p.amount || 0), 0), cash = ps.filter((p) => isCash(p.method)).reduce((s, p) => s + (+p.amount || 0), 0);
    return { tot, cash, bank: tot - cash, un: ps.reduce((s, p) => s + unalloc(p), 0) };
  }
  function payRows(ps) {
    return ps.map((p) => `<tr><td>${E(p.date)}</td><td><b>${E(p.reference || "—")}</b></td><td>${E(p.client || "—")}</td><td>${E(PN(p.projectId))}</td><td>${E(invLabel(p))}</td><td>${E(p.method || "—")}</td><td class="r">${M(p.amount)}</td><td class="r g">${M(allocated(p))}</td><td class="r ${unalloc(p) > 0 ? "o" : ""}">${M(unalloc(p))}</td><td><span class="psc-st ${payStatus(p) === "Allocated" ? "ok" : "warn"}">${payStatus(p)}</span></td><td class="psc-act"><button class="btn small" onclick="pscViewPayment('${p.id}')">View</button><button class="btn small" onclick="pscPrintReceipt('${p.id}')">⎙ Receipt</button><button class="btn small" onclick="pscAllocHistory('${p.id}')">Allocations</button></td></tr>`).join("");
  }
  window.salesPaymentsPage = function () {
    salesEnsureData();
    const d = D(), all = uniqPayments(), ps = filteredPayments(), k = payKpis(ps);
    const opt = (arr, sel, lbl) => `<option value="">${lbl}</option>` + [...new Set(arr.filter(Boolean))].sort().map((v) => `<option ${v === sel ? "selected" : ""}>${E(v)}</option>`).join("");
    const projOpt = `<option value="">All projects</option>` + (d.projects || []).map((p) => `<option value="${E(p.id)}" ${p.id === pf.project ? "selected" : ""}>${E(p.name)}</option>`).join("");
    document.getElementById("view").innerHTML = head("Sales & Invoiced", "Customer receipts, allocations and collection register.", salesHeaderActions()) + salesTabs() + `
    <div class="psc">
      <div class="psc-k"><div class="b"><small>Total Received (${ps.length})</small><b>${M(k.tot)}</b></div><div class="g"><small>Cash Received</small><b>${M(k.cash)}</b></div><div class="s"><small>Bank / Transfer / Other</small><b>${M(k.bank)}</b></div><div class="o"><small>Unallocated Payments</small><b>${M(k.un)}</b></div></div>
      <div class="psc-f">
        <input id="pfq" placeholder="🔍 Search receipt, client, invoice…" value="${E(pf.q)}">
        <select id="pfclient">${opt(all.map((p) => p.client), pf.client, "All clients")}</select>
        <select id="pfproject">${projOpt}</select>
        <select id="pfinvoice">${opt((d.invoices || []).map((i) => i.number), pf.invoice, "All invoices")}</select>
        <select id="pfmethod">${opt(all.map((p) => p.method), pf.method, "All methods")}</select>
        <select id="pfstatus">${opt(["Allocated", "Partially Allocated", "Unallocated"], pf.status, "All status")}</select>
        <input type="date" id="pffrom" value="${E(pf.from)}" title="From"><input type="date" id="pfto" value="${E(pf.to)}" title="To">
        <button class="btn small" id="pfreset">Reset</button>
      </div>
      <div class="panel"><div class="panel-head"><h3>Payment Register <small class="muted">· ${ps.length} of ${all.length} receipts</small></h3><div class="psc-tools"><button class="btn small primary" onclick="receiveInvoicePayment()">+ Receive Payment</button><button class="btn small" id="pfstmt">📄 Payment Statement</button><button class="btn small" id="pfprint">⎙ Print</button><button class="btn small" id="pfcsv">Excel / CSV</button></div></div>
      <div class="psc-t"><table class="table"><thead><tr><th>Date</th><th>Receipt No</th><th>Client</th><th>Project / Site</th><th>Invoice</th><th>Method</th><th class="r">Amount</th><th class="r">Allocated</th><th class="r">Unallocated</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>${payRows(ps) || '<tr><td colspan="11" class="empty">No payments match these filters.</td></tr>'}</tbody>${ps.length ? `<tfoot><tr><td colspan="6">Total</td><td class="r">${M(k.tot)}</td><td class="r">${M(k.tot - k.un)}</td><td class="r">${M(k.un)}</td><td colspan="2"></td></tr></tfoot>` : ""}</table></div></div>
    </div>`;
    const bindVal = (id, key, ev) => { const el = document.getElementById(id); if (el) el[ev || "onchange"] = () => { pf[key] = el.value; if (key === "q") { clearTimeout(bindVal.t); bindVal.t = setTimeout(() => { salesPaymentsPage(); const q = document.getElementById("pfq"); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }, 250); } else salesPaymentsPage(); }; };
    bindVal("pfq", "q", "oninput"); ["client", "project", "invoice", "method", "status", "from", "to"].forEach((k2) => bindVal("pf" + k2, k2));
    document.getElementById("pfreset").onclick = () => { Object.keys(pf).forEach((x) => (pf[x] = "")); salesPaymentsPage(); };
    document.getElementById("pfcsv").onclick = () => csv("payment-register", ["Date", "Receipt", "Client", "Project", "Invoice", "Method", "Amount", "Allocated", "Unallocated", "Status"], ps.map((p) => [p.date, p.reference, p.client, PN(p.projectId), invLabel(p), p.method, r2(p.amount), allocated(p), unalloc(p), payStatus(p)]));
    const printReg = () => printDoc("Payment Statement", filterMeta({ project: pf.project, client: pf.client, from: pf.from, to: pf.to }), [["Total Received", M(k.tot)], ["Cash", M(k.cash)], ["Bank / Transfer", M(k.bank)], ["Unallocated", M(k.un)]],
      `<table><thead><tr><th>#</th><th>Date</th><th>Receipt</th><th>Client</th><th>Project</th><th>Invoice</th><th>Method</th><th class="r">Amount</th><th class="r">Allocated</th><th class="r">Unallocated</th></tr></thead><tbody>${ps.map((p, i) => `<tr><td>${i + 1}</td><td>${E(p.date)}</td><td>${E(p.reference)}</td><td>${E(p.client)}</td><td>${E(PN(p.projectId))}</td><td>${E(invLabel(p))}</td><td>${E(p.method)}</td><td class="r">${M(p.amount)}</td><td class="r">${M(allocated(p))}</td><td class="r">${M(unalloc(p))}</td></tr>`).join("")}<tr class="grand"><td colspan="7">GRAND TOTAL</td><td class="r">${M(k.tot)}</td><td class="r">${M(k.tot - k.un)}</td><td class="r">${M(k.un)}</td></tr></tbody></table>`, true);
    document.getElementById("pfprint").onclick = printReg; document.getElementById("pfstmt").onclick = printReg;
  };

  function allocTable(p) {
    const al = allocsOf(p);
    return `<table class="table"><thead><tr><th>Invoice</th><th>Project</th><th>Invoice Date</th><th>Due</th><th class="r">Invoice Amount</th><th class="r">Allocated (this receipt)</th><th class="r">Invoice Balance now</th></tr></thead><tbody>${al.map((a) => { const i = invById(a.invoiceId) || {}; return `<tr><td><b>${E(i.number || "—")}</b></td><td>${E(PN(i.projectId))}</td><td>${E(i.date || "—")}</td><td>${E(i.dueDate || "—")}</td><td class="r">${M(i.amount)}</td><td class="r g">${M(a.amount)}</td><td class="r">${i.id ? M(OUT(i)) : "—"}</td></tr>`; }).join("") || '<tr><td colspan="7" class="empty">This receipt is not linked to any invoice.</td></tr>'}</tbody></table>`;
  }
  window.pscViewPayment = function (id) {
    const p = uniqPayments().find((x) => x.id === id); if (!p) return;
    const f = (l, v) => `<div><small>${l}</small><b>${v}</b></div>`;
    modal("Receipt " + (p.reference || ""), `<div class="psc-d">${f("Receipt No", E(p.reference || "—"))}${f("Date", E(p.date))}${f("Client", E(p.client || "—"))}${f("Project / Site", E(PN(p.projectId)))}${f("Method", E(p.method || "—"))}${f("Bank / Cash Account", E(p.account || "—"))}${f("Amount", M(p.amount))}${f("Allocated", M(allocated(p)))}${f("Unallocated", M(unalloc(p)))}${f("Status", payStatus(p))}${f("Entered By", E(p.createdBy || "—"))}${f("Entered At", E(p.createdAt ? new Date(p.createdAt).toLocaleString() : "—"))}</div>
      <h4 class="psc-h">Linked invoices</h4>${allocTable(p)}${p.notes ? `<div class="sales-note">${E(p.notes)}</div>` : ""}${p.attachmentData ? `<p><a class="btn small" href="${E(p.attachmentData)}" download="${E(p.attachmentName || "attachment")}">📎 ${E(p.attachmentName || "Attachment")}</a></p>` : ""}
      <div class="psc-tools" style="margin-top:10px"><button class="btn small primary" onclick="pscPrintReceipt('${p.id}')">⎙ Print / PDF Receipt</button></div>`, true);
  };
  window.salesViewPayment = window.pscViewPayment;
  window.pscAllocHistory = function (id) {
    const p = uniqPayments().find((x) => x.id === id); if (!p) return;
    const log = (D().salesAudit || []).filter((a) => p.reference && String(a.detail || "").includes(p.reference));
    modal("Allocation History · " + (p.reference || ""), allocTable(p) + `<h4 class="psc-h">Audit trail</h4><table class="table"><thead><tr><th>Date</th><th>Action</th><th>Detail</th><th>User</th></tr></thead><tbody>${log.map((a) => `<tr><td>${E(new Date(a.date).toLocaleString())}</td><td>${E(a.action)}</td><td>${E(a.detail)}</td><td>${E(a.user)}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">No audit entries recorded for this receipt.</td></tr>'}</tbody></table>`, true);
  };
  window.pscPrintReceipt = function (id) {
    const p = uniqPayments().find((x) => x.id === id); if (!p) return;
    const al = allocsOf(p);
    printDoc("Payment Receipt", `Receipt No: <b>${E(p.reference || "—")}</b> · Date: <b>${E(p.date)}</b><br>Client: <b>${E(p.client || "—")}</b> · Project: <b>${E(PN(p.projectId))}</b>`,
      [["Amount Received", M(p.amount)], ["Allocated", M(allocated(p))], ["Unallocated", M(unalloc(p))], ["Method", p.method || "—"]],
      `<h3>Allocation</h3><table><thead><tr><th>Invoice</th><th>Project</th><th>Due Date</th><th class="r">Invoice Amount</th><th class="r">Allocated</th><th class="r">Balance</th></tr></thead><tbody>${al.map((a) => { const i = invById(a.invoiceId) || {}; return `<tr><td>${E(i.number || "—")}</td><td>${E(PN(i.projectId))}</td><td>${E(i.dueDate || "—")}</td><td class="r">${M(i.amount)}</td><td class="r">${M(a.amount)}</td><td class="r">${i.id ? M(OUT(i)) : "—"}</td></tr>`; }).join("")}<tr class="grand"><td colspan="4">TOTAL</td><td class="r">${M(allocated(p))}</td><td></td></tr></tbody></table>${p.account ? `<p>Account: ${E(p.account)}</p>` : ""}${p.notes ? `<p>Notes: ${E(p.notes)}</p>` : ""}`);
  };

  // ================= RECEIVABLES =================
  let open = {};
  function invoicesForPayment(inv) {
    const d = D(), out = [];
    uniqPayments().forEach((p) => allocsOf(p).forEach((a) => { if (a.invoiceId === inv.id) out.push({ date: p.date, ref: p.reference, method: p.method, amount: a.amount, pid: p.id }); }));
    if (!out.length) (inv.payments || []).forEach((l) => out.push({ date: l.date, ref: l.reference, method: l.method, amount: +l.amount || 0, pid: l.id }));
    return out.sort((a, b) => String(a.date).localeCompare(String(b.date)));
  }
  function rxData() {
    const d = D(), f = SF(), invs = salesApplyFilters().filter(ISSUED), map = new Map();
    invs.forEach((i) => {
      const k = clientKey(i);
      if (!map.has(k)) map.set(k, { key: k, clientId: i.clientId || "", client: i.client || (typeof quoteClientName === "function" ? quoteClientName(i.clientId) : "") || "Unknown", invs: [] });
      map.get(k).invs.push(i);
    });
    const byProj = (x) => !f.project || x.projectId === f.project;
    const rows = [...map.values()].map((r) => {
      const ids = new Set(r.invs.map((i) => i.id)), pids = new Set(r.invs.map((i) => i.projectId));
      r.contract = (d.contracts || []).filter((c) => r.clientId && c.clientId === r.clientId && byProj(c)).reduce((s, c) => s + (+c.value || 0), 0);
      r.invoiced = r.invs.reduce((s, i) => s + (+i.amount || 0), 0);
      r.received = r.invs.reduce((s, i) => s + (+i.received || 0), 0);
      r.outstanding = r.invs.reduce((s, i) => s + OUT(i), 0);
      r.overdue = r.invs.filter(isOverdue).reduce((s, i) => s + OUT(i), 0);
      const mine = (x) => (x.invoiceId ? ids.has(x.invoiceId) : r.clientId && x.clientId === r.clientId && byProj(x));
      r.retention = (d.retentions || []).filter(mine).reduce((s, x) => s + Math.max(0, (+x.amount || 0) - (+x.released || 0)), 0);
      r.advance = (d.advances || []).filter(mine).reduce((s, x) => s + Math.max(0, (+x.amount || 0) - (+x.adjusted || 0)), 0);
      r.projects = [...pids];
      return r;
    }).sort((a, b) => b.outstanding - a.outstanding || a.client.localeCompare(b.client));
    const aging = BUCKETS.map((b, bi) => { const list = invs.filter((i) => OUT(i) > 0.001 && bucketOf(i) === bi); return { label: b[0], list, amount: list.reduce((s, i) => s + OUT(i), 0) }; });
    return { invs, rows, aging };
  }
  window.salesReceivablesPage = function () {
    salesEnsureData();
    const { invs, rows, aging } = rxData();
    const T = (k) => rows.reduce((s, r) => s + r[k], 0), maxA = Math.max(1, ...aging.map((a) => a.amount));
    const body = rows.map((r) => {
      const isOpen = open[r.key];
      let h = `<tr class="rx-c ${isOpen ? "on" : ""}" data-k="${E(r.key)}"><td><span class="rx-tg">${isOpen ? "▾" : "▸"}</span> <b>${E(r.client)}</b><small>${r.projects.length} project(s) · ${r.invs.length} invoice(s)</small></td><td class="r">${M(r.contract)}</td><td class="r">${M(r.invoiced)}</td><td class="r g">${M(r.received)}</td><td class="r"><b>${M(r.outstanding)}</b></td><td class="r ${r.overdue > 0 ? "o" : ""}">${M(r.overdue)}</td><td class="r">${M(r.retention)}</td><td class="r">${M(r.advance)}</td><td class="psc-act"><button class="btn small" data-a="inv">Invoices</button><button class="btn small" data-a="pay">Payments</button><button class="btn small" data-a="stmt">Statement</button><button class="btn small primary" data-a="recv">Receive</button></td></tr>`;
      if (isOpen) r.projects.forEach((pid) => {
        const pi = r.invs.filter((i) => i.projectId === pid);
        h += `<tr class="rx-p"><td colspan="4">🏗 ${E(PN(pid))} <small>${pi.length} invoice(s)</small></td><td class="r"><b>${M(pi.reduce((s, i) => s + OUT(i), 0))}</b></td><td class="r">${M(pi.filter(isOverdue).reduce((s, i) => s + OUT(i), 0))}</td><td colspan="2"></td><td><button class="btn small" onclick="pbProjectStatement('invoices','${E(pid)}')">Project Statement</button></td></tr>`;
        pi.sort((a, b) => String(a.date).localeCompare(String(b.date))).forEach((i) => {
          const pays = invoicesForPayment(i), od = isOverdue(i);
          h += `<tr class="rx-i"><td>↳ <b>${E(i.number)}</b> <small>${E(i.date || "")} · Due ${E(i.dueDate || "—")}</small></td><td></td><td class="r">${M(i.amount)}</td><td class="r g">${M(i.received || 0)}</td><td class="r"><b>${M(OUT(i))}</b></td><td class="r">${od ? `<span class="psc-st bad">${daysPast(i.dueDate)}d overdue</span>` : OUT(i) > 0 ? '<span class="psc-st ok">Not yet due</span>' : '<span class="psc-st ok">Paid</span>'}</td><td colspan="2"><small>${pays.map((p) => `${E(p.date)} · ${E(p.ref || "")} · ${M(p.amount)}`).join("<br>") || "No payments yet"}</small></td><td>${OUT(i) > 0 ? `<button class="btn small" onclick="receiveInvoicePayment('${i.id}')">Receive</button>` : ""}</td></tr>`;
        });
      });
      return h;
    }).join("");
    document.getElementById("view").innerHTML = head("Sales & Invoiced", "Customer receivables, aging and collection management.", salesHeaderActions()) + salesTabs() + salesFilterBar() + `
    <div class="psc">
      <div class="psc-k"><div class="b"><small>Total Outstanding</small><b>${M(T("outstanding"))}</b></div><div class="o"><small>Total Overdue</small><b>${M(T("overdue"))}</b></div><div class="s"><small>Retention Balance (held separately)</small><b>${M(T("retention"))}</b></div><div class="g"><small>Advance Balance (held separately)</small><b>${M(T("advance"))}</b></div></div>
      <div class="rx-ag">${aging.map((a, i) => `<button class="rx-b ${i === 0 ? "cur" : "due"}" data-b="${i}"><small>${a.label}${i === 0 ? " · not yet due" : " · overdue"}</small><b>${M(a.amount)}</b><i><em style="width:${Math.round((a.amount / maxA) * 100)}%"></em></i><span>${a.list.length} invoice(s) ›</span></button>`).join("")}</div>
      <div class="panel"><div class="panel-head"><h3>Receivables Register <small class="muted">· click a client to see projects, invoices &amp; payments</small></h3><div class="psc-tools"><button class="btn small" id="rxprint">⎙ Print</button><button class="btn small" id="rxcsv">Excel / CSV</button></div></div>
      <div class="psc-t"><table class="table"><thead><tr><th>Client</th><th class="r">Contract Value</th><th class="r">Invoiced</th><th class="r">Received</th><th class="r">Outstanding</th><th class="r">Overdue</th><th class="r">Retention</th><th class="r">Advance</th><th>Actions</th></tr></thead>
      <tbody>${body || '<tr><td colspan="9" class="empty">No receivables for these filters.</td></tr>'}</tbody>${rows.length ? `<tfoot><tr><td>Total</td><td class="r">${M(T("contract"))}</td><td class="r">${M(T("invoiced"))}</td><td class="r">${M(T("received"))}</td><td class="r">${M(T("outstanding"))}</td><td class="r">${M(T("overdue"))}</td><td class="r">${M(T("retention"))}</td><td class="r">${M(T("advance"))}</td><td></td></tr></tfoot>` : ""}</table></div></div>
      <div class="sales-note" style="margin-top:6px">Outstanding = invoice amount − allocated receipts − credit applied. Retention and advance balances are shown separately and are not added to Outstanding.</div>
    </div>`;
    salesBindFilters();
    const find = (k) => rows.find((r) => r.key === k);
    document.querySelectorAll(".rx-c").forEach((tr) => tr.addEventListener("click", (e) => {
      const r = find(tr.dataset.k), a = e.target.closest("button")?.dataset.a;
      if (!a) { open[r.key] = !open[r.key]; salesReceivablesPage(); return; }
      e.stopPropagation();
      if (a === "inv") invList("Invoices · " + r.client, r.invs);
      if (a === "pay") payHistory(r);
      if (a === "stmt") clientStatement(r);
      if (a === "recv") { const i = r.invs.find((x) => OUT(x) > 0); if (i) receiveInvoicePayment(i.id); else toast("This client has no outstanding invoice"); }
    }));
    document.querySelectorAll(".rx-b").forEach((b) => (b.onclick = () => { const a = aging[+b.dataset.b]; invList("Aging · " + a.label, a.list); }));
    document.getElementById("rxcsv").onclick = () => csv("receivables", ["Client", "Contract", "Invoiced", "Received", "Outstanding", "Overdue", "Retention", "Advance"], rows.map((r) => [r.client, r2(r.contract), r2(r.invoiced), r2(r.received), r2(r.outstanding), r2(r.overdue), r2(r.retention), r2(r.advance)]));
    document.getElementById("rxprint").onclick = () => printDoc("Receivables Statement", filterMeta(SF()), [["Outstanding", M(T("outstanding"))], ["Overdue", M(T("overdue"))], ["Retention", M(T("retention"))], ["Advance", M(T("advance"))]],
      `<h3>Aging</h3><table><thead><tr>${aging.map((a) => `<th class="r">${a.label}</th>`).join("")}</tr></thead><tbody><tr>${aging.map((a) => `<td class="r">${M(a.amount)}</td>`).join("")}</tr></tbody></table><h3>Clients</h3><table><thead><tr><th>Client</th><th class="r">Contract</th><th class="r">Invoiced</th><th class="r">Received</th><th class="r">Outstanding</th><th class="r">Overdue</th><th class="r">Retention</th><th class="r">Advance</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${E(r.client)}</td><td class="r">${M(r.contract)}</td><td class="r">${M(r.invoiced)}</td><td class="r">${M(r.received)}</td><td class="r">${M(r.outstanding)}</td><td class="r">${M(r.overdue)}</td><td class="r">${M(r.retention)}</td><td class="r">${M(r.advance)}</td></tr>`).join("")}<tr class="grand"><td>TOTAL</td><td class="r">${M(T("contract"))}</td><td class="r">${M(T("invoiced"))}</td><td class="r">${M(T("received"))}</td><td class="r">${M(T("outstanding"))}</td><td class="r">${M(T("overdue"))}</td><td class="r">${M(T("retention"))}</td><td class="r">${M(T("advance"))}</td></tr></tbody></table>`, true);
  };

  function invList(title, list) {
    const tot = list.reduce((s, i) => s + OUT(i), 0);
    modal(title, `<div class="psc-t" style="max-height:60vh"><table class="table"><thead><tr><th>Invoice</th><th>Client</th><th>Project</th><th>Date</th><th>Due</th><th class="r">Amount</th><th class="r">Received</th><th class="r">Outstanding</th><th>Age</th><th></th></tr></thead><tbody>${list.map((i) => `<tr><td><b>${E(i.number)}</b></td><td>${E(i.client || "—")}</td><td>${E(PN(i.projectId))}</td><td>${E(i.date || "—")}</td><td>${E(i.dueDate || "—")}</td><td class="r">${M(i.amount)}</td><td class="r">${M(i.received || 0)}</td><td class="r"><b>${M(OUT(i))}</b></td><td>${isOverdue(i) ? `<span class="psc-st bad">${daysPast(i.dueDate)}d overdue</span>` : OUT(i) > 0 ? '<span class="psc-st ok">Not due</span>' : '<span class="psc-st ok">Paid</span>'}</td><td>${OUT(i) > 0 ? `<button class="btn small" onclick="receiveInvoicePayment('${i.id}')">Receive</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="10" class="empty">No invoices.</td></tr>'}</tbody><tfoot><tr><td colspan="7">Total outstanding</td><td class="r">${M(tot)}</td><td colspan="2"></td></tr></tfoot></table></div>`, true);
  }
  function payHistory(r) {
    const ids = new Set(r.invs.map((i) => i.id)), list = [];
    uniqPayments().forEach((p) => { const al = allocsOf(p).filter((a) => ids.has(a.invoiceId)); if (al.length || (!allocsOf(p).length && clientKey(p) === r.key)) list.push({ p, amt: al.reduce((s, a) => s + a.amount, 0), nos: al.map((a) => invById(a.invoiceId)?.number).join(", ") }); });
    list.sort((a, b) => String(a.p.date).localeCompare(String(b.p.date)));
    modal("Payment History · " + r.client, `<div class="psc-t" style="max-height:60vh"><table class="table"><thead><tr><th>Date</th><th>Receipt</th><th>Method</th><th>Invoices</th><th class="r">Allocated</th><th></th></tr></thead><tbody>${list.map((x) => `<tr><td>${E(x.p.date)}</td><td><b>${E(x.p.reference)}</b></td><td>${E(x.p.method)}</td><td>${E(x.nos || "—")}</td><td class="r">${M(x.amt)}</td><td><button class="btn small" onclick="pscViewPayment('${x.p.id}')">View</button></td></tr>`).join("") || '<tr><td colspan="6" class="empty">No payments recorded.</td></tr>'}</tbody><tfoot><tr><td colspan="4">Total</td><td class="r">${M(list.reduce((s, x) => s + x.amt, 0))}</td><td></td></tr></tfoot></table></div>`, true);
  }
  function clientStatement(r) {
    let body = "";
    r.projects.forEach((pid) => {
      const pi = r.invs.filter((i) => i.projectId === pid).sort((a, b) => String(a.date).localeCompare(String(b.date)));
      body += `<tr class="grp"><td colspan="7">${E(PN(pid))}</td></tr>` + pi.map((i) => `<tr><td>${E(i.date)}</td><td>${E(i.number)}</td><td>${E(i.dueDate || "—")}</td><td class="r">${M(i.amount)}</td><td class="r">${M(i.received || 0)}</td><td class="r">${M(OUT(i))}</td><td>${isOverdue(i) ? daysPast(i.dueDate) + "d overdue" : OUT(i) > 0 ? "Not due" : "Paid"}</td></tr>`).join("") +
        `<tr class="sub"><td colspan="3">Subtotal</td><td class="r">${M(pi.reduce((s, i) => s + (+i.amount || 0), 0))}</td><td class="r">${M(pi.reduce((s, i) => s + (+i.received || 0), 0))}</td><td class="r">${M(pi.reduce((s, i) => s + OUT(i), 0))}</td><td></td></tr>`;
    });
    printDoc("Client Statement", `Client: <b>${E(r.client)}</b> · ${filterMeta({ ...SF(), client: "" })}`, [["Invoiced", M(r.invoiced)], ["Received", M(r.received)], ["Outstanding", M(r.outstanding)], ["Overdue", M(r.overdue)]],
      `<table><thead><tr><th>Date</th><th>Invoice</th><th>Due</th><th class="r">Amount</th><th class="r">Received</th><th class="r">Outstanding</th><th>Status</th></tr></thead><tbody>${body}<tr class="grand"><td colspan="3">GRAND TOTAL</td><td class="r">${M(r.invoiced)}</td><td class="r">${M(r.received)}</td><td class="r">${M(r.outstanding)}</td><td></td></tr></tbody></table><p>Retention held: ${M(r.retention)} · Advance balance: ${M(r.advance)}</p>`);
  }

  const css = `
  .psc-k{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:8px}
  .psc-k div{background:#fff;border:1px solid #e3e9f2;border-left:4px solid #64748b;border-radius:10px;padding:7px 12px}
  .psc-k .b{border-left-color:#1d4ed8}.psc-k .g{border-left-color:#16a34a}.psc-k .o{border-left-color:#dc2626}.psc-k .s{border-left-color:#0ea5e9}
  .psc-k small{display:block;font-size:11px;color:#64748b;font-weight:700}.psc-k b{font-size:16px;color:#14213d}
  .psc-f{display:grid;grid-template-columns:2fr repeat(5,1fr) 130px 130px auto;gap:6px;margin-bottom:8px;background:#fff;border:1px solid #e3e9f2;border-radius:10px;padding:7px}
  .psc-f input,.psc-f select{height:32px;border:1px solid #d5deea;border-radius:8px;padding:0 8px;font-size:12.5px;min-width:0}
  .psc-tools{display:flex;gap:6px;flex-wrap:wrap;margin-left:auto}.psc .panel-head{display:flex;align-items:center;gap:8px}
  .psc-t{max-height:calc(100vh - 360px);min-height:180px;overflow:auto;border-top:1px solid #eef2f7}
  .psc-t table{font-size:13px;width:100%}.psc-t th{position:sticky;top:0;z-index:1;white-space:nowrap}.psc-t td{padding:6px 8px;white-space:nowrap}
  .psc-t tfoot td{position:sticky;bottom:0;background:#14213d;color:#fff;font-weight:800}
  .psc .r,.psc-t .r{text-align:right}.psc td.g,.psc-t td.g{color:#15803d;font-weight:700}.psc td.o,.psc-t td.o{color:#b91c1c;font-weight:700}
  .psc-act{display:flex;gap:4px}.psc-act .btn{padding:3px 8px;font-size:11.5px;height:26px}
  .psc-st{font-size:11px;font-weight:700;border-radius:6px;padding:2px 7px;background:#fef3c7;color:#92400e}.psc-st.ok{background:#dcfce7;color:#166534}.psc-st.bad{background:#fee2e2;color:#991b1b}
  .psc-d{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}.psc-d div{border:1px solid #e3e9f2;border-radius:8px;padding:6px 10px}.psc-d small{display:block;font-size:11px;color:#64748b}
  .psc-h{margin:10px 0 6px;color:#14213d}
  .rx-ag{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-bottom:8px}
  .rx-b{text-align:left;background:#fff;border:1px solid #e3e9f2;border-top:3px solid #dc2626;border-radius:10px;padding:6px 10px;cursor:pointer;display:flex;flex-direction:column;gap:2px}
  .rx-b.cur{border-top-color:#16a34a}.rx-b:hover{background:#f6f9ff}.rx-b small{font-size:11px;color:#64748b;font-weight:700}.rx-b b{font-size:14px;color:#14213d}
  .rx-b i{height:5px;background:#eef2f7;border-radius:4px;overflow:hidden}.rx-b em{display:block;height:100%;background:#dc2626}.rx-b.cur em{background:#16a34a}.rx-b span{font-size:11px;color:#1d4ed8;font-weight:700}
  .rx-c{cursor:pointer}.rx-c small{display:block;font-size:11px;color:#64748b}.rx-c.on td{background:#eef4ff}.rx-tg{color:#1d4ed8}
  .rx-p td{background:#f3f6fb;font-weight:700;color:#14213d}.rx-p small{font-weight:500;color:#64748b}.rx-i td{font-size:12.5px;background:#fff}.rx-i small{color:#64748b}
  @media (max-width:1400px){.psc-f{grid-template-columns:repeat(5,1fr)}.psc-k b{font-size:15px}.rx-b b{font-size:13px}}
  @media (max-height:800px){.psc-t{max-height:calc(100vh - 330px)}.psc-k div{padding:5px 10px}}
  `;
  const st = document.createElement("style"); st.id = "pb-sales-collect"; st.textContent = css; document.head.appendChild(st);
})();
