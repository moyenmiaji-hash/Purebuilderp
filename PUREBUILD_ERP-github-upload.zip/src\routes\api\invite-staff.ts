import { createFileRoute } from "@tanstack/react-router";
import { isStrongPassword, isUuid } from "@/lib/security";
import {
  authenticateActiveRequest,
  isAdmin,
  writeSecurityAudit,
} from "@/integrations/supabase/request-auth.server";

const STAFF_PERMS = {
  submit_progress: true,
  submit_attendance: true,
  submit_materials: true,
  submit_equipment: true,
  submit_diary: true,
};
const MANAGER_PERMS = {
  ...STAFF_PERMS,
  review_progress: true,
  manage_boq: true,
  manage_materials: true,
};

export const Route = createFileRoute("/api/invite-staff")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const authResult = await authenticateActiveRequest(request);
        if (!authResult.ok) return authResult.response;
        const adminResult = await isAdmin(authResult.auth);
        if (adminResult === null) {
          return Response.json(
            { error: "Authorization is temporarily unavailable." },
            { status: 503 },
          );
        }
        if (!adminResult) {
          return Response.json(
            { error: "Only an Admin can create staff accounts." },
            { status: 403 },
          );
        }
        if (Number(request.headers.get("content-length") || 0) > 16_384) {
          return Response.json({ error: "Request is too large." }, { status: 413 });
        }

        let value: unknown;
        try {
          value = await request.json();
        } catch {
          return Response.json({ error: "Bad request." }, { status: 400 });
        }
        if (typeof value !== "object" || value === null || Array.isArray(value)) {
          return Response.json({ error: "Bad request." }, { status: 400 });
        }
        const body = value as {
          email?: unknown;
          display_name?: unknown;
          password?: unknown;
          role?: unknown;
          project_ids?: unknown;
        };
        const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
        const name = typeof body.display_name === "string" ? body.display_name.trim() : "";
        const password = typeof body.password === "string" ? body.password : "";
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || email.length > 254) {
          return Response.json({ error: "Email is not valid." }, { status: 400 });
        }
        if (!name || name.length > 120) {
          return Response.json(
            { error: "Name must be between 1 and 120 characters." },
            { status: 400 },
          );
        }
        if (!isStrongPassword(password)) {
          return Response.json(
            {
              error:
                "Password must be at least 12 characters and include upper/lowercase letters, a number, and a symbol.",
            },
            { status: 400 },
          );
        }
        if (body.role !== "staff" && body.role !== "manager") {
          return Response.json({ error: "Choose a valid account role." }, { status: 400 });
        }
        if (
          !Array.isArray(body.project_ids) ||
          body.project_ids.length === 0 ||
          body.project_ids.length > 20
        ) {
          return Response.json(
            { error: "Choose between 1 and 20 assigned projects." },
            { status: 400 },
          );
        }
        const projectIds = [...new Set(body.project_ids)];
        if (
          projectIds.length !== body.project_ids.length ||
          projectIds.some((id) => typeof id !== "string" || !isUuid(id))
        ) {
          return Response.json({ error: "Project assignment is invalid." }, { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: projects, error: projectError } = await supabaseAdmin
          .from("team_projects")
          .select("id, status")
          .eq("organization_id", authResult.auth.organizationId)
          .in("id", projectIds);
        if (projectError) {
          console.error("[Staff invite] Could not verify project assignments.", projectError);
          return Response.json(
            { error: "Could not verify the selected projects." },
            { status: 500 },
          );
        }
        if (
          !projects ||
          projects.length !== projectIds.length ||
          projects.some((project) => project.status !== "active")
        ) {
          return Response.json(
            { error: "Choose active projects belonging to your company." },
            { status: 400 },
          );
        }

        const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: { display_name: name },
        });
        if (createError || !created.user) {
          console.error("[Staff invite] Supabase could not create the account.", createError);
          return Response.json({ error: "Could not create the account." }, { status: 400 });
        }

        const userId = created.user.id;
        const role = body.role;
        const permissions = role === "manager" ? MANAGER_PERMS : STAFF_PERMS;
        const rollback = async () => {
          const { error: membershipError } = await supabaseAdmin
            .from("team_project_members")
            .delete()
            .eq("user_id", userId);
          const { error: roleError } = await supabaseAdmin
            .from("user_roles")
            .delete()
            .eq("user_id", userId);
          const { error: profileError } = await supabaseAdmin
            .from("profiles")
            .delete()
            .eq("id", userId);
          const { error: deleteUserError } = await supabaseAdmin.auth.admin.deleteUser(userId);
          return [membershipError, roleError, profileError, deleteUserError]
            .filter((result) => result.error)
            .map((result) => result.error?.message);
        };

        const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
          id: userId,
          organization_id: authResult.auth.organizationId,
          display_name: name,
          role,
          status: "active",
          permissions,
        });
        if (profileError) {
          console.error("[Staff invite] Could not create the staff profile.", profileError);
          const cleanupErrors = await rollback();
          return Response.json(
            {
              error: cleanupErrors.length
                ? "Account setup failed; manual cleanup is required."
                : "Account setup failed.",
            },
            { status: 500 },
          );
        }

        const { error: roleError } = await supabaseAdmin.from("user_roles").insert({
          user_id: userId,
          role,
        });
        if (roleError) {
          console.error("[Staff invite] Could not assign the staff role.", roleError);
          const cleanupErrors = await rollback();
          return Response.json(
            {
              error: cleanupErrors.length
                ? "Account setup failed; manual cleanup is required."
                : "Account setup failed.",
            },
            { status: 500 },
          );
        }

        const { error: memberError } = await supabaseAdmin.from("team_project_members").insert(
          projectIds.map((projectId) => ({
            organization_id: authResult.auth.organizationId,
            project_id: projectId,
            user_id: userId,
            status: "active",
            permissions,
          })),
        );
        if (memberError) {
          console.error(
            "[Staff invite] Could not assign projects to the staff account.",
            memberError,
          );
          const cleanupErrors = await rollback();
          return Response.json(
            {
              error: cleanupErrors.length
                ? "Account setup failed; manual cleanup is required."
                : "Account setup failed.",
            },
            { status: 500 },
          );
        }

        const userAuditWarning = await writeSecurityAudit(
          authResult.auth.userId,
          authResult.auth.organizationId,
          "user_created",
          userId,
        );
        const accessAuditWarning = await writeSecurityAudit(
          authResult.auth.userId,
          authResult.auth.organizationId,
          "project_access_changed",
          `${userId}:${projectIds.join(",")}`,
          "project_access",
        );
        const warnings = [userAuditWarning, accessAuditWarning].filter(Boolean);
        return Response.json({
          data: { email, user_id: userId },
          ...(warnings.length ? { warning: warnings.join(" ") } : {}),
        });
      },
    },
  },
});
