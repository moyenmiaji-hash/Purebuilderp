CREATE TABLE public.site_expense_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  requested_by uuid NOT NULL,
  request_date date NOT NULL,
  category text NOT NULL,
  amount numeric NOT NULL,
  payee text,
  description text,
  review_status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_expense_requests TO authenticated;
GRANT ALL ON public.site_expense_requests TO service_role;
ALTER TABLE public.site_expense_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or office read expense requests" ON public.site_expense_requests FOR SELECT TO authenticated
  USING (requested_by = auth.uid() OR public.is_office_user(auth.uid()));

CREATE OR REPLACE FUNCTION public.submit_site_expense_request(p_project_id uuid, p jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); a numeric := (p->>'amount')::numeric;
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_expense_requests WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'requestId',rid,'duplicate',true); END IF; END IF;
  IF a IS NULL OR a <= 0 THEN RAISE EXCEPTION 'Amount must be more than 0'; END IF;
  IF coalesce(trim(p->>'category'),'') = '' THEN RAISE EXCEPTION 'Category is required'; END IF;
  INSERT INTO public.site_expense_requests(project_id, requested_by, request_date, category, amount, payee, description, idempotency_key)
  VALUES (p_project_id, auth.uid(), coalesce(nullif(p->>'request_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date),
    trim(p->>'category'), a, nullif(p->>'payee',''), nullif(p->>'description',''), k) RETURNING id INTO rid;
  RETURN jsonb_build_object('saved',true,'requestId',rid);
END $$;

CREATE OR REPLACE FUNCTION public.review_site_expense_request(p_id uuid, p_decision text, p_note text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE r public.site_expense_requests;
BEGIN
  IF NOT public.is_office_user(auth.uid()) THEN RAISE EXCEPTION 'not authorized'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_expense_requests WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Request already reviewed or not found'; END IF;
  IF r.requested_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own request'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_expense_requests SET review_status=p_decision, reviewed_by=auth.uid(), reviewed_at=now(), review_note=nullif(trim(p_note),'') WHERE id=p_id;
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $$;

CREATE TABLE public.project_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.team_projects(id),
  title text NOT NULL,
  doc_type text NOT NULL DEFAULT 'Drawing',
  file_path text NOT NULL,
  file_name text,
  is_active boolean NOT NULL DEFAULT true,
  uploaded_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.project_documents TO authenticated;
GRANT ALL ON public.project_documents TO service_role;
ALTER TABLE public.project_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members and office read docs" ON public.project_documents FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR (is_active AND public.pb_is_member(project_id, auth.uid())));
CREATE POLICY "office add docs" ON public.project_documents FOR INSERT TO authenticated
  WITH CHECK (public.is_office_user(auth.uid()) AND uploaded_by = auth.uid());
CREATE POLICY "office update docs" ON public.project_documents FOR UPDATE TO authenticated
  USING (public.is_office_user(auth.uid())) WITH CHECK (public.is_office_user(auth.uid()));

CREATE POLICY "office upload project docs" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'project-documents' AND public.is_office_user(auth.uid()));
CREATE POLICY "read project docs" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'project-documents' AND (public.is_office_user(auth.uid())
    OR public.pb_is_member(((storage.foldername(name))[1])::uuid, auth.uid())));