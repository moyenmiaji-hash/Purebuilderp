import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const src = readFileSync(path.resolve(__dirname, "../../public/app/boq-calc.js"), "utf8");
const box: Record<string, any> = {};
new Function("window", src)(box);
const c = box["PB_BOQ_CALC"];

describe("BOQ row progress", () => {
  it("done / left / % from BOQ qty and executed qty", () => {
    const r = c.rowStats({ qty: 300, executedQty: 55, rate: 100 });
    expect(r.left).toBe(245);
    expect(r.pct).toBeCloseTo(18.33, 1);
    expect(r.state).toBe("In progress");
    expect(r.doneValue).toBe(5500);
  });
  it("done never goes above BOQ qty", () => {
    const r = c.rowStats({ qty: 100, executedQty: 130, rate: 1 });
    expect(r.done).toBe(100);
    expect(r.left).toBe(0);
    expect(r.state).toBe("Completed");
  });
  it("building progress is weighted by amount", () => {
    const g = c.groupStats([
      { qty: 100, executedQty: 100, rate: 1, amount: 100 },
      { qty: 100, executedQty: 0, rate: 9, amount: 900 },
    ]);
    expect(g.pct).toBeCloseTo(10); // plain average would be 50%
    expect(g.counts["Completed"]).toBe(1);
    expect(g.counts["Not started"]).toBe(1);
  });
});

describe("foreman daily calculation", () => {
  it("today is added on top of approved + waiting quantity", () => {
    const r = c.foremanCalc({ quantity: 300, approved: 50, reported: 55 }, 20);
    expect(r.pending).toBe(5);
    expect(r.after).toBe(75);
    expect(r.leftAfter).toBe(225);
    expect(r.pctAfter).toBeCloseTo(25);
  });
  it("today cannot go above the remaining BOQ quantity", () => {
    const r = c.foremanCalc({ quantity: 100, approved: 80, reported: 90 }, 25);
    expect(r.over).toBe(true);
    expect(r.today).toBe(10);
    expect(r.leftAfter).toBe(0);
  });
});
