/* Project Details Pro — display-only upgrade of Projects / Sites → View Details.
   Wraps window.projectDetail and decorates the rendered panel. Never writes data.
   The 'locations' tab (Locations & Allocation) is intentionally left untouched. */
(function(){
  if(window.__pdProLoaded)return;window.__pdProLoaded=true;
  const E=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const M=v=>typeof money==='function'?money(v):'AED '+(Number(v)||0).toFixed(2);
  const css=`<style id="pdpro-css">
  .project-dashboard .pd-tabs{flex-wrap:wrap;overflow:visible}
  .pdpro-bar{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 10px;padding:8px;border:1px solid var(--pd-border,#e4eaf2);border-radius:10px;background:var(--panel,#fff)}
  .pdpro-bar input,.pdpro-bar select{height:32px;border:1px solid var(--pd-border,#e4eaf2);border-radius:8px;padding:0 9px;font:inherit;font-size:13px;background:var(--panel,#fff);color:inherit}
  .pdpro-bar input[type=search]{flex:1;min-width:180px}
  .pdpro-bar .pdpro-count{font-size:12px;color:#718199;margin-left:auto}
  .pdpro-act{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:10px}
  .pdpro-act>div{border:1px solid var(--pd-border,#e4eaf2);border-radius:10px;padding:9px;background:var(--panel,#fff);min-width:0}
  .pdpro-act small{display:block;color:#718199;font-size:11px}.pdpro-act b{display:block;font-size:16px;margin-top:3px}
  .pdpro-list{margin-top:8px;border:1px solid var(--pd-border,#e4eaf2);border-radius:10px;background:var(--panel,#fff)}
  .pdpro-list h4{margin:0;padding:9px 10px;border-bottom:1px solid var(--pd-border,#e4eaf2);font-size:13px}
  .pdpro-list div{display:flex;justify-content:space-between;gap:8px;padding:7px 10px;font-size:12px;border-bottom:1px solid var(--pd-border,#eef2f7)}
  .pdpro-list div:last-child{border-bottom:0}
  @media(max-width:900px){.pdpro-act{grid-template-columns:repeat(2,minmax(0,1fr))}.pdx-cards{grid-template-columns:repeat(2,minmax(0,1fr))!important}.pdx-grid{grid-template-columns:1fr!important}.pdx-info{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
.pdpro-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-bottom:10px}
  .pdpro-cards>div{border:1px solid var(--pd-border,#e4eaf2);border-radius:10px;padding:12px;background:var(--panel,#fff)}
  .pdpro-cards small{display:block;color:#718199;font-size:12px}.pdpro-cards b{display:block;font-size:22px;margin-top:4px}
  .pdpro-chart{border:1px solid var(--pd-border,#e4eaf2);border-radius:10px;padding:10px 12px;margin-bottom:12px;background:var(--panel,#fff)}
  .pdpro-chart h4{margin:0 0 8px;font-size:14px}
  .pdpro-crow{display:grid;grid-template-columns:minmax(110px,180px) 1fr 120px 54px;gap:10px;align-items:center;padding:5px 0;font-size:13px}
  .pdpro-crow i{height:12px;background:#eef2f7;border-radius:6px;overflow:hidden}.pdpro-crow em{display:block;height:100%;background:linear-gradient(90deg,#df4c57,#f08a4b);border-radius:6px}
  .pdpro-crow b{text-align:right}.pdpro-crow small{color:#718199;text-align:right}
  @media print{.pdpro-bar{display:none!important}}
  </style>`;

  function overview(panel,pid){
    const p=(db.projects||[]).find(x=>x.id===pid)||{};
    const info=panel.querySelector('.pdx-info');
    if(info&&!info.dataset.pdpro){info.dataset.pdpro='1';
      info.insertAdjacentHTML('beforeend',[['Start date',p.start||'—'],['Expected completion',p.end||'—'],['Contract value',M(p.contract||0)]].map(([a,b])=>`<div><small>${a}</small><b>${E(b)}</b></div>`).join(''));}
    if(panel.querySelector('.pdpro-act'))return;
    const today=typeof hrToday==='function'?hrToday():new Date().toISOString().slice(0,10);
    const prog=(db.progress||[]).filter(x=>x.projectId===pid);
    const pending=prog.filter(x=>/submit|pending|review/i.test(String(x.status||''))).length
      +(db.payables||[]).filter(x=>x.projectId===pid&&/pending|submitted|review/i.test(String(x.status||''))).length;
    const boq=(db.boq||[]).filter(x=>x.projectId===pid);
    const plan=db.boqPlan||{};
    const done=b=>(Number(b.qty)||0)>0&&(Number(b.executedQty)||0)>=(Number(b.qty)||0);
    const endOf=b=>(plan[b.id]&&plan[b.id].end)||p.end||'';
    const startOf=b=>(plan[b.id]&&plan[b.id].start)||'';
    const delayed=boq.filter(b=>!done(b)&&endOf(b)&&endOf(b)<today);
    const upcoming=boq.filter(b=>!done(b)&&(Number(b.executedQty)||0)===0&&(!startOf(b)||startOf(b)>=today));
    const hist=(db.projectHistory||[]).filter(x=>x.projectId===pid).map(h=>({d:String(h.date||'').slice(0,16).replace('T',' '),t:h.action,s:h.details}))
      .concat(prog.map(x=>({d:x.date||'',t:'Progress update',s:(x.description||x.boqId||'')+(x.qty?` · ${x.qty}`:'')})))
      .sort((a,b)=>String(b.d).localeCompare(String(a.d))).slice(0,5);
    const box=`<div class="pdpro-act">${[['Total daily reports',prog.length],['Pending approvals',pending],['Recent activities (5)',hist.length],['Upcoming work',upcoming.length],['Delayed activities',delayed.length]].map(([a,b])=>`<div><small>${a}</small><b>${b}</b></div>`).join('')}</div>
    <div class="pdx-grid" style="margin-top:8px">
      <div class="pdpro-list"><h4>Recent Activities</h4>${hist.map(h=>`<div><span>${E(h.t)} — ${E(h.s)}</span><small>${E(h.d)}</small></div>`).join('')||'<div><span class="muted">No activity yet.</span></div>'}</div>
      <div class="pdpro-list"><h4>Upcoming Work</h4>${upcoming.slice(0,5).map(b=>`<div><span>${E(b.boqId||'')} ${E(b.description||'')}</span><small>${E(startOf(b)||'Not started')}</small></div>`).join('')||'<div><span class="muted">Nothing pending to start.</span></div>'}</div>
      <div class="pdpro-list"><h4>Delayed Activities</h4>${delayed.slice(0,5).map(b=>`<div><span>${E(b.boqId||'')} ${E(b.description||'')}</span><small style="color:#d84149">due ${E(endOf(b))}</small></div>`).join('')||'<div><span class="muted">No delayed work.</span></div>'}</div>
    </div>`;
    const grid=panel.querySelector('.pdx-grid');
    (grid||panel.lastElementChild||panel).insertAdjacentHTML('afterend',box);
  }

  function toolbar(panel,tab){
    if(panel.querySelector('.pdpro-bar'))return;
    const rows=()=>[...panel.querySelectorAll('table tbody tr')].filter(r=>!r.querySelector('td[colspan]'));
    const all=rows();if(!all.length&&tab!=='history')return;
    let extra='';
    if(tab==='history'){
      const types=[...new Set(all.map(r=>(r.cells[1]||{}).textContent||'').filter(Boolean))].sort();
      extra=`<select data-f="type"><option value="">All activity types</option>${types.map(t=>`<option>${E(t)}</option>`).join('')}</select><input type="date" data-f="from" title="From"><input type="date" data-f="to" title="To">`;
    }
    panel.insertAdjacentHTML('afterbegin',`<div class="pdpro-bar"><input type="search" placeholder="Search in this section…" data-f="q">${extra}<button class="btn small" data-f="print">Print / PDF</button><span class="pdpro-count"></span></div>`);
    const bar=panel.querySelector('.pdpro-bar'),cnt=bar.querySelector('.pdpro-count');
    const apply=()=>{
      const q=(bar.querySelector('[data-f=q]').value||'').toLowerCase().trim();
      const ty=bar.querySelector('[data-f=type]')?.value||'',fr=bar.querySelector('[data-f=from]')?.value||'',to=bar.querySelector('[data-f=to]')?.value||'';
      let shown=0;const list=rows();
      list.forEach(r=>{const txt=r.textContent.toLowerCase();const d=((r.cells[0]||{}).textContent||'').trim().slice(0,10);
        let ok=!q||txt.includes(q);
        if(ok&&ty)ok=((r.cells[1]||{}).textContent||'').trim()===ty;
        if(ok&&fr)ok=d>=fr;if(ok&&to)ok=d<=to;
        r.style.display=ok?'':'none';if(ok)shown++;});
      cnt.textContent=list.length?`${shown} of ${list.length} rows`:'';
    };
    bar.addEventListener('input',apply);bar.addEventListener('change',apply);
    bar.querySelector('[data-f=print]').onclick=()=>{typeof projectPrintDetail==='function'?projectPrintDetail():window.print()};
    apply();
  }


  function tracker(panel,pid,tab){
    if(panel.querySelector('.pdpro-trk')||typeof projectFinancialData!=='function')return;
    const b=(typeof projectBuildingSel!=='undefined'&&projectBuildingSel)||'';
    const fin=projectFinancialData(pid,b);
    const amt=x=>x.type==='Supplier Credit Note'?-Math.abs(Number(x.amount)||0):(Number(x.amount)||0);
    const test={materials:/material/i,labour:/labou?r|wage|salary|equipment|machinery/i}[tab];
    const recs=(fin.costRecords||[]).filter(x=>!test||test.test(x.category||''));
    const by={};recs.forEach(x=>{const k=x.category||'Uncategorized';by[k]=(by[k]||0)+amt(x)});
    const rows=Object.entries(by).sort((a,c)=>Math.abs(c[1])-Math.abs(a[1]));
    const total=rows.reduce((n,r)=>n+r[1],0),max=Math.max(1,...rows.map(r=>Math.abs(r[1])));
    const where=b?(b==='__general'?'General (no site)':b):'All sites';
    const title={finance:'Expense Tracker',materials:'Material Expense Tracker',labour:'Labour & Equipment Expense Tracker'}[tab];
    const cards=tab==='finance'
      ?[['Income',fin.totalIncomeReceived||0,'#15945b'],['Expense',fin.actualCost||0,'#df4c57']]
      :[[tab==='materials'?'Material Expense':'Labour & Equipment Expense',total,'#df4c57'],['Records',null,'#2373c7']];
    const html=`<div class="pdpro-trk"><div class="pdpro-cards">${cards.map(([l,v,c])=>`<div style="border-left:4px solid ${c}"><small>${l} · ${E(where)}</small><b style="color:${c}">${v==null?recs.length:M(v)}</b></div>`).join('')}</div>
      <div class="pdpro-chart"><h4>${title} — by category <small class="muted">${E(where)}</small></h4>${rows.map(([k,v])=>`<div class="pdpro-crow"><span>${E(k)}</span><i><em style="width:${(Math.abs(v)/max*100).toFixed(1)}%"></em></i><b>${M(v)}</b><small>${total?(v/total*100).toFixed(1):0}%</small></div>`).join('')||'<p class="muted" style="margin:8px 0">No expenses recorded yet.</p>'}</div></div>`;
    if(tab==='finance'){const k=panel.querySelector('.pd-kpis');if(k){const n=k.nextElementSibling;k.style.display='none';if(n&&n.tagName==='P')n.style.display='none';k.insertAdjacentHTML('beforebegin',html);return}}
    const bar=panel.querySelector('.pdpro-bar');(bar?bar.insertAdjacentHTML('afterend',html):panel.insertAdjacentHTML('afterbegin',html));
  }

  function decorate(pid,tab){
    const panel=document.querySelector('.project-dashboard .pd-panel');if(!panel)return;
    if(!document.getElementById('pdpro-css'))document.head.insertAdjacentHTML('beforeend',css);
    if(tab==='locations')return; // keep Locations & Allocation exactly as it is
    try{if(tab==='overview')overview(panel,pid);else{toolbar(panel,tab);if(['finance','materials','labour'].includes(tab))tracker(panel,pid,tab)}}catch(e){console.warn('project-details-pro',e)}
  }

  function wrap(){
    const orig=window.projectDetail;if(typeof orig!=='function'||orig.__pdpro)return false;
    const w=function(pid,tab){const r=orig.apply(this,arguments);const t=window.projectDetailsTab||tab||'overview';
      decorate(pid,t);setTimeout(()=>decorate(pid,t),60);return r};
    w.__pdpro=true;window.projectDetail=w;try{projectDetail=w}catch(e){}return true;
  }
  if(!wrap())document.addEventListener('DOMContentLoaded',wrap);
})();
