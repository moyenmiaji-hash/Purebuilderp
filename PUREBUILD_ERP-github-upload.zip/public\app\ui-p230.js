// p230 display layer: always white/light theme (theme switch hidden), no collapse menu,
// side menu fits without scrolling (desktop), digital "View all" buttons, Clay Dashboard,
// clean prints with company logo + location and no browser URL/link text. Never saves data.
(function () {
  const DB = () => { try { return db; } catch (e) { return window.db || {}; } };
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // 1) Light theme only
  function forceLight() {
    try { if (appTheme !== "light") { appTheme = "light"; applyTheme(); } } catch (e) {}
    document.body.classList.add("light-theme"); document.body.classList.remove("dark-theme");
    try { localStorage.setItem("PURE_BUILD_THEME", "light"); } catch (e) {}
  }
  window.toggleTheme = function () { forceLight(); };
  try { toggleTheme = window.toggleTheme; } catch (e) {}

  // 2) No collapse menu
  function noCollapse() {
    // p234: only the old "mini" mode is removed; the ☰ button may still hide/show the menu (nav-collapsed).
    document.body.classList.remove("nav-mini");
    try { localStorage.setItem("PB_NAV_MINI", "0"); } catch (e) {}
    document.querySelectorAll(".pb-mini-btn").forEach((b) => b.remove());
  }

  // 3) Side menu fits screen (desktop)
  function fitNav() {
    const sb = document.querySelector(".app>.sidebar"); if (!sb || window.innerWidth <= 900) return;
    // p231: never zoom the menu (it shrank everything when a sub-menu opened); compact a bit, then let it scroll on its own.
    sb.style.removeProperty("zoom");
    document.body.classList.toggle("pb-nav-tight", sb.scrollHeight > sb.clientHeight + 1 && !sb.querySelector(".nav .open, .nav [aria-expanded=true]"));
  }

  // 4) Digital View all buttons
  function tagViewAll() {
    document.querySelectorAll("button,a").forEach((b) => {
      if (b.classList.contains("pb-va")) return;
      const t = (b.textContent || "").trim();
      if (/^view all/i.test(t) && t.length < 30) b.classList.add("pb-va");
    });
  }

  // 5) Dashboard flag
  function dashFlag() { let p = ""; try { p = page; } catch (e) {} document.body.classList.toggle("pb-dash", p === "dashboard"); }

  // 6) Print: logo + location in every printed header
  function companyInfo() {
    const s = DB().settings || {};
    const bits = [s.companyAddress, s.companyPhone, s.companyEmail, s.companyWebsite].filter(Boolean).map(E).join(" · ");
    return { logo: s.companyLogo || "", bits };
  }
  function enrichPrint() {
    const { logo, bits } = companyInfo();
    document.querySelectorAll("#printSheet .print-head, #pbPrintHead").forEach((h) => {
      const left = h.querySelector(".print-brand, .pph-l") || h.firstElementChild; if (!left) return;
      if (logo && !h.querySelector("img")) { const img = document.createElement("img"); img.src = logo; img.alt = ""; img.className = "pb-plogo"; left.prepend(img); left.style.display = "flex"; left.style.alignItems = "center"; left.style.gap = "10px"; }
      if (bits && !h.querySelector(".pb-ploc")) { const d = document.createElement("div"); d.className = "pb-ploc"; d.innerHTML = bits; (left.querySelector("div") || left).appendChild(d); }
    });
  }
  const prevPrint = window.print;
  window.print = function () {
    // header for page/modal prints is added inside prevPrint; enrich just before native dialog via beforeprint
    return prevPrint.apply(window, arguments);
  };
  window.addEventListener("beforeprint", enrichPrint);

  const css = `
  #themeToggle,.theme-toggle,.pb-mini-btn{display:none!important}
  @media(min-width:901px){
    html body .app>.sidebar{position:sticky!important;top:0!important;height:100vh!important;max-height:100vh!important;overflow-y:auto!important;overflow-x:hidden!important;zoom:1!important;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:#c7c9d9 transparent}
    html body .app>.sidebar::-webkit-scrollbar{width:5px}
    html body .app>.sidebar::-webkit-scrollbar-thumb{background:#c7c9d9;border-radius:9px}
    html body.pb-nav-tight .app>.sidebar .nav button{padding-top:6px!important;padding-bottom:6px!important;min-height:0!important}
    html body.pb-nav-tight .app>.sidebar .group{margin-top:6px!important;margin-bottom:2px!important}
  }
  .pb-va{display:inline-flex!important;align-items:center;justify-content:center;gap:6px;height:30px!important;min-height:30px!important;padding:0 12px!important;border-radius:9px!important;
    background:#ffffff!important;color:#29283A!important;border:1px solid #d9d6ee!important;
    font:600 12px/1 "Segoe UI",Arial,sans-serif!important;letter-spacing:.01em;text-transform:none!important;white-space:nowrap;
    box-shadow:0 1px 2px rgba(41,40,58,.06)!important;cursor:pointer;transition:background .15s,border-color .15s,color .15s}
  .pb-va::before{content:"";width:6px;height:6px;border-radius:50%;background:#7c6fe0;flex:none}
  .pb-va:hover{background:#f4f2ff!important;border-color:#7c6fe0!important;color:#4c3fc0!important}
  /* One button system (size/shape only, colors stay per-meaning) */
  html body #view .btn,html body #modal .btn,html body #view .pagehead button,html body #modal .modalfoot button{
    min-height:34px;padding:0 14px;border-radius:10px!important;font-size:12.5px!important;font-weight:600!important;line-height:1.1;
    display:inline-flex;align-items:center;justify-content:center;gap:6px;transition:transform .12s,box-shadow .12s,filter .12s}
  html body #view .btn:hover,html body #modal .btn:hover{filter:brightness(.98);box-shadow:0 2px 6px rgba(41,40,58,.12)}
  html body #view .btn:active,html body #modal .btn:active{transform:translateY(1px)}
  html body #view .btn svg,html body #modal .btn svg{width:15px;height:15px}
  /* Fixed layout: top bar sticks, popups above menu */
  html body .topbar{position:sticky!important;top:0!important;z-index:60!important}
  html body #modal,html body .modal{z-index:2000!important}
  html body.mobile-nav-open{overflow:hidden}
  /* Clay Dashboard */
  html body.light-theme.pb-dash #view{background:radial-gradient(circle at 10% 0%,#ece9ff 0,transparent 45%),radial-gradient(circle at 100% 100%,#e0f2fe 0,transparent 45%),#f1f0f8!important}
  html body.light-theme.pb-dash #view .card,html body.light-theme.pb-dash #view .panel,html body.light-theme.pb-dash #view [class*="kpi"]:not([class*="kpis"]):not([class*="grid"]),html body.light-theme.pb-dash #view .stat{
    border-radius:22px!important;border:1px solid rgba(255,255,255,.8)!important;background:linear-gradient(145deg,#ffffff,#f3f1fb)!important;
    box-shadow:8px 8px 18px rgba(124,111,190,.18),-6px -6px 14px rgba(255,255,255,.95),inset 1px 1px 0 rgba(255,255,255,.9)!important}
  html body.light-theme.pb-dash #view [class*="kpi"]:not([class*="kpis"]):not([class*="grid"]):hover{transform:translateY(-2px)}
  html body.light-theme.pb-dash #view button:not(.pb-va){border-radius:14px!important;box-shadow:4px 4px 10px rgba(124,111,190,.18),-3px -3px 8px #fff!important}
  /* Print: clean, no browser URL/links */
  .pb-ploc{font-size:10px;color:#475569;margin-top:2px}
  .pb-plogo{max-height:46px;max-width:120px;object-fit:contain}
  @media print{
    @page{size:A4;margin:12mm 11mm 14mm;
      @bottom-right{content:"Page " counter(page) " of " counter(pages);font:9px Arial,sans-serif;color:#555}
      @top-left{content:none}@top-center{content:none}@top-right{content:none}@bottom-left{content:none}@bottom-center{content:none}}
    html,body{background:#fff!important;color:#111!important}
    a[href]::after{content:none!important}
    a{color:inherit!important;text-decoration:none!important}
    .pb-va,.pb-staff-link,.pb-mini-btn,#themeToggle,.toast{display:none!important}
    #view td:last-child button,#modalBody td:last-child button{display:none!important}
    thead{display:table-header-group}tr{break-inside:avoid}
    .print-table,.print-table th,.print-table td{border-color:#cfd4dc!important}
    #pbPrintHead,#printSheet .print-head{border-bottom:2px solid #1f2937!important}
  }
  }`;
  function addCss() { if (document.getElementById("pb-ui230")) return; const s = document.createElement("style"); s.id = "pb-ui230"; s.textContent = css; document.head.appendChild(s); }

  let q = 0;
  function run() { if (q) return; q = requestAnimationFrame(() => { q = 0; noCollapse(); tagViewAll(); dashFlag(); fitNav(); }); }
  function init() {
    addCss(); forceLight(); run();
    new MutationObserver(run).observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", run);
    setTimeout(run, 800); setTimeout(run, 2500);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
