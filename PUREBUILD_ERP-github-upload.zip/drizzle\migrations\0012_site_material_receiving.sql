ALTER TABLE public.site_stock_submissions
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS ref_id text,
  ADD COLUMN IF NOT EXISTS ref_label text,
  ADD COLUMN IF NOT EXISTS approved_lines jsonb;

CREATE TABLE IF NOT EXISTS public.site_stock_events (
  id bigserial PRIMARY KEY,
  submission_id uuid NOT NULL REFERENCES public.site_stock_submissions(id),
  event_type text NOT NULL,
  detail jsonb,
  note text,
  actor uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_stock_events TO authenticated;
GRANT ALL ON public.site_stock_events TO service_role;
ALTER TABLE public.site_stock_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Office or submitter can read stock events" ON public.site_stock_events FOR SELECT TO authenticated
  USING (public.is_office_user(auth.uid()) OR EXISTS (SELECT 1 FROM public.site_stock_submissions s WHERE s.id = submission_id AND s.submitted_by = auth.uid()));

CREATE OR REPLACE FUNCTION public.submit_site_stock_update(p_project_id uuid, p jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE rid uuid; k text := nullif(p->>'idempotency_key',''); d date := coalesce(nullif(p->>'work_date','')::date, (now() AT TIME ZONE 'Asia/Dubai')::date);
  kd text := coalesce(nullif(p->>'kind',''),'daily'); ln jsonb; nm text; src text := nullif(p->>'source',''); ref text := nullif(p->>'ref_id','');
BEGIN
  IF NOT public.pb_is_member(p_project_id, auth.uid()) THEN RAISE EXCEPTION 'You are not assigned to this site'; END IF;
  IF k IS NOT NULL THEN SELECT id INTO rid FROM public.site_stock_submissions WHERE idempotency_key = k;
    IF rid IS NOT NULL THEN RETURN jsonb_build_object('saved',true,'id',rid,'duplicate',true); END IF; END IF;
  IF kd NOT IN ('daily','site_purchase','receiving') THEN RAISE EXCEPTION 'Invalid update type'; END IF;
  IF d > (now() AT TIME ZONE 'Asia/Dubai')::date THEN RAISE EXCEPTION 'Date cannot be in the future'; END IF;
  IF jsonb_typeof(p->'lines') <> 'array' OR jsonb_array_length(p->'lines') = 0 THEN RAISE EXCEPTION 'Add at least one material'; END IF;
  FOR ln IN SELECT * FROM jsonb_array_elements(p->'lines') LOOP
    IF coalesce(trim(ln->>'item'),'') = '' THEN RAISE EXCEPTION 'Material name is required'; END IF;
    IF coalesce((ln->>'received')::numeric,0) < 0 OR coalesce((ln->>'used')::numeric,0) < 0 OR coalesce((ln->>'damaged')::numeric,0) < 0
       OR coalesce((ln->>'returned')::numeric,0) < 0 OR coalesce((ln->>'qty')::numeric,0) < 0
       OR coalesce((ln->>'accepted')::numeric,0) < 0 OR coalesce((ln->>'shortage')::numeric,0) < 0 OR coalesce((ln->>'expected')::numeric,0) < 0 THEN RAISE EXCEPTION 'Quantities cannot be negative'; END IF;
    IF kd = 'receiving' AND coalesce((ln->>'accepted')::numeric,0) + coalesce((ln->>'damaged')::numeric,0) > coalesce((ln->>'received')::numeric,0) + 0.000001 THEN
      RAISE EXCEPTION 'Accepted + damaged cannot be more than received for %', ln->>'item'; END IF;
  END LOOP;
  IF kd = 'receiving' THEN
    IF src NOT IN ('central','supplier','site_purchase') THEN RAISE EXCEPTION 'Choose the material source'; END IF;
    IF src IN ('central','site_purchase') AND ref IS NULL THEN RAISE EXCEPTION 'Choose the delivery you are receiving'; END IF;
    IF src IN ('central','site_purchase') AND EXISTS (SELECT 1 FROM public.site_stock_submissions WHERE project_id = p_project_id AND kind = 'receiving' AND source = src AND ref_id = ref AND review_status <> 'rejected') THEN
      RAISE EXCEPTION 'This delivery was already received'; END IF;
    IF src = 'supplier' AND nullif(trim(p->>'invoice_no'),'') IS NOT NULL AND EXISTS (SELECT 1 FROM public.site_stock_submissions WHERE project_id = p_project_id AND kind = 'receiving' AND source = 'supplier'
       AND lower(trim(invoice_no)) = lower(trim(p->>'invoice_no')) AND lower(coalesce(supplier,'')) = lower(coalesce(trim(p->>'supplier'),'')) AND review_status <> 'rejected') THEN
      RAISE EXCEPTION 'This supplier invoice / challan was already received'; END IF;
  END IF;
  SELECT display_name INTO nm FROM public.profiles WHERE id = auth.uid();
  INSERT INTO public.site_stock_submissions(project_id, submitted_by, submitted_name, work_date, kind, lines, supplier, invoice_no, remarks, photos, idempotency_key, source, ref_id, ref_label)
  VALUES (p_project_id, auth.uid(), nm, d, kd, p->'lines', nullif(p->>'supplier',''), nullif(p->>'invoice_no',''), nullif(p->>'remarks',''), coalesce(p->'photos','[]'::jsonb), k,
    CASE WHEN kd='receiving' THEN src END, CASE WHEN kd='receiving' THEN ref END, CASE WHEN kd='receiving' THEN nullif(p->>'ref_label','') END)
  RETURNING id INTO rid;
  INSERT INTO public.site_stock_events(submission_id, event_type, detail, actor) VALUES (rid, 'submitted', jsonb_build_object('kind', kd, 'source', src, 'lines', jsonb_array_length(p->'lines')), auth.uid());
  RETURN jsonb_build_object('saved',true,'id',rid);
END $function$;

CREATE OR REPLACE FUNCTION public.review_site_stock_update(p_id uuid, p_decision text, p_note text)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE r public.site_stock_submissions;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed or not found'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own update'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),'') WHERE id = p_id;
  INSERT INTO public.site_stock_events(submission_id, event_type, note, actor) VALUES (p_id, p_decision, nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $function$;

CREATE OR REPLACE FUNCTION public.review_site_receiving(p_id uuid, p_decision text, p_note text, p_lines jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE r public.site_stock_submissions; ln jsonb; i int := 0; orig jsonb;
BEGIN
  IF NOT public.pb_can_manage_tasks(auth.uid()) THEN RAISE EXCEPTION 'Only Admin or Manager can approve'; END IF;
  IF p_decision NOT IN ('approved','rejected') THEN RAISE EXCEPTION 'invalid decision'; END IF;
  SELECT * INTO r FROM public.site_stock_submissions WHERE id = p_id FOR UPDATE;
  IF NOT FOUND OR r.kind <> 'receiving' THEN RAISE EXCEPTION 'Receiving entry not found'; END IF;
  IF r.review_status <> 'pending' THEN RAISE EXCEPTION 'Already reviewed'; END IF;
  IF r.submitted_by = auth.uid() THEN RAISE EXCEPTION 'You cannot approve your own receiving'; END IF;
  IF p_decision = 'rejected' AND coalesce(trim(p_note),'') = '' THEN RAISE EXCEPTION 'Please write the reason for rejection'; END IF;
  IF p_decision = 'approved' THEN
    IF jsonb_typeof(p_lines) <> 'array' OR jsonb_array_length(p_lines) <> jsonb_array_length(r.lines) THEN RAISE EXCEPTION 'Approved lines do not match'; END IF;
    FOR ln IN SELECT * FROM jsonb_array_elements(p_lines) LOOP
      orig := r.lines->i;
      IF coalesce((ln->>'accepted')::numeric,-1) < 0 OR (ln->>'accepted')::numeric > coalesce((orig->>'received')::numeric,0) + 0.000001 THEN
        RAISE EXCEPTION 'Approved quantity for % must be between 0 and the received quantity', orig->>'item'; END IF;
      i := i + 1;
    END LOOP;
  END IF;
  UPDATE public.site_stock_submissions SET review_status = p_decision, reviewed_by = auth.uid(), reviewed_at = now(), review_note = nullif(trim(p_note),''),
    approved_lines = CASE WHEN p_decision = 'approved' THEN p_lines END WHERE id = p_id;
  INSERT INTO public.site_stock_events(submission_id, event_type, detail, note, actor) VALUES (p_id, p_decision, CASE WHEN p_decision='approved' THEN jsonb_build_object('lines', p_lines) END, nullif(trim(p_note),''), auth.uid());
  RETURN jsonb_build_object('saved',true,'status',p_decision);
END $function$;

CREATE OR REPLACE FUNCTION public.get_site_incoming(p_project_id uuid)
 RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE legacy text; cen jsonb; pur jsonb; sp jsonb;
BEGIN
  IF NOT (public.is_office_user(auth.uid()) OR public.pb_is_member(p_project_id, auth.uid())) THEN RAISE EXCEPTION 'not authorized'; END IF;
  SELECT local_project_id INTO legacy FROM public.team_projects WHERE id = p_project_id;
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', v->>'id', 'no', v->>'no', 'date', v->>'date', 'lines', v->'lines') ORDER BY v->>'date' DESC), '[]'::jsonb) INTO cen
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'whVouchers','[]'::jsonb)) v
   WHERE c.id = 1 AND v->>'kind' = 'CISS' AND v->>'status' = 'Approved' AND v->>'projectId' = legacy
     AND NOT EXISTS (SELECT 1 FROM public.site_stock_submissions s WHERE s.project_id = p_project_id AND s.kind='receiving' AND s.source='central' AND s.ref_id = v->>'id' AND s.review_status <> 'rejected');
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', t->>'id', 'date', t->>'date', 'item', t->>'material', 'unit', t->>'unit', 'qty', t->'qty', 'supplier', t->>'supplier', 'invoice', coalesce(t->>'invoiceNo', t->>'reference')) ORDER BY t->>'date' DESC), '[]'::jsonb) INTO pur
    FROM public.erp_cloud_state c, jsonb_array_elements(coalesce(c.data->'transactions','[]'::jsonb)) t
   WHERE c.id = 1 AND t->>'type' = 'Purchase' AND coalesce(t->>'category','') ~* '^material' AND coalesce(trim(t->>'material'),'') <> '' AND t->>'projectId' = legacy;
  SELECT coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'date', s.work_date, 'supplier', s.supplier, 'invoice', s.invoice_no, 'lines', s.lines) ORDER BY s.work_date DESC), '[]'::jsonb) INTO sp
    FROM public.site_stock_submissions s
   WHERE s.project_id = p_project_id AND s.kind = 'site_purchase' AND s.review_status = 'approved'
     AND NOT EXISTS (SELECT 1 FROM public.site_stock_submissions x WHERE x.project_id = p_project_id AND x.kind='receiving' AND x.source='site_purchase' AND x.ref_id = s.id::text AND x.review_status <> 'rejected');
  RETURN jsonb_build_object('central', cen, 'purchases', pur, 'site_purchases', sp);
END $function$;