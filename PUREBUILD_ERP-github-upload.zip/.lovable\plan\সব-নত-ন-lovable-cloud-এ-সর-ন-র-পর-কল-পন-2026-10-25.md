# সব নতুন Lovable Cloud-এ সরানোর পরিকল্পনা

## লক্ষ্য
অ্যাপের সব data, login আর স্টাফের রিপোর্ট পুরনো Cloud থেকে নতুন Lovable Cloud-এ সরানো, কিছু না মুছে।

## ধাপগুলো
1. **Backup (আপনি করবেন)** — Settings → Data Management → Download Backup JSON চাপবেন, আর একটা Safety Copy রাখবেন। পুরনো Cloud যেমন আছে তেমনই থাকবে, কিছু মোছা হবে না।
2. **নতুন Cloud-এ ঘর বানানো (আমি করব)** — অ্যাপ যা যা রাখে তার জন্য জায়গা: ERP-র মূল data, ব্যবহারকারী আর তাদের role, প্রজেক্ট ও সদস্য, BOQ, স্টাফের Site Progress রিপোর্ট ও ছবি, হাজিরা, মালের চাহিদা, যন্ত্রের লগ, Site Diary, Audit Trail। কে কী দেখতে পারবে তার নিয়ম সহ।
3. **স্টাফ বানানোর ব্যবস্থা (আমি করব)** — Access পাতার "Invite mobile staff" নতুন Cloud-এ সরাসরি কাজ করবে।
4. **আপনার Admin login (আমি করব)** — আপনার ইমেইল দিয়ে নতুন Cloud-এ Admin অ্যাকাউন্ট।
5. **Data তোলা** — Backup JSON থেকে ERP-র সব data নতুন Cloud-এ তোলা হবে। আগে গুনে মিলিয়ে দেখব (প্রজেক্ট, লেনদেন, Invoice-এর সংখ্যা)।
6. **অ্যাপকে নতুন Cloud-এর সাথে যুক্ত করা** — শুধু শেষে, সব মিলে গেলে। দরকার হলে এক লাইন বদলে আবার পুরনো Cloud-এ ফেরা যাবে।
7. **পরীক্ষা** — Admin login, Nazim-এর স্টাফ login, একটা রিপোর্ট পাঠানো।

## যা জানা দরকার
- পুরনো Cloud-এ স্টাফদের আগের পাঠানো রিপোর্ট আর ছবি আমি পড়তে পারি না। সেগুলো সরাতে হলে আপনাকে পুরনো Cloud থেকে সেগুলোর export দিতে হবে, নইলে সেগুলো পুরনো Cloud-এই থাকবে।
- পুরনো স্টাফ login সরবে না; নতুন Cloud-এ আবার Invite করতে হবে।
- Publish করার আগে পর্যন্ত আসল লিংক আগের মতোই পুরনো Cloud-এ চলবে।

## Technical details
- Tables (public, with GRANTs + RLS + has_role on user_roles): erp_cloud_state (+ erp_state_save rpc with revision check), profiles, user_roles, team_projects, team_project_members, team_boq_items, site_progress_reports, site_progress_report_boq_lines, site_boq_assignments, erp_site_attendance(+history), erp_attendance_submissions, site_material_requests(+lines), site_equipment_logs, site_diary_entries, audit_log; RPCs used by team-staff.js/team-erp.js recreated from their call signatures.
- Private bucket site-progress-photos with signed URLs.
- invite-staff becomes a createServerFn/server route using the admin client after verifying caller is admin.
- team-cloud-config.js switched last; old values kept in a comment for rollback.
