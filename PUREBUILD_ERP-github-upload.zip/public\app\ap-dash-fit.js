/* AP Dashboard one-page fit (display-only). Keeps the AP Dashboard tab in one fixed layout that fits
   the screen: compact summary row, KPI row, tools, then Recent Bills + AP Health filling the rest
   (tables scroll inside). Supplier Summary stays on the Suppliers & Vendors tab. Never saves data. */
(function () {
  if (typeof payables !== "function") return;
  const css = `
.apfit .apd{gap:8px;margin-bottom:8px}
.apfit .apd-hero{gap:8px}
.apfit .apd-card{padding:10px 12px;border-radius:13px}
.apfit .apd-main .big{font-size:24px;margin:3px 0 0}
.apfit .apd-main .sub{font-size:11px}
.apfit .apd-bar{margin:8px 0 4px;height:7px}
.apfit .apd-h{margin-bottom:6px}
.apfit .apd-donut{width:78px;height:78px;flex-basis:78px}
.apfit .apd-donut div{width:50px;height:50px;font-size:8px}
.apfit .apd-donut b{font-size:11px}
.apfit .apd-leg{gap:2px;font-size:10px}
.apfit .apd-sup{gap:4px;max-height:84px;overflow:auto}
.apfit .apd-sup .tr{height:5px}
.apfit .apd-kpis{grid-template-columns:repeat(var(--apk,6),minmax(0,1fr));gap:8px}
.apfit .apd-k{padding:7px 10px 7px 13px;border-radius:12px}
.apfit .apd-k b{font-size:15px;margin-top:2px}
.apfit .apd-k span{font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.apfit .apx2-bar{margin:0 0 8px!important}
.apfit .apx2-bar .btn{padding:6px 10px;font-size:11px}
.apfit .ap-overview-card[style*="margin-top"]{display:none!important}
.apfit .ap-overview-grid{height:var(--apfit-h,auto);min-height:220px;align-items:stretch;margin-top:0}
.apfit .ap-overview-grid>.ap-overview-card{display:flex;flex-direction:column;min-height:0;height:100%}
.apfit .ap-overview-grid>.ap-overview-card .tablewrap{flex:1 1 auto;height:auto!important;min-height:0;max-height:none!important;overflow:auto}
.apfit .ap-overview-grid>.ap-overview-card .ap-health-list{flex:1 1 auto;min-height:0;overflow:auto}
.apfit .ap-overview-grid .pager,.apfit .ap-overview-grid .pb-pager{display:none!important}
@media(max-width:1100px){.apfit .apd-hero{grid-template-columns:1.2fr 1fr 1fr}.apfit .apd-kpis{grid-template-columns:repeat(var(--apk,6),minmax(0,1fr))}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  function fit() {
    const ws = document.querySelector("#view .ap-workspace");
    const shell = ws && (ws.closest(".ap-page-shell") || ws);
    document.querySelectorAll(".apfit").forEach((n) => { if (n !== shell) n.classList.remove("apfit"); });
    if (!ws || (window.apTab || "overview") !== "overview" || !ws.querySelector(".apd") || innerWidth < 900) { shell && shell.classList.remove("apfit"); return; }
    shell.classList.add("apfit");
    const k = ws.querySelector(".apd-kpis"); if (k) k.style.setProperty("--apk", k.children.length || 6);
    ws.querySelectorAll(".ap-overview-grid .tablewrap").forEach((t) => t.setAttribute("data-no-pager", ""));
    const g = ws.querySelector(".ap-overview-grid"); if (!g) return;
    const top = g.getBoundingClientRect().top;
    const h = Math.floor(innerHeight - top - 16);
    g.style.setProperty("--apfit-h", Math.max(220, h) + "px");
  }
  window.apDashFit = fit;
  const base = payables;
  window.payables = payables = function () { const r = base.apply(this, arguments); try { fit(); requestAnimationFrame(fit); } catch (e) { console.error("AP fit", e); } return r; };
  let t; addEventListener("resize", () => { clearTimeout(t); t = setTimeout(fit, 80); });
})();
