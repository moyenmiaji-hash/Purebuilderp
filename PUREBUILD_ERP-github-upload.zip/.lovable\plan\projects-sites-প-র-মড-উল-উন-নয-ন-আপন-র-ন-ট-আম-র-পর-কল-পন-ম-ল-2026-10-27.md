# Projects / Sites পুরো মডিউল উন্নয়ন — আপনার নোট + আমার পরিকল্পনা মিলিয়ে

লাল ভুল বার্তাটা আসল কোড-ভুল না, নোটের লেখা। নোটে ১০টা ট্যাবের কথা আছে — সবগুলো ট্যাব অ্যাপে আগে থেকেই আছে। তাই নতুন ট্যাব/মেনু বানানো হবে না; যা আছে সেটাই ঠিক ও সম্পূর্ণ করা হবে। Overview আর Locations & Allocation-এর চেহারা বদলাবে না, শুধু হিসাব যাচাই হবে। পুরনো কোনো তথ্য মোছা বা বদলানো হবে না।

কাজটা বড়, তাই ৪টা ধাপে করব। প্রতিটা ধাপ শেষে আপনি Publish করে দেখবেন, তারপর পরের ধাপ।

## ধাপ ১: হিসাব ঠিক করা + BOQ & Work Progress (সবচেয়ে জরুরি)
- Overview-এর বাক্সগুলো (Contract, Income, Expenses, Net Profit, Work Completed, Client Due, Budget Used) একই নিয়মে হিসাব হচ্ছে কিনা যাচাই। একই খরচ দুই জায়গায় দুবার গোনা হলে ঠিক করা। প্রতিটা বাক্সে ছোট "i" দিয়ে লেখা থাকবে হিসাবটা কোথা থেকে আসে।
- BOQ & Work Progress টেবিল: Code, Trade, Description, Unit, Original Qty, Approved Qty, Rate, Amount, আগে হয়েছে, আজ, মোট হয়েছে, বাকি, % বার।
- Building / Floor / Room ফিল্টার আর খোঁজা।
- "Progress যোগ" ঘর: তারিখ, পরিমাণ, নোট, ছবি। বাকির বেশি বা শূন্যের কম দেওয়া যাবে না (Variation অনুমোদন থাকলে ছাড়া)।
- অফিসের Progress আর ফোরম্যানের Approve হওয়া রিপোর্ট একই ইতিহাসে দেখাবে, এবং ফোরম্যানের ফোনের "বাকি" পরিমাণেও অফিসের Progress ধরা হবে (আগে বাকি ছিল)। একই এন্ট্রি দুবার গোনা হবে না।
- Building / Floor ধরে মোট সারাংশ, Print ও CSV।

## ধাপ ২: Daily Reports + Materials + Labour & Equipment
- Daily Reports: Draft / Submitted / Approved / Rejected অবস্থা এক তালিকায়, তারিখ-Building-অবস্থা ফিল্টার, আবহাওয়া ও নোট ঘর। Approve একবারই Progress-এ যোগ হবে।
- Materials (প্রজেক্ট/Site অনুযায়ী): Opening, কেনা, এসেছে, বের হয়েছে, ফেরত, Adjustment (কারণ লিখতে হবে), বর্তমান বাকি, মূল্য, কম মাল সতর্কতা। মাল কম থাকলে বের করা যাবে না।
- Labour: কর্মী ধরে ও তারিখ ধরে হাজিরা, OT, পাওনা, পরিশোধ অবস্থা; একই দিনে একই কর্মীর হাজিরা দুবার হবে না।
- Equipment: নিজের/ভাড়া, ঘণ্টা/দিন, ভাড়া, তেল, মেরামত — খরচের সারাংশ।

## ধাপ ৩: Expenses & Payments + Quotations
- Expenses: Paid / Unpaid / Partial / Overdue অবস্থা, তারিখ-ধরন-Site-অবস্থা ফিল্টার, Voucher Print, প্রজেক্ট খরচ রিপোর্ট। মাল/শ্রমিক/যন্ত্রের খরচ একবারই গোনা হবে।
- Quotations (প্রজেক্ট ট্যাবে): নম্বর দুবার হবে না, Draft / Sent / Approved / Rejected / Expired, মেয়াদ শেষ হলে নিজে Expired দেখাবে, সংশোধনের ইতিহাস। Approved Quotation থেকে দুবার আয় বা প্রজেক্ট তৈরি হবে না।

## ধাপ ৪: Drawings & Documents + Project History
- Documents: শিরোনাম, ধরন, নম্বর, Revision, তারিখ, Building/Floor; আপলোড, দেখা, ডাউনলোড, খোঁজা; নতুন Revision দিলে পুরনোটা ইতিহাসে থাকবে। ফাইল ব্যক্তিগত জায়গায় থাকবে, সবার জন্য খোলা লিংক না।
- Project History: আগে বানানো Audit ব্যবস্থাই ব্যবহার হবে (নতুন আলাদা না)। প্রজেক্টের সব কাজ — কে, কখন, কী বদলাল, আগের/নতুন মান, কারণ — খোঁজা, তারিখ/মডিউল/ব্যবহারকারী ফিল্টার, পাতা ভাগ। সাধারণ ব্যবহারকারী মুছতে বা বদলাতে পারবে না।

## সব ধাপে যা মানা হবে
- পুরনো তথ্য মোছা/বদলানো নয়; নতুন তথ্য পাশের আলাদা ঘরে।
- প্রতিটা Publish-এর আগে নিরাপত্তা কপি।
- আলাদা টেস্ট ব্রাউজারে নকল তথ্য দিয়ে পরীক্ষা; ফোন ও কম্পিউটার দুই মাপে দেখা।
- শেষে বাংলায় রিপোর্ট: কী করা হলো, কী পরীক্ষা হলো, কী বাকি।

## যা এবার করা হবে না
- নতুন মেনু/ট্যাব, Overview ও Locations-এর চেহারা বদল।
- সার্ভারে "শুধু নিজের প্রজেক্ট দেখা" আটকানো — এর জন্য Cloud-এ তথ্য ভাগ করতে হবে; আলাদা অনুমতি নিয়ে পরে করা ভালো।

## Technical details
- All 10 project tabs already exist in `public/app/index.html`; extend existing renderers, no new pages. `setPage()` only.
- New fields as optional side fields/maps (`boq.approvedQty`, `progressEntry.source`, `stock.movement`, `quotation.revisions`, `doc.revisions`); old records load unchanged; missing BOQ status = Approved.
- Dedupe progress via stable entry ids (office entry id / cloud report line id) before summing.
- Documents use existing private storage bucket with signed URLs; history reads existing `audit_log` filtered by project.
- Bump `PB_SAFETY_VERSION` each phase.
