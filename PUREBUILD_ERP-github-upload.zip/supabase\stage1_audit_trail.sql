-- PURE BUILD — Stage 1: Audit Trail (safe: does NOT change or delete any existing data)
-- Run in the Cloud SQL editor only after taking a backup. Rollback: supabase/stage1_audit_trail_rollback.sql

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  actor_id uuid,
  actor_role text,
  project_id text,
  module text not null,
  record_id text,
  action text not null,            -- create | update | delete | void | approve | reject | permission_change
  old_values jsonb,
  new_values jsonb,
  reason text,
  status text not null default 'success'
);
create index if not exists audit_log_created_idx on public.audit_log (created_at desc);
create index if not exists audit_log_project_idx on public.audit_log (project_id);
create index if not exists audit_log_record_idx on public.audit_log (record_id);

-- Read-only for signed-in users; nobody can edit/delete from the app.
grant select on public.audit_log to authenticated;
grant all on public.audit_log to service_role;
alter table public.audit_log enable row level security;

create or replace function public.audit_can_read()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p
    where p.id = auth.uid() and p.status = 'active' and p.role in ('admin','auditor'))
$$;

drop policy if exists "Admins and auditors read audit log" on public.audit_log;
create policy "Admins and auditors read audit log" on public.audit_log
  for select to authenticated using (public.audit_can_read());

-- Strip secrets from any stored record.
create or replace function public.audit_clean(v jsonb)
returns jsonb language sql immutable as $$
  select case when v is null then null
    else v - 'password' - 'pass' - 'token' - 'access_token' - 'secret' - 'apiKey' end
$$;

-- Compares old vs new ERP data list by id and writes one audit row per change.
create or replace function public.audit_erp_state()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  k text;
  modules text[] := array['projects','transactions','boq','invoices','quotations','payables',
    'stock','employees','progress','dailyReports','runningBills','projectLocations'];
  o jsonb; n jsonb; rid text; role_now text;
begin
  select role into role_now from public.profiles where id = auth.uid();
  foreach k in array modules loop
    if jsonb_typeof(coalesce(new.data->k, '[]')) <> 'array' or jsonb_typeof(coalesce(old.data->k,'[]')) <> 'array' then
      if (old.data->k) is distinct from (new.data->k) then
        insert into audit_log(actor_id, actor_role, module, action, old_values, new_values)
        values (auth.uid(), role_now, k, 'update', null, jsonb_build_object('changed', true));
      end if;
      continue;
    end if;
    -- created + updated
    for n in select * from jsonb_array_elements(coalesce(new.data->k, '[]')) loop
      rid := n->>'id';
      if rid is null then continue; end if;
      select e into o from jsonb_array_elements(coalesce(old.data->k, '[]')) e where e->>'id' = rid limit 1;
      if o is null then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, new_values)
        values (auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'), k, rid, 'create', audit_clean(n));
      elsif o is distinct from n then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, old_values, new_values, reason)
        values (auth.uid(), role_now, coalesce(n->>'projectId', n->>'project', n->>'pid'), k, rid,
          case when lower(coalesce(n->>'status','')) in ('void','approved','rejected') and (o->>'status') is distinct from (n->>'status')
               then lower(case when lower(n->>'status')='approved' then 'approve' when lower(n->>'status')='rejected' then 'reject' else 'void' end)
               else 'update' end,
          audit_clean(o), audit_clean(n), n->>'reason');
      end if;
      o := null;
    end loop;
    -- deleted
    for o in select * from jsonb_array_elements(coalesce(old.data->k, '[]')) loop
      rid := o->>'id';
      if rid is null then continue; end if;
      if not exists (select 1 from jsonb_array_elements(coalesce(new.data->k, '[]')) e where e->>'id' = rid) then
        insert into audit_log(actor_id, actor_role, project_id, module, record_id, action, old_values)
        values (auth.uid(), role_now, coalesce(o->>'projectId', o->>'project', o->>'pid'), k, rid, 'delete', audit_clean(o));
      end if;
    end loop;
  end loop;
  return new;
end $$;

drop trigger if exists erp_state_audit on public.erp_cloud_state;
create trigger erp_state_audit after update on public.erp_cloud_state
  for each row execute function public.audit_erp_state();

-- Log role / permission changes on profiles.
create or replace function public.audit_profiles()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (old.role, old.status, old.permissions) is distinct from (new.role, new.status, new.permissions) then
    insert into audit_log(actor_id, actor_role, module, record_id, action, old_values, new_values)
    values (auth.uid(), (select role from profiles where id = auth.uid()), 'user_management', new.id::text,
      'permission_change',
      jsonb_build_object('role', old.role, 'status', old.status, 'permissions', old.permissions),
      jsonb_build_object('role', new.role, 'status', new.status, 'permissions', new.permissions));
  end if;
  return new;
end $$;

drop trigger if exists profiles_audit on public.profiles;
create trigger profiles_audit after update on public.profiles
  for each row execute function public.audit_profiles();
