/* Staff phone: Foreman Material Update (daily usage / damage / return) and Site Purchase.
   Sends to Cloud via submit_site_stock_update; office approves in Warehouse → Approval Center.
   Foreman never changes central warehouse balances. Closing = Opening + Received + Returns from WH − Used − Damaged − Returned. */
(function () {
  const cl = () => window.PB_STAFF_CLIENT;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const f2 = (v) => Number(n(v).toFixed(3)).toLocaleString("en-US");
  const today = () => new Date(Date.now() + 4 * 3600e3).toISOString().slice(0, 10);
  const calc = () => window.PBWhCalc;
  let sites = [], bal = [], mode = "daily", sending = false;

  function build() {
    if ($("pbs-stock")) return;
    const s = document.createElement("form"); s.id = "pbs-stock"; s.className = "card"; s.dataset.tab = "stockupd"; s.noValidate = true;
    s.innerHTML = `<div class="body"><div class="section-title"><span>📦</span><h2>Material stock update</h2></div>
      <p class="hint">Tell the office what you used, damaged or returned today. “On site now” already includes material the office sent you, so “Received” is only a confirmation. Bought it yourself? Use “Site purchase”. Stock changes only after the office approves.</p>
      <div class="pbs-seg"><button type="button" data-m="daily" class="on">Daily usage</button><button type="button" data-m="site_purchase">Site purchase</button></div>
      <div class="field"><label>Assigned site *</label><select id="pbs-site"></select></div>
      <div class="field"><label>Work date *</label><input id="pbs-date" type="date"></div>
      <div id="pbs-purchase" hidden><div class="field"><label>Supplier / shop *</label><input id="pbs-sup" maxlength="120"></div><div class="field"><label>Bill / invoice no.</label><input id="pbs-inv" maxlength="60"></div></div>
      <div id="pbs-lines"></div>
      <button type="button" class="btn" id="pbs-add" style="width:100%;margin:6px 0">＋ Add another material</button>
      <div class="field"><label>Remarks</label><textarea id="pbs-rem" rows="2" maxlength="400"></textarea></div>
      <div class="field"><label>Photo evidence</label><input id="pbs-ph" type="file" accept="image/*" multiple></div>
      <button type="submit" class="submit">Send to office</button><div class="notice" id="pbs-msg"></div>
      <h3 style="margin:16px 0 6px">My recent updates</h3><div id="pbs-hist" class="hint">—</div></div>`;
    document.querySelector("main.shell").appendChild(s);
    s.querySelectorAll(".pbs-seg button").forEach((b) => (b.onclick = () => { mode = b.dataset.m; s.querySelectorAll(".pbs-seg button").forEach((x) => x.classList.toggle("on", x === b)); $("pbs-purchase").hidden = mode !== "site_purchase"; drawLines(); }));
    $("pbs-site").onchange = loadBal;
    $("pbs-add").onclick = () => addLine({});
    $("pbs-lines").addEventListener("input", recalc);
    s.onsubmit = (e) => { e.preventDefault(); send(); };
  }
  function lineHtml(l) {
    const known = !!l.known;
    const name = known ? `<b>${esc(l.item)}</b> <small>${esc(l.unit)}</small><input type="hidden" class="pl-i" value="${esc(l.item)}"><input type="hidden" class="pl-u" value="${esc(l.unit)}">`
      : `<div class="pbs-g2"><input class="pl-i" placeholder="Material name" maxlength="80" value="${esc(l.item || "")}"><input class="pl-u" placeholder="Unit" maxlength="20" value="${esc(l.unit || "")}"></div>`;
    if (mode === "site_purchase") return `<div class="pbs-line">${name}<div class="pbs-g2"><label>Qty<input type="number" class="pl-q" min="0" step="any" inputmode="decimal"></label><label>Rate (AED)<input type="number" class="pl-r" min="0" step="any" inputmode="decimal"></label></div><div class="pbs-c"></div></div>`;
    return `<div class="pbs-line" data-open="${n(l.balance)}">${name}<div class="pbs-open">On site now: <b>${f2(l.balance)}</b></div>
      <div class="pbs-g4"><label>Received<input type="number" class="pl-rc" min="0" step="any" inputmode="decimal"></label><label>Used<input type="number" class="pl-us" min="0" step="any" inputmode="decimal"></label><label>Damaged<input type="number" class="pl-dm" min="0" step="any" inputmode="decimal"></label><label>Returned<input type="number" class="pl-rt" min="0" step="any" inputmode="decimal"></label></div><div class="pbs-c"></div></div>`;
  }
  function addLine(l) { $("pbs-lines").insertAdjacentHTML("beforeend", lineHtml(l)); recalc(); }
  function drawLines() {
    const box = $("pbs-lines"); if (!box) return;
    if (mode === "daily") box.innerHTML = bal.length ? bal.map((b) => lineHtml({ ...b, known: true })).join("") : `<p class="hint">No stock is recorded for this site yet. Use “Add another material” if you have something to report.</p>`;
    else box.innerHTML = lineHtml({});
    recalc();
  }
  function recalc() {
    document.querySelectorAll("#pbs-lines .pbs-line").forEach((d) => {
      const c = d.querySelector(".pbs-c"), g = (k) => n(d.querySelector(k)?.value);
      if (mode === "site_purchase") { c.textContent = g(".pl-q") ? "Amount: AED " + f2(g(".pl-q") * g(".pl-r")) : ""; return; }
      const o = { opening: Math.max(0, n(d.dataset.open) - g(".pl-rc")), received: g(".pl-rc"), used: g(".pl-us"), damaged: g(".pl-dm"), transferredOut: g(".pl-rt") };
      const close = calc() ? calc().siteClosing(o) : o.opening + o.received - o.used - o.damaged - o.transferredOut;
      // "Received" is a confirmation of what the office sent; the office Issue Voucher already added it.
      const err = calc() ? calc().checkSiteLine(o) : close < 0 ? "Not enough stock" : "";
      c.innerHTML = `Closing: <b>${f2(close)}</b>${err ? ` <span class="pbs-err">${esc(err)}</span>` : ""}`;
      d.classList.toggle("bad", !!err);
    });
  }
  async function loadSites() {
    const c = cl(), u = (await c.auth.getUser()).data.user; if (!u) return;
    const { data: m } = await c.from("team_project_members").select("project_id").eq("user_id", u.id).eq("status", "active");
    const ids = (m || []).map((x) => x.project_id);
    const { data } = ids.length ? await c.from("team_projects").select("id,name").in("id", ids) : { data: [] };
    sites = data || [];
    $("pbs-site").innerHTML = `<option value="">Choose your site</option>` + sites.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("");
    if (sites.length === 1) $("pbs-site").value = sites[0].id;
    $("pbs-date").value = today(); $("pbs-date").max = today();
    loadBal(); loadHist();
  }
  async function loadBal() {
    const pid = $("pbs-site").value; bal = [];
    if (pid) { const { data, error } = await cl().rpc("get_site_stock_balance", { p_project_id: pid }); if (!error) bal = (data || []).filter((b) => n(b.balance) > 0); }
    drawLines();
  }
  async function loadHist() {
    const { data } = await cl().from("site_stock_submissions").select("id,project_id,work_date,kind,lines,review_status,review_note,created_at").neq("kind", "receiving").order("created_at", { ascending: false }).limit(15);
    const nm = (id) => (sites.find((s) => s.id === id) || {}).name || "Site";
    $("pbs-hist").innerHTML = (data || []).map((r) => `<div class="pbs-h"><b>${r.kind === "daily" ? "📦 Daily usage" : "🛒 Site purchase"}</b> · ${esc(nm(r.project_id))} · ${r.work_date}<span class="pbs-st ${r.review_status}">${r.review_status === "pending" ? "Waiting" : r.review_status === "approved" ? "Approved" : "Rejected"}</span><small>${esc((r.lines || []).map((l) => l.item).join(", "))}${r.review_note ? " — Office: " + esc(r.review_note) : ""}</small></div>`).join("") || "No updates yet.";
  }
  async function send() {
    if (sending) return; const msg = $("pbs-msg"); msg.textContent = "";
    const pid = $("pbs-site").value, d = $("pbs-date").value;
    if (!pid) { msg.textContent = "Choose your site."; return; }
    if (!d || d > today()) { msg.textContent = "Choose a date that is not in the future."; return; }
    const lines = [];
    for (const el of document.querySelectorAll("#pbs-lines .pbs-line")) {
      const g = (k) => el.querySelector(k)?.value ?? "", item = g(".pl-i").trim(), unit = g(".pl-u").trim();
      if (mode === "site_purchase") {
        const q = n(g(".pl-q")), r = n(g(".pl-r")); if (!item && !q) continue;
        if (!item || !unit || q <= 0) { msg.textContent = "Each purchase line needs a material, unit and quantity."; return; }
        if (r < 0) { msg.textContent = "Rate cannot be negative."; return; }
        lines.push({ item, unit, qty: q, rate: r });
      } else {
        const o = { opening: Math.max(0, n(el.dataset.open) - n(g(".pl-rc"))), received: n(g(".pl-rc")), used: n(g(".pl-us")), damaged: n(g(".pl-dm")), transferredOut: n(g(".pl-rt")) };
        if (!o.received && !o.used && !o.damaged && !o.transferredOut) continue;
        if (!item || !unit) { msg.textContent = "Write the material name and unit."; return; }
        const err = calc() ? calc().checkSiteLine(o) : ""; if (err) { msg.textContent = item + ": " + err; return; }
        lines.push({ item, unit, opening: o.opening, received: o.received, used: o.used, damaged: o.damaged, returned: o.transferredOut, closing: calc() ? calc().siteClosing(o) : 0 });
      }
    }
    if (!lines.length) { msg.textContent = "Enter at least one quantity."; return; }
    if (mode === "site_purchase" && !$("pbs-sup").value.trim()) { msg.textContent = "Write the supplier / shop name."; return; }
    sending = true; const btn = document.querySelector("#pbs-stock button[type=submit]"); btn.disabled = true; msg.textContent = "Sending…";
    try {
      const key = "fsu-" + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + "-" + Math.random());
      const photos = [], prof = window.PB_STAFF_PROFILE || {};
      for (const file of [...($("pbs-ph").files || [])].slice(0, 6)) {
        const path = `${prof.organization_id}/${pid}/stock-${key}/${Date.now()}-${file.name.replace(/[^\w.-]+/g, "_")}`;
        const { error } = await cl().storage.from("site-progress-photos").upload(path, file, { contentType: file.type, upsert: false });
        if (error) throw error; photos.push({ path, original_name: file.name, size: file.size });
      }
      const { error } = await cl().rpc("submit_site_stock_update", { p_project_id: pid, p: { idempotency_key: key, kind: mode, work_date: d, lines, supplier: $("pbs-sup").value.trim(), invoice_no: $("pbs-inv").value.trim(), remarks: $("pbs-rem").value.trim(), photos } });
      if (error) throw error;
      msg.textContent = "✅ Sent. The office will approve it."; $("pbs-rem").value = ""; $("pbs-ph").value = ""; $("pbs-sup").value = ""; $("pbs-inv").value = "";
      drawLines(); loadHist();
    } catch (e) { msg.textContent = "Could not send: " + (e.message || e); }
    finally { sending = false; btn.disabled = false; }
  }
  function addQuick() { document.querySelectorAll(".fw-quick").forEach((q) => { if (!q.querySelector("[data-goto=stockupd]")) q.insertAdjacentHTML("beforeend", `<button type="button" data-goto="stockupd">🧮<span>Stock update</span></button>`); }); }

  const css = document.createElement("style");
  css.textContent = `.pbs-seg{display:flex;gap:6px;margin:4px 0 10px}.pbs-seg button{flex:1;border:1px solid #DCD8EE;background:#fff;color:#29283A;border-radius:12px;padding:9px;font-weight:700}.pbs-seg button.on{background:linear-gradient(135deg,#8875DC,#5B3FC4);color:#fff;border-color:transparent}
  .pbs-line{border:1px solid #E4E1F3;border-radius:14px;padding:10px;margin:8px 0;background:#fff}.pbs-line.bad{border-color:#dc2626;background:#fef2f2}.pbs-open{font-size:12.5px;color:#6b6889;margin:2px 0 6px}
  .pbs-g4{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.pbs-g2{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:4px}.pbs-g4 label,.pbs-g2 label{font-size:11px;font-weight:700;color:#6b6889;display:flex;flex-direction:column;gap:2px}
  .pbs-g4 input,.pbs-g2 input{width:100%;min-width:0;box-sizing:border-box}.pbs-c{font-size:12.5px;margin-top:6px}.pbs-err{color:#dc2626;font-weight:700}
  .pbs-h{border-bottom:1px dashed #E4E1F3;padding:6px 0;display:flex;flex-wrap:wrap;gap:4px;align-items:center}.pbs-h small{width:100%;color:#6b6889}.pbs-st{margin-left:auto;border-radius:8px;padding:1px 8px;font-size:11px;font-weight:800;background:#fef3c7;color:#92400e}.pbs-st.approved{background:#dcfce7;color:#166534}.pbs-st.rejected{background:#fee2e2;color:#991b1b}
  .fw-quick button[data-goto=stockupd]{background:linear-gradient(150deg,#0891b2,#164e63)!important;border-color:#06b6d4!important}
  @media(max-width:380px){.pbs-g4{grid-template-columns:1fr 1fr}}`;
  document.head.appendChild(css);

  const boot = setInterval(() => {
    if (!cl() || !document.querySelector("main.shell")) return; clearInterval(boot);
    build(); addQuick(); setInterval(addQuick, 2000);
    if (window.PB_STAFF_PROFILE) loadSites(); window.addEventListener("pb:staff-ready", loadSites);
  }, 200);
})();
