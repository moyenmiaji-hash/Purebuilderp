/* PURE_BUILD Warehouse & Stock formulas (pure, no DOM). Tested in src/test/stock-calc.test.ts */
(function (root) {
  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  const sign = (x) => (x.direction === "In" ? 1 : -1);
  const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };

  /** Date range for a period key. Returns {from,to} as YYYY-MM-DD ("" = open). */
  function periodRange(key, todayStr, from, to) {
    const t = todayStr ? new Date(todayStr + "T00:00:00") : new Date();
    const y = t.getFullYear(), m = t.getMonth();
    const first = (yy, mm) => iso(new Date(yy, mm, 1));
    const last = (yy, mm) => iso(new Date(yy, mm + 1, 0));
    switch (key) {
      case "today": return { from: iso(t), to: iso(t) };
      case "month": return { from: first(y, m), to: last(y, m) };
      case "lastMonth": return { from: first(y, m - 1), to: last(y, m - 1) };
      case "3m": return { from: first(y, m - 2), to: last(y, m) };
      case "6m": return { from: first(y, m - 5), to: last(y, m) };
      case "year": return { from: y + "-01-01", to: y + "-12-31" };
      case "lastYear": return { from: (y - 1) + "-01-01", to: (y - 1) + "-12-31" };
      case "custom": return { from: from || "", to: to || "" };
      default: return { from: "", to: "" };
    }
  }

  /** Movement category used by reports: received / issued / returned / adjIn / adjOut / damaged / transferIn / transferOut */
  function kindOf(x) {
    const t = String(x.movement || x.source || "").toLowerCase();
    if (/return/.test(t)) return x.direction === "In" ? "returned" : "issued";
    if (/wastage|damage/.test(t)) return "damaged";
    if (/transfer/.test(t)) return x.direction === "In" ? "transferIn" : "transferOut";
    if (/adj/.test(t)) return x.direction === "In" ? "adjIn" : "adjOut";
    return x.direction === "In" ? "received" : "issued";
  }

  /** Material statement for a period. keyFn groups rows (e.g. material+unit). */
  function statement(rows, range, keyFn) {
    const map = new Map();
    const get = (x) => {
      const k = keyFn(x);
      if (!map.has(k)) map.set(k, { key: k, item: x.item, unit: x.unit, opening: 0, received: 0, issued: 0, returned: 0, adjIn: 0, adjOut: 0, damaged: 0, transferIn: 0, transferOut: 0 });
      return map.get(k);
    };
    rows.forEach((x) => {
      const r = get(x), q = num(x.qty), d = String(x.date || "");
      if (range.from && d < range.from) { r.opening += sign(x) * q; return; }
      if (range.to && d > range.to) return;
      r[kindOf(x)] += q;
    });
    return [...map.values()].map((r) => ({
      ...r,
      closing: r.opening + r.received + r.returned + r.adjIn + r.transferIn - r.issued - r.damaged - r.adjOut - r.transferOut,
    }));
  }

  /** Ledger with running balance per key, oldest first. */
  function ledger(rows, keyFn) {
    const bal = new Map();
    return rows.slice().sort((a, b) => String(a.date || "").localeCompare(String(b.date || "")) || num(a._seq) - num(b._seq))
      .map((x) => { const k = keyFn(x); const v = (bal.get(k) || 0) + sign(x) * num(x.qty); bal.set(k, v); return { row: x, balance: v }; });
  }

  /** Check an issue voucher: lines [{key,qty}] against available map {key:qty}. Returns list of shortages. */
  function issueShortages(lines, available) {
    const need = new Map();
    lines.forEach((l) => need.set(l.key, (need.get(l.key) || 0) + num(l.qty)));
    const out = [];
    need.forEach((q, k) => { const a = num(available[k]); if (q > a + 1e-9) out.push({ key: k, need: q, available: a }); });
    return out;
  }

  /** Next voucher number like GRN-0007 */
  function nextNo(prefix, existing) {
    let max = 0;
    (existing || []).forEach((n) => { const m = String(n || "").match(/(\d+)$/); if (m && String(n).startsWith(prefix)) max = Math.max(max, Number(m[1])); });
    return prefix + "-" + String(max + 1).padStart(4, "0");
  }

  const api = { periodRange, kindOf, statement, ledger, issueShortages, nextNo };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.PBStockCalc = api;
})(typeof window !== "undefined" ? window : globalThis);
