# নতুন Supabase project চালু করা

এই ধাপগুলো নতুন, খালি Supabase project-এর জন্য। আগের browser-এর ERP data এই project-এ নিজে থেকে কপি হবে না।

1. Supabase Dashboard-এ project খুলে **SQL Editor → New query** নির্বাচন করুন।
2. VS Code-এ `supabase/migrations/20261110110000_initial_setup.sql` খুলুন। পুরো ফাইল কপি করে SQL Editor-এ paste করে **Run** চাপুন। এটি একবারই চালাবেন।
3. Supabase Dashboard-এ **Authentication → Users → Add user** থেকে নিজের email ও password দিয়ে login account তৈরি করুন, যদি আগে না থাকে।
4. ঠিক একটি Auth user থাকলে `supabase/bootstrap_first_admin.sql` চালান। একাধিক Auth user থাকলে নির্দিষ্ট account-কে `profiles.role='admin'` এবং `user_roles`-এ `admin` row দিয়ে promote করুন।
5. `supabase/migrations/20261110161000_security_hardening.sql` চালান। Admin access email/password দিয়েই হবে; এই handover configuration-এ MFA বাধ্যতামূলক নয়।
6. `supabase/migrations/20261110170000_tenant_scoped_erp_state.sql` চালান। এটি বিদ্যমান ERP snapshot/history রেখে company-scoped row বানায়। একাধিক company profile থাকলেও কোনো পুরনো row-এর owner নিশ্চিত না হলে migration থেমে যায়; নিজে থেকে কোনো company-তে data assign করে না।
7. `supabase/migrations/20261110180000_audit_project_and_storage_events.sql` চালান।
8. `supabase/migrations/20261110183000_fix_erp_state_audit_array_types.sql` চালান; এটি snapshot-এর array/object shape বদলালে audit trigger-এর error আটকায়।
9. অ্যাপ refresh করে Admin email/password দিয়ে sign in করুন। ERP ও Cloud Team একই Supabase auth session ব্যবহার করে।

Initial migration-এর আগে Auth users তৈরি থাকলে তাদের default non-admin profile migration-এ তৈরি হবে। `bootstrap_first_admin.sql` শুধু ঠিক একটি Auth user থাকলেই ব্যবহারযোগ্য।

`supabase/migrations/20261110110000_initial_setup.sql`-এ ERP schema, access policies এবং private file storage তৈরি হয়। এতে 0002–0004 migrations ইচ্ছাকৃতভাবে বাদ, কারণ সেগুলো অন্য একটি email-কে Admin করত।

Sign in-এর পর ERP snapshot একই organization-এর company-specific browser storage key-তে load হয়; পুরনো unscoped browser data আলাদা করে import নির্বাচন না করা পর্যন্ত অক্ষত থাকে। কোনো Supabase **secret/service-role key** browser code-এ বা এই SQL ফাইলগুলোতে রাখবেন না। Project URL ও Publishable key শুধু `public/app/team-cloud-config.js`-এ থাকে।

## Security settings and deployment

Existing Supabase project-এ migration চালানোর আগে database backup নিন, আগের migration state পরীক্ষা করুন, এবং `20261110161000`, `20261110170000`, `20261110180000`, তারপর `20261110183000` ক্রমানুসারে চালান। একই migration দ্বিতীয়বার চালাবেন না।

`supabase/config.toml` local Supabase CLI stack-এর জন্য signup বন্ধ, TOTP, refresh-token rotation, IP-based sign-in rate limit এবং session timeout সেট করে। এটি Supabase-hosted project-এ নিজে থেকে কোনো পরিবর্তন করে না। Hosted project's Auth dashboard-এ একই settings আলাদাভাবে দিন। সেখানে minimum password length 12, uppercase/lowercase/digit/symbol requirement, leaked-password protection (plan-এ থাকলে), public signup off, TOTP, CAPTCHA, rate limit ও session expiry configure করুন।

Turnstile site key `public/app/team-cloud-config.js`-এ বসান এবং Supabase Auth CAPTCHA চালু করুন। Cloudflare WAF/rate limit app-এর `/api/*` route রক্ষা করতে পারে; browser থেকে Supabase Auth-এ যাওয়া request সরাসরি Supabase-এ যায়, তাই সেগুলোর rate limit Supabase dashboard-এ configure করতে হবে।

Cloudflare-এ static-only Pages deploy নয়, **Workers with Static Assets** ব্যবহার করুন: এই app-এর build `cloudflare-module` Worker output তৈরি করে এবং server API route আছে। Build command `npm run build`; Nitro deploy step `npx nitro deploy --prebuilt`। `VITE_SUPABASE_URL` ও `VITE_SUPABASE_PUBLISHABLE_KEY` build environment variables হিসেবে দিন। `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` এবং `SUPABASE_SERVICE_ROLE_KEY` Worker runtime secrets/bindings-এ দিন; service-role key কখনো `VITE_` prefix, browser config বা Git-এ দেবেন না। `public/_headers` Cloudflare static assets-এর জন্য security headers যোগ করে।

Migration-গুলো RLS, private buckets, project/company path checks এবং সীমিত append-only audit যোগ করে। `erp_cloud_state` এখন প্রতি organization-এর জন্য আলাদা snapshot রাখে, কিন্তু ERP business records এখনও একটি JSON snapshot-এ আছে; পূর্ণ SaaS tenancy-এর জন্য সেগুলোকে company-aware table-এ ধাপে ধাপে স্থানান্তর এবং প্রতিটি table-এ RLS দরকার। বর্তমান handover project-এ migration-গুলো প্রয়োগ করা হয়েছে; একই project-এ এগুলো আবার চালাবেন না।
