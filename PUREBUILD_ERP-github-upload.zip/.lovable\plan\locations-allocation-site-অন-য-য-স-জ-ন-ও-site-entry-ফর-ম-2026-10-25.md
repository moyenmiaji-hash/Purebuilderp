# Locations & Allocation: Site অনুযায়ী সাজানো ও Site entry ফর্ম

এই ভুল বার্তাটা আসল কোড-ভুল না, এটা নোট ফাইলের লেখা। নোটে যা চাওয়া হয়েছে তার পরিকল্পনা নিচে। পুরনো তথ্য মোছা হবে না, নতুন মেনু যোগ হবে না।

## ১. Site বাছলে শুধু ওই Site-এর Location
- উপরে "Building A" বাছলে Locations & Allocation-এ শুধু Building A-এর Floor/Room সারি দেখাবে ("jjj" বা অন্য Site দেখাবে না)।
- উপরের ৪টা মোট (Locations, BOQ Items, Total Qty, Total Amount) ওই Site-এর হিসাব দেখাবে।
- "All Sites" বাছলে আগের মতো সব দেখাবে।

## ২. Add location: Building নিজে থেকে বসানো
- কোনো Site বাছা থাকলে "Building / structure" ঘরে ওই Site-এর নাম নিজে থেকে বসে থাকবে, যেন শুধু Floor/level আর Room/area লিখে "Add location" দিলেই হয়।
- একটা Location যোগ করার পর Building ঘরটা খালি হবে না; Floor আর Room খালি হবে, যাতে পরের Floor (যেমন 2nd Floor) সাথে সাথে যোগ করা যায়।
- এরপর আগের মতো ওই সারির "Add BOQ item here" চেপে BOQ যোগ করা যাবে।

## ৩. "+ Add Site"-এ সুন্দর entry ফর্ম
- ছোট ব্রাউজার-পপআপের বদলে একটা পরিষ্কার ফর্ম খুলবে: Site / Building নাম (জরুরি), আর চাইলে প্রথম Floor ও Room।
- Save দিলে Site তৈরি হবে আর সাথে সাথে বাছাই হয়ে যাবে। একই নাম আগে থাকলে সতর্ক করবে।

## ৪. Site Remove
- Site বোতামের পাশে ছোট "×" থাকবে। চাপলে নিশ্চিত করতে জিজ্ঞেস করবে।
- শুধু ওই Site-এর খালি Location-গুলো সরবে। যে Site-এ BOQ, খরচ বা মাল আছে, সেটা মোছা যাবে না; জানিয়ে দেবে কেন — যাতে কোনো হিসাব হারায় না।

## ৫. "Add BOQ item here"-এর পাশে "View all"
- প্রতিটা Location সারিতে "View all" বোতাম থাকবে। চাপলে একটা পপআপে ওই Location-এর সব BOQ item দেখাবে (ID, বিবরণ, Qty, Rate, Amount, কাজ কতটা হয়েছে) আর নিচে মোট। প্রতিটা item চাপলে আগের BOQ বিস্তারিত পপআপ খুলবে।

## যা করা হবে না
- নতুন মেনু/পাতা, হিসাবের নিয়ম বদল, পুরনো তথ্য মোছা — কিছুই না।

## Technical details
- Filter `projectLocations` rows and totals with existing `matchBuilding` using the selected site.
- Prefill building input from selected site; keep it after add.
- Add Site modal reuses existing modal styles; pushes `{building, floor?, area?}`.
- Remove: block if any BOQ/transaction/stockTxn/dailyReport has that building; otherwise drop its location rows.
- View all modal lists BOQ items matched by building/floor/area. Pages still change via `setPage()`. Tested only in a throwaway browser.
