// Labour & HR add-on (p67): attendance month scroll / View all, and Salary Statement (paid vs due).
// Read-only: only reads db.workers / db.hrPayroll and hrPayrollCalc(); never saves data.
(function () {
  const E = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : "AED " + Number(v || 0).toLocaleString());
  const DB = () => { try { return db; } catch (e) { return window.db || {}; } };
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const mLabel = (k) => { const [y, m] = k.split("-"); return MON[+m - 1] + " " + y; };

  // ---------- Attendance: View all + scroll buttons ----------
  function attendanceTools() {
    const wrap = document.querySelector(".hr-attendance-wrap");
    if (!wrap || wrap.dataset.sp) return;
    wrap.dataset.sp = 1;
    const bar = document.createElement("div");
    bar.className = "hsp-attbar";
    bar.innerHTML = `<button type="button" class="hsp-b" data-a="start" title="Day 1">⏮</button><button type="button" class="hsp-b" data-a="left" title="Earlier days">‹ Earlier</button><button type="button" class="hsp-b" data-a="right" title="Later days">Later ›</button><button type="button" class="hsp-b" data-a="end" title="Last day">⏭</button><span class="hsp-sep"></span><button type="button" class="hsp-b hsp-all" data-a="all">⛶ View all month</button>`;
    wrap.parentElement.insertBefore(bar, wrap);
    const step = () => Math.max(200, wrap.clientWidth * 0.6);
    bar.onclick = (ev) => {
      const b = ev.target.closest("button"); if (!b) return;
      const a = b.dataset.a;
      if (a === "left") wrap.scrollBy({ left: -step(), behavior: "smooth" });
      else if (a === "right") wrap.scrollBy({ left: step(), behavior: "smooth" });
      else if (a === "start") wrap.scrollTo({ left: 0, behavior: "smooth" });
      else if (a === "end") wrap.scrollTo({ left: wrap.scrollWidth, behavior: "smooth" });
      else if (a === "all") {
        const on = !wrap.classList.contains("hsp-full");
        wrap.classList.toggle("hsp-full", on);
        b.textContent = on ? "✕ Close full view" : "⛶ View all month";
        b.classList.toggle("on", on);
      }
    };
  }

  // ---------- Salary Statement ----------
  function monthsFor(w, payroll) {
    const set = new Set(payroll.filter((p) => String(p.workerId) === String(w.id)).map((p) => p.month));
    const now = new Date(); const cur = now.toISOString().slice(0, 7);
    const start = w.joiningDate ? w.joiningDate.slice(0, 7) : null;
    for (let i = 0; i < 24; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (start && k < start) break;
      try { const c = hrPayrollCalc(w, k); if (c.present > 0 || c.otHours > 0) set.add(k); } catch (e) {}
    }
    return [...set].filter((k) => k <= cur).sort();
  }
  function rowsFor(w) {
    const pay = DB().hrPayroll || [];
    return monthsFor(w, pay).map((k) => {
      const r = pay.find((p) => String(p.workerId) === String(w.id) && p.month === k);
      const c = hrPayrollCalc(w, k);
      const earned = r && r.status === "Paid" ? Number(r.calculatedNet ?? r.net ?? c.net) : c.net;
      const paid = r && r.status === "Paid" ? Number(r.net || 0) : 0;
      return { k, c, r, earned, paid, due: Math.max(0, earned - paid) };
    });
  }
  function workers() {
    const pid = (() => { try { return selectedProject || ""; } catch (e) { return ""; } })();
    return (typeof hrWorkers === "function" ? hrWorkers() : DB().workers || []).filter((w) => !pid || w.projectId === pid);
  }

  function curMonth() { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
  function shiftM(k, n) { const [y, m] = k.split("-").map(Number); const d = new Date(y, m - 1 + n, 1); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
  let ST = { month: curMonth(), filter: "all", sel: null, view: "emp" };
  function openStatement(focusId) {
    if (focusId) { ST.sel = focusId; ST.view = "emp"; }
    let ov = document.getElementById("hspOv"); if (ov) ov.remove();
    ov = document.createElement("div"); ov.id = "hspOv"; ov.className = "hsp-ov";
    document.body.appendChild(ov);
    const build = () => {
      const mk = ST.month; // "" = all months
      const base = workers().map((w) => {
        const rs = rowsFor(w);
        const upto = mk ? rs.filter((r) => r.k <= mk) : rs;
        const cur = mk ? rs.find((r) => r.k === mk) : null;
        const prevRows = mk ? rs.filter((r) => r.k < mk && r.due > 0) : [];
        const prevDue = prevRows.reduce((a, x) => a + x.due, 0);
        const prevMonths = prevRows.map((r) => { const [y, m] = r.k.split("-").map(Number); return new Date(y, m - 1, 1).toLocaleString("en-US", { month: "short", year: "numeric" }) + " " + M(r.due); }).join(", ");
        const earned = mk ? (cur ? cur.earned : 0) : rs.reduce((a, x) => a + x.earned, 0);
        const paid = mk ? (cur ? cur.paid : 0) : rs.reduce((a, x) => a + x.paid, 0);
        const due = mk ? (cur ? cur.due : 0) : rs.reduce((a, x) => a + x.due, 0);
        const totalDue = upto.reduce((a, x) => a + x.due, 0);
        return { w, rs: upto, cur, prevDue, prevMonths, earned, paid, due, totalDue };
      });
      const T = base.reduce((a, x) => ({ e: a.e + x.earned, p: a.p + x.paid, d: a.d + x.due, pv: a.pv + x.prevDue, t: a.t + x.totalDue }), { e: 0, p: 0, d: 0, pv: 0, t: 0 });
      const vis = base.filter((x) => ST.filter === "all" || (ST.filter === "due" ? x.totalDue > 0 : x.totalDue <= 0)).sort((a, b) => b.totalDue - a.totalDue || String(a.w.name).localeCompare(String(b.w.name)));
      const nDue = base.filter((x) => x.totalDue > 0).length;
      const ml = mk ? mLabel(mk) : "All months";
      ov.innerHTML = `<div class="hsp-box"><div class="hsp-head"><div><h3>Salary Statement · ${E(ml)}</h3><p>Earned, paid and due for the month, plus unpaid salary from earlier months.</p></div><div class="hsp-acts"><button class="hsp-b" id="hspPrev" ${mk ? "" : "disabled"}>‹</button><input type="month" id="hspM" value="${E(mk)}"><button class="hsp-b" id="hspNext" ${mk && mk < curMonth() ? "" : "disabled"}>›</button><button class="hsp-b ${mk ? "" : "on"}" id="hspAll">All months</button><button class="hsp-b ${ST.view === "sum" ? "on" : ""}" id="hspSum">☰ All employees</button><input id="hspQ" type="search" placeholder="Search employee…"><button class="hsp-b" id="hspPrint">🖨 Print</button><button class="hsp-b" id="hspCsv">⬇ CSV</button><button class="hsp-b hsp-x" id="hspClose">✕</button></div></div>
      <div class="hsp-kpis hsp-k5">${mk ? `<div class="r"><small>Previous months due</small><b>${M(T.pv)}</b></div>` : ""}<div><small>${mk ? "Earned this month" : "Total earned"}</small><b>${M(T.e)}</b></div><div class="g"><small>${mk ? "Paid this month" : "Total paid"}</small><b>${M(T.p)}</b></div><div class="r"><small>${mk ? "Due this month" : "Total due"}</small><b>${M(T.d)}</b></div>${mk ? `<div class="r"><small>Total due (up to ${E(ml)})</small><b>${M(T.t)}</b></div>` : ""}<div><small>Employees with due</small><b>${nDue} / ${base.length}</b></div></div>
      <div class="hsp-body"><div class="hsp-side"><div class="hsp-f">${[["all", "All " + base.length], ["due", "With due " + nDue], ["clear", "Clear " + (base.length - nDue)]].map(([k, l]) => `<button type="button" data-f="${k}" class="${ST.filter === k ? "on" : ""}">${l}</button>`).join("")}</div><div class="hsp-list" id="hspList">${vis.map((x) => `<button type="button" class="hsp-emp" data-id="${E(x.w.id)}" data-s="${E((x.w.name + " " + (x.w.workerId || "")).toLowerCase())}"><span><b>${E(x.w.name)}</b><small>${E(x.w.workerId || "")} · ${E(typeof projectName === "function" ? projectName(x.w.projectId) : "")}</small>${mk && x.prevDue > 0 ? `<small class="r">Prev due ${M(x.prevDue)}${x.prevMonths ? " (" + E(x.prevMonths) + ")" : ""}</small>` : ""}</span><em class="${x.totalDue > 0 ? "r" : "g"}">${x.totalDue > 0 ? "Due " + M(x.totalDue) : "Clear"}</em></button>`).join("") || '<p class="hsp-empty">No employees.</p>'}</div></div><div class="hsp-detail" id="hspDetail"></div></div></div>`;
      const d = ov.querySelector("#hspDetail");
      const showSum = () => {
        ST.view = "sum"; ov.querySelectorAll(".hsp-emp").forEach((b) => b.classList.remove("on"));
        d.innerHTML = `<div class="hsp-dh"><h4>All employees · ${E(ml)}</h4><span>${vis.length} employees</span></div><table class="hsp-t"><thead><tr><th>#</th><th>Employee</th><th>ID</th>${mk ? "<th>Prev. due</th><th>Present</th>" : ""}<th>Earned</th><th>Paid</th><th>Due</th>${mk ? "<th>Total due</th>" : ""}</tr></thead><tbody>${vis.map((x, i) => `<tr class="hsp-row" data-id="${E(x.w.id)}" data-s="${E((x.w.name + " " + (x.w.workerId || "")).toLowerCase())}"><td>${i + 1}</td><td><b>${E(x.w.name)}</b></td><td>${E(x.w.workerId || "")}</td>${mk ? `<td class="${x.prevDue > 0 ? "r" : ""}">${x.prevDue ? M(x.prevDue) + (x.prevMonths ? `<br><small style="font-weight:500;opacity:.85">${E(x.prevMonths)}</small>` : "") : "—"}</td><td>${x.cur ? x.cur.c.present : 0}</td>` : ""}<td>${M(x.earned)}</td><td class="g">${x.paid ? M(x.paid) : "—"}</td><td class="${x.due > 0 ? "r" : "g"}">${x.due > 0 ? M(x.due) : "✓ 0"}</td>${mk ? `<td class="${x.totalDue > 0 ? "r" : "g"}"><b>${x.totalDue > 0 ? M(x.totalDue) : "✓ 0"}</b></td>` : ""}</tr>`).join("") || `<tr><td colspan="9" class="hsp-empty">No employees.</td></tr>`}</tbody><tfoot><tr><td colspan="3">TOTAL</td>${mk ? `<td>${M(vis.reduce((a, x) => a + x.prevDue, 0))}</td><td></td>` : ""}<td>${M(vis.reduce((a, x) => a + x.earned, 0))}</td><td>${M(vis.reduce((a, x) => a + x.paid, 0))}</td><td>${M(vis.reduce((a, x) => a + x.due, 0))}</td>${mk ? `<td>${M(vis.reduce((a, x) => a + x.totalDue, 0))}</td>` : ""}</tr></tfoot></table>`;
        d.querySelectorAll(".hsp-row").forEach((r) => (r.onclick = () => show(r.dataset.id)));
      };
      const show = (wid) => {
        const x = base.find((a) => String(a.w.id) === String(wid)); if (!x) return;
        ST.view = "emp"; ST.sel = wid;
        ov.querySelectorAll(".hsp-emp").forEach((b) => b.classList.toggle("on", b.dataset.id === String(wid)));
        const rs = x.rs.slice().reverse();
        d.innerHTML = `<div class="hsp-dh"><h4>${E(x.w.name)}</h4><span>Basic ${M(x.w.basicSalary || 0)} · Daily ${M(x.w.rate || 0)} · ${Number(x.w.workHours || 8)} h/day · OT ${M(x.w.otRate || (x.w.rate ? x.w.rate / (x.w.workHours || 8) : 0))}/h</span></div>
        <div class="hsp-mini">${mk ? `<div class="r"><small>Previous due</small><b>${M(x.prevDue)}</b>${x.prevMonths ? `<small>${E(x.prevMonths)}</small>` : ""}</div>` : ""}<div><small>${mk ? "Earned " + E(ml) : "Earned"}</small><b>${M(x.earned)}</b></div><div class="g"><small>Paid</small><b>${M(x.paid)}</b></div><div class="r"><small>${mk ? "Total due now" : "Due"}</small><b>${M(mk ? x.totalDue : x.due)}</b></div></div>
        <table class="hsp-t"><thead><tr><th>Month</th><th>Present</th><th>OT h</th><th>Basic</th><th>OT Pay</th><th>Allow.</th><th>Deduct.</th><th>Earned</th><th>Paid</th><th>Paid on</th><th>Due</th></tr></thead><tbody>${rs.map((r) => `<tr class="${r.k === mk ? "hsp-cur" : ""}"><td>${mLabel(r.k)}</td><td>${r.c.present}</td><td>${r.c.otHours}</td><td>${M(r.c.basic)}</td><td>${M(r.c.ot)}</td><td>${M(r.c.allowance)}</td><td>${M(r.c.advance + r.c.deduction)}</td><td><b>${M(r.earned)}</b></td><td class="g">${r.paid ? M(r.paid) : "—"}</td><td>${r.r && r.r.paymentDate ? E(r.r.paymentDate) + " · " + E(r.r.paymentMethod || "") : "—"}</td><td class="${r.due > 0 ? "r" : "g"}"><b>${r.due > 0 ? M(r.due) : "✓ 0"}</b></td></tr>`).join("") || '<tr><td colspan="11" class="hsp-empty">No salary months yet.</td></tr>'}</tbody><tfoot><tr><td colspan="7">TOTAL</td><td>${M(x.rs.reduce((a, r) => a + r.earned, 0))}</td><td>${M(x.rs.reduce((a, r) => a + r.paid, 0))}</td><td></td><td>${M(x.totalDue)}</td></tr></tfoot></table>`;
      };
      ov.querySelectorAll(".hsp-emp").forEach((b) => (b.onclick = () => show(b.dataset.id)));
      if (ST.view === "sum" || !vis.length) showSum(); else show(vis.some((x) => String(x.w.id) === String(ST.sel)) ? ST.sel : vis[0].w.id);
      const setM = (v) => { ST.month = v; build(); };
      ov.querySelector("#hspM").onchange = (e) => setM(e.target.value || "");
      ov.querySelector("#hspPrev").onclick = () => mk && setM(shiftM(mk, -1));
      ov.querySelector("#hspNext").onclick = () => mk && setM(shiftM(mk, 1));
      ov.querySelector("#hspAll").onclick = () => setM("");
      ov.querySelector("#hspSum").onclick = showSum;
      ov.querySelectorAll(".hsp-f button").forEach((b) => (b.onclick = () => { ST.filter = b.dataset.f; build(); }));
      ov.querySelector("#hspClose").onclick = () => ov.remove();
      ov.onclick = (e) => { if (e.target === ov) ov.remove(); };
      ov.querySelector("#hspQ").oninput = (e) => { const q = e.target.value.trim().toLowerCase(); ov.querySelectorAll(".hsp-emp,.hsp-row").forEach((b) => (b.style.display = !q || b.dataset.s.includes(q) ? "" : "none")); };
      ov.querySelector("#hspCsv").onclick = () => {
        const lines = [["Employee", "ID", "Month", "Present", "OT Hours", "Earned", "Paid", "Due"]];
        base.forEach((x) => x.rs.forEach((r) => lines.push([x.w.name, x.w.workerId || "", r.k, r.c.present, r.c.otHours, r.earned.toFixed(2), r.paid.toFixed(2), r.due.toFixed(2)])));
        const csv = lines.map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
        const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); a.download = "salary-statement-" + (mk || "all") + ".csv"; a.click();
      };
      ov.querySelector("#hspPrint").onclick = () => {
        const w = window.open("", "_blank"); if (!w) return;
        w.document.write(`<html><head><title>Salary Statement</title><style>body{font-family:Arial;padding:20px;color:#14213d}table{width:100%;border-collapse:collapse;font-size:12px}th,td{border:1px solid #ccd;padding:5px;text-align:left}th{background:#eef2f7}.r{color:#b91c1c}.g{color:#15803d}.hsp-mini{display:flex;gap:16px;margin:8px 0}</style></head><body><h2>PURE_BUILD · Salary Statement · ${E(ml)}</h2>${d.innerHTML}</body></html>`);
        w.document.close(); w.focus(); w.print();
      };
    };
    build();
  }
  document.head.insertAdjacentHTML("beforeend", `<style>
  .hsp-acts input[type=month]{height:34px;border:1px solid #d6dde8;border-radius:9px;padding:0 8px}
  .hsp-b.on{background:#14213d;color:#fff}.hsp-b:disabled{opacity:.4}
  .hsp-kpis.hsp-k5{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
  .hsp-side{display:flex;flex-direction:column;min-height:0;border-right:1px solid #e5eaf2}.hsp-side .hsp-list{flex:1;border-right:0}
  .hsp-f{display:flex;gap:6px;padding:8px 8px 0}.hsp-f button{flex:1;border:1px solid #d6dde8;background:#fff;border-radius:8px;padding:5px;font-size:11.5px;font-weight:700;cursor:pointer}.hsp-f button.on{background:#14213d;color:#fff}
  .hsp-emp small.r{color:#b91c1c;font-weight:700}
  .hsp-detail{overflow:auto}.hsp-t thead th{position:sticky;top:0}.hsp-row{cursor:pointer}.hsp-row:hover{background:#f1f5f9}.hsp-cur{background:#fff7ed}
  </style>`);
  window.hrSalaryStatement = openStatement;

  function payrollTools() {
    const body = document.getElementById("hrPayBody"); if (!body) return;
    const tb = document.querySelector(".hr-toolbar");
    if (tb && !tb.querySelector(".hsp-open")) {
      const b = document.createElement("button"); b.type = "button"; b.className = "btn primary hsp-open"; b.textContent = "📄 Salary Statement (Paid / Due)";
      b.onclick = () => openStatement(); tb.appendChild(b);
    }
    // Due KPI: replace "On Hold" with total due (all months) for clarity
    const k = [...document.querySelectorAll(".hr-pay-kpis .hr-kpi")].find((x) => /On Hold/.test(x.textContent));
    if (k && !k.dataset.sp) {
      k.dataset.sp = 1;
      let due = 0; try { workers().forEach((w) => rowsFor(w).forEach((r) => (due += r.due))); } catch (e) {}
      k.classList.add("bad"); k.style.cursor = "pointer"; k.title = "Open Salary Statement";
      k.innerHTML = `<span>!</span><small>Total Due (all months)</small><b>${M(due)}</b><em class="hr-kpi-sub">click for statement</em>`;
      k.onclick = () => openStatement();
    }
  }

  const run = () => { try { attendanceTools(); payrollTools(); } catch (e) { console.warn("hr-salary-pro", e); } };
  const start = () => { const v = document.getElementById("view"); if (v) new MutationObserver(run).observe(v, { childList: true, subtree: true }); run(); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();

  const css = `
  .hsp-attbar{display:flex;gap:6px;align-items:center;margin:0 0 8px;flex-wrap:wrap}
  .hsp-b{border:1px solid #cfdcf6;background:#fff;color:#1d4ed8;-webkit-text-fill-color:#1d4ed8;border-radius:9px;height:32px;padding:0 12px;font-weight:700;font-size:12.5px;cursor:pointer}
  .hsp-b:hover{background:#eaf1fe}.hsp-b.on{background:#1d4ed8;color:#fff;-webkit-text-fill-color:#fff}
  .hsp-sep{flex:1}
  .hr-attendance-wrap{scroll-behavior:smooth}
  .hr-attendance-wrap::-webkit-scrollbar{height:12px;width:10px}.hr-attendance-wrap::-webkit-scrollbar-thumb{background:#9db6e8;border-radius:8px}.hr-attendance-wrap::-webkit-scrollbar-track{background:#eef2f7}
  .hr-attendance-wrap.hsp-full{position:fixed!important;inset:56px 16px 16px!important;max-height:none!important;z-index:9000;background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.35);padding:8px}
  .hr-attendance-wrap.hsp-full table{min-width:0!important;width:100%;table-layout:fixed}
  .hr-attendance-wrap.hsp-full th,.hr-attendance-wrap.hsp-full td{padding:2px!important;font-size:10.5px!important}
  .hr-attendance-wrap.hsp-full .hr-att-worker-head,.hr-attendance-wrap.hsp-full td:first-child{width:170px}
  .hsp-attbar:has(+.hsp-full){position:fixed;top:12px;left:16px;right:16px;z-index:9001;background:#fff;padding:6px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.2)}
  .hsp-ov{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9500;display:grid;place-items:center;padding:16px}
  .hsp-box{background:#fff;color:#14213d;width:min(1280px,100%);height:min(90vh,860px);border-radius:16px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,.4)}
  .hsp-head{display:flex;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid #e5eaf2;flex-wrap:wrap}
  .hsp-head h3{margin:0;font-size:19px}.hsp-head p{margin:2px 0 0;font-size:12.5px;color:#64748b}
  .hsp-acts{display:flex;gap:6px;align-items:center}.hsp-acts input{height:32px;border:1px solid #dbe3ef;border-radius:9px;padding:0 10px}
  .hsp-x{color:#475569;-webkit-text-fill-color:#475569}
  .hsp-kpis,.hsp-mini{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:12px 18px}
  .hsp-mini{grid-template-columns:repeat(3,1fr);padding:8px 0}
  .hsp-kpis>div,.hsp-mini>div{border:1px solid #e5eaf2;border-radius:12px;padding:10px 12px;background:#f8fafc}
  .hsp-kpis small,.hsp-mini small{display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase}
  .hsp-kpis b,.hsp-mini b{font-size:19px}
  .hsp-kpis .g,.hsp-mini .g{background:#ecfdf3;border-color:#bbf7d0}.hsp-kpis .r,.hsp-mini .r{background:#fef2f2;border-color:#fecaca}
  .hsp-body{flex:1;display:grid;grid-template-columns:300px 1fr;min-height:0;border-top:1px solid #e5eaf2}
  .hsp-list{overflow:auto;border-right:1px solid #e5eaf2;padding:8px}
  .hsp-emp{width:100%;display:flex;justify-content:space-between;align-items:center;gap:8px;text-align:left;border:1px solid transparent;background:none;border-radius:10px;padding:8px 10px;cursor:pointer;color:#14213d}
  .hsp-emp:hover{background:#f1f5fb}.hsp-emp.on{background:#eaf1fe;border-color:#bfd3fb}
  .hsp-emp small{display:block;font-size:11px;color:#64748b}
  .hsp-emp em{font-style:normal;font-size:11.5px;font-weight:800;white-space:nowrap}
  .r{color:#b91c1c}.g{color:#15803d}
  .hsp-detail{overflow:auto;padding:12px 18px}
  .hsp-dh h4{margin:0;font-size:17px}.hsp-dh span{font-size:12px;color:#64748b}
  .hsp-t{width:100%;border-collapse:collapse;font-size:12.5px}
  .hsp-t th{position:sticky;top:0;background:#14213d;color:#fff;-webkit-text-fill-color:#fff;padding:7px 8px;text-align:left;font-size:11px;text-transform:uppercase}
  .hsp-t td{padding:7px 8px;border-bottom:1px solid #eef2f7;white-space:nowrap}
  .hsp-t tfoot td{font-weight:800;background:#f1f5fb;position:sticky;bottom:0}
  .hsp-empty{color:#94a3b8;text-align:center;padding:20px}
  @media(max-width:760px){.hsp-body{grid-template-columns:1fr}.hsp-list{max-height:180px;border-right:0;border-bottom:1px solid #e5eaf2}.hsp-kpis{grid-template-columns:repeat(2,1fr)}}
  `;
  const st = document.createElement("style"); st.id = "pb-hr-salary-pro"; st.textContent = css; document.head.appendChild(st);
})();
