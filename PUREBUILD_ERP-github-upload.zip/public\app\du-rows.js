// Daily Progress Update, section 4: office enters the same materials / labour / equipment a foreman sends from the phone.
// Additive only: new db.stock and db.labour rows (same shape as an approved foreman report import) tagged sourceReportId.
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (v) => (typeof esc === "function" ? esc(v ?? "") : String(v ?? ""));
  const KINDS = {
    in: { title: "Materials Received (Stock IN)", key: "materialIn", cols: [["item", "Material", "text", 1], ["qty", "Qty", "number"], ["unit", "Unit", "text"], ["supplier", "Supplier", "text"], ["challan", "Challan No.", "text"], ["vehicle", "Vehicle", "text"]] },
    out: { title: "Materials Used (Stock OUT)", key: "materialOut", cols: [["item", "Material", "text", 1], ["qty", "Qty", "number"], ["unit", "Unit", "text"], ["usedFor", "Used For", "text"], ["location", "Location", "text"]] },
    lab: { title: "Labour", key: "labourEntries", cols: [["category", "Category / Trade", "text"], ["workers", "Workers", "number"], ["hours", "Hours", "number"], ["overtime", "Overtime hrs", "number"], ["remarks", "Remarks", "text"]] },
    eq: { title: "Equipment", key: "equipment", cols: [["name", "Equipment", "text"], ["code", "Code", "text"], ["hours", "Operating hrs", "number"], ["condition", "Condition", "select"], ["remarks", "Remarks", "text"]] },
  };
  const css = document.createElement("style");
  css.textContent = `.dur-blk{margin-bottom:10px}.dur-blk h5{margin:0 0 5px;font-size:12px;color:#36507a;display:flex;justify-content:space-between;align-items:center}
.dur-blk table{width:100%;border-collapse:collapse;font-size:12px}.dur-blk th{background:#f2f6fb;text-align:left;padding:5px;font-size:10px;color:#52647d}
.dur-blk td{padding:3px 4px;border-top:1px solid var(--line)}.dur-blk td input,.dur-blk td select{width:100%;min-width:60px;padding:5px 6px}
.dur-x{border:0;background:#fdecea;color:#c0392b;border-radius:6px;width:24px;height:24px;cursor:pointer}`;
  document.head.appendChild(css);

  function items() {
    const pid = typeof selectedProject !== "undefined" ? selectedProject : "";
    return [...new Set((db.stock || []).filter((x) => !pid || x.projectId === pid).map((x) => String(x.item || "").trim()).filter(Boolean))];
  }
  function rowHtml(k, r = {}) {
    return `<tr>${KINDS[k].cols.map(([f, , t, dl]) => `<td>${t === "select"
      ? `<select data-f="${f}">${["", "Good", "Needs Service", "Breakdown"].map((o) => `<option ${o === r[f] ? "selected" : ""}>${o}</option>`).join("")}</select>`
      : `<input data-f="${f}" type="${t}" ${t === "number" ? 'min="0" step="any"' : ""} ${dl ? 'list="durItems"' : ""} value="${E(r[f])}">`}</td>`).join("")}<td><button type="button" class="dur-x" title="Remove">×</button></td></tr>`;
  }
  function html(draft) {
    return `<datalist id="durItems">${items().map((i) => `<option value="${E(i)}">`).join("")}</datalist>` + Object.entries(KINDS).map(([k, d]) => `<div class="dur-blk" data-k="${k}"><h5>${d.title}<button type="button" class="btn small" data-add="${k}">＋ Add row</button></h5>
<table><thead><tr>${d.cols.map((c) => `<th>${c[1]}</th>`).join("")}<th></th></tr></thead><tbody>${(draft?.[d.key] || []).map((r) => rowHtml(k, r)).join("")}</tbody></table></div>`).join("");
  }
  function bind() {
    document.querySelectorAll(".dur-blk").forEach((blk) => {
      const k = blk.dataset.k, tb = blk.querySelector("tbody");
      blk.querySelector("[data-add]").onclick = () => tb.insertAdjacentHTML("beforeend", rowHtml(k));
      tb.addEventListener("click", (e) => { if (e.target.closest(".dur-x")) e.target.closest("tr").remove(); });
      tb.addEventListener("change", (e) => {
        if (e.target.dataset.f !== "item") return;
        const hit = (db.stock || []).find((x) => String(x.item || "").toLowerCase() === e.target.value.trim().toLowerCase());
        const u = e.target.closest("tr").querySelector('[data-f="unit"]'); if (hit && u && !u.value) u.value = hit.unit || "";
      });
    });
  }
  function read() {
    const out = {};
    Object.entries(KINDS).forEach(([k, d]) => {
      out[d.key] = [...document.querySelectorAll(`.dur-blk[data-k="${k}"] tbody tr`)].map((tr) => {
        const r = {}; tr.querySelectorAll("[data-f]").forEach((i) => { const t = d.cols.find((c) => c[0] === i.dataset.f)[2]; r[i.dataset.f] = t === "number" ? n(i.value) : i.value.trim(); });
        return r;
      }).filter((r) => (k === "in" || k === "out" ? r.item && r.qty > 0 : k === "lab" ? r.workers > 0 || r.hours > 0 || r.category : r.name));
    });
    return out;
  }
  function available(pid, item, unit) {
    const key = String(item).trim().toLowerCase(), u = String(unit || "").trim().toLowerCase();
    return (db.stock || []).filter((x) => x.projectId === pid && String(x.item || "").trim().toLowerCase() === key && (!u || String(x.unit || "").trim().toLowerCase() === u))
      .reduce((a, x) => a + (x.direction === "In" ? n(x.qty) : x.direction === "Out" ? -n(x.qty) : 0), 0);
  }
  function stockShort(rows, pid) {
    const need = {}; rows.forEach((r) => { const k = r.item.toLowerCase() + "|" + (r.unit || "").toLowerCase(); need[k] = need[k] || { ...r, qty: 0 }; need[k].qty += r.qty; });
    const ins = read().materialIn;
    for (const r of Object.values(need)) {
      const inToday = ins.filter((x) => x.item.toLowerCase() === r.item.toLowerCase() && (x.unit || "").toLowerCase() === (r.unit || "").toLowerCase()).reduce((a, x) => a + x.qty, 0);
      const av = available(pid, r.item, r.unit) + inToday;
      if (r.qty > av + 1e-9) return `Not enough stock for ${r.item}: available ${fmt(av)} ${r.unit || ""}, used ${fmt(r.qty)}`;
    }
    return "";
  }
  function post(rep, ex) {
    db.stock = db.stock || []; db.labour = db.labour || [];
    const base = { date: rep.date, projectId: rep.projectId, ...(rep.building ? { building: rep.building } : {}), sourceReportId: rep.id, enteredBy: "office" };
    ex.materialIn.forEach((m, i) => db.stock.push({ ...base, id: `${rep.id}-in-${i}`, item: m.item, unit: m.unit || "", direction: "In", qty: m.qty, movement: "Receipt",
      note: `Supplier: ${m.supplier || "—"} | Challan: ${m.challan || "—"} | Vehicle: ${m.vehicle || "—"}` }));
    ex.materialOut.forEach((m, i) => db.stock.push({ ...base, id: `${rep.id}-out-${i}`, item: m.item, unit: m.unit || "", direction: "Out", qty: m.qty, movement: "Consumption",
      note: `Used For: ${m.usedFor || "—"} | Location: ${m.location || rep.location || "—"}` }));
    ex.labourEntries.forEach((l, i) => db.labour.push({ ...base, id: `${rep.id}-lab-${i}`, worker: l.category || "Site Crew", role: l.category || "General Labour",
      units: l.workers, rate: 0, note: l.remarks || "", hours: l.hours, overtime: l.overtime }));
  }
  window.PB_DU_ROWS = { html, bind, read, post, stockShort, available };
})();
