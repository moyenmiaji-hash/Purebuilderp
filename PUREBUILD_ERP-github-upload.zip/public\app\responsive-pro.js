/* PURE_BUILD global responsive layer (display only).
   - Dashboard stays in the viewport on tablet/desktop; phone content scrolls without shrinking text.
   - Below 1280px: tab strips scroll sideways instead of overlapping, summary cards wrap.
   - Below 1024px (tablet) and 768px (phone): headers wrap, squeezed grids stack,
     topbar search shrinks so bell/profile stay visible, wide tables scroll inside their box.
   Never changes data, ids, formulas or click handlers. */
(function () {
  var B = 'html body';
  var css = `
/* ---- safe everywhere ---- */
${B} #view img, ${B} #view video, ${B} #view canvas{max-width:100%}
${B} #view svg:not([width]){max-width:100%}
${B} .pb-rt-scroll{overflow-x:auto!important;-webkit-overflow-scrolling:touch;max-width:100%}
${B} .pb-rt-scroll > table{min-width:max-content}

/* Keep Labour attendance salary amounts readable on laptop and phone widths. */
@media (max-width:1400px){
  ${B} #view .hr-kpis{grid-template-columns:repeat(3,minmax(0,1fr))!important}
  ${B} #view .hr-kpis .hr-kpi>b{
    white-space:normal!important;overflow:visible!important;text-overflow:clip!important;
    overflow-wrap:anywhere!important
  }
}
@media (max-width:700px){
  ${B} #view .hr-kpis{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  ${B} #view .ledger-tools{min-width:0;width:100%;box-sizing:border-box}
  ${B} #view .ledger-tools .tx-searchbar{
    grid-template-columns:repeat(2,minmax(0,1fr));min-width:0;width:100%;box-sizing:border-box
  }
  ${B} #view .ledger-tools .tx-search-main{
    grid-column:1/-1;min-width:0;width:100%;box-sizing:border-box
  }
  ${B} #view .ledger-tools .tx-search-main input{min-width:0;width:100%;max-width:100%;box-sizing:border-box}
  ${B} #view .ledger-tools .ledger-date-range{
    grid-column:1/-1;min-width:0;width:100%;box-sizing:border-box
  }
  ${B} #view .ledger-tools .ledger-date-range .select{
    flex:1 1 0;width:0;min-width:0;max-width:100%;box-sizing:border-box
  }
  ${B} #view .ledger-tools .tx-searchbar>select{min-width:0;width:100%;max-width:100%;box-sizing:border-box}
}

/* Labour & HR must scroll as a page instead of clipping tall sections. */
html body.labour-mode{
  height:auto!important;min-height:100vh!important;min-height:100dvh!important;
  overflow-x:hidden!important;overflow-y:auto!important
}
html body.labour-mode .app{
  height:auto!important;min-height:100vh!important;min-height:100dvh!important
}
html body.labour-mode .main{
  height:auto!important;min-height:100vh!important;min-height:100dvh!important;overflow:visible!important
}
html body.labour-mode .content{
  height:auto!important;min-height:calc(100vh - 64px)!important;min-height:calc(100dvh - 64px)!important;
  overflow:visible!important;display:block!important
}
html body.labour-mode #view{
  height:auto!important;min-height:0!important;overflow:visible!important;display:block!important
}

/* Keep the desktop sidebar fixed while the main workspace owns page scrolling. */
@media (min-width:901px){
  html body[class]{
    height:100vh!important;height:100dvh!important;overflow:hidden!important
  }
  html body[class] .app{
    height:100vh!important;height:100dvh!important;min-height:0!important
  }
  html body[class] .app>.sidebar{
    position:fixed!important;inset:0 auto 0 0!important;
    width:var(--pb-fixed-sidebar-width,240px)!important;
    height:100vh!important;height:100dvh!important;max-height:100dvh!important;
    align-self:stretch!important;overflow-x:hidden!important;overflow-y:auto!important;
    overscroll-behavior:contain
  }
  html body:not(.nav-collapsed) .app>.main{
    grid-column:2!important
  }
  html body.nav-collapsed .app>.main{
    grid-column:1!important
  }
  html body[class] .main{
    height:100vh!important;height:100dvh!important;min-height:0!important;
    overflow:auto!important;overscroll-behavior:contain
  }
}
@media (min-width:701px) and (max-width:1100px){
  html body.dashboard-mode{height:100vh!important;height:100dvh!important;min-height:0!important;overflow:hidden!important}
  html body.dashboard-mode .app{
    display:block!important;
    height:100vh!important;height:100dvh!important;min-height:0!important;overflow:hidden!important
  }
  @media (min-width:901px){
    html body.dashboard-mode .app{display:grid!important;grid-template-columns:clamp(210px,16vw,280px) minmax(0,1fr)!important}
  }
  html body.dashboard-mode.nav-collapsed .app{grid-template-columns:minmax(0,1fr)!important}
  html body.dashboard-mode .main{
    display:flex!important;flex-direction:column!important;width:100%!important;
    height:100vh!important;height:100dvh!important;min-width:0!important;min-height:0!important;overflow:hidden!important
  }
  html body.dashboard-mode .topbar{flex:0 0 auto!important}
  html body.dashboard-mode .content{
    box-sizing:border-box!important;display:flex!important;flex:1 1 0!important;flex-direction:column!important;
    width:100%!important;height:auto!important;min-width:0!important;min-height:0!important;max-height:none!important;
    overflow:hidden!important;gap:6px!important;padding:7px!important
  }
  html body.dashboard-mode #view{
    display:flex!important;flex:1 1 0!important;flex-direction:column!important;
    width:100%!important;min-width:0!important;min-height:0!important;overflow:hidden!important
  }
  html body.dashboard-mode .content>.pagehead{box-sizing:border-box!important;flex:0 0 42px!important;min-height:42px!important;margin:0!important;padding:5px 8px!important}
  html body.dashboard-mode .content>.pagehead h1{font-size:clamp(13px,1.5vw,17px)!important}
  html body.dashboard-mode .content>.dashboard-kpis{
    box-sizing:border-box!important;display:grid!important;flex:0 0 auto!important;
    grid-template-columns:repeat(4,minmax(0,1fr))!important;grid-auto-rows:minmax(0,1fr)!important;
    gap:5px!important;margin:0!important
  }
  html body.dashboard-mode .dashboard-kpis .kpi{box-sizing:border-box!important;height:auto!important;min-height:0!important;padding:5px!important;gap:2px!important}
  html body.dashboard-mode .dashboard-kpis .kpi .kpi-icon{width:21px!important;height:21px!important;margin:0 0 2px!important}
  html body.dashboard-mode .dashboard-kpis .kpi .kpi-title{font-size:clamp(8px,1vw,10px)!important;line-height:1.1!important;white-space:normal!important}
  html body.dashboard-mode .dashboard-kpis .kpi .kpi-value{font-size:clamp(10px,1.25vw,14px)!important;line-height:1.1!important}
  html body.dashboard-mode .dashboard-kpis .kpi .kpi-trend{font-size:clamp(7px,.85vw,9px)!important;line-height:1.1!important}
  html body.dashboard-mode #view#view > .dashboard-row{
    box-sizing:border-box!important;display:grid!important;flex:1 1 0!important;height:auto!important;min-height:0!important;
    grid-auto-rows:minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important;gap:5px!important;margin:0!important;overflow:hidden!important
  }
  html body.dashboard-mode #view#view > .overview-row{grid-template-columns:minmax(0,1.6fr) minmax(0,1fr) minmax(0,.9fr)!important}
  html body.dashboard-mode #view#view > .analysis-row{grid-template-columns:repeat(4,minmax(0,1fr))!important}
  html body.dashboard-mode #view#view > .activity-row{grid-template-columns:minmax(0,1.4fr) minmax(0,1fr) minmax(0,1fr)!important}
  html body.dashboard-mode #view#view > .dashboard-row>.dashboard-panel{
    box-sizing:border-box!important;display:flex!important;flex-direction:column!important;
    width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;overflow:auto!important;
    padding:6px!important;-webkit-overflow-scrolling:touch
  }
  html body.dashboard-mode .dashboard-panel .panel-head{flex:0 0 auto!important;min-width:0!important;gap:3px!important;margin:0 0 4px!important}
  html body.dashboard-mode .dashboard-panel .panel-head h3{font-size:clamp(9px,1vw,12px)!important;line-height:1.15!important}
  html body.dashboard-mode .project-financial-panel .tablewrap{flex:1 1 auto!important;min-height:0!important;overflow:auto!important}
  html body.dashboard-mode .project-financial-panel .dashboard-table{width:100%!important;min-width:620px!important;table-layout:auto!important}
  html body.dashboard-mode .project-financial-panel .dashboard-table th,
  html body.dashboard-mode .project-financial-panel .dashboard-table td{padding:4px!important;font-size:9px!important;line-height:1.1!important}
}

/* ---- < 1280px : laptops ---- */
@media (max-width:1279.98px){
  /* topbar: search shrinks so bell + profile stay on screen */
  ${B} .topbar{min-width:0!important;max-width:100%}
  ${B} .topbar .topbar-spacer{min-width:0!important;flex:1 1 auto!important}
  ${B} .topbar .topbar-search{width:auto!important;min-width:0!important;flex:1 1 auto!important;max-width:100%!important}
  ${B} .topbar .topbar-search input{min-width:0!important;width:100%!important}
  ${B} .topbar .topbar-search kbd{display:none!important}
  ${B} .topbar .topbar-tools{flex:0 0 auto!important;min-width:0!important}
  ${B} .ap-tabs, ${B} .ap-tabs.appro, ${B} .sales-tabs{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto!important;scrollbar-width:thin;-webkit-overflow-scrolling:touch}
  ${B} .ap-tabs > *, ${B} .sales-tabs > *{flex:0 0 auto!important;white-space:nowrap!important;width:auto!important;min-width:max-content!important}
  ${B} .ledger-summary-card{flex-wrap:wrap;min-width:0}
  ${B} .ledger-summary-card > *{min-width:0}
  ${B} .pbs-cards{grid-template-columns:repeat(auto-fill,minmax(250px,1fr))!important}
  ${B} .hrref-kpi-row{grid-template-columns:repeat(4,minmax(0,1fr))!important}
  ${B} .labour-att-card, ${B} .lac-main{flex-wrap:wrap!important;min-width:0}
}

/* ---- < 1024px : tablets ---- */
@media (max-width:1023.98px){
  ${B} .pagehead{height:auto!important;min-height:0!important;flex:0 0 auto!important;flex-wrap:wrap!important;row-gap:8px}
  ${B} .pagehead > *{min-width:0}
  ${B} .hrref-main-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;min-height:0!important}
  ${B} .hrref-expiry-cards{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))!important}
  ${B} .hrref-title, ${B} .hrref-project-head{flex-wrap:wrap;min-width:0}
  ${B} .quote-kpis{grid-template-columns:repeat(3,minmax(0,1fr))!important}
  ${B} .modalbox{max-width:96vw!important}
  ${B} .hrref-kpi-row{grid-template-columns:repeat(3,minmax(0,1fr))!important}
  ${B} .topbar .topbar-tools .user > :not(.admin-avatar){display:none!important}
  ${B} .topbar .topbar-tools{gap:6px!important}
  ${B} .topbar .topbar-search small{display:none!important}
}

/* ---- < 768px : phones ---- */
@media (max-width:767.98px){
  ${B} .pagehead{align-items:flex-start!important}
  ${B} .pagehead > :last-child{flex-wrap:wrap;gap:6px}
  ${B} .hrref-main-grid, ${B} .hrref-bottom-grid, ${B} .hrref-footer-grid{grid-template-columns:minmax(0,1fr)!important}
  ${B} .quote-kpis, ${B} .hrref-kpi-row{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  html:root body.dashboard-mode:not(.zz1):not(.zz2):not(.zz3) #view#view#view#view#view .dashboard-kpis .kpi .kpi-value{
    font-size:clamp(12px,3.5vw,15px)!important;line-height:1.15!important;
    white-space:normal!important;overflow-wrap:anywhere!important
  }
  ${B} .pb-rt-g2{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  ${B} #view input, ${B} #view select, ${B} #view textarea, ${B} #modal input, ${B} #modal select, ${B} #modal textarea{max-width:100%;font-size:16px}
  ${B} #modal .modalbox{width:100vw!important;max-width:100vw!important;max-height:100dvh!important;border-radius:14px 14px 0 0!important}
  ${B} #view .btn, ${B} #modal .btn{min-height:38px}
}

/* ---- < 375px : small phones ---- */
@media (max-width:374.98px){
  ${B} .quote-kpis, ${B} .pb-rt-g2{grid-template-columns:minmax(0,1fr)!important}
  ${B} .topbar .topbar-tools .top-tool{display:none!important}
}
@media print{${B} .pb-rt-scroll{overflow:visible!important}}
`;
  function syncSidebarWidth() {
    if (window.innerWidth <= 900 || document.body.classList.contains('nav-collapsed')) return;
    var app = document.querySelector('.app');
    if (!app || getComputedStyle(app).display === 'block') return;
    var firstTrack = getComputedStyle(app).gridTemplateColumns.split(' ')[0];
    var width = parseFloat(firstTrack);
    if (Number.isFinite(width) && width > 0) app.style.setProperty('--pb-fixed-sidebar-width', width + 'px');
  }
  syncSidebarWidth();

  var st = document.createElement('style');
  st.id = 'pb-responsive-pro';
  st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  /* Wide tables: let the table's own box scroll sideways (only below 1024px). */
  function scrollable(el) {
    var o = getComputedStyle(el).overflowX;
    return o === 'auto' || o === 'scroll';
  }
  function tidy() {
    if (window.innerWidth >= 1024) return;
    var view = document.getElementById('view');
    if (!view) return;
    view.querySelectorAll('table').forEach(function (t) {
      var p = t.parentElement;
      if (!p || p.classList.contains('pb-rt-scroll')) return;
      if (t.offsetWidth <= p.clientWidth + 2) return;
      var a = p, ok = false;
      while (a && a !== view) { if (scrollable(a)) { ok = true; break; } a = a.parentElement; }
      if (!ok) p.classList.add('pb-rt-scroll');
    });
    if (window.innerWidth >= 768) return;
    /* Grids with 3-6 squeezed columns (not calendars) become 2 columns on phones */
    view.querySelectorAll('div').forEach(function (g) {
      if (g.classList.contains('pb-rt-g2') || !g.offsetParent || g.closest('table') || /bar|chart|legend|calendar|cal-|day/i.test(g.className)) return;
      var cs = getComputedStyle(g);
      if (cs.display.indexOf('grid') < 0) return;
      var tr = cs.gridTemplateColumns.split(' ').map(parseFloat).filter(function (x) { return x > 0; });
      if (tr.length < 3 || tr.length > 6 || g.children.length < 3) return;
      if (Math.min.apply(null, tr) < 100 && g.clientWidth > 250) g.classList.add('pb-rt-g2');
    });
  }
  var t;
  function run() { clearTimeout(t); t = setTimeout(tidy, 150); }
  window.addEventListener('resize', function () { syncSidebarWidth(); run(); });
  function start() {
    syncSidebarWidth();
    run();
    var v = document.getElementById('view');
    if (v) new MutationObserver(run).observe(v, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
