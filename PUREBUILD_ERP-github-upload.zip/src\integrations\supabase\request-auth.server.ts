import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

export type RequestAuth = {
  client: ReturnType<typeof createClient<Database>>;
  userId: string;
  organizationId: string;
  role: string;
};

export type RequestAuthResult = { ok: true; auth: RequestAuth } | { ok: false; response: Response };

export async function authenticateActiveRequest(request: Request): Promise<RequestAuthResult> {
  const authorization = request.headers.get("authorization") || "";
  const match = /^Bearer ([^\s]+)$/.exec(authorization);
  if (!match) {
    return {
      ok: false,
      response: Response.json({ error: "Please sign in first." }, { status: 401 }),
    };
  }

  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) {
    console.error("[Auth] Supabase request authentication is not configured.");
    return {
      ok: false,
      response: Response.json(
        { error: "Authentication is temporarily unavailable." },
        { status: 503 },
      ),
    };
  }

  const client = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: { Authorization: `Bearer ${match[1]}` },
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
  const { data: authData, error: authError } = await client.auth.getUser(match[1]);
  if (authError || !authData.user) {
    return {
      ok: false,
      response: Response.json({ error: "Please sign in again." }, { status: 401 }),
    };
  }

  const { data: profile, error: profileError } = await client
    .from("profiles")
    .select("id, organization_id, role, status")
    .eq("id", authData.user.id)
    .maybeSingle();
  if (profileError) {
    console.error("[Auth] Could not verify the caller's profile.", profileError);
    return {
      ok: false,
      response: Response.json(
        { error: "Authorization is temporarily unavailable." },
        { status: 503 },
      ),
    };
  }
  if (!profile || profile.status !== "active") {
    return {
      ok: false,
      response: Response.json({ error: "An active account is required." }, { status: 403 }),
    };
  }

  return {
    ok: true,
    auth: {
      client,
      userId: authData.user.id,
      organizationId: profile.organization_id,
      role: profile.role,
    },
  };
}

export async function isAdmin(auth: RequestAuth): Promise<boolean | null> {
  const { data, error } = await auth.client.rpc("has_role", {
    _user_id: auth.userId,
    _role: "admin",
  });
  if (error) {
    console.error("[Auth] Could not verify the caller's administrator role.", error);
    return null;
  }
  return data === true;
}

export async function writeSecurityAudit(
  actorId: string,
  organizationId: string,
  action: string,
  recordId: string,
  module = "user_management",
): Promise<string | null> {
  const { supabaseAdmin } = await import("./client.server");
  const { error } = await supabaseAdmin.rpc("pb_log_security_event", {
    p_actor: actorId,
    p_organization: organizationId,
    p_action: action,
    p_record_id: recordId,
    p_module: module,
  });
  if (error) {
    console.error("[Audit] Could not record an administrative security event.", error);
    return "The change succeeded, but its audit record could not be written.";
  }
  return null;
}
