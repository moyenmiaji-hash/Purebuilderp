/* Site Progress V2 — draws the Site Progress menu (overrides window.progress; old page kept as PB_OLD_PROGRESS, unused).
   Five sections: Overview · Work Progress (Foreman / Manual) · BOQ Tracking · Approval Center · Reports & Analytics.
   Read-only over db.projects / db.boq / db.progress. All saving goes through the existing forms:
   manual entry = Daily Progress Update form (PB_DAILY_UPDATE), foreman approve/reject = existing Cloud review box (#pb-cloud-reports).
   One shared stats() source feeds every number so KPIs, tabs and reports always match. */
(function () {
  const n = (v) => { const x = Number(v); return Number.isFinite(x) ? x : 0; };
  const E = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const M = (v) => (typeof money === "function" ? money(v) : n(v).toFixed(2));
  const F = (v) => (typeof fmt === "function" ? fmt(v) : String(Math.round(n(v) * 100) / 100));
  const C = () => window.PBProgressCalc;
  const todayS = () => new Date().toISOString().slice(0, 10);
  const SECTIONS = [["overview", "Overview"], ["work", "Work Progress"], ["boq", "BOQ Tracking"], ["approval", "Approval Center"], ["reports", "Reports & Analytics"]];
  const st = { tab: "overview", sub: "foreman", from: "", to: "", cat: "", bst: "", ast: "", rep: "daily", list: "", tbl: {} };
  try { Object.assign(st, JSON.parse(sessionStorage.getItem("PB_SPV2") || "{}"), { tbl: {} }); } catch (e) {}
  const keep = () => { try { sessionStorage.setItem("PB_SPV2", JSON.stringify({ tab: st.tab, sub: st.sub, rep: st.rep })); } catch (e) {} };

  const css = document.createElement("style");
  css.textContent = `
.v2{display:flex;flex-direction:column;gap:10px;color:#12233d}
.v2-head{display:flex;gap:8px;align-items:center;flex-wrap:wrap;background:#fff;border:1px solid #e3e9f1;border-radius:12px;padding:10px 12px}
.v2-head h2{margin:0 auto 0 0;font-size:18px}
.v2-head select,.v2-head input,.v2 .v2-f select,.v2 .v2-f input{height:34px;border:1px solid #cfdcec;border-radius:8px;padding:0 8px;font-size:12.5px;background:#fff;color:#12233d}
.v2-tabs{display:flex;gap:2px;border-bottom:2px solid #e3e9f1;flex-wrap:wrap}
.v2-tabs button{border:0;background:none;padding:9px 14px;font-weight:700;font-size:13px;color:#5b6b7f;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px}
.v2-tabs button.on{color:#0f3d6e;border-bottom-color:#0f3d6e}
.v2-sub{display:inline-flex;gap:4px;background:#eef2f7;border-radius:9px;padding:3px}.v2-sub button{border:0;background:none;padding:6px 12px;border-radius:7px;font-weight:700;font-size:12.5px;color:#475569;cursor:pointer}.v2-sub button.on{background:#fff;color:#0f3d6e;box-shadow:0 1px 3px rgba(0,0,0,.08)}
.v2-k{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px}
.v2-k button{text-align:left;background:#fff;border:1px solid #e3e9f1;border-radius:10px;padding:8px 10px;cursor:pointer;min-width:0}
.v2-k button:hover,.v2-k button.on{border-color:#0f3d6e;box-shadow:0 0 0 1px #0f3d6e inset}
.v2-k button>span{display:block;flex:1;min-width:0}
.v2-k small,.v2-k i{display:block;white-space:normal;overflow-wrap:anywhere}
.v2-k small{font-size:10.5px;font-weight:800;color:#5b6b7f;text-transform:uppercase;letter-spacing:.02em}
.v2-k b{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#12233d}.v2-k i{font-style:normal;font-size:11px;color:#64748b}
.v2-p{background:#fff;border:1px solid #e3e9f1;border-radius:12px;padding:10px 12px}
.v2-p h3{margin:0;font-size:14px}.v2-p .v2-h{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px}.v2-p .v2-h small{display:block;color:#64748b;font-size:11.5px;font-weight:400}
.v2-2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.v2-f{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.v2-t{overflow:auto;border:1px solid #e3e9f1;border-radius:9px}
.v2-t table{width:100%;border-collapse:collapse;font-size:12.5px}
.v2-t th{background:#f3f6fa;color:#334155;text-align:left;padding:7px 8px;font-size:11.5px;white-space:nowrap;border-bottom:1px solid #e3e9f1;cursor:pointer;position:sticky;top:0}
.v2-t th.ns{cursor:default}.v2-t td{padding:6px 8px;border-bottom:1px solid #f0f3f7;vertical-align:middle}.v2-t .r{text-align:right;white-space:nowrap}
.v2-bar{display:flex;align-items:center;gap:6px;min-width:110px}.v2-bar i{flex:1;height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden}.v2-bar em{display:block;height:100%;background:#0f7a43}.v2-bar.pl em{background:#94a3b8}.v2-bar small{font-size:11px;color:#475569;min-width:38px;text-align:right}
.v2-b{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10.5px;font-weight:800;white-space:nowrap}
.v2-b.g{background:#e6f6ec;color:#15803d}.v2-b.a{background:#fff6dd;color:#a16207}.v2-b.r{background:#fde8e8;color:#b91c1c}.v2-b.s{background:#eef2f7;color:#475569}.v2-b.bl{background:#e0efff;color:#1d4ed8}
.v2-pg{display:flex;justify-content:space-between;align-items:center;padding:6px 2px 0;font-size:12px;color:#5b6b7f}.v2-pg div{display:flex;gap:4px}
.v2-pg button{border:1px solid #cfdcec;background:#fff;border-radius:6px;padding:3px 9px;font-size:12px;cursor:pointer}.v2-pg button:disabled{opacity:.4;cursor:default}
.v2-note{font-size:12px;color:#475569;background:#f6f9fd;border:1px solid #e3e9f1;border-radius:9px;padding:8px 10px}
.v2-al{padding:7px 10px;border-radius:8px;font-size:12.5px;margin-bottom:6px;background:#f1f5f9;color:#334155}.v2-al[data-go]{cursor:pointer}.v2-al.a{background:#fff6dd;color:#92400e}.v2-al.r{background:#fde8e8;color:#991b1b}.v2-al.g{background:#e6f6ec;color:#166534}
.v2-head .btn{height:34px}
.v2-empty{text-align:center;color:#64748b;padding:16px}
.v2 input,.v2 select{width:auto!important;flex:0 0 auto;margin:0!important}.v2 input[data-tq]{min-width:200px}
.v2-t td.r,.v2-t th.r{color:inherit!important}
@media(max-width:1100px){.v2-k{grid-template-columns:repeat(3,minmax(0,1fr))}.v2-2{grid-template-columns:1fr}}
@media(max-width:640px){.v2-k{grid-template-columns:repeat(2,minmax(0,1fr))}.v2-head h2{width:100%}}
body.dark-theme .v2,body.dark-theme .v2-k b,body.dark-theme .v2-head select{color:#e2ecf8}
body.dark-theme .v2-head,body.dark-theme .v2-p,body.dark-theme .v2-k button,body.dark-theme .v2-pg button,body.dark-theme .v2 select,body.dark-theme .v2 input{background:#132235;border-color:#344960;color:#e2ecf8}
body.dark-theme .v2-tabs button.on{color:#7cb3ff;border-bottom-color:#7cb3ff}body.dark-theme .v2-t th{background:#17283c;color:#cbd5e1;border-color:#344960}body.dark-theme .v2-t td{border-color:#22364d}body.dark-theme .v2-note{background:#17283c;border-color:#344960;color:#cbd5e1}
`;
  document.head.appendChild(css);

  // ---------- one shared data source ----------
  const bldOf = (x, b) => x.building || (b && b.building) || "";
  const statusOf = (x) => { const s = String(x.approvalStatus || ""); if (/reject|return/i.test(s)) return "Rejected"; if (/review/i.test(s)) return "Under Review"; if (/submit|pending/i.test(s)) return "Submitted"; if (/draft/i.test(s)) return "Draft"; return "Approved"; };
  const isForeman = (x) => (!!(x.foreman || x.submittedBy) && x.source !== "stage-update" && x.source !== "room-entry") || !(x.source === "stage-update" || x.source === "room-entry" || (!String(x.id || "").startsWith("cloud-") && !x.sourceReportId && x.source !== "foreman" && x.source !== "Foreman" && !x.cloudReportId));
  function stats() {
    const pid = selectedProject, pb = typeof progressBuilding !== "undefined" ? progressBuilding : "";
    const inB = (b) => !pb || (b.building || "") === pb;
    const boq = (db.boq || []).filter((b) => b.projectId === pid && C().approvedish(b) && inB(b));
    const byId = {}; boq.forEach((b) => { byId[b.id] = b; });
    const findB = (x) => byId[x.boqId] || boq.find((b) => x.boqCode && b.boqId === x.boqCode);
    const items = boq.map((b) => {
      const qty = n(b.qty), ex = Math.max(0, n(b.executedQty)), done = qty > 0 ? Math.min(qty, ex) : ex, rem = Math.max(0, qty - ex), pct = qty > 0 ? Math.min(100, (ex / qty) * 100) : 0;
      return { b, qty, done, rem, pct, rate: n(b.rate), amt: qty * n(b.rate), cat: b.category || b.trade || "General", status: pct >= 100 ? "Completed" : ex > 0 ? "In Progress" : "Not Started" };
    });
    const inR = (d) => (!st.from || d >= st.from) && (!st.to || d <= st.to);
    const entries = (db.progress || []).filter((x) => x.projectId === pid && n(x.todayQty) > 0).map((x) => { const b = findB(x) || {}; return { x, b, date: String(x.date || "").slice(0, 10), status: statusOf(x), foreman: isForeman(x), by: x.foreman || x.submittedBy || x.createdBy || (isForeman(x) ? "Foreman" : "Office"), bld: bldOf(x, b), value: n(x.todayQty) * n(x.rate || b.rate) }; })
      .filter((e) => (!pb || e.bld === pb) && inR(e.date)).sort((a, z) => z.date.localeCompare(a.date));
    const p = (db.projects || []).find((z) => z.id === pid) || {};
    const pct = C().weighted(boq), plan = C().planned(p.start, p.end, todayS());
    return { p, boq, items, entries, pct, plan, pending: entries.filter((e) => e.status === "Submitted" || e.status === "Under Review") };
  }

  // ---------- generic sortable / searchable / paged table ----------
  // cols: [{h, k (sort key fn), r (right), ns (no sort)}]; rows: arrays of html cells; keys: per-row arrays of sort values
  function table(id, cols, rows, opt = {}) {
    const t = (st.tbl[id] = st.tbl[id] || { q: "", s: -1, d: 1, pg: 1, size: opt.size || 15 });
    let list = rows.map((r, i) => ({ r, i }));
    const hasLoc = rows.some((r) => r.loc), bset = [...new Set(rows.filter((r) => r.loc).map((r) => r.loc.bld))].sort((a, z) => String(a).localeCompare(String(z), undefined, { numeric: true }));
    if (t.bld && !bset.includes(t.bld)) t.bld = "";
    const fset = [...new Set(rows.filter((r) => r.loc && r.loc.flr && (!t.bld || r.loc.bld === t.bld)).map((r) => r.loc.flr))].sort((a, z) => String(a).localeCompare(String(z), undefined, { numeric: true }));
    if (t.flr && !fset.includes(t.flr)) t.flr = "";
    if (t.bld) list = list.filter((o) => o.r.loc && o.r.loc.bld === t.bld);
    if (t.flr) list = list.filter((o) => o.r.loc && o.r.loc.flr === t.flr);
    if (t.q) { const q = t.q.toLowerCase(); list = list.filter((o) => String(o.r.text || "").toLowerCase().includes(q)); }
    if (t.s >= 0) list.sort((a, z) => { const x = a.r.keys[t.s], y = z.r.keys[t.s]; return (typeof x === "number" && typeof y === "number" ? x - y : String(x ?? "").localeCompare(String(y ?? ""), undefined, { numeric: true })) * t.d; });
    const pages = Math.max(1, Math.ceil(list.length / t.size)); t.pg = Math.min(Math.max(1, t.pg), pages);
    const shown = list.slice((t.pg - 1) * t.size, t.pg * t.size);
    return `<div class="v2-f" style="margin-bottom:6px">${hasLoc ? `<select data-tl="${id}" data-k="bld"><option value="">All buildings</option>${bset.map((b) => `<option ${t.bld === b ? "selected" : ""}>${E(b)}</option>`).join("")}</select><select data-tl="${id}" data-k="flr"><option value="">All floors</option>${fset.map((f) => `<option ${t.flr === f ? "selected" : ""}>${E(f)}</option>`).join("")}</select>` : ""}${opt.filters || ""}<input data-tq="${id}" placeholder="Search…" value="${E(t.q)}" style="min-width:180px"></div>
<div class="v2-t"><table data-tid="${id}"><thead><tr>${cols.map((c, i) => `<th class="${c.r ? "r " : ""}${c.ns ? "ns" : ""}" ${c.ns ? "" : `data-ts="${i}"`}>${E(c.h)}${t.s === i ? (t.d > 0 ? " ▲" : " ▼") : ""}</th>`).join("")}</tr></thead><tbody>
${shown.map((o, k) => `${opt.group && t.s < 0 && !t.q && o.r.grp && (k === 0 || shown[k - 1].r.grp !== o.r.grp) ? `<tr><td colspan="${cols.length}" style="background:#eef4ff;font-weight:700;color:#1e3a8a;padding:6px 10px">${E(o.r.grp)}</td></tr>` : ""}<tr>${o.r.cells.map((c, i) => `<td class="${cols[i].r ? "r" : ""}">${c}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${cols.length}" class="v2-empty">${E(opt.empty || "No records.")}</td></tr>`}
</tbody></table></div>
<div class="v2-pg"><span>${list.length ? `${(t.pg - 1) * t.size + 1}–${Math.min(list.length, t.pg * t.size)} of ${list.length}` : "0 records"} · Rows per page <select data-tz="${id}" style="height:26px;border:1px solid #cfdcec;border-radius:6px">${[10, 15, 25, 50, 100].map((z) => `<option ${t.size === z ? "selected" : ""}>${z}</option>`).join("")}</select></span><div><button data-tp="${id}" data-v="-1" ${t.pg <= 1 ? "disabled" : ""}>‹ Previous</button><span style="padding:3px 6px">Page ${t.pg} / ${pages}</span><button data-tp="${id}" data-v="1" ${t.pg >= pages ? "disabled" : ""}>Next ›</button></div></div>`;
  }
  const bar = (pct, cls = "") => `<div class="v2-bar ${cls}"><i><em style="width:${Math.max(0, Math.min(100, pct))}%"></em></i><small>${pct.toFixed(1)}%</small></div>`;
  const badge = (s) => `<span class="v2-b ${/Approved|Completed/.test(s) ? "g" : /Rejected/.test(s) ? "r" : /Submitted|Under Review/.test(s) ? "a" : /In Progress/.test(s) ? "bl" : "s"}">${E(s)}</span>`;
  const loc = (x, b) => [x.floor || b.floor, x.room || x.area || b.area || b.room].filter(Boolean).join(" · ") || "—";

  // ---------- record lists reused by KPIs, Work Progress, Approval ----------
  function entryTable(id, list, opt = {}) {
    const cols = [{ h: "Date" }, { h: "Submitted by" }, { h: "Building" }, { h: "Floor · Location" }, { h: "BOQ" }, { h: "Work" }, { h: "Qty", r: 1 }, { h: "Unit", ns: 1 }, { h: "Completed / BOQ", r: 1 }, { h: "Progress" }, { h: "Status" }];
    if (opt.actions) cols.push({ h: "", ns: 1 });
    const rows = list.map((e) => { const q = n(e.b.qty), d = n(e.b.executedQty), pc = q ? Math.min(100, (d / q) * 100) : 0;
      const cells = [E(e.date), `<b>${E(e.by)}</b><br><small style="color:#64748b">${e.foreman ? "Foreman" : "Office"}</small>`, E(e.bld || "General"), E(loc(e.x, e.b)), E(e.b.boqId || e.x.boqCode || "—"), E(e.b.description || e.x.title || "Work"), `<b>${F(e.x.todayQty)}</b>`, E(e.b.unit || ""), `${F(d)} / ${F(q)}`, bar(pc), badge(e.status)];
      if (opt.actions) cells.push(window.PB_PROGRESS_EXTRAS ? `<button class="btn small" onclick="PB_PROGRESS_EXTRAS.hist('${E(e.x.id)}')">History</button>` : "");
      return { cells, keys: [e.date, e.by, e.bld, loc(e.x, e.b), e.b.boqId, e.b.description, n(e.x.todayQty), "", d, pc, e.status], loc: { bld: e.bld || "General", flr: e.x.floor || e.b.floor || "" }, text: [e.date, e.by, e.bld, loc(e.x, e.b), e.b.boqId, e.b.description, e.status].join(" ") }; });
    return table(id, cols, rows, opt);
  }
  function itemTable(id, list, opt = {}) {
    if (!opt.keepOrder) { const lk = (i) => [i.b.building || "", i.b.floor || "", i.b.area || i.b.room || "", i.b.boqId || ""].map((x) => String(x).toLowerCase()).join("|"); list = list.slice().sort((x, y) => lk(x).localeCompare(lk(y), undefined, { numeric: true })); opt = { ...opt, group: 1 }; }
    const cols = [{ h: "BOQ Code" }, { h: "Work Item" }, { h: "Category" }, { h: "Building" }, { h: "Floor" }, { h: "Room" }, { h: "Unit", ns: 1 }, { h: "BOQ Qty", r: 1 }, { h: "Completed", r: 1 }, { h: "Remaining", r: 1 }, { h: "Progress" }, { h: "Rate", r: 1 }, { h: "Amount", r: 1 }, { h: "Status" }, { h: "", ns: 1 }];
    const rows = list.map((i) => ({ cells: [E(i.b.boqId || "—"), `<b>${E(i.b.description || "Work")}</b>`, E(i.cat), `<b>${E(i.b.building || "General")}</b>`, E(i.b.floor || "—"), E(i.b.area || i.b.room || "—"), E(i.b.unit || ""), F(i.qty), F(i.done), F(i.rem), bar(i.pct), M(i.rate), M(i.amt), badge(i.status), i.rem > 0 && window.PB_WORK_REGISTER ? `<button class="btn small" onclick="PB_WORK_REGISTER.update('${E(i.b.id)}')">Update</button>` : ""],
      loc: { bld: i.b.building || "General", flr: i.b.floor || "" }, grp: `🏢 ${i.b.building || "General"} · ${i.b.floor || "No floor"}`, keys: [i.b.boqId, i.b.description, i.cat, i.b.building || "", i.b.floor || "", i.b.area || i.b.room || "", "", i.qty, i.done, i.rem, i.pct, i.rate, i.amt, i.status, ""], text: [i.b.boqId, i.b.description, i.cat, i.b.building, i.b.floor, i.b.area, i.b.room, i.status].join(" ") }));
    return table(id, cols, rows, opt);
  }

  // ---------- sections ----------
  const SV = {
    items: '<path d="M9 5h11M9 12h11M9 19h11"/><circle cx="4.5" cy="5" r="1.5"/><circle cx="4.5" cy="12" r="1.5"/><circle cx="4.5" cy="19" r="1.5"/>',
    pct: '<path d="M3 20h18"/><path d="M6 16l4-5 3 3 5-7"/><path d="M15 7h3v3"/>',
    done: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.8 2.8L16.5 9.5"/>',
    prog: '<path d="M14.5 5.5l4 4-9 9H5.5v-4z"/><path d="M12.5 7.5l4 4"/>',
    rem: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/>',
    pend: '<path d="M12 3l8 4v5c0 4.5-3.4 8.2-8 9-4.6-.8-8-4.5-8-9V7z"/><path d="M12 8v5M12 16h.01"/>',
    ai: '<path d="M12 3v3M12 18v3M3 12h3M18 12h3"/><rect x="7" y="7" width="10" height="10" rx="2"/><path d="M10 10h4v4h-4z"/>',
    crew: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 4.5a3 3 0 010 7M21 20c0-2.6-1.6-4.8-4-5.6"/>',
  };
  const ico = (k, c) => `<span style="display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;background:${c}1a;color:${c};flex:0 0 auto"><svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${SV[k]}</svg></span>`;
  // one row per real update (same person + work + date + qty shown once)
  const uniq = (list) => { const seen = new Set(); return list.filter((e) => { const k = [e.by, e.b.id || e.x.boqId || e.x.boqCode, e.date, n(e.x.todayQty)].join("|"); if (seen.has(k)) return false; seen.add(k); return true; }); };
  function overview(S) {
    const done = S.items.filter((i) => i.status === "Completed"), prog = S.items.filter((i) => i.status === "In Progress"), rem = S.items.filter((i) => i.status !== "Completed"), notS = S.items.filter((i) => i.status === "Not Started");
    const remVal = rem.reduce((s, i) => s + i.rem * i.rate, 0);
    const IC = { items: "#2563eb", pct: "#0f7a43", done: "#16a34a", prog: "#0ea5e9", rem: "#d97706", pend: "#dc2626" };
    const K = [["items", "Total Work Items", S.items.length, "approved BOQ items"], ["pct", "Overall Progress", S.pct.toFixed(1) + "%", "weighted by BOQ value"], ["done", "Completed", done.length, "items 100% done"], ["prog", "In Progress", prog.length, "items started"], ["rem", "Remaining", rem.length, remVal ? M(remVal) + " left" : "items not finished"], ["pend", "Pending Approval", S.pending.length, "submitted updates"]];
    const kp = `<div class="v2-k">${K.map(([k, l, v, i]) => `<button type="button" tabindex="-1" style="cursor:default;pointer-events:none;display:flex;gap:10px;align-items:center;border-top:3px solid ${IC[k]}">${ico(k, IC[k])}<span style="min-width:0"><small>${l}</small><b>${v}</b><i>${E(i)}</i></span></button>`).join("")}</div>`;
    const t = todayS(), last = {}; (db.progress || []).forEach((x) => { if (x.projectId === selectedProject && n(x.todayQty) > 0) { const d = String(x.date || "").slice(0, 10); if (!last[x.boqId] || d > last[x.boqId]) last[x.boqId] = d; } });
    const stalled = prog.filter((i) => last[i.b.id] && C().dayDiff(last[i.b.id], t) >= 7);
    // ---- intelligence ----
    const ok = uniq(S.entries.filter((e) => e.status === "Approved"));
    const recent = ok.filter((e) => e.date && C().dayDiff(e.date, t) >= 0 && C().dayDiff(e.date, t) < 14);
    const days = new Set(recent.map((e) => e.date)).size, v14 = recent.reduce((s, e) => s + e.value, 0), perDay = days ? v14 / days : 0;
    let eta = "";
    if (perDay > 0 && remVal > 0) { const d = new Date(t + "T00:00:00"); d.setDate(d.getDate() + Math.ceil(remVal / perDay)); eta = d.toISOString().slice(0, 10); }
    const blds = {}; S.items.forEach((i) => { const k = i.b.building || "General"; (blds[k] = blds[k] || []).push(i.b); });
    const bRows = Object.entries(blds).map(([k, it]) => ({ k, n: it.length, p: C().weighted(it) })).sort((x, y) => y.p - x.p);
    const al = [];
    if (S.pending.length) al.push(["a", `${S.pending.length} update(s) waiting for your approval`, "approval"]);
    if (stalled.length) al.push(["r", `${stalled.length} work item(s) idle 7+ days: ${stalled.slice(0, 3).map((i) => i.b.boqId || i.b.description).join(", ")}${stalled.length > 3 ? "…" : ""}`, "boq"]);
    if (S.plan != null && S.pct + 10 < S.plan) al.push(["r", `Behind plan by ${(S.plan - S.pct).toFixed(1)}%`, ""]);
    if (!S.entries.some((e) => e.foreman && e.date === t)) al.push(["s", "No foreman update received today", "work"]);
    const ins = [];
    ins.push(["g", perDay ? `Work speed: about ${M(perDay)} of work per working day (last 14 days)` : "Work speed: not enough approved updates in the last 14 days"]);
    if (eta) ins.push(["bl", `Estimated finish at this speed: ${eta}${S.p.end ? (eta > S.p.end ? ` — after planned end ${S.p.end}` : ` — before planned end ${S.p.end}`) : ""}`]);
    if (bRows.length > 1) ins.push(["g", `Best building: ${bRows[0].k} (${bRows[0].p.toFixed(1)}%) · Slowest: ${bRows[bRows.length - 1].k} (${bRows[bRows.length - 1].p.toFixed(1)}%)`]);
    if (notS.length) ins.push(["s", `${notS.length} item(s) not started yet — ${M(notS.reduce((s, i) => s + i.amt, 0))} of BOQ`]);
    const insCol = { g: "#15803d", bl: "#1d4ed8", s: "#475569" };
    const smart = `<div class="v2-p"><div class="v2-h"><h3 style="display:flex;gap:8px;align-items:center">${ico("ai", "#7c3aed")}<span>Smart Insights<small>alerts and forecast from your data</small></span></h3></div>
${al.length ? al.map(([c, m, go]) => `<div class="v2-al ${c}" ${go ? `data-go="${go}"` : ""}>${E(m)}${go ? " ›" : ""}</div>`).join("") : '<div class="v2-al g">All good — no alerts</div>'}
<div style="display:grid;gap:6px;margin-top:8px;padding-top:8px;border-top:1px dashed #e3e9f1">${ins.map(([c, m]) => `<div style="display:flex;gap:8px;font-size:12.5px;color:${insCol[c]}"><span style="width:7px;height:7px;border-radius:50%;background:currentColor;margin-top:6px;flex:0 0 auto"></span><span>${E(m)}</span></div>`).join("")}</div></div>`;
    // ---- foreman updates (each update once) ----
    const fAll = uniq(S.entries.filter((e) => e.foreman)), fDay = (fAll.find((e) => e.date === t) || fAll[0] || {}).date || "", fList = fAll.filter((e) => e.date === fDay);
    const fBox = `<div class="v2-p"><div class="v2-h"><h3 style="display:flex;gap:8px;align-items:center">${ico("crew", "#0f7a43")}<span>Foreman Updates ${fDay === t ? "Today" : ""}<small>${fDay === t ? `${fList.length} update(s) today` : fDay ? `no update today · latest ${E(fDay)}` : "no updates yet"}</small></span></h3><div style="display:flex;gap:6px"><button class="btn small" data-go="work">View all</button><button class="btn small" data-app="1">📱 Foreman App</button></div></div>${fList.length ? `<div style="display:grid;gap:6px;max-height:300px;overflow:auto">${fList.map((e) => { const q = n(e.b.qty), d = n(e.b.executedQty), pc = q ? Math.min(100, (d / q) * 100) : 0; return `<div style="border:1px solid #e3e9f1;border-left:4px solid #0f7a43;border-radius:9px;padding:7px 10px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>${E(e.b.boqId || e.x.boqCode || "")} ${E(e.b.description || e.x.title || "Work")}</b>${badge(e.status)}</div><div style="font-size:12px;color:#475569;margin:3px 0">🏢 ${E(e.bld || "General")} · 🏬 ${E(e.x.floor || e.b.floor || "—")} · 🚪 ${E(e.x.room || e.x.area || e.b.area || e.b.room || "—")}</div><div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;align-items:center"><span>👷 <b>${E(e.by)}</b> · Today <b>${F(e.x.todayQty)} ${E(e.b.unit || "")}</b> · Done ${F(d)} / ${F(q)}</span><span style="min-width:120px">${bar(pc)}</span></div></div>`; }).join("")}</div>` : '<div class="v2-note">No foreman updates yet. Click "📱 Foreman App" to send the app link to foremen.</div>'}</div>`;
    const cats = {}; S.items.forEach((i) => { (cats[i.cat] = cats[i.cat] || []).push(i.b); });
    const projRows = (db.projects || []).map((p) => { const it = (db.boq || []).filter((b) => b.projectId === p.id && C().approvedish(b)); return { p, n: it.length, act: C().weighted(it), plan: C().planned(p.start, p.end, todayS()) }; }).filter((r) => r.n);
    const plan = S.plan;
    const mini = (title, rows) => `<div><div style="font-size:11.5px;font-weight:800;color:#5b6b7f;text-transform:uppercase;margin:8px 0 4px">${title}</div>${rows.map(([k, c, p]) => `<div style="display:grid;grid-template-columns:minmax(0,1fr) 40px 150px;gap:8px;align-items:center;font-size:12.5px;padding:3px 0"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${E(k)}</span><span style="color:#64748b;text-align:right">${c}</span>${bar(p)}</div>`).join("") || '<div class="v2-empty">No BOQ items.</div>'}</div>`;
    return `${kp}<div class="v2-2">${smart}${fBox}</div>
<div class="v2-2"><div class="v2-p"><div class="v2-h"><h3>Planned vs Actual <small>${E(S.p.name || "")} · straight line from project start (${E(S.p.start || "not set")}) to end (${E(S.p.end || "not set")})</small></h3></div>
<div style="display:grid;gap:8px;font-size:12.5px"><div>Planned ${plan == null ? '<span style="color:#64748b">— set project start/end dates in Projects to see the plan</span>' : bar(plan, "pl")}</div><div>Actual ${bar(S.pct)}</div><div>${plan == null ? "" : S.pct + 10 < plan ? badge("Rejected").replace("Rejected", "Behind plan") : badge("Approved").replace("Approved", "On track")}</div></div></div>
<div class="v2-p"><div class="v2-h"><h3>Progress by building & category <small>items · progress</small></h3></div>${mini("Building", bRows.map((r) => [r.k, r.n, r.p]))}${mini("Category", Object.entries(cats).map(([c, it]) => [c, it.length, C().weighted(it)]))}</div></div>
<div class="v2-p"><div class="v2-h"><h3>Project-wise progress <small>all projects</small></h3></div><div class="v2-t"><table><thead><tr><th class="ns">Project</th><th class="ns r">Items</th><th class="ns">Planned</th><th class="ns">Actual</th></tr></thead><tbody>${projRows.map((r) => `<tr><td><a href="#" data-proj="${E(r.p.id)}">${E(r.p.name)}</a></td><td class="r">${r.n}</td><td>${r.plan == null ? "—" : bar(r.plan, "pl")}</td><td>${bar(r.act)}</td></tr>`).join("") || '<tr><td colspan="4" class="v2-empty">No projects with BOQ.</td></tr>'}</tbody></table></div></div>`;
  }
  function work(S) {
    const sub = `<div class="v2-sub"><button type="button" data-sub="foreman" class="${st.sub === "foreman" ? "on" : ""}">👷 Foreman Updates</button><button type="button" data-sub="manual" class="${st.sub === "manual" ? "on" : ""}">✍️ Manual Update</button></div>`;
    if (st.sub === "manual") {
      const office = S.entries.filter((e) => !e.foreman);
      return `<div class="v2-p"><div class="v2-h">${sub}<button class="btn primary" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ New Manual Update</button></div>
<div class="v2-note">The form uses the BOQ quantity and the already-approved quantity, then calculates Total = Previous + Today, Remaining = BOQ − Total and Progress %. It blocks quantities above the BOQ and a second entry for the same work on the same date. Or pick a work item below and click <b>Update</b>.</div></div>
<div class="v2-p"><div class="v2-h"><h3>Pick work to update</h3></div>${itemTable("mi", S.items.filter((i) => i.rem > 0), { size: 10, empty: "All work is complete." })}</div>
<div class="v2-p"><div class="v2-h"><h3>Office updates</h3></div>${entryTable("mo", office, { size: 10, empty: "No office updates yet." })}</div>`;
    }
    return `<div class="v2-p"><div class="v2-h">${sub}<small>Sent from the foreman phone app. New reports are reviewed in the Approval Center.</small></div>${entryTable("fm", S.entries.filter((e) => e.foreman), { size: 15, empty: "No foreman updates yet." })}</div>`;
  }
  function boqTrack(S) {
    const cats = [...new Set(S.items.map((i) => i.cat))];
    const list = S.items.filter((i) => (!st.cat || i.cat === st.cat) && (!st.bst || i.status === st.bst));
    const tot = list.reduce((s, i) => s + i.amt, 0), ex = list.reduce((s, i) => s + i.done * i.rate, 0);
    const filters = `<select data-f="cat"><option value="">All categories</option>${cats.map((c) => `<option ${st.cat === c ? "selected" : ""}>${E(c)}</option>`).join("")}</select><select data-f="bst"><option value="">All status</option>${["Not Started", "In Progress", "Completed"].map((c) => `<option ${st.bst === c ? "selected" : ""}>${c}</option>`).join("")}</select>`;
    return `<div class="v2-p"><div class="v2-h"><h3>BOQ Tracking <small>${list.length} items · BOQ ${M(tot)} · executed ${M(ex)} · remaining ${M(tot - ex)}</small></h3></div>${itemTable("bq", list, { size: 15, filters })}</div>`;
  }
  function approval(S) {
    const ss = ["Draft", "Submitted", "Under Review", "Approved", "Rejected"], cnt = (s) => S.entries.filter((e) => e.status === s).length;
    const list = S.entries.filter((e) => !st.ast || e.status === st.ast);
    const filters = `<select data-f="ast"><option value="">All status</option>${ss.map((s) => `<option ${st.ast === s ? "selected" : ""}>${s}</option>`).join("")}</select>`;
    return `<div class="v2-k" style="grid-template-columns:repeat(5,minmax(0,1fr))">${ss.map((s) => `<button type="button" data-ast="${s}" class="${st.ast === s ? "on" : ""}"><small>${s}</small><b>${cnt(s)}</b></button>`).join("")}</div>
<div class="v2-p"><div class="v2-h"><h3>Foreman submissions to review <small>Approve / Reject with remarks. Only approved quantity is added to the BOQ, once.</small></h3></div><section id="pb-cloud-reports"></section></div>
<div class="v2-p"><div class="v2-h"><h3>All progress submissions <small>Rejected and pending entries are not counted in official progress.</small></h3></div>${entryTable("ap", list, { size: 15, filters, actions: true })}</div>`;
  }
  // reports
  const REPS = { daily: "Daily Progress", weekly: "Weekly Progress", monthly: "Monthly Progress", boq: "BOQ Execution", pva: "Planned vs Actual", pend: "Pending Approval" };
  function repData(S) {
    const mode = { daily: "day", weekly: "week", monthly: "month" }[st.rep];
    if (mode) {
      const g = {}; S.entries.filter((e) => e.status === "Approved").forEach((e) => { const k = C().periodKey(e.date, mode), r = (g[k] = g[k] || { k, n: 0, items: new Set(), v: 0, by: new Set() }); r.n++; r.items.add(e.x.boqId); r.v += e.value; r.by.add(e.by); });
      return { h: [mode === "week" ? "Week from" : mode === "month" ? "Month" : "Date", "Approved updates", "BOQ items", "Work value", "Reported by"], rows: Object.values(g).sort((a, b) => b.k.localeCompare(a.k)).map((r) => [r.k, r.n, r.items.size, M(r.v), [...r.by].join(", ")]) };
    }
    if (st.rep === "boq") return { h: ["BOQ Code", "Work", "Category", "Unit", "BOQ Qty", "Completed", "Remaining", "Progress %", "Rate", "Amount", "Executed amount", "Status"], rows: S.items.map((i) => [i.b.boqId, i.b.description, i.cat, i.b.unit, F(i.qty), F(i.done), F(i.rem), i.pct.toFixed(1), M(i.rate), M(i.amt), M(i.done * i.rate), i.status]) };
    if (st.rep === "pva") return { h: ["Project", "Start", "End", "Planned %", "Actual %", "Gap", "Status"], rows: (db.projects || []).map((p) => { const it = (db.boq || []).filter((b) => b.projectId === p.id && C().approvedish(b)); if (!it.length) return null; const a = C().weighted(it), pl = C().planned(p.start, p.end, todayS()); return [p.name, p.start || "—", p.end || "—", pl == null ? "—" : pl.toFixed(1), a.toFixed(1), pl == null ? "—" : (a - pl).toFixed(1), pl == null ? "No plan dates" : a + 10 < pl ? "Behind" : "On track"]; }).filter(Boolean) };
    return { h: ["Date", "Submitted by", "Work", "Qty", "Unit", "Status"], rows: S.pending.map((e) => [e.date, e.by, e.b.description || e.x.title || "", F(e.x.todayQty), e.b.unit || "", e.status]) };
  }
  function reports(S) {
    const d = repData(S);
    return `<div class="v2-p"><div class="v2-h"><div class="v2-sub">${Object.entries(REPS).map(([k, l]) => `<button type="button" data-rep="${k}" class="${st.rep === k ? "on" : ""}">${l}</button>`).join("")}</div><div class="v2-f"><button class="btn small" data-x="csv">Excel (CSV)</button><button class="btn small" data-x="print">PDF / Print</button></div></div>
<div class="v2-note" style="margin-bottom:8px">${E(S.p.name || "")}${st.from || st.to ? ` · ${E(st.from || "start")} → ${E(st.to || "today")}` : " · all dates"}. Daily/weekly/monthly count approved updates only.</div>
<div class="v2-t" style="max-height:480px"><table id="v2Rep"><thead><tr>${d.h.map((h) => `<th class="ns">${E(h)}</th>`).join("")}</tr></thead><tbody>${d.rows.map((r) => `<tr>${r.map((c) => `<td>${E(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${d.h.length}" class="v2-empty">No records.</td></tr>`}</tbody></table></div></div>`;
  }
  function exportCsv(S) { const d = repData(S), t = [d.h, ...d.rows].map((a) => a.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\n"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + t], { type: "text/csv" })); a.download = `${st.rep}-progress-report-${todayS()}.csv`; a.click(); }
  function exportPrint(S) {
    const tb = document.getElementById("v2Rep"); if (!tb) return; const s = db.settings || {};
    const f = document.createElement("iframe"); f.style.cssText = "position:fixed;width:0;height:0;border:0"; document.body.appendChild(f);
    f.contentDocument.open(); f.contentDocument.write(`<html><head><title>${E(REPS[st.rep])} Report</title><style>@page{size:A4 landscape;margin:11mm}body{font-family:Arial;font-size:10.5px}h1{font-size:16px;margin:0}table{width:100%;border-collapse:collapse}th{background:#14213d;color:#fff;padding:5px;text-align:left;-webkit-print-color-adjust:exact;print-color-adjust:exact}td{padding:4px 5px;border-bottom:1px solid #ddd}thead{display:table-header-group}</style></head><body><h1>${E(s.companyName || "PURE_BUILD")} — ${E(REPS[st.rep])} Report</h1><p>${E(S.p.name || "")} · ${st.from || st.to ? E((st.from || "start") + " → " + (st.to || "today")) : "All dates"} · Printed ${todayS()}</p>${tb.outerHTML}<p style="margin-top:28px">Prepared by: ____________ &nbsp; Checked by: ____________ &nbsp; Approved by: ____________</p></body></html>`); f.contentDocument.close();
    setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); setTimeout(() => f.remove(), 1500); }, 400);
  }

  // ---------- page ----------
  function page() {
    const v = document.getElementById("view"); if (!v) return;
    v.classList.remove("pt-on");
    const projects = db.projects || [];
    const bl = selectedProject && typeof projectBuildings === "function" ? projectBuildings(selectedProject) : [];
    const head = `<div class="v2-head"><h2>📐 Site Progress</h2>
<select id="v2P"><option value="">— Select project —</option>${projects.map((p) => `<option value="${E(p.id)}" ${p.id === selectedProject ? "selected" : ""}>${E(p.name)}</option>`).join("")}</select>
<select id="v2B" ${bl.length ? "" : "disabled"}><option value="">All buildings</option>${bl.map((b) => `<option ${progressBuilding === b ? "selected" : ""}>${E(b)}</option>`).join("")}</select>
<input type="date" id="v2F" value="${E(st.from)}" title="From date"><input type="date" id="v2T" value="${E(st.to)}" title="To date">${st.from || st.to ? '<button class="btn small" id="v2C">All dates</button>' : ""}<button class="btn small" data-app="1" title="Foreman staff app">📱 Foreman App</button><button class="btn small" onclick="typeof setPage==='function'&&setPage('tasks')" title="Assign work to foreman">🎯 Assign Task</button><button class="btn small primary" onclick="PB_DAILY_UPDATE&&PB_DAILY_UPDATE.open()">＋ Update</button></div>`;
    if (!selectedProject || !C()) { v.innerHTML = `<div class="v2">${head}<div class="v2-p"><h3>Select a project above</h3><p style="color:#64748b;margin:4px 0 0">All Site Progress information is shown for the selected project.</p></div></div>`; bind(v, null); return; }
    const S = stats();
    const body = { overview, work, boq: boqTrack, approval, reports }[st.tab] || overview;
    v.innerHTML = `<div class="v2">${head}<div class="v2-tabs">${SECTIONS.map(([k, l]) => `<button type="button" data-tab="${k}" class="${st.tab === k ? "on" : ""}">${l}${k === "approval" && S.pending.length ? ` <span class="v2-b a">${S.pending.length}</span>` : ""}</button>`).join("")}</div>${body(S)}</div>`;
    bind(v, S);
  }
  function appModal() {
    const url = new URL("staff-mobile.html", location.href).href, p = (db.projects || []).find((z) => z.id === selectedProject) || {};
    const msg = `PURE_BUILD Foreman App${p.name ? " — " + p.name : ""}\nOpen this link, sign in with your email and send daily work updates:\n${url}`;
    if (typeof openModal !== "function") { window.open(url, "_blank"); return; }
    openModal("📱 Foreman / Staff App", `<div class="v2-note" style="margin-bottom:10px">Foremen send work quantity, photos, labour and materials from this app. Once you approve in <b>Approval Center</b>, it is added to BOQ and Site Progress. Give foreman accounts and project access from the <b>Access</b> page.</div>
<div class="field"><label>App Link</label><input id="v2Url" value="${E(url)}" readonly style="width:100%"></div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button class="btn primary" id="v2Copy">📋 Copy Link</button><a class="btn" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(msg)}">💬 Send on WhatsApp</a><a class="btn" target="_blank" rel="noopener" href="${E(url)}">↗ Open App</a><button class="btn" onclick="closeModal&&closeModal();setPage&&setPage('access')">👤 Access Page</button></div>`, () => true);
    setTimeout(() => document.getElementById("v2Copy")?.addEventListener("click", () => { navigator.clipboard?.writeText(url).then(() => typeof toast === "function" && toast("Link copied")); }), 50);
  }
  const re = () => (typeof render === "function" ? render() : page());
  function bind(v, S) {
    const on = (sel, ev, fn) => v.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, fn));
    on("#v2P", "change", (e) => { selectedProject = e.target.value; try { progressBuilding = ""; } catch (x) {} st.tbl = {}; st.list = ""; re(); });
    on("#v2B", "change", (e) => { progressBuilding = e.target.value; st.tbl = {}; re(); });
    on("#v2F", "change", (e) => { st.from = e.target.value; st.tbl = {}; re(); }); on("#v2T", "change", (e) => { st.to = e.target.value; st.tbl = {}; re(); }); on("#v2C", "click", () => { st.from = st.to = ""; re(); });
    on("[data-tab]", "click", (e) => { st.tab = e.currentTarget.dataset.tab; keep(); re(); });
    on("[data-sub]", "click", (e) => { st.sub = e.currentTarget.dataset.sub; keep(); re(); });
    on("[data-kpi]", "click", (e) => { e.preventDefault(); e.stopPropagation(); const k = e.currentTarget.dataset.kpi; st.list = st.list === k ? "" : k; delete st.tbl.kp; re(); if (st.list) setTimeout(() => document.querySelector("#view .v2-kd")?.scrollIntoView({ behavior: "smooth", block: "start" }), 30); });
    on("[data-app]", "click", appModal);
    on("[data-go]", "click", (e) => { st.tab = e.currentTarget.dataset.go; keep(); re(); });
    on("[data-proj]", "click", (e) => { e.preventDefault(); selectedProject = e.currentTarget.dataset.proj; try { progressBuilding = ""; } catch (x) {} st.tbl = {}; re(); });
    on("[data-ast]", "click", (e) => { const s = e.currentTarget.dataset.ast; st.ast = st.ast === s ? "" : s; delete st.tbl.ap; re(); });
    on("[data-f]", "change", (e) => { st[e.currentTarget.dataset.f] = e.currentTarget.value; st.tbl = {}; re(); });
    on("[data-rep]", "click", (e) => { st.rep = e.currentTarget.dataset.rep; keep(); re(); });
    on("[data-x]", "click", (e) => { const S2 = stats(); e.currentTarget.dataset.x === "csv" ? exportCsv(S2) : exportPrint(S2); });
    on("th[data-ts]", "click", (e) => { const id = e.currentTarget.closest("table").dataset.tid, t = st.tbl[id], i = +e.currentTarget.dataset.ts; if (!t) return; t.d = t.s === i ? -t.d : 1; t.s = i; re(); });
    on("[data-tp]", "click", (e) => { const t = st.tbl[e.currentTarget.dataset.tp]; if (t) { t.pg += +e.currentTarget.dataset.v; re(); } });
    on("[data-tl]", "change", (e) => { const t = st.tbl[e.currentTarget.dataset.tl]; if (!t) return; t[e.currentTarget.dataset.k] = e.currentTarget.value; if (e.currentTarget.dataset.k === "bld") t.flr = ""; t.pg = 1; re(); });
    on("[data-tz]", "change", (e) => { const t = st.tbl[e.currentTarget.dataset.tz]; if (!t) return; t.size = +e.currentTarget.value || 15; t.pg = 1; re(); });
    let tm; on("[data-tq]", "input", (e) => { const id = e.currentTarget.dataset.tq, t = st.tbl[id]; if (!t) return; t.q = e.currentTarget.value; t.pg = 1; clearTimeout(tm); tm = setTimeout(() => { re(); const i = document.querySelector(`[data-tq="${id}"]`); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 300); });
  }
  function install() {
    if (window.progress && window.progress.__spn) return;
    page.__spn = true; page.__pt = true;
    window.PB_OLD_PROGRESS = window.PB_OLD_PROGRESS || window.progress;
    window.progress = page;
  }
  install();
  window.addEventListener("load", () => setTimeout(install, 0));
  window.PB_SITE_PROGRESS_NEW = { page, stats, appModal };
})();
