/* AP Dashboard look (display-only). Redraws the top of the AP Dashboard tab:
   summary banner, KPI cards, aging donut and top suppliers. Reads db.payables only; never saves. */
(function () {
  if (typeof payables !== "function") return;
  const M = (v) => (typeof money === "function" ? money(v) : "AED " + Math.round(v || 0).toLocaleString());
  const E = (s) => (typeof esc === "function" ? esc(s) : String(s == null ? "" : s));
  const css = `
.apd{display:grid;gap:12px;margin-bottom:12px}
.apd-hero{display:grid;grid-template-columns:1.3fr 1fr 1fr;gap:12px}
.apd-card{background:linear-gradient(150deg,#fff,#f7fafd);border:1px solid #dce6ef;border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(20,48,77,.06)}
.apd-main{background:linear-gradient(135deg,#0f2a4a,#1d4f86);color:#fff;border:0}
.apd-main small{color:#b9d3f0;font-weight:800;letter-spacing:.08em;font-size:10px}
.apd-main .big{font-size:30px;font-weight:900;margin:6px 0 2px}
.apd-main .sub{font-size:12px;color:#d5e6f8}
.apd-bar{height:9px;border-radius:9px;background:rgba(255,255,255,.18);overflow:hidden;margin:12px 0 6px}
.apd-bar i{display:block;height:100%;background:linear-gradient(90deg,#34d399,#a7f3d0);border-radius:9px}
.apd-legend{display:flex;justify-content:space-between;font-size:11px;color:#d5e6f8}
.apd-h{font-size:11px;font-weight:900;color:#5b7189;letter-spacing:.06em;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center}
.apd-h button{font-size:10px}
.apd-donut-wrap{display:flex;gap:14px;align-items:center}
.apd-donut{width:112px;height:112px;border-radius:50%;flex:0 0 112px;display:grid;place-items:center}
.apd-donut div{width:72px;height:72px;border-radius:50%;background:#fff;display:grid;place-items:center;text-align:center;font-size:9px;color:#71869c;font-weight:800}
.apd-donut b{display:block;font-size:13px;color:#153754}
.apd-leg{display:grid;gap:5px;font-size:11px;flex:1}
.apd-leg div{display:flex;justify-content:space-between;gap:6px}
.apd-leg span{display:flex;align-items:center;gap:6px;color:#4a5f75}
.apd-leg i{width:9px;height:9px;border-radius:3px;display:inline-block}
.apd-sup{display:grid;gap:8px}
.apd-sup .row{font-size:11px;cursor:pointer}
.apd-sup .row div:first-child{display:flex;justify-content:space-between;color:#24425f;font-weight:700}
.apd-sup .tr{height:6px;background:#edf2f7;border-radius:6px;margin-top:3px;overflow:hidden}
.apd-sup .tr i{display:block;height:100%;background:linear-gradient(90deg,#2b6cb0,#63b3ed);border-radius:6px}
.apd-kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}
.apd-k{position:relative;background:#fff;border:1px solid #dce6ef;border-radius:14px;padding:12px 12px 12px 15px;cursor:pointer;transition:transform .15s,box-shadow .15s;overflow:hidden}
.apd-k:hover{transform:translateY(-2px);box-shadow:0 10px 22px rgba(20,48,77,.09)}
.apd-k:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--c)}
.apd-k small{display:block;font-size:10px;font-weight:800;color:#71869c}
.apd-k b{display:block;font-size:17px;color:#153754;margin-top:4px}
.apd-k span{display:block;font-size:10px;color:#93a3b4;margin-top:2px}
.apd-empty{font-size:12px;color:#8a9aab;padding:10px 0}
body:not(.light-theme) .apd-card:not(.apd-main),body:not(.light-theme) .apd-k{}
@media(max-width:1100px){.apd-hero{grid-template-columns:1fr}.apd-kpis{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.apd-kpis{grid-template-columns:repeat(2,1fr)}}
@media print{.apd-k:hover{transform:none}}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  function draw() {
    if ((window.apTab || "overview") !== "overview") return;
    const ws = document.querySelector("#view .ap-workspace"); if (!ws || ws.querySelector(".apd")) return;
    const sp = typeof selectedProject !== "undefined" ? selectedProject : "";
    const all = (db.payables || []).filter((p) => !sp || p.projectId === sp);
    const posted = all.filter((p) => (typeof apIsPosted === "function" ? apIsPosted(p) : true));
    const out = (p) => Math.max(0, Number(apOutstandingAmount(p)) || 0);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    /* same rule as the AP page: days from today to the bill due date (no due date = due today) */
    const due = (p) => { if (!p.dueDate) return 0; return Math.round((new Date(p.dueDate + "T00:00:00") - today) / 86400000); };
    let billed = 0, outstanding = 0, overdue = 0, week = 0; const ag = [0, 0, 0, 0, 0]; const sup = {};
    posted.forEach((p) => {
      billed += Number(p.amount) || 0; const b = out(p); if (b <= 0) return; outstanding += b;
      const d = due(p); if (d < 0) overdue += b; else if (d <= 7) week += b;
      const o = -d; ag[o <= 0 ? 0 : o <= 30 ? 1 : o <= 60 ? 2 : o <= 90 ? 3 : 4] += b;
      const k = String(p.supplier || "—").trim(); sup[k] = (sup[k] || 0) + b;
    });
    const paid = Math.max(0, billed - outstanding); const pct = billed ? Math.round((paid / billed) * 100) : 0;
    const pending = all.filter((p) => ["Draft", "Submitted"].includes(p.apStatus || "")).length;
    const adv = ws.querySelector(".appx-dash .appx-kpi:nth-child(2) b"); const advTxt = adv ? adv.textContent : M(0);
    const mis = ws.querySelector(".appx-dash .appx-kpi:nth-child(3) b"); const misTxt = mis ? mis.textContent : "0";
    const cols = ["#22a06b", "#3b82f6", "#f5a524", "#f97316", "#e5484d"], names = ["Not due", "1–30 days", "31–60 days", "61–90 days", "90+ days"];
    let acc = 0; const seg = ag.map((v, i) => { const a = acc; acc += outstanding ? (v / outstanding) * 100 : 0; return `${cols[i]} ${a}% ${acc}%`; }).join(",");
    const donutBg = outstanding ? `conic-gradient(${seg})` : "#edf2f7";
    const top = Object.entries(sup).sort((a, b) => b[1] - a[1]).slice(0, 5); const mx = top.length ? top[0][1] : 1;
    const k = (c, l, v, s, tab) => `<div class="apd-k" style="--c:${c}" onclick="setApTab('${tab}')"><small>${l}</small><b>${v}</b><span>${s}</span></div>`;
    const html = `<div class="apd">
<div class="apd-hero">
 <div class="apd-card apd-main"><small>TOTAL SUPPLIER BALANCE</small><div class="big">${M(outstanding)}</div><div class="sub">${posted.length} posted bills · ${Object.keys(sup).length} suppliers with balance</div>
  <div class="apd-bar"><i style="width:${pct}%"></i></div><div class="apd-legend"><span>Paid ${M(paid)} (${pct}%)</span><span>Billed ${M(billed)}</span></div></div>
 <div class="apd-card"><div class="apd-h">AGING OF BALANCE <button class="btn small" onclick="setApTab('aging')">Open</button></div>
  <div class="apd-donut-wrap"><div class="apd-donut" style="background:${donutBg}"><div><span>Overdue<b>${outstanding ? Math.round((overdue / outstanding) * 100) : 0}%</b></span></div></div>
  <div class="apd-leg">${ag.map((v, i) => `<div><span><i style="background:${cols[i]}"></i>${names[i]}</span><b>${M(v)}</b></div>`).join("")}</div></div></div>
 <div class="apd-card"><div class="apd-h">TOP SUPPLIERS TO PAY <button class="btn small" onclick="setApTab('suppliers')">All</button></div>
  <div class="apd-sup">${top.map(([n, v]) => `<div class="row" onclick="setApTab('suppliers')"><div><span>${E(n)}</span><span>${M(v)}</span></div><div class="tr"><i style="width:${Math.max(4, (v / mx) * 100)}%"></i></div></div>`).join("") || '<div class="apd-empty">No supplier balance. All paid.</div>'}</div></div>
</div>
<div class="apd-kpis">
 ${k("#e5484d", "Overdue", M(overdue), "Needs payment now", "reports")}
 ${k("#f5a524", "Due Next 7 Days", M(week), "Upcoming bills", "bills")}
 ${k("#22a06b", "Total Paid", M(paid), pct + "% of billed", "payments")}
 ${k("#7c5cd6", "Pending Approval", pending, "Draft / Submitted bills", "approval")}
 ${k("#0ea5e9", "Vendor Advances", advTxt, "Unadjusted balance", "advances")}
 ${k("#d9534f", "Match Issues", misTxt, "3-way mismatches", "verify")}
</div></div>`;
    ws.querySelectorAll(".ap-simple-kpis,.appx-dash").forEach((n) => (n.style.display = "none"));
    ws.insertAdjacentHTML("afterbegin", html);
  }
  const base = payables;
  window.payables = payables = function () { const r = base.apply(this, arguments); try { draw(); } catch (e) { console.error("AP dashboard look", e); } return r; };
})();
