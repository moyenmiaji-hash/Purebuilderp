import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/app")({
  beforeLoad: () => {
    throw redirect({ href: "/app/erp.html" });
  },
  head: () => ({
    meta: [
      { title: "PURE BUILD ERP – App" },
      { name: "description", content: "Open the PURE BUILD construction ERP." },
      { property: "og:title", content: "PURE BUILD ERP – App" },
      { property: "og:description", content: "Open the PURE BUILD construction ERP." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});
