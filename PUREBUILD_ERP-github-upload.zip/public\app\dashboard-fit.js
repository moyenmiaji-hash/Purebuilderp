/* Dashboard one-screen fit + click-to-open box viewer (display only, never saves).
   Every box except the top KPI cards opens in a movable window with Bigger / Smaller / Close. */
(function () {
  var css = `
html body.dashboard-mode #view .dashboard-row>.dashboard-panel{min-height:0!important;overflow:hidden!important;position:relative}
html body.dashboard-mode #view .dashboard-row{margin-bottom:8px!important;gap:8px!important}
html body.dashboard-mode #view .project-financial-panel .pf-scroll{min-height:0!important}
html body.dashboard-mode #view .overview-row{grid-template-columns:minmax(0,2.4fr) minmax(0,1fr)!important}
html body.dashboard-mode #view .overview-row>.dashboard-panel.project-financial-panel:nth-child(n){grid-column:1!important;grid-row:1!important}
html body.dashboard-mode #view .overview-row>.dashboard-panel.dashboard-quick-panel:nth-child(n){grid-column:2!important;grid-row:1!important}
html body.dashboard-mode #view .overview-row>.dashboard-panel:nth-child(n):not(.project-financial-panel):not(.dashboard-quick-panel){grid-column:1/-1!important;grid-row:2!important}
.dbx-head-host{display:flex!important;align-items:center;gap:8px}.dbx-head-host>h2,.dbx-head-host>h3,.dbx-head-host>h4{margin-right:auto!important}
.dbx-abs{position:absolute;top:10px;right:10px}
.dbx-hint{margin-left:8px;white-space:nowrap;flex:none;font-size:10px;font-weight:800;color:#2f80ed;background:#fff;border:1px solid #cfe0f5;border-radius:8px;padding:2px 6px;cursor:pointer;z-index:3}.dbx-hint:hover{background:#2f80ed;color:#fff}
.dbx-win{position:fixed;z-index:9999;background:var(--panel,#fff);color:inherit;border-radius:14px;box-shadow:0 24px 70px rgba(10,30,60,.35);display:flex;flex-direction:column;overflow:hidden;border:1px solid #d6e2ee}
body.dark-theme .dbx-win{background:#10233a;border-color:#2b4159}
.dbx-bar{display:flex;align-items:center;gap:6px;padding:8px 10px;background:linear-gradient(135deg,#0f2a4a,#1d4f86);color:#fff;cursor:move;user-select:none}
.dbx-bar b{flex:1;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dbx-bar button{border:0;border-radius:8px;padding:5px 10px;font-weight:800;cursor:pointer;background:#ffffff22;color:#fff}
.dbx-bar button.x{background:#e5484d}
.dbx-body{flex:1;overflow:auto;padding:12px}
.dbx-body .dashboard-panel{height:auto!important;max-height:none!important;overflow:visible!important;cursor:default!important;box-shadow:none!important;border:0!important;margin:0!important;width:auto!important}
.dbx-body .pf-scroll{max-height:none!important;height:auto!important}
.dbx-body .dbx-hint{display:none}`;
  var s = document.createElement("style"); s.textContent = css; document.head.appendChild(s);

  function fit() {
    if (!document.body.classList.contains("dashboard-mode")) return;
    var view = document.getElementById("view"); if (!view) return;
    var rows = view.querySelectorAll(".dashboard-row"); if (!rows.length) return;
    var top = rows[0].getBoundingClientRect().top + window.scrollY;
    var avail = window.innerHeight - top - 12;
    var units = 0;
    rows.forEach(function (r) { units += r.classList.contains("overview-row") ? 2 : 1; });
    var gaps = units * 8;
    var unit = Math.max(150, Math.floor((avail - gaps) / units));
    rows.forEach(function (r) {
      r.querySelectorAll(":scope>.dashboard-panel").forEach(function (p) {
        p.style.setProperty("height", unit + "px", "important");
        p.style.setProperty("max-height", unit + "px", "important");
        var sc = p.querySelector(".pf-scroll"); if (sc) sc.style.setProperty("max-height", (unit - 70) + "px", "important");
        if (!p.querySelector(".dbx-hint")) {
          var h = p.querySelector("h2,h3,h4"), host = h && h.parentElement !== p ? h.parentElement : null;
          var btn = '<button type="button" class="dbx-hint">View all ⤢</button>';
          if (host) { host.classList.add("dbx-head-host"); host.insertAdjacentHTML("beforeend", btn); }
          else { p.insertAdjacentHTML("beforeend", btn); p.lastElementChild.classList.add("dbx-abs"); }
        }
      });
    });
  }

  function open(panel) {
    var t = panel.querySelector("h2,h3,h4,.panel-title");
    var title = t ? t.textContent.trim() : "Dashboard";
    var w = Math.min(1100, innerWidth - 60), h = Math.min(720, innerHeight - 60);
    var win = document.createElement("div"); win.className = "dbx-win";
    win.style.cssText += ";width:" + w + "px;height:" + h + "px;left:" + (innerWidth - w) / 2 + "px;top:" + (innerHeight - h) / 2 + "px";
    win.innerHTML = '<div class="dbx-bar"><b></b><button type="button" data-z="1" title="Bigger">＋ Bigger</button><button type="button" data-z="-1" title="Smaller">－ Smaller</button><button type="button" data-z="max" title="Full screen">⤢</button><button type="button" class="x" title="Close">✕ Cancel</button></div><div class="dbx-body"></div>';
    win.querySelector("b").textContent = title;
    var clone = panel.cloneNode(true); clone.removeAttribute("style");
    win.querySelector(".dbx-body").appendChild(clone);
    document.body.appendChild(win);
    win.querySelector(".x").onclick = function () { win.remove(); };
    win.querySelectorAll("[data-z]").forEach(function (b) {
      b.onclick = function () {
        var r = win.getBoundingClientRect(), z = b.dataset.z;
        if (z === "max") { win.style.left = "10px"; win.style.top = "10px"; win.style.width = innerWidth - 20 + "px"; win.style.height = innerHeight - 20 + "px"; return; }
        var f = z === "1" ? 1.15 : 0.87;
        var nw = Math.max(360, Math.min(innerWidth - 10, r.width * f)), nh = Math.max(260, Math.min(innerHeight - 10, r.height * f));
        win.style.width = nw + "px"; win.style.height = nh + "px";
        win.style.left = Math.max(5, r.left + (r.width - nw) / 2) + "px"; win.style.top = Math.max(5, r.top + (r.height - nh) / 2) + "px";
      };
    });
    var bar = win.querySelector(".dbx-bar");
    bar.addEventListener("pointerdown", function (e) {
      if (e.target.closest("button")) return;
      var r = win.getBoundingClientRect(), dx = e.clientX - r.left, dy = e.clientY - r.top;
      bar.setPointerCapture(e.pointerId);
      function mv(ev) { win.style.left = Math.max(0, Math.min(innerWidth - 80, ev.clientX - dx)) + "px"; win.style.top = Math.max(0, Math.min(innerHeight - 40, ev.clientY - dy)) + "px"; }
      function up() { bar.removeEventListener("pointermove", mv); bar.removeEventListener("pointerup", up); }
      bar.addEventListener("pointermove", mv); bar.addEventListener("pointerup", up);
    });
  }

  document.addEventListener("click", function (e) {
    if (!document.body.classList.contains("dashboard-mode")) return;
    var b = e.target.closest("#view .dbx-hint"); if (!b) return;
    var p = b.closest(".dashboard-panel"); if (p) open(p);
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") { var w = document.querySelectorAll(".dbx-win"); if (w.length) w[w.length - 1].remove(); } });

  var t; function later() { clearTimeout(t); t = setTimeout(fit, 120); }
  new MutationObserver(later).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });
  addEventListener("resize", later); later();
})();
