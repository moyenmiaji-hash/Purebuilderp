/* Locations & Allocation drill-down view (Building -> Floor -> Room -> Room panel).
   UI only: reads db.projectLocations / db.boq / db.locationMeta in their existing shape.
   The previous list view stays available below ("Manage list") so all old actions keep working. */
(function(){
  const num=v=>Number(v)||0;
  const nav=window.PB_LOC_NAV={pid:null,b:'',f:'',tab:'floors',q:''};
  const J=v=>esc(JSON.stringify(v));
  const blds=pid=>Array.isArray(db.projectLocations?.[pid])?db.projectLocations[pid]:[];
  const boqOf=pid=>(db.boq||[]).filter(i=>String(i.projectId)===String(pid));
  const inB=(i,b)=>String(i.building||'')===b;
  const stats=list=>{const q=list.reduce((n,i)=>n+num(i.qty),0),d=list.reduce((n,i)=>n+Math.min(num(i.executedQty),num(i.qty)),0),amt=list.reduce((n,i)=>n+num(i.amount),0),done=list.reduce((n,i)=>n+(num(i.qty)?Math.min(num(i.executedQty),num(i.qty))/num(i.qty)*num(i.amount):0),0);return{n:list.length,q,d,amt,pct:q?Math.min(100,d/q*100):0,rem:Math.max(0,amt-done)}};
  function roomStatus(list){
    if(!list.length)return['Not Started','ns'];
    if(list.some(i=>['Draft','Under Review'].includes(boqStatus(i))))return['Pending','pe'];
    const s=stats(list);if(s.pct>=99.999)return['Completed','co'];if(s.d>0)return['In Progress','ip'];return['Not Started','ns'];
  }
  const ico={b:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 7h2M14 7h2M8 11h2M14 11h2M8 15h2M14 15h2M10 21v-3h4v3"/></svg>',
    door:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17M3 21h18"/><circle cx="14.5" cy="12" r=".8" fill="currentColor"/></svg>'};
  const go=(b,f)=>{nav.b=b;nav.f=f;nav.q='';projectDetail(nav.pid,'locations')};
  window.pbLocGo=(b,f)=>go(b||'',f||'');
  window.pbLocTab=t=>{nav.tab=t;projectDetail(nav.pid,'locations')};
  function addLoc(pid,b,f,r){
    db.projectLocations=db.projectLocations||{};const L=db.projectLocations[pid]=blds(pid);
    let B=L.find(x=>String(x.name||'').toLowerCase()===b.toLowerCase());if(!B){B={name:b,floors:[]};L.push(B)}B.floors=Array.isArray(B.floors)?B.floors:[];
    if(!f)return true;let F=B.floors.find(x=>String(x.name||'').toLowerCase()===f.toLowerCase());if(!F){F={name:f,rooms:[]};B.floors.push(F)}F.rooms=Array.isArray(F.rooms)?F.rooms:[];
    if(r&&!F.rooms.some(x=>String(x).toLowerCase()===r.toLowerCase()))F.rooms.push(r);return true;
  }
  window.pbLocAdd=function(kind){
    const pid=nav.pid,lbl=kind==='b'?'Building name':kind==='f'?'Floor name':'Room name / number',ph=kind==='b'?'Building E':kind==='f'?'8th Floor':'801';
    openModal(`Add ${kind==='b'?'Building':kind==='f'?'Floor':'Room'}`,`<div class="formgrid"><div class="field full"><label>${lbl} *</label><input id="lfName" maxlength="160" placeholder="${ph}"></div></div>`,()=>{
      const v=document.getElementById('lfName').value.trim();if(!v){toast(lbl+' is required');return false}
      const B=blds(pid).find(x=>x.name===nav.b),F=B?.floors?.find(x=>x.name===nav.f);
      if(kind==='b'&&blds(pid).some(x=>String(x.name).toLowerCase()===v.toLowerCase())){toast('That building already exists');return false}
      if(kind==='f'&&(B?.floors||[]).some(x=>String(x.name).toLowerCase()===v.toLowerCase())){toast('That floor already exists');return false}
      if(kind==='r'&&(F?.rooms||[]).some(x=>String(x).toLowerCase()===v.toLowerCase())){toast('That room already exists on this floor');return false}
      if(kind==='b')addLoc(pid,v);else if(kind==='f')addLoc(pid,nav.b,v);else addLoc(pid,nav.b,nav.f,v);
      projectHistoryAdd(pid,'Project location added',[kind==='b'?v:nav.b,kind==='f'?v:kind==='r'?nav.f:'',kind==='r'?v:''].filter(Boolean).join(' / '));
      save();closeModal();if(kind==='b')nav.b=v;projectDetail(pid,'locations');return false});
  };
  window.pbLocBulk=function(){
    const pid=nav.pid;if(!nav.b){toast('Open a building first');return}
    openModal(`Bulk Add · ${esc(nav.b)}`,`<div class="formgrid"><div class="field"><label>From floor no. *</label><input id="lbFrom" type="number" min="0" value="1"></div><div class="field"><label>To floor no. *</label><input id="lbTo" type="number" min="0" value="10"></div><div class="field"><label>Rooms per floor</label><input id="lbRooms" type="number" min="0" max="200" value="12"></div><div class="field"><label>Room numbering</label><select id="lbFmt" class="select"><option value="h">Floor × 100 (801, 802…)</option><option value="s">Simple (Room 1, 2…)</option></select></div></div><p class="muted">Existing floors and rooms are kept; only missing ones are added.</p>`,()=>{
      const a=Math.floor(num(document.getElementById('lbFrom').value)),z=Math.floor(num(document.getElementById('lbTo').value)),n=Math.min(200,Math.floor(num(document.getElementById('lbRooms').value))),h=document.getElementById('lbFmt').value==='h';
      if(z<a||z-a>150){toast('Check the floor range');return false}
      const ord=k=>k===0?'Ground Floor':k+(k%100>=11&&k%100<=13?'th':['th','st','nd','rd'][k%10]||'th')+' Floor';
      for(let k=a;k<=z;k++){addLoc(pid,nav.b,ord(k));for(let r=1;r<=n;r++)addLoc(pid,nav.b,ord(k),h?String(k*100+r):'Room '+r)}
      projectHistoryAdd(pid,'Bulk locations added',`${nav.b}: floors ${a}–${z}, ${n} rooms each`);save();closeModal();projectDetail(pid,'locations');toast('Floors and rooms added');return false});
  };
  function tree(pid,L,boq){
    return `<div class="lf-tree"><input class="input lf-search" placeholder="🔎 Search building, floor or room…" value="${esc(nav.q)}" oninput="PB_LOC_NAV.q=this.value;const q=this.value.trim().toLowerCase();document.querySelectorAll('.lf-node').forEach(n=>n.style.display=!q||n.dataset.t.includes(q)?'':'none')">
    ${L.map(B=>{const fl=B.floors||[],open=nav.b===B.name,rc=fl.reduce((n,f)=>n+(f.rooms||[]).length,0);
      return `<div class="lf-node" data-t="${esc([B.name,...fl.map(f=>f.name+' '+(f.rooms||[]).join(' '))].join(' ').toLowerCase())}"><button type="button" class="lf-bld ${open?'on':''}" onclick='pbLocGo(${J(B.name)},"")'><i>${ico.b}</i><span><b>${esc(B.name)}</b><small>${fl.length} Floors · ${rc} Rooms</small></span><em>${open?'⌃':'⌄'}</em></button>
      ${open?`<div class="lf-fl">${fl.map(F=>`<button type="button" class="${nav.f===F.name?'on':''}" onclick='pbLocGo(${J(B.name)},${J(F.name)})'><span>› ${esc(F.name)}</span><small>${(F.rooms||[]).length} Rooms</small></button>`).join('')||'<div class="muted" style="padding:6px 12px">No floors yet</div>'}</div>`:''}</div>`}).join('')||'<div class="empty">No buildings yet. Use “+ Add Building”.</div>'}</div>`;
  }
  function crumbs(){const c=[`<a onclick='pbLocGo("","")'>Locations &amp; Allocation</a>`];if(nav.b)c.push(`<a onclick='pbLocGo(${J(nav.b)},"")'>${esc(nav.b)}</a>`);if(nav.f)c.push(`<b>${esc(nav.f)}</b>`);return `<div class="lf-crumb">${nav.b?`<a class="lf-back" onclick='pbLocGo(${nav.f?J(nav.b):'""'},"")'>←</a>`:''}Projects / Sites › ${c.join(' › ')}</div>`}
  const kpi=(v,l,cls='')=>`<div class="lf-kpi ${cls}"><b>${v}</b><small>${l}</small></div>`;
  function buildingView(pid,B,boq){
    const fl=B.floors||[],rc=fl.reduce((n,f)=>n+(f.rooms||[]).length,0),items=boq.filter(i=>inB(i,B.name)),s=stats(items);
    const floorCard=F=>{const fi=items.filter(i=>String(i.floor||'')===F.name),fs=stats(fi);return `<button type="button" class="lf-fcard ${nav.f===F.name?'on':''}" onclick='pbLocGo(${J(B.name)},${J(F.name)})'><i>${ico.b}</i><span><b>${esc(F.name)}</b><small>${(F.rooms||[]).length} Rooms${fi.length?` · ${fs.pct.toFixed(0)}%`:''}</small></span><em class="lf-x" title="Delete floor" onclick='pbLocDel("f",${J(F.name)},"",event)'>✕</em><em>›</em></button>`};
    const rooms=[];fl.forEach(F=>(F.rooms||[]).forEach(r=>rooms.push([F.name,String(r)])));
    return `<div class="lf-card"><div class="lf-bhead"><div class="lf-bimg">${ico.b}</div><div><h3>${esc(B.name)}</h3><div class="muted">${esc(projectName(pid))}</div></div><div class="lf-acts"><button class="btn primary" type="button" onclick="pbLocAdd('f')">+ Add Floor</button><button class="btn" type="button" onclick="pbLocBulk()">Bulk Add</button></div></div>
    <div class="lf-kpis">${kpi(fl.length,'Total Floors')}${kpi(rc,'Total Rooms')}${kpi(items.length,'Assigned BOQ')}${kpi(s.pct.toFixed(0)+'%','Overall Progress','gr')}</div>
    <div class="lf-tabs"><button class="${nav.tab!=='rooms'?'on':''}" onclick="pbLocTab('floors')">Floors</button><button class="${nav.tab==='rooms'?'on':''}" onclick="pbLocTab('rooms')">All Rooms</button></div>
    ${nav.tab==='rooms'?roomGrid(pid,B.name,null,rooms,items):`<div class="lf-fgrid">${fl.map(floorCard).join('')||'<div class="empty">No floors yet. Use “+ Add Floor” or “Bulk Add”.</div>'}</div>`}</div>`;
  }
  function used(pid,b,f,r){const m=x=>String(x.projectId)===String(pid)&&String(x.building||(typeof stockBld==='function'&&x.direction?stockBld(x):'')||'')===b&&(!f||String(x.floor||'')===f)&&(!r||String(x.area||x.room||'')===r);
    const n=(db.boq||[]).filter(m).length+(f?(db.transactions||[]).filter(m).length+(db.stock||[]).filter(m).length+(db.dailyLogs||db.dailyReports||[]).filter(m).length:0);return n}
  window.pbLocDel=function(kind,f,r,ev){ev&&ev.stopPropagation();const pid=nav.pid,B=blds(pid).find(x=>x.name===nav.b);if(!B)return;
    const F=(B.floors||[]).find(x=>x.name===f);if(!F)return;const label=kind==='f'?f:`${r} (${f})`;
    const u=used(pid,B.name,f,kind==='r'?r:'');if(u){toast(`Cannot delete ${label}: ${u} BOQ / cost / stock / report record(s) use it. Move them first.`);return}
    if(kind==='f'&&(F.rooms||[]).length&&!confirm(`${f} has ${(F.rooms||[]).length} room(s). Delete the floor and its empty rooms?`))return;
    if(!confirm(`Delete ${label}? Nothing else is removed.`))return;
    if(kind==='f'){B.floors=B.floors.filter(x=>x!==F);if(nav.f===f)nav.f=''}else F.rooms=(F.rooms||[]).filter(x=>String(x)!==r);
    projectHistoryAdd(pid,kind==='f'?'Floor deleted':'Room deleted',[B.name,f,kind==='r'?r:''].filter(Boolean).join(' / '));save();toast('Deleted');projectDetail(pid,'locations')};
  window.pbLocTpl=function(){const pid=nav.pid,B=blds(pid).find(x=>x.name===nav.b),F=B&&(B.floors||[]).find(x=>x.name===nav.f);if(!F)return;
    const others=(B.floors||[]).filter(x=>x!==F&&(x.rooms||[]).length),fn=parseInt(String(F.name).match(/\d+/)?.[0]||'1',10);
    openModal(`Room template · ${esc(F.name)}`,`<div class="formgrid"><div class="field full"><label>Method</label><select id="ltM" class="select" onchange="document.getElementById('ltA').style.display=this.value==='n'?'':'none';document.getElementById('ltC').style.display=this.value==='c'?'':'none'"><option value="n">Number of rooms (auto names)</option>${others.length?'<option value="c">Copy rooms from another floor</option>':''}<option value="l">Type a list of room names</option></select></div>
    <div id="ltA" class="formgrid" style="grid-column:1/-1"><div class="field"><label>How many rooms *</label><input id="ltN" type="number" min="1" max="200" value="12"></div><div class="field"><label>First number</label><input id="ltS" type="number" min="0" value="${fn*100+1}"></div><div class="field"><label>Prefix (optional)</label><input id="ltP" maxlength="20" placeholder="Room "></div></div>
    <div id="ltC" class="field full" style="display:none"><label>Copy from floor</label><select id="ltF" class="select">${others.map(o=>`<option value="${esc(o.name)}">${esc(o.name)} (${o.rooms.length} rooms)</option>`).join('')}</select><small class="muted">Numbers are shifted to this floor (e.g. 701 → ${fn}01).</small></div>
    <div class="field full"><label>Or room names, comma / new line</label><textarea id="ltL" placeholder="Kitchen, Bedroom 1, Toilet"></textarea></div></div><p class="muted">Existing rooms are kept; duplicates are skipped.</p>`,()=>{
      const m=document.getElementById('ltM').value;let names=[];
      if(m==='n'){const n=Math.min(200,Math.floor(num(document.getElementById('ltN').value))),st=Math.floor(num(document.getElementById('ltS').value)),pr=document.getElementById('ltP').value;if(n<1){toast('Enter how many rooms');return false}for(let i=0;i<n;i++)names.push(pr+(st+i))}
      else if(m==='c'){const src=(B.floors||[]).find(x=>x.name===document.getElementById('ltF').value),sn=parseInt(String(src?.name||'').match(/\d+/)?.[0]||'',10);names=(src?.rooms||[]).map(r=>{r=String(r);const k=parseInt(r.match(/\d+/)?.[0]||'',10);return sn&&k&&Math.floor(k/100)===sn?r.replace(String(k),String(fn*100+k%100)):r})}
      else names=document.getElementById('ltL').value.split(/[,\n]/).map(x=>x.trim()).filter(Boolean);
      if(!names.length){toast('No rooms to add');return false}
      const before=(F.rooms||[]).length;names.forEach(r=>addLoc(pid,B.name,F.name,r.slice(0,200)));const added=F.rooms.length-before;
      projectHistoryAdd(pid,'Rooms added from template',`${B.name} / ${F.name}: ${added} room(s)`);save();closeModal();toast(`${added} room(s) added`);projectDetail(pid,'locations');return false});
  };
  function roomGrid(pid,b,f,rooms,items){
    return `<div class="lf-rgrid">${rooms.map(([fn,r])=>{const ri=items.filter(i=>String(i.floor||'')===fn&&String(i.area||'')===r),[st,c]=roomStatus(ri);
      return `<button type="button" class="lf-room" data-t="${esc((r+' '+fn).toLowerCase())}" onclick='pbRoomOpen(${J(pid)},${J([b,fn,r])})'><i>${ico.door}</i><span><b>${esc(r)}</b>${f?'':`<small class="muted">${esc(fn)}</small>`}<em class="lf-st ${c}">${st}</em></span><u class="lf-x" title="Delete room" onclick='pbLocDel("r",${J(fn)},${J(r)},event)'>✕</u><u>›</u></button>`}).join('')||'<div class="empty">No rooms on this floor yet. Use “+ Add Room”.</div>'}</div>`;
  }
  function floorView(pid,B,F,boq){
    const items=boq.filter(i=>inB(i,B.name)),rooms=(F.rooms||[]).map(r=>[F.name,String(r)]),fi=items.filter(i=>String(i.floor||'')===F.name),s=stats(fi);
    return `<div class="lf-card"><div class="lf-bhead"><div class="lf-bimg sm">${ico.b}</div><div><h3>${esc(F.name)}</h3><div class="muted">${rooms.length} Rooms · ${fi.length} BOQ · ${s.pct.toFixed(0)}% · ${money(s.amt)}</div></div><div class="lf-acts"><input class="input" style="min-height:34px;width:200px" placeholder="🔎 Search room…" oninput="const q=this.value.trim().toLowerCase();document.querySelectorAll('.lf-room').forEach(n=>n.style.display=!q||n.dataset.t.includes(q)?'':'none')"><select class="select" style="min-height:34px" onchange="const v=this.value;document.querySelectorAll('.lf-room').forEach(n=>n.style.display=!v||n.querySelector('.lf-st').classList.contains(v)?'':'none')"><option value="">Filter: All</option><option value="ns">Not Started</option><option value="ip">In Progress</option><option value="pe">Pending</option><option value="co">Completed</option></select><button class="btn" type="button" onclick="pbLocTpl()">Room Template</button><button class="btn primary" type="button" onclick="pbLocAdd('r')">+ Add Room</button><button class="btn" type="button" style="color:#d84149!important;border-color:#f3c2c5!important" onclick='pbLocDel("f",${J(F.name)},"")'>Delete Floor</button></div></div>
    ${roomGrid(pid,B.name,F.name,rooms,items)}</div>`;
  }
  const orig=window.projectLocationSection;
  window.projectLocationSection=function(pid){
    if(nav.pid!==pid){nav.pid=pid;nav.b='';nav.f='';nav.tab='floors'}
    const L=blds(pid),boq=boqOf(pid);
    const selB=(typeof projectBuildingSel!=='undefined'&&projectBuildingSel&&projectBuildingSel!=='__general')?projectBuildingSel:'';
    if(selB&&!nav.b)nav.b=selB;
    if(nav.b&&!L.some(B=>B.name===nav.b)){nav.b='';nav.f=''}
    if(!nav.b&&L.length)nav.b=L[0].name;
    const B=L.find(x=>x.name===nav.b),F=B&&nav.f?(B.floors||[]).find(x=>x.name===nav.f):null;if(!F)nav.f='';
    const main=!B?'<div class="lf-card"><div class="empty">Add your first building with “+ Add Building”.</div></div>':F?floorView(pid,B,F,boq):buildingView(pid,B,boq);
    return `<div class="lf"><div class="lf-top"><div><h2>Locations &amp; Allocation</h2><p class="muted">Manage buildings, floors, rooms and area allocation</p></div><div class="lf-acts"><button class="btn primary" type="button" onclick="pbLocAdd('b')">+ Add Building</button><button class="btn" type="button" onclick="pbLocBulk()">Bulk Add</button></div></div>
    ${crumbs()}<div class="lf-body">${tree(pid,L,boq)}<div class="lf-main">${main}</div></div>
    <details class="lf-old"><summary>Manage list (details, remove, add BOQ by location)</summary>${orig(pid)}</details></div>`;
  };
  const css=document.createElement('style');css.textContent=`
.lf{--lf-b:#1d63d8;--lf-bd:#e3e8ef;color:#172337;background:#f6f8fb;border-radius:14px;padding:16px;margin:-4px}.lf h2,.lf h3,.lf b{color:#172337}.lf .input,.lf .select{background:#fff!important;color:#172337!important;border:1px solid var(--lf-bd)!important}.lf .btn:not(.primary){background:#fff!important;color:#1d63d8!important;border:1px solid #bcd2f5!important}.lf .lf-tabs button.on,.lf .btn.primary{color:#fff!important}.lf-bhead .lf-acts{flex-wrap:nowrap}.lf-old summary,.lf-old{color:#475569}.lf-old>.panel{margin-top:8px}.lf select,.lf input{-webkit-text-fill-color:#172337;opacity:1}.lf .muted{color:#64748b}
.lf-top{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap}.lf-top h2{margin:0;font-size:20px}.lf-top p{margin:2px 0 0;font-size:12px}
.lf-acts{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.lf .btn.primary{background:var(--lf-b);border-color:var(--lf-b);color:#fff}
.lf-crumb{font-size:12px;color:#64748b;margin:10px 0}.lf-crumb a{cursor:pointer;color:#475569}.lf-crumb a:hover{color:var(--lf-b)}.lf-crumb .lf-back{font-weight:800;margin-right:8px}
.lf-body{display:grid;grid-template-columns:300px minmax(0,1fr);gap:14px;align-items:start}
.lf-tree,.lf-card{background:#fff;border:1px solid var(--lf-bd);border-radius:12px;padding:12px}.lf-search{width:100%;min-height:34px;margin-bottom:10px}
.lf-bld{display:flex;align-items:center;gap:10px;width:100%;border:1px solid var(--lf-bd);background:#fff;border-radius:10px;padding:9px;cursor:pointer;text-align:left;color:inherit;margin-bottom:6px}.lf-bld.on{border-color:#bcd2f5;background:#f3f7fe}
.lf-bld i,.lf-fcard i,.lf-room i,.lf-bimg{display:grid;place-items:center;width:36px;height:36px;border-radius:9px;background:#eaf1fd;color:var(--lf-b);flex:none}
.lf-bld span,.lf-fcard span,.lf-room span{flex:1;min-width:0}.lf-bld small,.lf-fcard small{display:block;color:#64748b;font-size:11px}.lf-bld em,.lf-fcard em,.lf-room u{font-style:normal;text-decoration:none;color:#64748b}
.lf-fl{margin:0 0 8px 12px;border-left:2px solid #eef2f7}.lf-fl button{display:flex;justify-content:space-between;width:100%;border:0;background:none;padding:9px 12px;cursor:pointer;color:inherit;font-size:13px;border-radius:8px}.lf-fl button:hover{background:#f6f8fb}.lf-fl button.on{background:#e8f0fd;color:var(--lf-b);font-weight:700}.lf-fl small{color:#64748b}
.lf-bhead{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.lf-bhead>div:nth-child(2){flex:1;min-width:160px}.lf-bhead h3{margin:0;font-size:19px}.lf-bimg{width:58px;height:58px;border-radius:12px}.lf-bimg svg{width:32px;height:32px}.lf-bimg.sm{width:44px;height:44px}
.lf-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:14px 0}.lf-kpi{border:1px solid var(--lf-bd);border-radius:10px;padding:12px;background:#fff}.lf-kpi b{display:block;font-size:20px}.lf-kpi small{color:#64748b;font-size:11px}.lf-kpi.gr{background:#f0fbf4;border-color:#c9ecd6}.lf-kpi.gr b{color:#15803d}
.lf-tabs{display:inline-flex;gap:4px;background:#f1f5f9;border-radius:999px;padding:3px;margin-bottom:12px}.lf-tabs button{border:0;background:none;border-radius:999px;padding:7px 26px;cursor:pointer;color:#334155;font-size:12px}.lf-tabs button.on{background:var(--lf-b);color:#fff;font-weight:700}
.lf-fgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.lf-fcard{display:flex;align-items:center;gap:10px;border:1px solid var(--lf-bd);border-radius:10px;padding:14px;background:#fff;cursor:pointer;text-align:left;color:inherit}.lf-fcard:hover,.lf-room:hover{box-shadow:0 6px 16px #0f172a14}.lf-fcard.on{border:2px solid var(--lf-b)}
.lf-rgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}.lf-room{display:flex;align-items:center;gap:10px;border:1px solid var(--lf-bd);border-radius:10px;padding:10px;background:#fff;cursor:pointer;text-align:left;color:inherit}.lf-room b{display:block;font-size:14px}.lf-room small{display:block;font-size:10px}
.lf-st{display:inline-block;font-style:normal;font-size:10px;font-weight:700;border-radius:999px;padding:2px 8px;margin-top:3px}.lf-st.ns{background:#f1f5f9;color:#475569}.lf-st.ip{background:#dcfce7;color:#15803d}.lf-st.co{background:#dbeafe;color:#1d4ed8}.lf-st.pe{background:#fef3c7;color:#b45309}
.lf-x{opacity:0;color:#d84149!important;padding:2px 6px;border-radius:6px;font-size:12px}.lf-room:hover .lf-x,.lf-fcard:hover .lf-x{opacity:1}.lf-x:hover{background:#fdecee}@media(hover:none){.lf-x{opacity:1}}.lf-bhead .lf-acts{flex-wrap:wrap!important;justify-content:flex-end}.lf-old{margin-top:14px}.lf-old summary{cursor:pointer;font-size:12px;color:#64748b;padding:6px 0}
@media(max-width:1000px){.lf-body{grid-template-columns:1fr}.lf-fgrid,.lf-rgrid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:560px){.lf-kpis,.lf-fgrid,.lf-rgrid{grid-template-columns:1fr 1fr}}`;document.head.appendChild(css);
})();
